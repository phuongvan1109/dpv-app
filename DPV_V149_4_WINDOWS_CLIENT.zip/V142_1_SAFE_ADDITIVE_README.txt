DPV V142.1 — SMART SAFE ADDITIVE
=================================

MỤC TIÊU
- Sửa kiến trúc V142: không sửa các luồng V141.2 đã ổn định.
- V141.2 là STABLE BASE.
- Tính năng mới chỉ nạp bằng 2 file addon riêng:
  app_v142_1_safe_addon.js
  style_v142_1_safe_addon.css
- index.html chỉ thêm đúng 1 link CSS + 1 script JS sau V141.2.

CÁC FILE STABLE GIỮ NGUYÊN BYTE-FOR-BYTE
- app_release_v141.js
- app_v101.js
- bridge/host.jsx
- bridge/host_bundle.jsx
- packer.js
- multipacker.js
- trueshape_v101.js
- desktop-engine_v132.js
- Windows src/VDPRO.cs
- Mac native DPV/DPVServer/DPVDialogBridge và DPVWindow.js

VÌ SAO V142 CŨ CÓ NGUY CƠ LỖI
V142 trước đó đã chèn API/SMART trực tiếp vào app_v101/app_release và sửa host.jsx/host_bundle.jsx.
Điều này làm tính năng mới chia sẻ cùng runtime với các nút Chọn CSV/TXT và + Thêm vị trí AI.
V142.1 bỏ cách đó hoàn toàn và rebase từ V141.2.

2 ĐƯỜNG CHẠY ĐỘC LẬP
1) STABLE V141.2 — giữ nguyên:
   Chọn CSV/TXT
   + Thêm vị trí đang chọn trong AI
   Tự map
   Preview record trong Illustrator
   Khôi phục
   Chạy VDP & xuất PDF record
   Preflight V141
   Async CSV Bridge V141.2
   UUID Work-copy Rebind V140.1

2) SMART SAFE ADD-ON — nút riêng:
   Data Transform: Trim, gộp space, Upper/Lower/Title, Find/Replace, Fallback, Zero Padding
   Mapping Preset SAFE: chỉ áp cột/action/prefix/suffix lên target đang tồn tại; KHÔNG tạo/xóa/đổi UUID target
   Naming Template phần sau Prefix: ví dụ {record:0000}_{ten:title}
   Preview SMART
   Chạy VDP SMART SAFE

SMART SAFE hoạt động bằng cách tạo BẢN SAO record trong RAM, thêm field synthetic rồi gửi vào Bridge V141.2 nguyên bản.
Không patch host Illustrator.

AUTO FIT TEXT
Auto Fit của V142 cũ tạm thời không đưa vào V142.1 SAFE vì muốn làm đúng chức năng đó phải can thiệp host Illustrator.
Sẽ chỉ đưa trở lại khi được tách thành module độc lập/fail-safe; ưu tiên hiện tại là không làm hỏng workflow ổn định.

NGUYÊN TẮC TỪ V142.1 TRỞ ĐI
- Stable base là immutable.
- Không sửa handler cũ để thêm tính năng mới.
- Tính năng mới dùng nút/module riêng.
- Mặc định OFF / không ảnh hưởng output cũ.
- Mỗi bản phải có diff/hash kiểm tra stable base trước khi đóng ZIP.
