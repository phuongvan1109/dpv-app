DPV V147.4 – STANDALONE CREATE TO ILLUSTRATOR SAFE

Root fix: V147 standalone buttons previously only updated UI status and never called Illustrator.
V147.4 routes standalone QR / Code128 AUTO / EAN-13 through the existing stable PreviewVariableData bridge and existing barcode engines.
- selected-object mode: code fits selected placeholder bounds
- artboard mode: creates temporary placeholder centered on active artboard
- batch artboard mode: simple grid using width/height/columns/gap controls
No VDP CSV is required.
