DPV V77 — FIDELITY ARTBOARD + LEGACY UNITS VDP

VẤN ĐỀ V75
V75 vẫn rebuild/copy artwork sang document khác để gộp PDF. Một số file Illustrator có clipping/opacity mask, linked image, live effect, plugin/symbol hoặc cấu trúc layer phức tạp có thể bị thiếu/nhảy khỏi artboard khi duplicate cross-document.

CƠ CHẾ V76
1. VDP scan dùng UUID read-only của PageItem (Illustrator 2024–2026), không ghi Note/Name vào artwork.
2. Nếu file AI đang ở trạng thái Saved, DPV copy nguyên file AI và mở bản copy để chạy batch.
3. Mỗi record được apply trên template rồi duplicate snapshot NGAY TRONG CÙNG document.
4. Snapshot được giữ ẩn trong lúc xuất PDF riêng. Cuối batch template gốc bị xóa, snapshot hiện lại và PDF gộp được save một lần.
5. PDF dùng artboardRange rõ ràng và tắt Preserve Illustrator Editing Capabilities, nên artwork ngoài trang/pasteboard không lọt vào dữ liệu PDF private khi mở lại.

ĐƠN VỊ MM
- V77 KHÔNG ép document mới sang Millimeters; đơn vị document trở về mặc định/original như các bản trước V76.
- Các ô kích thước trong app là mm.
- Illustrator scripting nội bộ vẫn bắt buộc dùng point; DPV quy đổi bằng 1 mm = 2.834645669 pt.
- PDF theo chuẩn PDF lưu kích thước hình học bằng point, nhưng kích thước vật lý trang được xuất đúng theo mm đã nhập. Khi tạo AI mới từ DPV, ruler/document preset là mm.

KHUYẾN NGHỊ
- V76 bắt buộc file nguồn .AI đã Save (Ctrl+S) trước khi chạy batch VDP. Đây là điều kiện để giữ nguyên cấu trúc artwork và UUID.
- Sau khi nâng từ V75 lên V76, hãy chọn lại các đối tượng Variable Data và bấm "Lấy đối tượng đang chọn trong AI" để mapping dùng UUID mới.
- Test 3 record trước, sau đó chạy số lượng lớn.


V77 UNIT ROLLBACK
- Đã trả cách tạo document về app.documents.add(...) như bản cũ.
- Không đổi hệ tính toán dàn/bleed/PON; vẫn dùng point nội bộ và quy đổi mm ở nơi cần thiết như trước.
