DPV V139 PRO EXPERIENCE — STABILITY FIRST

MỚI
1. PRE-FLIGHT: kiểm tra kết nối, nguồn, khổ/lề/gap, layout, output, PON/CATTP, Duplex và VDP trước khi xuất.
2. PRESET THẬT: lưu/áp dụng thông số dàn bằng localStorage; không lưu đường dẫn file để tránh nhầm job.
3. JOB CENTER: ghi nhẹ lịch sử Tính nhanh / Preview / Build / VDP / Combine. Không can thiệp artwork.
4. CTRL+K COMMAND PALETTE: tìm và chạy nhanh chức năng.
5. SYSTEM / DIAGNOSTICS: trạng thái app, nguồn, layout, output, VDP, viewport.
6. UI PERFORMANCE: Nhanh / Cân bằng / Đẹp. Chỉ thay hiệu ứng giao diện, không thay chất lượng hay engine dàn.

LƯU Ý
- Không chuyển Windows sang WebView2 trong bản này vì đây là thay đổi native shell lớn, có nguy cơ làm mất ổn định Bridge/file dialog. V139 ưu tiên nâng UX theo lớp không phá Core.
- Bridge V138 được giữ nguyên vì V139 không thay bất kỳ lệnh Illustrator nào.
