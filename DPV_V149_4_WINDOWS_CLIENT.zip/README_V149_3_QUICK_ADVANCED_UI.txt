DPV V149.3 — QUICK / ADVANCED UI + ACCORDION

Mục tiêu: giảm độ rối giao diện nhưng không xóa chức năng.

QUICK MODE
- Giữ các thao tác chính: nguồn, artboard, khổ, khe, đầu ra, tính nhanh, dàn file.
- Các thiết lập nâng cao vẫn giữ nguyên giá trị ở nền và không bị reset.

ADVANCED MODE
- Hiển thị toàn bộ thông số như V149.2.

ACCORDION
- Mỗi cột có nút +/- để thu gọn/mở rộng.
- Trạng thái được lưu local để lần sau mở app vẫn giữ cách bố trí.

Tương thích: Windows x64 + macOS Intel.
