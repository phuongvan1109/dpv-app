DPV® V111 — COMPLETE BRAND + COCOA PON FIX + CORE V101 STABLE

- Icon mới dùng đúng artwork DPV do người dùng cung cấp.
- Đồng bộ PNG 16/32/48/64/128/256/512/1024, Windows ICO, macOS ICNS.
- Windows: icon DPV.exe, cửa sổ, taskbar và shortcut Desktop dùng icon mới.
- macOS Intel: Finder, Dock và DPV.app dùng DPV-v111.icns để tránh cache icon cũ.
- Giao diện: favicon, sidebar/logo và splash loading dùng cùng icon mới.
- Giữ Cocoa NSOpenPanel PON Fix của V109 trên Mac.
- Không thay đổi Core V101 STABLE / thuật toán dàn.
