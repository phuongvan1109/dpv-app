DPV V147.7.8 – REMOTE FONT SEARCH + EXACT TEXT GAP SAFE

Fixes two issues from V147.7.7:
1) The app no longer transfers a giant full font list. Font search is performed inside Illustrator across ALL app.textFonts and only matching results are returned. This bypasses old ~2000-result bridge/UI limits.
2) Barcode text gap is locale-safe (0,5 = 0.5) and is interpreted as the actual vertical gap between the normal barcode bars and the top of human-readable text for Code128 and EAN-13.

Mac + Windows. Stable Core/VDP/layout modules are unchanged.
