DPV V147.7.6 – BRIDGE VERSION LOCK + STANDALONE SAFE

Root fix for repeated “Load failed”:
- Native Mac/Windows bridge expected a different VDPRO_BRIDGE_VERSION than host_bundle.jsx.
- That forced the entire ~474KB host to reload on every Illustrator command.
- Re-evaluating the cumulative V146/V147 wrappers repeatedly could stack wrappers and fail on later Standalone create calls.

V147.7.6 locks the host version to the version expected by each native bridge:
- Mac Intel: 0.1.20-v88-mac-intel-v87-core
- Windows: 0.1.20-v138-no-stroke-fidelity

It also creates new Standalone button IDs and sends through DPVVDP101.bridgeCall only, so old V147 capture listeners cannot intercept.
