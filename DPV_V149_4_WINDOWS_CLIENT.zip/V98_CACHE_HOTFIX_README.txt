DPV V98 — CACHE HOTFIX

Sửa lỗi V97: biến cachedV96 còn sót trong bridge sau khi đổi tên cache sang cachedV97.
Lỗi này làm nút Đối chiếu / Mở xem trước khuôn / Dàn Link báo: cachedV96 is undefined.
V98 thay toàn bộ tham chiếu sai bằng cachedV97 trên cả host.jsx và host_bundle.jsx, Windows và Mac Intel.
Không thay đổi thuật toán AUTO MAX / Exact Gap của V97.
