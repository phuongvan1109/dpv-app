DPV V93 — EXACT GAP 2 TRỤC

Mục tiêu: Gap ngang 2mm và Gap dọc 2mm phải bám contour KHUON_BE thật cả khi khuôn có góc lõm Bézier và xoay 90/180/270.

Nguyên nhân V83–V92: polygon collision của đường cong chỉ lấy 4–8 mẫu/segment. Với góc lõm, chord xấp xỉ lấn vào phần rỗng nên bộ dàn giữ thừa khoảng cách, có thể thấy 2.2–2.4mm dù nhập 2mm.

V93 dùng sampling control-polygon ~0.9mm/mẫu (8–28 mẫu/segment), geometricBounds thật cho bbox cardinal và giữ safety chỉ 0.002mm.

Sau khi cài V93, hãy LẤY LẠI FILE ĐANG MỞ / LẤY KHUÔN ĐANG CHỌN để DPV đọc lại contour độ chính xác V93.
