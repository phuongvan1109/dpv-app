DPV V148.9 - OUTPUT MODE + CUSTOM NUMBER START

1) Đầu ra khi dàn:
- FILE IN + KHUÔN BẾ (như trước).
- Chỉ FILE IN (không tạo PDF KHUÔN BẾ).

2) STT tên file tùy chọn:
- Để trống: giữ cách đánh số tự động hiện tại.
- STT FILE IN bắt đầu = 1.12 -> 1.12, 1.13, 1.14...
- STT KHUÔN bắt đầu = 2.10 -> 2.10, 2.11, 2.12...
- Có thể nhập có khoảng trắng như 1. 12; DPV tự chuẩn hóa thành 1.12.
- Hỗ trợ số bắt đầu đơn như 12 -> 12, 13, 14...

3) Multi Artboard:
- FILE IN tăng STT liên tục theo từng artboard được xuất.
- KHUÔN BẾ tăng STT theo từng nhóm kích thước/khuôn.

4) Quy tắc an toàn:
- PON cắt thành phẩm và In 2 mặt AB tự chuyển sang Chỉ FILE IN vì các chế độ này vốn không xuất khuôn riêng.
- Khi chọn Chỉ FILE IN, ô STT KHUÔN bị vô hiệu hóa để tránh nhầm.

Giữ nguyên License, Google Login, Auto Update, Multi Artboard, VDP và Core V101.
