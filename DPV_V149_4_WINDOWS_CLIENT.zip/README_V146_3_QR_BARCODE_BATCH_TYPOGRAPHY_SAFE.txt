DPV V146.3 – QR/BARCODE BATCH + TYPOGRAPHY SAFE

This package is built from V146.2 stable base.
Additions:
- batch-run readiness for qrVector / code128Vector / ean13Vector
- barcode typography UI for Code128 and EAN-13 (font, size, tracking, text gap, bar height, quiet zone)
- additive-only loaders in index.html
No stable-base core modules were intentionally replaced.
