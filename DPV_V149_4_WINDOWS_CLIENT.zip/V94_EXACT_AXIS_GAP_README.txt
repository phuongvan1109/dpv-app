DPV® Desktop Beta 0.1.20 — V94 EXACT AXIS GAP + MODERN UI

V94 GAP FIX
- Sửa định nghĩa khe KHUÔN ĐẶC BIỆT: gap ngang/dọc được giải theo đúng trục X/Y.
- Không còn dùng khoảng cách Euclid ở góc cong để quyết định pitch của hàng/cột.
- Tìm tiếp xúc polygon theo hướng dịch, sau đó cộng đúng gapX/gapY.
- gapX=2mm, gapY=2mm -> mục tiêu khe thẳng thực tế 2.000mm ở cả ngang và dọc.
- Giữ xoay 0/90/180/270 và dàn so le KHUÔN ĐẶC BIỆT.
- Áp dụng đồng nhất Windows + Mac Intel.

Sau khi cài V94: lấy lại file/khuôn đang chọn để DPV đọc lại contour rồi Tính nhanh lại.
