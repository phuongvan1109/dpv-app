DPV V86 — INTERNAL PDF COMBINE

KHÔNG CẦN ADOBE ACROBAT.

Cách 1 - tự động sau VDP:
1. Bật "Xuất PDF riêng từng record".
2. Bật "Sau khi xuất PDF riêng → DPV tự Combine thành 1 PDF".
3. DPV xuất record 1..N trước, sau đó Combine các PDF đã render thành PDF nhiều trang.

Cách 2 - PDF có sẵn:
- Bấm "Combine các PDF có sẵn trực tiếp trong DPV".
- Chọn nhiều PDF. DPV sắp xếp tên file theo số tự nhiên (1,2,3...10,11...) rồi gộp.
- Chế độ thủ công mặc định mỗi file PDF được xem là 1 trang.

Engine Combine:
- Không copy artwork gốc.
- Mỗi page PDF được Place dạng link vào 1 artboard.
- Save PDF nhiều trang một lần ở cuối.
- PDF record gốc không bị xóa.
