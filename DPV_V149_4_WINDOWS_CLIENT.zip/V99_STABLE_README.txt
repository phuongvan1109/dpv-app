DPV® Desktop Beta 0.1.20 — V99 STABLE CACHE / AUTO MAX EXACT GAP
Build 2026-09-05

V99 STABILITY FIX
- Sửa lỗi nghiêm trọng: UI V97/V98 lưu layout vào precomputedLayoutV96 nhưng Bridge lại đọc precomputedLayoutV97, khiến Illustrator bỏ cache và chạy lại solver True-Shape nặng -> treo/Not Responding.
- V99 dùng precomputedLayoutV99 thống nhất Windows + Mac Intel.
- Khi layout cache thiếu hoặc sai, Illustrator DỪNG NGAY và báo bấm Tính nhanh lại; không tự chạy solver nặng trong Illustrator.
- Sửa biến simpleFastV96 bị sót tên thành simpleFastV97 trong nhánh tạo Link.
- Cache-bust app_v99.js / desktop-engine_v99.js / trueshape_v99.js.
- Giữ AUTO MAX Exact Gap, Preview/Build Low-Lag, Preserve Links, Demi, PON, VDP Stream Low-RAM và Combine PDF.

Cách test: Lấy file đang mở -> Tính nhanh -> Mở xem trước khuôn -> Dàn Link. Nếu thay bất kỳ thông số nào, V99 sẽ tự tính cache mới trước khi gọi Illustrator.
