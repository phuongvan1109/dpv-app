DPV V112 — STARTUP SAFE / CORE V101 STABLE

MUC TIEU
- Sua truong hop cai dat xong DPV khong mo duoc.
- Windows: loi icon/branding khong con duoc phep lam crash constructor; startup exception duoc ghi vao %LOCALAPPDATA%\DPV\startup.log.
- Mac Intel: bo preflight bat buoc Illustrator truoc khi hien cua so; DPV mo doc lap, Illustrator co the ket noi sau.
- Splash V111 co failsafe tu an de khong che giao dien neu JavaScript tai cham.
- Giu nguyen Core V101 STABLE va Cocoa PON Fix.
