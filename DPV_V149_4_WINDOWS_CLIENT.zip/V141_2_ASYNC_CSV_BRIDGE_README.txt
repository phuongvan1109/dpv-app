DPV® V141.2
Windows: chức năng sản xuất giữ nguyên V141.1/V141; chỉ đồng bộ version package.
Mac Intel: V141.2 thêm Async CSV Token Bridge để sửa lỗi WKWebView "Load failed" khi chọn CSV/TXT.
Core V101 và engine dàn không thay đổi.
