DPV V126 — DUPLEX MIRROR FIX

Fix mặt B trong chế độ A/B:
- Với AB bù góc, vị trí mặt B được phản ngang theo khổ dàn.
- A1 bên trái -> B1 bên phải; A cuối bên phải -> B tương ứng bên trái.
- Y giữ nguyên.
- Góc vẫn bù đúng: 0->0, 90->270, 270->90.
- Áp dụng chung cho Dàn file và VDP Sheet vì dùng cùng ANP_duplexLayoutV60.
- Không thay thuật toán V101 về số con, gap, lề, True-Shape, PON.
