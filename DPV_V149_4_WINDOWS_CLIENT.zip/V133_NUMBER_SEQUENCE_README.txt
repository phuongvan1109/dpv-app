DPV V133 — NUMBER SEQUENCE

MỚI TRONG VARIABLE DATA
- Có 2 nguồn dữ liệu: CSV/TXT hoặc Dãy số tự động.
- Dãy số: Bắt đầu / Kết thúc / Bước nhảy.
- Tự đảo chiều nếu Bắt đầu > Kết thúc.
- Tuỳ chọn thêm số 0 phía trước với độ dài cố định.
- Tiền tố / hậu tố.
- Tên cột map tuỳ chỉnh, mặc định SO_NHAY.
- Dùng được Preview, PDF từng record và VDP Sheet trực tiếp lên khổ in.
- Không thay Core V101, Mixed Rotation Safe V132, PON, CATTP, Duplex A/B, Bleed, Combine.

Ví dụ:
Start=1, End=500, Step=1, Zero=ON, Width=4 => 0001 ... 0500
Prefix=SP-, Suffix=-A => SP-0001-A ... SP-0500-A

Giới hạn an toàn: 50.000 record mỗi lần tạo.
