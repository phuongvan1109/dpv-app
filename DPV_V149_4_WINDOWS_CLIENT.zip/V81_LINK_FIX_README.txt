V81 — SỬA MẤT LINK FILE DÀN
- Nguyên nhân V76–V80: hàm PDF dùng chung bị đặt preserveEditability=false để phục vụ VDP. Điều này vô tình tác động cả FILE DÀN chính.
- V81 tách policy: FILE DÀN dùng preserveEditability=true như V71; VDP vẫn dùng ANP_savePDFRangeV76 riêng với preserveEditability=false.
- Khi mở PDF FILE DÀN lại trong Illustrator, các PlacedItem link sẽ còn trong Links panel nếu file nguồn link vẫn tồn tại.
