DPV V135 HYBRID DATA

VDP có 3 nguồn dữ liệu:
1. CSV / TXT
2. Dãy số tự động
3. CSV + Dãy số

Chế độ CSV + Dãy số giữ nguyên toàn bộ cột CSV/TXT và thêm một cột số tự động (mặc định SO_NHAY).
Mỗi record CSV nhận đúng một số theo Start + Step. Số lượng dãy tự khớp số record CSV để không lệch tên/địa chỉ.

Ví dụ CSV có 111 record, Start=1, Step=1, Zero Pad=4:
record 1 -> SO_NHAY=0001
record 2 -> SO_NHAY=0002
...
record 111 -> SO_NHAY=0111

Có thể map TEN vào TextFrame 1, DIA_CHI vào TextFrame 2 và SO_NHAY vào TextFrame 3 trong cùng một record/tờ dàn.
Không sửa Core V101 / Mixed Rotation Safe V132 / PON / VDP Sheet / Duplex.
