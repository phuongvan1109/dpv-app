DPV V118 IE TABLE FIX
- Fix lỗi 3 cột co thành các dải rất hẹp khi maximize/restore trên Windows.
- Windows desktop rộng dùng CSS table-layout thay vì flex cho 3 cột chính.
- Cửa sổ/DPI không đủ rộng tự xếp dọc + một vùng scroll, không cắt nội dung.
- Topbar tự giảm nội dung phụ trước khi tràn.
- Không thay Core V101, PON, VDP, True-Shape, Exact Gap hoặc Illustrator Bridge.
