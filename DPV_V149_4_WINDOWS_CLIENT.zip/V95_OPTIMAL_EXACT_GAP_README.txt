DPV® Desktop Beta 0.1.20 — V95 OPTIMAL EXACT GAP + MODERN UI

V95 GAP ENGINE REWRITE
- Sửa lỗi V94: bật khe chính xác làm giảm số con do chỉ lấy biên va chạm ngoài cùng.
- Solver mới MULTI-CONTACT quét mọi vùng tiếp xúc của khuôn lõm, kể cả vị trí khóa đầu-đuôi nằm sâu trong lõm.
- Tối ưu số con trước trên nhiều cặp xoay 0/90/180/270 và 8 pha so le, sau đó giữ khe X/Y đúng giá trị nhập.
- Khe ngang và dọc được giải độc lập; gapX=2, gapY=2 không dùng max() để đổi pitch.
- Bézier contour dùng adaptive flatten tolerance ~0.018 mm thay vì sample thô, giảm sai số ở bo cong.
- Giữ KHUÔN ĐẶC BIỆT xoay, True-Shape, Demi, Preserve Links, VDP, Combine PDF.
- Đồng bộ Windows + Mac Intel.

Sau khi cài: lấy lại file/khuôn để đọc contour V95, rồi Tính nhanh và Dàn Link lại.
