DPV V147.8 – VDP TEXT TRACKING SAFE

Built from V147.7.9.
Adds an optional Tracking control to each Variable Data Text mapping.
- blank = preserve tracking from original Illustrator layout
- numeric value = override tracking for that mapping
- Illustrator tracking units (1/1000 em)
- supported in Preview / record export / VDP Sheet through the common Text apply engine
Other actions and production layout logic are unchanged.
