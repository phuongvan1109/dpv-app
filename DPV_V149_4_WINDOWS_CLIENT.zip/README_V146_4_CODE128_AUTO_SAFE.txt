DPV V146.4 – CODE128 AUTO A/B/C SAFE

Built from V146.3.3 stable base.
This additive patch upgrades action code128Vector to AUTO subset selection similar to Barcode Studio:
- numeric even-length strings prefer Code128-C
- mixed strings can switch B/C automatically
- QR and EAN-13 remain unchanged
- barcode typography settings remain supported
