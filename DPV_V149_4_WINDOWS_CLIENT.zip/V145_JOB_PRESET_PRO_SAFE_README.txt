DPV V145 — JOB PRESET PRO SAFE
==============================
Stable Base: DPV V144 Production Planner Safe / Core V101

MỤC TIÊU
- Thêm Job Preset Pro vào Thư viện preset hiện có.
- Không thay preset dàn legacy của DPV.
- Không sửa Core V101, Bridge, VDP, Cut & Stack, Duplex, Recovery hoặc Production Planner.

JOB PRESET PRO LƯU
1) Layout: khổ, lề, header, gap, max qty, bleed, rotate, exact/uniform gap, True Shape, Stagger, Fast, title, Corner Safe, Demi...
2) Finishing: Auto PON, Fit PON, Process K100, khuôn stroke/link, PON đỏ, CATTP và kích thước dấu cắt.
3) Duplex: bật/tắt 2 mặt + hướng mặt B hiện tại.
4) Production Planner V144: số lượng, hao hụt, giá/tờ, chi phí in, chi phí cố định.
5) VDP output settings an toàn: prefix/tên PDF, Combine, Sheet order/last-sheet settings nếu các control đang tồn tại.

KHÔNG BAO GIỜ LƯU
- File nguồn Illustrator/PDF
- CSV/TXT
- Đường dẫn file PON
- Thư mục output
- UUID / target mapping Illustrator

Mapping VDP vẫn dùng Mapping Preset SAFE V142.1 riêng để tránh gán nhầm object.

TÍNH NĂNG
- Tối đa 30 Job Preset Pro.
- Ghim ★ preset quan trọng.
- Áp dụng 1 click; sau đó DPV tự Tính nhanh, KHÔNG tự Build Illustrator.
- Copy JSON / Nhập JSON để chuyển preset sang máy khác mà không dùng native file dialog.
- Khi VDP chưa mở lúc áp dụng, các thiết lập VDP được giữ pending và áp dụng sau khi người dùng bấm mở VDP.

KIẾN TRÚC SAFE
So với V144, runtime cũ chỉ thay index.html để load đúng 1 CSS + 1 JS mới.
Các file runtime V144 còn lại giữ byte-for-byte.
