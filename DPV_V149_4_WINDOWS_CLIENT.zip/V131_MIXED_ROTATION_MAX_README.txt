DPV V131 MIXED ROTATION MAX

Mục tiêu:
- Exact Gap vẫn đúng theo Gap ngang / dọc.
- Tự thử lưới thẳng 0°, lưới thẳng 90° và mọi tổ hợp hàng/cột trộn 0°/90°.
- Ưu tiên tuyệt đối số con tối đa.
- Nếu bố cục trộn KHÔNG tăng số con, giữ lưới thẳng để dễ sản xuất.
- Lề vẫn là hard limit V101.
- Không thay PON, CATTP, VDP, Duplex A/B, AI Stay Open, QR UI, Manual Preview.

Case kiểm chứng:
Tem 219x30 mm · khổ 320x390 · lề 8 · gap 2/2:
- Solver cũ Exact Gap: 11 con.
- V131 Mixed Rotation Max: 13 con (4 hàng ngang + 1 hàng xoay chứa 9 con).
