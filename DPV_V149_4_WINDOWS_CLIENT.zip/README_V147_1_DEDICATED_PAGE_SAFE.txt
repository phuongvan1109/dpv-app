DPV V147.1 – QR/BARCODE STUDIO DEDICATED PAGE SAFE

Built directly from V147 stable package.
UI-only additive change:
- moves existing QR/Barcode Standalone Studio out of Dàn file page
- opens it in a dedicated full-screen page like Variable Data
- adds QR / Barcode Studio to left sidebar
- adds close button + Escape support
- existing V147 form and handlers are moved, not rewritten
- no Core, Bridge, QR/Barcode engine, VDP, Cut & Stack or Duplex file is modified
