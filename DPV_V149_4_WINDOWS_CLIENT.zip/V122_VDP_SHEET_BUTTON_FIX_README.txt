DPV V122 — VDP SHEET BUTTON FIX

Nguyên nhân V121:
- app_v114.js tạo nút vdpSheetBuildBtn rồi gán newBtn.onclick=buildSheet.
- buildSheet không tồn tại trong file này, gây ReferenceError ngay trong makeUI().
- Nút vẫn hiện trên màn hình nhưng start() dừng trước bindBuildFix(), nên bấm không có tác dụng.

V122:
- Xóa binding tới hàm buildSheet không tồn tại.
- bindBuildFix() được chạy hoàn chỉnh.
- Thêm lớp app_v122.js tự kiểm tra và gắn lại handler cho nút Dàn & xuất.
- Hiển thị trạng thái khi bắt đầu, progress, lỗi Illustrator và hoàn tất.
- Không thay Core V101, layout, PON, Exact Gap, True-Shape hay Bridge JSX.
