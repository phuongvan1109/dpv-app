@echo off
setlocal
cd /d "%~dp0"
call "%~dp0INSTALL.cmd"
exit /b %errorlevel%
