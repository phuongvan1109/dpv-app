DPV V138 NO-STROKE FIDELITY

FIX CHÍNH
- Sửa lỗi Dãy số / CSV tự xuất hiện stroke dù TextFrame layout gốc không có stroke.
- Illustrator có thể giữ strokeWeight > 0 ẩn dù strokeColor đang NoColor; V137 áp lại strokeWeight làm stroke đen bật lên.
- V138 lưu trạng thái stroke thật riêng cho từng TextFrame.
- Nếu chữ gốc Stroke=None: ép NoColor + strokeWeight=0 sau khi thay nội dung.
- Nếu chữ gốc thật sự có stroke: vẫn giữ stroke của template.
- Giữ nguyên font, style, size, leading, tracking, scale, paragraph của V137.
- Áp dụng Preview / PDF record / VDP Sheet / Number Sequence / Hybrid Data.
- Core V101, Mixed Rotation, PON, CATTP, Duplex A/B không thay đổi.
