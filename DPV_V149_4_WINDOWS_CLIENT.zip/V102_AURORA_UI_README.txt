DPV V102 AURORA UI — CORE V101 STABLE

MỤC TIÊU
- Thiết kế lại giao diện theo phong cách dashboard hiện đại, sáng/thoáng, sidebar, search, KPI.
- Light / Dark chuyển tức thời và ghi nhớ lựa chọn.
- Windows và Mac Intel dùng chung visual layer.
- TUYỆT ĐỐI KHÔNG thay thuật toán dàn: Core/Bridge vẫn V101 STABLE.

GIAO DIỆN
- Sidebar: Dàn file, Biến đổi dữ liệu, Combine PDF, Preset, Cài đặt.
- Dashboard KPI đồng bộ số con, hiệu suất, trạng thái Illustrator.
- Search Ctrl/Cmd+K để tìm nhanh control.
- Dark mode tối ưu màu vàng + xanh DPV.
- Variable Data được đồng bộ theme.

LƯU Ý
- Thư viện Preset hiện chỉ là entry UI, chưa thêm engine preset để tránh tác động core ổn định.
