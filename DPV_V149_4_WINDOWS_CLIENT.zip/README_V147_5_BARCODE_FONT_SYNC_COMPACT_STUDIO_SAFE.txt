DPV V147.5 – BARCODE FONT SYNC + COMPACT STUDIO SAFE

Built from V147.4 stable base.

Changes:
- QR/Barcode Standalone Studio reads the real font list from Adobe Illustrator app.textFonts.
- Font selector uses Illustrator PostScript font names for reliable output.
- Font size is in pt, matching Illustrator.
- Text-to-barcode gap is adjustable in mm.
- Tracking, Regular/Bold, Live/Outline, bar height, bar width and quiet zone are available under Advanced.
- Compact UI: single/batch input toggles, barcode style hidden for QR, artboard size controls only shown when needed.
- Existing QR, Code128 AUTO, EAN-13, VDP, Cut & Stack, Duplex and Core remain unchanged.
