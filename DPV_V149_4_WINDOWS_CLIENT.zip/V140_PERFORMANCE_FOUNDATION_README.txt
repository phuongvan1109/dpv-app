DPV V140 PERFORMANCE FOUNDATION — STABILITY FIRST

MỤC TIÊU
Tối ưu runtime và thẩm mỹ mà không thay Core V101 hoặc pipeline Illustrator.

THAY ĐỔI
1. RELEASE BUNDLE
- index.html chỉ nạp style_release_v140.css cho toàn bộ UI styles.
- index.html chỉ nạp app_release_v140.js cho toàn bộ lớp app V101→V140.
- Engine packer / multipacker / trueshape V101 / desktop-engine V132 vẫn tách riêng và giữ nguyên.
- Các file source version cũ vẫn nằm nguyên trong app/ui để dễ kiểm tra và rollback.

2. JOB CENTER EVENT-DRIVEN
- Bỏ setInterval monitor mỗi 1.3 giây.
- Theo dõi #status và #vdpStatus bằng MutationObserver; IE11 fallback DOM event.
- Lưu thời lượng từng Job.

3. UI / TYPOGRAPHY
- Tăng font các vùng Pro Center trước đây 8–9px.
- Giữ layout sản xuất chính, không đổi ID/control.
- Settings có nút Nâng cao để giảm mật độ giao diện; có thể mở lại ngay.

4. PREVIEW
- Thêm viewer lớn cho canvas bố cục với Zoom / Refresh.
- Viewer chỉ copy canvas hiện tại, không tính lại hoặc thay layout.

5. RUNTIME DIAGNOSTICS
- Hiển thị số CSS/JS request thực tế, DOMContentLoaded, Job Monitor EVENT.

AN TOÀN
- Không thay Core V101.
- Không thay app_v136/v137/v138 text fidelity logic.
- Không thay bridge/host.jsx, PON, CATTP, Duplex, VDP mapping, PDF export.
- Preset/history V139 tiếp tục được dùng trong V140.
