DPV V142.2 — CUT & STACK SAFE ADDITIVE

MỤC TIÊU
- Thêm chế độ gán record để sau khi in → gom tờ → cắt → chồng từng xấp VT1 → VT2 → VT3… thì thành phẩm đúng thứ tự liên tục.
- Không sửa nút dàn VDP Sheet cũ, không sửa Bridge, Core V101, UUID mapping hay host.jsx.

VÍ DỤ 20 RECORD / 4 VỊ TRÍ
Tờ 1: VT1=1   VT2=6   VT3=11  VT4=16
Tờ 2: VT1=2   VT2=7   VT3=12  VT4=17
Tờ 3: VT1=3   VT2=8   VT3=13  VT4=18
Tờ 4: VT1=4   VT2=9   VT3=14  VT4=19
Tờ 5: VT1=5   VT2=10  VT3=15  VT4=20
Sau cắt: chồng VT1 → VT2 → VT3 → VT4 = 1 → 20.

TỜ CUỐI THIẾU RECORD
- Cut & Stack luôn để trống các vị trí dư ở cuối.
- Không dùng chế độ dồn giữa vì sẽ phá thứ tự xấp sau cắt.

AN TOÀN
- Stable base: V142.1 / V141.2.
- Chỉ thêm app_v142_2_cut_stack_safe.js + style_v142_2_cut_stack_safe.css và 2 dòng loader trong index.html.
- Nút “Dàn dữ liệu lên khổ in & xuất PDF tờ” cũ vẫn dùng code stable nguyên bản.
