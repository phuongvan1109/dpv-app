DPV V100 BALANCED AUTO MAX

Mục tiêu: nếu nhiều phương án đều đạt số con tối đa và đúng khoảng cách, DPV chọn phương án cân đối nhất thay vì phương án đầu tiên.

Thứ tự ưu tiên:
1. Số con lớn nhất.
2. Khoảng cách Exact Gap X/Y giữ nguyên.
3. Cân tâm các hàng/cột, giảm mép răng cưa lệch một phía.
4. Bounding box gọn hơn nếu độ cân bằng tương đương.

V100 chỉ thay tie-break của solver trên DPV. Bridge Illustrator giữ cache V99 STABLE để giảm rủi ro và tránh lag.
