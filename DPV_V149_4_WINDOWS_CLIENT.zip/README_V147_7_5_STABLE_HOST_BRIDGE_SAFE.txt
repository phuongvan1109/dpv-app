DPV V147.7.5 – STABLE HOST STANDALONE BRIDGE SAFE

Fix for: “Không gửi được lệnh tạo mã: Load failed”.

Root cause: V147.7.4 appended a large direct engine to host.jsx / host_bundle.jsx. The native bridge could fail while loading that host script before Illustrator executed the barcode command.

V147.7.5:
- restores host.jsx and host_bundle.jsx byte-for-byte from V147.7.3 stable host
- disables the V147.7.4 direct-engine UI ownership
- returns standalone QR/Code128/EAN-13 to the proven standaloneV1474 host path
- retains the current compact font picker/cache UI
- changes no Core V101 / layout / VDP / Cut & Stack / Duplex logic
