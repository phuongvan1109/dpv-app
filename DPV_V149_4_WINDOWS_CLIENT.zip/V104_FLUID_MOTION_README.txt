DPV V104 — FLUID MOTION UI

CORE: V101 STABLE (không sửa engine dàn)
BASE UI: V103 LIVE PREVIEW

Nâng cấp giao diện:
- Chuyển cảnh khởi động mềm, card reveal theo nhịp.
- Sidebar hover/active motion.
- Button press + ripple phản hồi tức thì.
- Light/Dark chuyển màu mềm.
- KPI/số con pulse nhẹ khi cập nhật.
- VDP modal và Settings mở theo spring-like motion.
- Progress/status chuyển động mượt.
- Live Preview zoom/pan giữ nguyên V103.
- Tôn trọng Reduce Motion của hệ điều hành.

Không thay thuật toán Exact Gap, lề, so le, True-Shape, Demi, PON, VDP hoặc Bridge của V101.
