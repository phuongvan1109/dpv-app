DPV V141 PREFLIGHT PRO

Xem V141_PREFLIGHT_PRO_README.txt để biết chức năng mới.
V140.1 Work-Copy Hotfix và Core V101 vẫn giữ nguyên.

DPV V140 PERFORMANCE FOUNDATION
Preflight + Preset + Job Center + Ctrl+K Command Palette + Diagnostics + UI Performance. Core V101 và Bridge Illustrator giữ nguyên để ưu tiên ổn định.

DPV V117 STABLE RESIZE · CORE V101 STABLE

DPV V95 OPTIMAL EXACT GAP
DPV V94 EXACT AXIS GAP
DPV V87 — DEMI RESTORE + CACHE SAFE
Xem V87_DEMI_FIX_README.txt.

DPV V86 — INTERNAL PDF COMBINE KHÔNG CẦN ACROBAT
- Xuất PDF record trước rồi DPV tự Combine trực tiếp.
- Có nút Combine các PDF có sẵn.
- Không cần cài Acrobat.

DPV V85 — ACROBAT POST-COMBINE

CÁCH KHUYẾN NGHỊ CHO 100+ RECORD
1. Bật “Xuất PDF riêng từng record”.
2. Nếu muốn 1 file nhiều trang, bật “Sau khi xuất PDF riêng → Combine bằng Adobe Acrobat”.
3. DPV render từng record trong Illustrator như V79/V80 Stream Low-RAM.
4. Sau khi record cuối hoàn tất, Illustrator không dựng document merge. Desktop Bridge gọi Adobe Acrobat để gộp PDF theo đúng thứ tự record.
5. Các PDF record vẫn được giữ lại để kiểm tra hoặc chạy lại Combine.

NÚT COMBINE PDF CÓ SẴN
- Bấm “Combine các PDF có sẵn bằng Acrobat”.
- Chọn nhiều PDF.
- Chọn tên file đích.
- DPV dùng Acrobat PDDoc InsertPages, không mở/dàn artwork trong Illustrator.

LƯU Ý
- Cần Adobe Acrobat Standard/Pro. Reader chỉ đọc PDF và không hỗ trợ chức năng chỉnh sửa/gộp này qua COM.
- Nếu Acrobat không có, phần xuất PDF record vẫn hoàn tất; Combine sẽ báo lỗi riêng.


DPV V84 — TRUE MULTIPAGE VDP

SỬA QUAN TRỌNG:
- Chọn record 1 đến 3 + bật “Gộp nhanh tất cả record vào 1 PDF nhiều trang” => PDF gộp phải có đúng 3 trang nếu file nguồn có 1 artboard.
- Nếu file nguồn có N artboard thì tổng trang = số record × N artboard.
- V84 bắt buộc bật saveMultipleArtboards cho PDF nhiều artboard, thay vì chỉ đặt artboardRange như V83.

DPV V83 — KHUÔN ĐẶC BIỆT XOAY + KHOẢNG CÁCH ĐỀU

Cách dùng:
1. Bật Cho phép xoay 90°/nhiều góc.
2. Bật Khoảng cách đều chính xác – kể cả khuôn đặc biệt xoay.
3. Bật True-Shape theo KHUON_BE.
4. Bật Khuôn đặc biệt – dàn so le nhanh.
5. Nhập Gap ngang/dọc. Với khuôn xoay, V83 dùng giá trị lớn hơn làm khoảng cách an toàn chung trên contour.

Khác V82:
- V82 buộc tắt Khuôn đặc biệt khi bật Khoảng cách đều.
- V83 cho phép hai chế độ chạy cùng lúc. Khuôn vẫn xoay đầu–đuôi/90°/270° nhưng khoảng cách contour được giữ theo gap.
- Lưới một hướng chỉ áp dụng khi không bật Khuôn đặc biệt hoặc không có shape KHUON_BE thật.


DPV V82 — KHOẢNG CÁCH DÀN ĐỀU TUYỆT ĐỐI

Vấn đề V81:
- Chế độ tối ưu số con có thể trộn cùng lúc mẫu 0° và 90°.
- Ví dụ tem 42x75 có thể dùng các cột 42x75 xen một cột 75x42 để tăng số con.
- Gap trong từng hàng/cột vẫn đúng, nhưng tại chỗ giao giữa hai hướng sẽ tạo khoảng trống lớn/nhỏ khác nhau, nhìn như khoảng cách không đều.

V82:
- Mặc định bật "Khoảng cách đều tuyệt đối – lưới 1 hướng".
- DPV thử cả 0° và 90°, sau đó dùng DUY NHẤT một hướng cho toàn tờ.
- Khoảng cách ngang = gapX; khoảng cách dọc = gapY.
- FILE IN và FILE KHUÔN dùng chung một layout nên trùng nhau.
- Nếu muốn ưu tiên số con tối đa như trước, bỏ chọn chế độ này rồi bật True-Shape/so-le.

Lưu ý: lưới đều có thể giảm số con/tờ. Ví dụ một bài trước đây đạt 27–28 con nhờ trộn hướng có thể còn khoảng 24 con khi khóa lưới đều. Đây là đánh đổi để khe dàn đều và dễ kiểm soát bế/cắt hơn.


DPV V79 — STREAM LOW-RAM

Mục tiêu: sửa tình trạng Illustrator trắng/Not Responding và quá chậm của V78 khi chỉ vài record.

Cơ chế mới:
1. Clone nguyên file AI đúng 1 lần.
2. Mỗi record chỉ restore/apply dữ liệu rồi Save PDF đúng artboard gốc.
3. Không duplicate toàn bộ artwork cho từng record.
4. PDF gộp được dựng bằng các trang PDF link trong một document merge nhẹ.
5. Mỗi record chạy thành một lượt JSX riêng, Illustrator có thời gian nhận event giữa các record.

Khuyến nghị: test 3 record trước, sau đó tăng lên 50/100+.


DPV V77 — FIDELITY ARTBOARD + LEGACY UNITS VDP

VẤN ĐỀ V75
V75 vẫn rebuild/copy artwork sang document khác để gộp PDF. Một số file Illustrator có clipping/opacity mask, linked image, live effect, plugin/symbol hoặc cấu trúc layer phức tạp có thể bị thiếu/nhảy khỏi artboard khi duplicate cross-document.

CƠ CHẾ V76
1. VDP scan dùng UUID read-only của PageItem (Illustrator 2024–2026), không ghi Note/Name vào artwork.
2. Nếu file AI đang ở trạng thái Saved, DPV copy nguyên file AI và mở bản copy để chạy batch.
3. Mỗi record được apply trên template rồi duplicate snapshot NGAY TRONG CÙNG document.
4. Snapshot được giữ ẩn trong lúc xuất PDF riêng. Cuối batch template gốc bị xóa, snapshot hiện lại và PDF gộp được save một lần.
5. PDF dùng artboardRange rõ ràng và tắt Preserve Illustrator Editing Capabilities, nên artwork ngoài trang/pasteboard không lọt vào dữ liệu PDF private khi mở lại.

ĐƠN VỊ MM
- V77 KHÔNG ép document mới sang Millimeters; đơn vị document trở về mặc định/original như các bản trước V76.
- Các ô kích thước trong app là mm.
- Illustrator scripting nội bộ vẫn bắt buộc dùng point; DPV quy đổi bằng 1 mm = 2.834645669 pt.
- PDF theo chuẩn PDF lưu kích thước hình học bằng point, nhưng kích thước vật lý trang được xuất đúng theo mm đã nhập. Khi tạo AI mới từ DPV, ruler/document preset là mm.

KHUYẾN NGHỊ
- V76 bắt buộc file nguồn .AI đã Save (Ctrl+S) trước khi chạy batch VDP. Đây là điều kiện để giữ nguyên cấu trúc artwork và UUID.
- Sau khi nâng từ V75 lên V76, hãy chọn lại các đối tượng Variable Data và bấm "Lấy đối tượng đang chọn trong AI" để mapping dùng UUID mới.
- Test 3 record trước, sau đó chạy số lượng lớn.


DPV V75 — EXACT ARTBOARD FAST VARIABLE DATA / COMBINED PDF

Bản này tập trung sửa đúng lỗi V74:
1. Artwork/link nhảy khỏi artboard khi gộp PDF.
2. Mở PDF trong Illustrator có trang bị mất nội dung do item không được translate sau embed.
3. Chạy chậm do embed ảnh link lặp lại cho từng record.

Cơ chế V75:
- Không embed PlacedItem khi copy sang document gộp.
- Chỉ relink khi link đích khác link nguồn.
- Ép tọa độ copy theo tọa độ nguồn + shift artboard.
- Artboard của từng record vẫn là bản dịch chính xác từ artboard gốc.
- Bỏ object nằm hoàn toàn ngoài vùng artboard gốc.

Nên test 3–5 record trước, sau đó chạy toàn bộ batch.


DPV V74 — LINKSAFE FAST VARIABLE DATA / FAST COMBINED PDF

MỤC TIÊU V74
Tăng tốc khi gộp rất nhiều record thành một PDF nhiều trang.

CƠ CHẾ MỚI
1) Tài liệu làm việc chỉ được clone 1 lần cho toàn bộ batch.
2) Mỗi record: khôi phục trạng thái gốc -> áp dữ liệu -> copy artwork trực tiếp vào tài liệu PDF gộp.
3) Không còn tạo hàng trăm PDF tạm rồi mở/import từng trang PDF như V72.
4) Chỉ save PDF gộp đúng 1 lần ở cuối batch.
5) Khi chạy batch, app.redraw() được bỏ qua để giảm thời gian Illustrator render màn hình.

CÁCH DÙNG
- Nếu chỉ cần 1 PDF gộp nhanh nhất: bỏ tick “Xuất PDF riêng từng record”, giữ tick “Gộp nhanh tất cả record vào 1 PDF nhiều trang”.
- Nếu cần cả PDF riêng + PDF gộp: bật cả hai. V73 vẫn nhanh hơn V72 ở phần gộp vì không import lại PDF.
- Với dữ liệu rất lớn, nên chia batch để mỗi PDF gộp không vượt 950 trang/artboard.

LƯU Ý
- Ảnh biến đổi vẫn dùng Linked/PlacedItem.
- File AI gốc không bị save đè; V73 làm việc trên bản clone.


DPV V72 — MULTI VDP + PDF GỘP
==============================
- Thêm nhiều vị trí biến đổi bằng nhiều lần chọn trong Illustrator.
- Tất cả kênh mapping chạy đồng thời trên mỗi record.
- Xuất PDF riêng từng record và/hoặc 1 PDF gộp nhiều trang.
- Lỗi VDP được hiển thị ngay trong cửa sổ Variable Data để dễ xử lý.

DPV® DESKTOP BETA 0.1.20 — V71 VARIABLE DATA

MỚI: BIẾN ĐỔI DỮ LIỆU KIỂU HP SMARTSTREAM DESIGNER (VDP)
- Mở nút “Biến đổi dữ liệu VDP” trên thanh trên cùng.
- Đọc CSV/TXT có header, hỗ trợ dấu phẩy, chấm phẩy hoặc TAB và chuỗi có dấu ngoặc kép.
- Chọn đối tượng trong Illustrator rồi bấm “Lấy đối tượng đang chọn trong AI”.
- Map từng đối tượng vào cột dữ liệu với 4 kênh MVP: Text, Image relink, Ẩn/hiện và Fill Color.
- Preview từng record trực tiếp trong Illustrator và có nút khôi phục nội dung gốc.
- Xuất mỗi record thành PDF riêng trong thư mục VARIABLE_DATA; thao tác xuất dùng bản duplicate nên không save đè file thiết kế gốc.
- Image: giá trị CSV có thể là đường dẫn đầy đủ hoặc tên file nằm cùng thư mục CSV/TXT.
- Fill Color nhận #RRGGBB, R,G,B hoặc C,M,Y,K.

DPV® DESKTOP BETA 0.1.20 — V65

BẢN V65 LẤY FILE ĐANG MỞ SIÊU NHANH
- Nút “Lấy file đang mở” chỉ đọc metadata, artboard và tối đa một nhóm vector khuôn nhỏ; không quét đệ quy toàn bộ artwork.
- File lớn chưa tìm được khuôn ngay sẽ hiển thị “Đọc nhanh · khuôn khi xuất” và tính tạm theo artboard.
- Khi xem trước hoặc xuất, Bridge vẫn đọc KHUON_BE thật để giữ đúng True-Shape và file khuôn vector.
- Cache lần đọc cùng tài liệu, artboard và số lượng đối tượng; bấm lại trả kết quả tức thời.
- Có thể chọn đúng contour rồi bấm “Lấy khuôn đang chọn” nếu muốn số con chính xác ngay trước khi xuất.

BẢN V64 LẤY ĐÚNG ARTBOARD, GIỮ BLEED VÀ DÀN AB BÙ GÓC
- Chọn artboard lấy đúng `artboardRect`; artwork/KHUON_BE/bleed tràn ngoài không làm 105x148 thành 109x152 mm.
- FILE IN lấy vùng artboard cộng đúng “Bleed trong Link”; mặt A và mặt B giữ vùng tràn giống nhau.
- Quy tắc AB mặc định giữ nguyên vị trí từng con và bù góc mặt B: 0°→0°, 90°→270°, 270°→90°.
- Không phản toàn tờ theo trục Y và không cộng 180° cho mọi con.
- Khuôn vòm/chữ D đối xứng ở chế độ Siêu nhẹ chỉ thử 0°/90°/180°/270°, giảm đáng kể thời gian tính mà vẫn giữ dàn khóa so le.

BẢN V63 CŨ — SỬA CHIỀU MẶT B THEO MÁY TRỞ GIẤY
- Mặc định dùng “Lật đầu tờ”: mặt B phản vị trí trên/dưới và mỗi artwork xoay bù 180°.
- Chỉ xoay artwork, không mirror/scale âm nên chữ và hình mặt B không bị lật ngược.
- Giữ lựa chọn “Lật cạnh tờ” cho máy trở trái/phải; chế độ này phản vị trí ngang và giữ chiều artwork.
- PON CATTP đi theo đúng bố cục mặt B; hai artboard vẫn canh giữa và xuất chung một PDF hai trang.

BẢN V62 SỬA TỌA ĐỘ MẶT B — CATTP HAI MẶT AB
- Sửa lỗi mặt A dàn đủ nhưng mặt B bị co thành một Link nhỏ nằm ngoài artboard.
- Vùng dàn `binW/binH` được khóa trước khi phản chiếu A/B; không còn tọa độ NaN.
- Kiểm tra riêng từng mặt: đủ số Link, có artwork và tâm artwork trùng tâm artboard rồi mới cho lưu PDF.
- Vẫn xuất một PDF hai trang A/B, không PON góc/chấm tròn và không FILE KHUÔN trong chế độ CATTP.

BẢN V61 CATTP IN HAI MẶT AB — MỘT FILE
- Bật “PON cắt theo thành phẩm”, bật “In 2 mặt AB”, sau đó chọn đúng 2 artboard cùng kích thước.
- Artboard chọn đầu là mặt A; artboard thứ hai là mặt B. Mặt B tự đối xứng trái/phải hoặc trên/dưới theo cách trở giấy.
- Xuất đúng 1 PDF gồm 2 trang/artboard A và B trong thư mục FILE IN; không tạo FILE KHUÔN.
- Hai trang chỉ có artwork, tiêu đề và PON CATTP. Không thêm PON 4 góc hay chấm tròn đăng ký.
- Artwork và PON CATTP được canh giữa độc lập trên từng artboard.
- Link nguồn PDF/AI dùng bộ lọc clipping-mask-safe, tránh lỗi xuất trang trắng khi dieline trùng bounds của clipping mask.
- Bố cục chỉ tính một lần rồi phản chiếu cho mặt B nên nhanh hơn dàn riêng hai mặt.

BẢN V59 CATTP CHỈ XUẤT FILE IN + PON BIÊN BẬC THANG
- Có tùy chọn đổi riêng bốn dấu PON vuông/L ở góc sang Process Red C0 M100 Y100 K0; chấm tròn đăng ký vẫn Process K100.
- Thêm PON cắt theo biên thành phẩm của bài dàn, dùng chung vị trí cho FILE IN và KHUÔN BẾ.
- Tự gộp các vị trí cắt trùng ở hàng/cột ngoài cùng để không tạo nét chồng.
- Cho nhập chiều dài PON cắt và khoảng cách từ mép thành phẩm đến đầu PON.
- PON cắt và PON khuôn trong FILE KHUÔN là stroke vector Process CMYK, không Symbol/Link/Pantone.

BẢN V55 DIRECT BEZIER GEOMETRY
- Sửa lỗi đỏ “KHUÔN BẾ không có Bézier Path thật sau Embed/Break Symbol”.
- Đọc trực tiếp anchor và tay nắm Bézier từ contour KHUON_BE trong file nguồn.
- FILE KHUÔN được dựng thành PathItem stroke Process CMYK; không DIE-LINK, Symbol, PluginItem hay Pantone.
- View khuôn trực tiếp qua Illustrator cũng dùng geometry Bézier mới.
- Bỏ công đoạn DIE-LINK/Embed/Break nên xử lý khuôn nhanh và ổn định hơn.

BẢN NHẬN ĐÚNG KHUÔN VÒM/D VÀ DÀN KHÓA NHAU 0.1.18
- Không còn dừng ở đường đỏ hoặc khung vuông đầu tiên; Bridge chấm điểm toàn bộ contour kín trong artwork.
- Nếu artwork và khuôn cùng nằm trong layer `KHUON_BE`, khung nền trùng artboard bị loại và contour cong ngoài cùng được ưu tiên.
- Một shape duy nhất được dùng xuyên suốt từ đo kích thước, tính True‑Shape, xem trước đến PDF KHUÔN BẾ.
- Thêm mẫu dàn cột khóa nhau: tự so sánh cặp xoay 90°/270° và 0°/180°, phù hợp khuôn vòm, chữ D và khuôn đầu–đuôi.
- Mỗi vị trí vẫn được kiểm tra va chạm bằng polygon của đường khuôn thật; FILE KHUÔN xuất vector Process CMYK.

BẢN NHẬN CONTOUR KHUÔN BẤT KỲ 0.1.17
- Khi không có tên/màu `KHUON_BE`, tự quét vector lồng trong group/layer/compound path.
- Ưu tiên đường kín có stroke, chọn contour ngoài lớn nhất và loại khung chữ nhật trùng artboard.
- Đường cong Bézier được lấy mẫu thành polygon va chạm để dàn True‑Shape/so le; FILE KHUÔN vẫn dùng vector nguồn.
- Thẻ nguồn đổi thành “Đã nhận shape khuôn”; chỉ hiện “Dùng artboard” khi thực sự không có contour hợp lệ.

BẢN SỬA GỌI COM WINDOWS 0.1.16
- Sửa lỗi “Windows Bridge không gọi được ConnectIllustrator: Invalid procedure call or argument”.
- Gọi thẳng hàm IDispatch của `window.external`, không dùng `Function.apply()` vốn không tương thích WebBrowser COM của Windows.
- Nhãn phiên bản hiển thị trong giao diện đồng bộ 0.1.16.

BẢN KẾT NỐI ILLUSTRATOR 64-BIT ỔN ĐỊNH 0.1.15
- Sửa trạng thái “Đang kết nối Adobe Illustrator…” bị treo do COM chờ `GetActiveObject` vô hạn.
- Nút Kết nối dùng COM 64-bit và tự dò ProgID Illustrator 2024/2025/2026; giao diện tự mở khóa sau 15 giây nếu Illustrator không phản hồi.
- Thông báo hướng dẫn kiểm tra hộp thoại đang chờ và quyền Administrator khi hai ứng dụng không cùng mức quyền.
- Thêm “Khuôn đặc biệt – dàn so le nhanh”: nhận KHUON_BE bất kỳ, thử xoay 0°/180°/90°/270° và dàn đầu–đuôi.
- Với bài nhiều con, dùng lưới True-Shape có kiểm tra va chạm khuôn thật theo từng hàng thay cho quét toàn tờ, giảm lag rõ rệt.
- Giữ chế độ vector CMYK cho FILE KHUÔN; FILE IN vẫn dùng Link/Symbol để nhẹ.
Ứng dụng dàn in độc lập kết nối trực tiếp Adobe Illustrator

MỤC ĐÍCH BẢN BETA
- DPV® chạy như một ứng dụng Windows riêng, có cửa sổ độc lập với Illustrator.
- Engine tính nhanh hình chữ nhật, xoay hỗn hợp, True-Shape và Demi chạy trong DPV® để thao tác giao diện không làm Illustrator lag.
- Illustrator Bridge chỉ đọc tài liệu/KHUON_BE, dựng Link và xuất FILE IN/FILE KHUÔN.
- Bản Beta dùng COM Automation của Illustrator trên Windows, không cần mở panel Extensions.

YÊU CẦU
- Windows 10 hoặc Windows 11.
- Adobe Illustrator 2024, 2025 hoặc 2026 bản desktop.
- Windows .NET Framework 4.x. Windows 10/11 thường đã có sẵn.

CÀI ĐẶT
1. Tắt VDPRO/DPV® cũ nếu đang mở.
2. Giải nén toàn bộ ZIP vào một thư mục.
3. Nhấp đúp install_windows.bat.
4. Bộ cài tạo DPV.exe tại %LOCALAPPDATA%\DPV và shortcut “DPV®” trên Desktop.
5. Mở Illustrator trước, sau đó mở DPV® và bấm Kết nối.

BẢN GOM FILE IN VÀ KHUÔN 0.1.13
- Mỗi lần xuất chỉ tạo một thư mục “FILE IN” để giao việc.
- Bên trong “FILE IN” chứa chung PDF FILE IN và PDF KHUÔN BẾ.
- Không còn tạo thư mục “KHUÔN BẾ” riêng.
- Bài nhiều artboard vẫn có thư mục bài riêng; bên trong gồm FILE IN và LINK_FILES.
- Tên PDF FILE IN/KHUÔN BẾ và quy cách đánh số vẫn giữ nguyên.

BẢN ICON CORGI 0.1.12
- Thay icon DPV® bằng mascot chó Corgi dựa trên hình tham chiếu của người dùng.
- Chữ DPV® được thu nhỏ thành nhãn xanh phía dưới để không che khuôn mặt.
- Đồng bộ icon mới cho DPV.exe, cửa sổ ứng dụng, shortcut Windows và toàn bộ bộ PNG/ICO.
- Giữ đúng bảng màu kem, vàng, xanh lá và viền đen của giao diện DPV®.

BẢN TÁCH THƯ MỤC ĐẦU RA 0.1.11 (ĐÃ ĐƯỢC 0.1.13 THAY THẾ)
- Bản 0.1.13 đã đổi lại theo yêu cầu: PDF in và PDF khuôn cùng nằm trong “FILE IN”.
- Quy cách tên PDF vẫn giữ nguyên như AutoNestPro 2.5.1.

BẢN VECTOR KHUÔN VÀ CHỪA PON 0.1.10
- FILE KHUÔN luôn là vector Process CMYK; Bridge vô hiệu hoàn toàn tùy chọn Link/Symbol trong tài liệu khuôn.
- Hình tròn và chữ nhật được dựng vector trực tiếp một lượt, không còn tạo rồi embed từng Link nên nhanh và nhẹ hơn rõ rệt.
- Khuôn hình dạng bất kỳ được bung, lọc và chuẩn hóa lại; nếu còn PlacedItem/Symbol, DPV® dừng xuất để tránh lỗi máy bế.
- Thêm “Chừa rộng bốn góc PON” và “Vùng trống PON 4 góc”; mặc định chừa 28 mm tính từ góc tờ.
- Thuật toán bố trí dạng chữ thập: cột/hàng giữa tận dụng hết khổ, hai mép lùi khỏi góc để PON luôn thoáng.
- Trường hợp 80×112 mm trên khổ 320×390, lề 8 mm, hở 2 mm vẫn đạt 11 con và chừa được bốn góc.
- Quy cách tên PDF tiếp tục giữ nguyên như AutoNestPro_v2.5.1_DemiLayerHotfix_Illustrator2024-2026.

BẢN SỬA QUY CÁCH TÊN FILE 0.1.9
- Đồng bộ cách lưu tên với AutoNestPro_v2.5.1_DemiLayerHotfix_Illustrator2024-2026.
- Chế độ file thường không còn lưu kiểu TEN_FILE_FILE-IN_22PCS.ai.
- FILE IN lưu mặc định dạng PDF: 1.1. FILE IN - TÊN - KT TEM 54X81MM - 320X390 - 22PCS.pdf.
- FILE KHUÔN lưu mặc định dạng PDF: 1. KHUÔN BẾ - KT 54X81MM - 320X390 - 22PCS.pdf.
- Tên PDF FILE IN trùng với tiêu đề đặt bên trong file; FILE KHUÔN không có tiêu đề.
- Nhiều artboard vẫn nhóm theo kích thước: khuôn 1/2/3 và file in 1.1/1.2, 2.1/2.2, 3.1/3.2.
- Tên thư mục bài nhiều artboard lấy từ tên tài liệu Illustrator, còn tên từng FILE IN chỉ lấy tên artboard.

BẢN SỬA XUẤT FILE 0.1.8
- Sửa lỗi “Cannot modify a layer that is locked” khi xuất FILE IN/KHUÔN, nhất là file nhiều con hoặc PON có layer khóa.
- Bridge tự mở khóa, hiện và kích hoạt đúng layer đích trước khi tạo Link, Symbol, khuôn, tiêu đề và PON.
- Không còn dựng đối tượng vào layer đang ẩn trong chế độ siêu nhẹ/fast vector.
- Nâng hộp “Chọn thư mục” thành cửa sổ Explorer hiện đại, có thanh địa chỉ, Quick access, ổ đĩa và danh sách thư mục như Windows.
- Nếu máy không hỗ trợ hộp hiện đại, DPV® tự dùng hộp chọn thư mục cũ để không chặn công việc.

BẢN ICON 0.1.7
- Thêm logo DPV® đồng bộ màu kem, vàng, xanh lá và viền đen.
- Gắn icon vào DPV.exe, cửa sổ ứng dụng, shortcut Desktop và góc trái giao diện.
- Kèm file vector SVG, PNG 1024/512/256/128/64/48/32/16 px và ICO đa kích thước trong thư mục assets/icon.

BẢN ĐỔI TÊN 0.1.6
- Đổi toàn bộ tên ứng dụng thành DPV®.
- File chạy đổi thành DPV.exe, thư mục cài đặt thành %LOCALAPPDATA%\DPV và shortcut Desktop là “DPV®”.
- Bộ cài tự đóng và dọn phiên bản VDPRO cũ để tránh xuất hiện hai ứng dụng.
- Giữ nguyên thuật toán, giao diện kem – vàng – xanh lá và kết nối Illustrator.

BẢN GIAO DIỆN 0.1.5
- Thiết kế lại theo phong cách thẻ bo tròn, viền đen rõ và giao diện sáng thoáng.
- Bảng màu mới: nền kem ngà, vàng cho thao tác chính, xanh lá cho trạng thái và thao tác phụ, cam cho cảnh báo.
- Sơ đồ dàn nhanh chuyển sang nền sáng đồng bộ với toàn bộ ứng dụng.
- Giữ nguyên engine dàn, True-Shape, Demi, nhiều artboard và kết nối Illustrator.

BẢN SỬA 0.1.4
- Sửa lỗi “ANP_v15ManualDiePreview is not a function” khi Illustrator còn giữ Bridge cũ trong bộ nhớ.
- Bridge tự kiểm tra phiên bản và đúng hàm cần gọi; thiếu hoặc cũ sẽ tự nạp lại, không cần khởi động lại Illustrator.
- Thông báo lỗi được rút gọn, không còn đổ toàn bộ dữ liệu khuôn dài vào giao diện.
- Đổi màu chủ đạo ứng dụng sang vàng và xanh lá.

BẢN MỚI 0.1.3
- Sau khi tính kích thước thủ công, nút “View khuôn trực tiếp qua Illustrator” sẽ được bật.
- Illustrator tạo tài liệu xem trước đúng khổ, lề, khoảng hở và số con; không cần file thiết kế và không lưu file.
- Khuôn thủ công được dựng bằng vector Process CMYK, không tạo Pantone; PON nằm ở layer dưới cùng.
- Tem tròn nhiều con dùng compound path siêu nhẹ để hạn chế lag trong Illustrator.

BẢN MỚI 0.1.2
- Thêm chế độ nhập kích thước tem thủ công, không cần mở file Illustrator.
- Chọn tem chữ nhật/vuông hoặc hình tròn; hình tròn nhập theo đường kính.
- Tự tính số con tối đa trên khổ và hiển thị sơ đồ dàn thu nhỏ ngay trong DPV®.
- Hình tròn tự bật True-Shape, so sánh lưới vuông với xếp tổ ong rồi chọn phương án nhiều con hơn.
- Bỏ bước dò hình chữ nhật không cần thiết khi tính tem tròn, giúp xem trước hàng nghìn con nhanh hơn.
- Sơ đồ tự rút gọn khi số lượng tem rất lớn để ứng dụng vẫn nhẹ.

BẢN SỬA 0.1.1
- Sửa lỗi không cài được khi thư mục giải nén có tên tiếng Việt hoặc ký tự Unicode.
- Bỏ cơ chế XCOPY /EXCLUDE làm mất thư mục src và báo thiếu VDPRO.cs.
- Bộ cài kiểm tra đủ file trước và sau khi sao chép, rồi mới tạo file ứng dụng.

QUY TRÌNH DÙNG
1. Mở file thiết kế trong Illustrator.
2. Mở DPV® và bấm Kết nối.
3. Bấm Lấy file đang mở, Chọn nhiều file hoặc Chọn artboard.
4. Nhập khổ in, lề, khoảng hở, Bleed và chế độ dàn.
5. Bấm Tính nhanh trên DPV®. Phép tính này chạy bên ngoài Illustrator.
6. Có thể bấm Đối chiếu bằng Illustrator hoặc Mở xem trước khuôn.
7. Chọn thư mục xuất rồi bấm Dàn Link & xuất IN/KHUÔN.

XEM NHANH BẰNG KÍCH THƯỚC, KHÔNG CẦN FILE
1. Bấm “Nhập kích thước tem”.
2. Chọn Chữ nhật/vuông hoặc Hình tròn.
3. Nhập rộng × cao; với hình tròn chỉ nhập đường kính.
4. Bấm “Tính và xem trước trên khổ”.
5. DPV® hiện số con tối đa và sơ đồ ngay trong app.
6. Bấm “View khuôn trực tiếp qua Illustrator” để mở tài liệu khuôn vector kiểm tra; tài liệu này chưa lưu file.
7. Chế độ thủ công không xuất FILE IN/KHUÔN vì chưa có file thiết kế.

TÍNH NĂNG ĐÃ ĐƯA VÀO
- Lấy file Illustrator đang mở và đường KHUON_BE.
- Lấy KHUON_BE đang chọn thủ công.
- Chọn nhiều file AI/PDF/EPS/SVG.
- Chọn một số hoặc tất cả artboard trong tài liệu.
- Dàn chữ nhật, xoay 90°, MaxRects nhiều kích thước.
- True-Shape polygon và hình tròn tổ ong.
- Bế 1 dao Demi bằng lưới đường thẳng dùng chung.
- Chế độ siêu nhẹ, FILE IN dạng Link, FILE KHUÔN vector Process CMYK, giữ màu file gốc.
- Tạo/nhúng PON và xuất FILE IN, FILE KHUÔN.
- Nhật ký kết nối, trạng thái tiến trình và đối chiếu kết quả Illustrator.

LƯU Ý BETA
- Bản hiện tại ưu tiên Windows vì kết nối Illustrator bằng COM Automation.
- Khi Illustrator thực sự tạo path/layer hoặc lưu PDF, Illustrator vẫn có thể bận trong thời gian ngắn; cửa sổ DPV® vẫn chạy độc lập.
- Không đổi tên hoặc xóa thư mục bridge trong thư mục cài DPV®.
- Nếu báo chưa kết nối, hãy mở Illustrator, chờ tài liệu tải xong rồi bấm Kết nối lại.
- Đây là bản thử nghiệm đầu tiên; nên kiểm tra kích thước và Overprint trước khi đưa lên máy bế/in.

GỠ CÀI ĐẶT
- Chạy uninstall_windows.bat.

Tên ứng dụng: DPV®


V74 FIX
- Sửa lỗi artwork có ảnh link/placed item bị ô trắng khi xuất PDF gộp nhanh.
- Khi copy sang document gộp, DPV sẽ relink theo đường dẫn tuyệt đối và embed ảnh link vào document gộp để PDF không mất hình.


V77 UNIT ROLLBACK
- Đã trả cách tạo document về app.documents.add(...) như bản cũ.
- Không đổi hệ tính toán dàn/bleed/PON; vẫn dùng point nội bộ và quy đổi mm ở nơi cần thiết như trước.


V81 — SỬA MẤT LINK FILE DÀN
- Nguyên nhân V76–V80: hàm PDF dùng chung bị đặt preserveEditability=false để phục vụ VDP. Điều này vô tình tác động cả FILE DÀN chính.
- V81 tách policy: FILE DÀN dùng preserveEditability=true như V71; VDP vẫn dùng ANP_savePDFRangeV76 riêng với preserveEditability=false.
- Khi mở PDF FILE DÀN lại trong Illustrator, các PlacedItem link sẽ còn trong Links panel nếu file nguồn link vẫn tồn tại.

=== V125 VDP PRODUCTION FIDELITY ===
- PDF VDP Sheet gộp giữ chính xác khổ Dàn file, ví dụ 330 x 390 mm vẫn là 330 x 390 mm sau Combine.
- Bleed dùng PDF MediaBox và cùng công thức padding/rotation với Dàn file V101.
- PON file / Auto PON / CATTP / tiêu đề lấy trực tiếp từ cấu hình Dàn file.
- Nếu Dàn file bật 2 mặt A/B + CATTP, VDP Sheet xuất mỗi tờ thành PDF 2 trang A/B và Combine đủ 2 trang/tờ.


=== V131 MIXED ROTATION MAX ===
Khi bật “Tối ưu tự động: khoảng cách đều chính xác + số con tối đa”, DPV không còn khóa toàn bộ bài theo một hướng.
V131 thử lưới thẳng 0°, lưới thẳng 90° và các tổ hợp hàng/cột trộn 0°/90°.
Quy tắc chọn: số con tối đa trước; nếu bằng nhau, chọn lưới thẳng. Gap X/Y và lề vẫn là giới hạn chính xác.
