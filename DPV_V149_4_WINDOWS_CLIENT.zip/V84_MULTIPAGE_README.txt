V84 TRUE MULTIPAGE VDP

Lỗi đã sửa: app báo “3 trang” nhưng file PDF gộp không thực sự có đủ 3 page.
Nguyên nhân: PDFSaveOptions có artboardRange nhưng chưa bật saveMultipleArtboards trong hàm xuất VDP.
V84 bật saveMultipleArtboards khi document có nhiều artboard và kiểm tra số artboard trước khi save.
