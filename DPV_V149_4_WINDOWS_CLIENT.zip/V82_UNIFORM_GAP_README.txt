DPV V82 — KHOẢNG CÁCH DÀN ĐỀU TUYỆT ĐỐI

Vấn đề V81:
- Chế độ tối ưu số con có thể trộn cùng lúc mẫu 0° và 90°.
- Ví dụ tem 42x75 có thể dùng các cột 42x75 xen một cột 75x42 để tăng số con.
- Gap trong từng hàng/cột vẫn đúng, nhưng tại chỗ giao giữa hai hướng sẽ tạo khoảng trống lớn/nhỏ khác nhau, nhìn như khoảng cách không đều.

V82:
- Mặc định bật "Khoảng cách đều tuyệt đối – lưới 1 hướng".
- DPV thử cả 0° và 90°, sau đó dùng DUY NHẤT một hướng cho toàn tờ.
- Khoảng cách ngang = gapX; khoảng cách dọc = gapY.
- FILE IN và FILE KHUÔN dùng chung một layout nên trùng nhau.
- Nếu muốn ưu tiên số con tối đa như trước, bỏ chọn chế độ này rồi bật True-Shape/so-le.

Lưu ý: lưới đều có thể giảm số con/tờ. Ví dụ một bài trước đây đạt 27–28 con nhờ trộn hướng có thể còn khoảng 24 con khi khóa lưới đều. Đây là đánh đổi để khe dàn đều và dễ kiểm soát bế/cắt hơn.
