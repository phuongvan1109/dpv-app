DPV V72 — MULTI POSITION + PDF GỘP
=======================================
1) Có thể chọn nhiều đối tượng cùng lúc trong Illustrator, hoặc chọn từng đối tượng rồi bấm “+ Thêm vị trí đang chọn trong AI”.
2) Mỗi vị trí có mapping riêng. Khi Preview/Build, tất cả mapping hợp lệ chạy đồng thời trên cùng record.
3) Xuất PDF: có thể bật PDF riêng từng record, PDF gộp nhiều trang, hoặc bật cả hai.
4) Tên PDF gộp mặc định: VDP_ALL.pdf trong thư mục VARIABLE_DATA.
5) V72 đã thay cơ chế clone document để sửa lỗi V71 không xuất được PDF.

DPV® V71 — VARIABLE DATA / SMARTSTREAM-LIKE VDP
=================================================

Mục tiêu
- Chạy dữ liệu biến đổi trực tiếp với Adobe Illustrator, tương tự workflow Variable Data của HP SmartStream Designer.
- Không thay thế chức năng dàn IN/KHUÔN đang có.

Cách dùng nhanh
1. Mở Illustrator và file thiết kế.
2. Mở DPV®, bấm Kết nối.
3. Bấm “Biến đổi dữ liệu VDP” ở thanh trên cùng.
4. Chọn CSV/TXT. Dòng đầu tiên phải là tên cột.
5. Trong Illustrator, chọn các đối tượng muốn biến đổi.
6. Bấm “Lấy đối tượng đang chọn trong AI”.
7. Với từng đối tượng, chọn Action và cột dữ liệu:
   - Text: thay contents của TextFrame.
   - Image relink: thay ảnh Linked/PlacedItem. File ảnh có thể là path đầy đủ hoặc tương đối với thư mục CSV.
   - Ẩn / hiện: 0/false/no/off/hide/ẩn/rỗng = ẩn; giá trị khác = hiện.
   - Fill Color: #RRGGBB, R,G,B hoặc C,M,Y,K.
8. Dùng Previous/Next hoặc nhập số record rồi Preview.
9. Có thể bấm Khôi phục nội dung gốc.
10. Chọn thư mục xuất, khoảng record và cột dùng đặt tên PDF.
11. Bấm “Chạy biến đổi & xuất PDF hàng loạt”.

Đầu ra
- PDF được tạo trong thư mục VARIABLE_DATA bên trong thư mục bạn chọn.
- Mỗi record = 1 PDF riêng.
- Nếu tài liệu có nhiều artboard, PDF của record đó giữ nhiều artboard.
- Khi batch export, DPV duplicate tài liệu cho từng record, save PDF rồi đóng duplicate; file gốc không bị save đè.

Lưu ý bản V71 MVP
- Image channel hiện hỗ trợ PlacedItem (ảnh link), chưa hỗ trợ thay nội dung RasterItem đã embed.
- Chưa có barcode/QR, rule builder, Mosaic/Collage hay gộp tất cả record vào một PDF duy nhất.
- Scan đối tượng gắn một marker ẩn DPVVDP vào trường Note của đối tượng để nhận lại đúng object khi duplicate.
