DPV V127 AI STAY OPEN

Fix chính:
- Sau khi VDP/VDP Sheet xuất xong, Illustrator không được tự thoát.
- Giữ một COM reference Illustrator sống suốt phiên DPV.
- Trước khi đóng work-copy/merge document, đảm bảo file .AI nguồn vẫn đang mở.
- Sau cleanup/Combine, tự kích hoạt lại đúng file AI nguồn.
- Nếu file nguồn bị đóng ngoài ý muốn nhưng path còn tồn tại, DPV tự mở lại file nguồn.
- Bridge version V127 để Illustrator bắt buộc reload hotfix mới.

Không thay Core V101, Exact Gap, True-Shape, PON, CATTP, Duplex, VDP Sheet layout.
