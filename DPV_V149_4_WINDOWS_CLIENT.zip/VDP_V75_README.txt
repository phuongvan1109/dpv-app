DPV V75 — EXACT ARTBOARD FAST VARIABLE DATA / COMBINED PDF

Bản này tập trung sửa đúng lỗi V74:
1. Artwork/link nhảy khỏi artboard khi gộp PDF.
2. Mở PDF trong Illustrator có trang bị mất nội dung do item không được translate sau embed.
3. Chạy chậm do embed ảnh link lặp lại cho từng record.

Cơ chế V75:
- Không embed PlacedItem khi copy sang document gộp.
- Chỉ relink khi link đích khác link nguồn.
- Ép tọa độ copy theo tọa độ nguồn + shift artboard.
- Artboard của từng record vẫn là bản dịch chính xác từ artboard gốc.
- Bỏ object nằm hoàn toàn ngoài vùng artboard gốc.

Nên test 3–5 record trước, sau đó chạy toàn bộ batch.
