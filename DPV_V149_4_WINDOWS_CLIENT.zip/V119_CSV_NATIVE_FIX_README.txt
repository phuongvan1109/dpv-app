DPV V119 CSV NATIVE FIX
- Fix Windows chọn CSV/TXT xong nhưng VDP không nhận dữ liệu.
- Tách native dialog chọn path và bước đọc file để tránh lỗi COM/WebBrowser khi dialog đóng.
- Hỗ trợ CSV, TXT, TSV; UTF-8/BOM, UTF-16, ANSI Vietnamese CP1258.
- Hỗ trợ dòng Excel sep=, / sep=; nếu có.
- Nút Đọc lại dùng cùng pipeline V119.
- Không sửa Core V101 imposition, PON, True-Shape, VDP sheet engine hay Illustrator Bridge.
