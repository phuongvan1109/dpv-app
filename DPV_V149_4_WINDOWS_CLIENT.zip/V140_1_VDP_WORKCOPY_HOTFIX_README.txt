DPV V140.1 — VDP WORK-COPY TARGET REBIND HOTFIX

LỖI ĐÃ SỬA
- Khi bấm “Dàn record trực tiếp lên khổ in” hoặc chạy batch VDP, DPV có thể báo:
  “Không tìm thấy Variable Data trong work-copy AI”.

NGUYÊN NHÂN
- UI map đối tượng bằng PageItem UUID để không làm dirty file thiết kế.
- Trên một số phiên bản Illustrator/macOS/Windows, khi file .AI nguồn vẫn đang mở và DPV mở một bản copy fidelity, Illustrator cấp UUID mới cho PageItem trong bản copy.
- UUID cũ vẫn đúng ở file nguồn nhưng không còn tồn tại trong work-copy, nên bước capture state trả về 0 target.

V140.1
- Giữ mapping UI/source như cũ.
- Sau khi mở work-copy, DPV tự tìm đúng PageItem tương ứng bằng thứ tự pageItems + type + bounds + text/link/name/layer và rebind sang UUID của work-copy.
- Chỉ rebind trong document tạm; KHÔNG ghi note/name vào file AI nguồn.
- Kiểm tra đủ 100% target trước khi chạy record.
- Nếu lỗi trước khi batch khởi động, tự đóng/xóa work-copy tạm và quay lại file AI nguồn.

KHÔNG THAY ĐỔI
- Core V101 / solver dàn / Mixed Rotation / Exact Gap / True Shape
- PON / CATTP / Duplex A-B / Bleed
- Font fidelity V136/V137 / No-Stroke V138
- CSV / Dãy số / CSV + Dãy số
- UI Performance Foundation V140
