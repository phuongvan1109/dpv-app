DPV V129 QR INFO SIDEBAR

- QR Zalo được đặt trực tiếp vào vùng trống của sidebar DPV.
- Mã QR dùng nguyên ảnh do người dùng cung cấp để ưu tiên khả năng quét.
- Click vào QR hoặc Phóng to mã QR để mở mã lớn.
- Card tự thu gọn/ẩn khi sidebar compact để không phá responsive.
- Tương thích Light/Dark.
- Core V101 và toàn bộ engine sản xuất giữ nguyên.
