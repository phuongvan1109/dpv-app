﻿@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "DPV_SOURCE=%~dp0"
set "DPV_TARGET=%LOCALAPPDATA%\DPV"
set "DPV_EXE=%DPV_TARGET%\DPV.exe"
set "DPV_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%DPV_CSC%" set "DPV_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
set "DPV_TARGET_VERSION=V149.4"
if not defined DPV_PREVIOUS_VERSION set "DPV_PREVIOUS_VERSION=Chưa cài"
if /I "%DPV_PREVIOUS_VERSION%"=="Chưa cài" if exist "%DPV_TARGET%\VERSION.txt" for /f "usebackq delims=" %%V in (`powershell.exe -NoProfile -Command "$t=Get-Content -Raw -LiteralPath '%DPV_TARGET%\VERSION.txt' -ErrorAction SilentlyContinue; if($t -match 'V\d+(?:\.\d+)+'){ $Matches[0] }"`) do set "DPV_PREVIOUS_VERSION=%%V"
if not exist "%DPV_SOURCE%src\VDPRO.cs" exit /b 11
if not exist "%DPV_CSC%" exit /b 12
taskkill /IM DPV.exe /F >nul 2>&1
taskkill /IM VDPRO.exe /F >nul 2>&1
if not exist "%DPV_TARGET%" mkdir "%DPV_TARGET%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop';$src=$env:DPV_SOURCE;$dst=$env:DPV_TARGET;foreach($n in @('app','assets','bridge','src')){$a=Join-Path $src $n;$b=Join-Path $dst $n;if(Test-Path -LiteralPath $b){Remove-Item -LiteralPath $b -Recurse -Force};Copy-Item -LiteralPath $a -Destination $b -Recurse -Force}" >nul 2>&1 || exit /b 21
for %%F in (README_VI.txt VERSION.txt V148_9_VERSION.txt V148_9_2_VERSION.txt V149_1_VERSION.txt V149_2_VERSION.txt V149_3_VERSION.txt V149_4_VERSION.txt README_V149_4_FRIENDLY_CUTE_UX.txt README_V148_9_OUTPUT_MODE_NUMBERING.txt README_V148_9_2_PDF_AI_FIDELITY.txt README_V149_1_NATIVE_BATCH_GEOMETRY_CACHE.txt README_V149_2_JOB_QUEUE_DIAGNOSTICS.txt README_V149_3_QUICK_ADVANCED_UI.txt VDP_SAMPLE.csv uninstall_windows.bat) do if exist "%DPV_SOURCE%%%F" copy /Y "%DPV_SOURCE%%%F" "%DPV_TARGET%\%%F" >nul
set "DPV_UPDATE_STATE_PATH=%DPV_TARGET%\app\ui\dpv_update_state.js"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$fresh=($env:DPV_PREVIOUS_VERSION -eq 'Chưa cài');$o=[ordered]@{fromVersion=$env:DPV_PREVIOUS_VERSION;toVersion=$env:DPV_TARGET_VERSION;freshInstall=$fresh;installedAt=(Get-Date).ToString('s')};$js='window.DPV_UPDATE_STATE = '+($o|ConvertTo-Json -Compress)+';';[IO.File]::WriteAllText($env:DPV_UPDATE_STATE_PATH,$js,(New-Object Text.UTF8Encoding($false)))" >nul 2>&1
"%DPV_CSC%" /nologo /codepage:65001 /target:winexe /platform:x64 /optimize+ /out:"%DPV_EXE%" /win32icon:"%DPV_TARGET%\assets\icon\DPV.ico" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Web.Extensions.dll "%DPV_TARGET%\src\VDPRO.cs" || exit /b 31
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell;$n='DPV'+[char]174;$p=Join-Path ([Environment]::GetFolderPath('Desktop')) ($n+'.lnk');$s=$w.CreateShortcut($p);$s.TargetPath='%DPV_EXE%';$s.WorkingDirectory='%DPV_TARGET%';$s.IconLocation='%DPV_EXE%,0';$s.Description=$n;$s.Save()" >nul 2>&1
start "" "%DPV_EXE%"
exit /b 0
