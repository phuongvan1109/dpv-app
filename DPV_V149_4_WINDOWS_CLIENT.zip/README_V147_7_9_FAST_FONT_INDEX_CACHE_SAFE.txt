DPV V147.7.9 – FAST FONT INDEX CACHE SAFE

Fixes slow remote font search in V147.7.8.
- Illustrator builds app.textFonts index once in RAM.
- Subsequent searches filter the cached index.
- Font browser does not scan on open.
- Search starts only after 2 characters with 600 ms debounce.
- Refresh button explicitly rebuilds the font index after fonts are installed/removed.
- Barcode exact text gap logic from V147.7.8 is preserved.
