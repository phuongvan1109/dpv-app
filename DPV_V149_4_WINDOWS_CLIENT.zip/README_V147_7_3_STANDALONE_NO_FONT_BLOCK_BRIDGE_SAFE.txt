DPV V147.7.3 – STANDALONE NO-FONT-BLOCK BRIDGE SAFE

Built directly from V147.7.2. Cross-platform Mac + Windows hotfix.

Root fix:
- V147.7.2 automatically loaded ~2000 Illustrator fonts as soon as Studio opened.
- That font request occupied the same PreviewVariableData bridge used by standalone create.
- If Create was clicked while fonts were still loading, the create request could wait behind the font job and hit the 25 second timeout.

V147.7.3 changes:
- no automatic font scan on Studio open
- cached font list in localStorage for instant font browser
- font refresh only when user presses reload
- create is blocked with a clear message only while an explicit font refresh is running
- direct native invocation is handled on both DPVNative (Mac) and window.external (Windows)
- direct Promise result AND VDPRO_receive callback are both supported
- standalone create timeout increased to 35 s with explicit host/bridge diagnostics
- Core/VDP/layout/QR-barcode host engine is not rewritten
