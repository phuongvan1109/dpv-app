DPV V137 EXACT TEXT TEMPLATE

Fix VDP Text/Number Sequence khi file A/B có TextFrame khác font/size.
- Chụp typography RIÊNG từng targetId trước batch.
- Restore bằng snapshot gốc, không lấy style từ record trước.
- Sau khi thay contents, áp style cho TextRange và từng Character.
- Giữ font family/style, size, leading, tracking, scale, baseline, fill/stroke, paragraph alignment.
- Áp dụng Preview, CSV/TXT, Dãy số, Hybrid Data, PDF record và VDP Sheet A/B.
- Core V101, Mixed Rotation, PON/CATTP, Duplex, Bleed không thay đổi.
