DPV V149.1 — NATIVE BATCH BRIDGE + GEOMETRY CACHE

- Multi Artboard Preview / Die Preview / Build prewarm toàn bộ KHUON_BE + layout trong một native Bridge operation.
- Cache KHUON_BE theo document/artboard/hint trong Illustrator persistent engine.
- Cache layout theo shape + thông số dàn; Preview -> Build có thể tái sử dụng solver result.
- File đã Save: cache an toàn qua nhiều job cho đến khi file thay đổi/save lại.
- File chưa Save: cache chỉ tồn tại trong đúng một operation để không dùng geometry cũ.
- Không đổi thuật toán Core V101, Fidelity AI/PDF, Output Mode, numbering, account/license hay Auto Update.
- UI hiển thị HIT/MISS/prewarm ms để kiểm tra hiệu năng thật.
