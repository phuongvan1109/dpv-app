DPV® V141.1 — PREFLIGHT DIALOG HOTFIX
========================================

Mục tiêu hotfix:
- Sửa lỗi macOS trong cửa sổ Variable Data: "Không mở được CSV/TXT: Load failed".
- Nguyên nhân: WKWebView có thể thất bại ở request cross-port tới Native Dialog Bridge dù DPVServer vẫn hoạt động.
- V141.1 tự fallback sang DPVServer same-origin để mở CSV/TXT khi Native Dialog Bridge request lỗi.
- Không thay Core V101, thuật toán dàn, VDP mapping, Work-Copy Rebind V140.1 hay Preflight Pro V141.
- Windows giữ nguyên luồng native hiện tại; chỉ cập nhật nhãn phiên bản.

Cách thử trên Mac Intel:
1. Chạy INSTALL_DPV_MAC_INTEL.command.
2. Mở DPV > Biến đổi dữ liệu.
3. Chọn CSV/TXT như bình thường.
4. Nếu Native Dialog Bridge bị WebKit chặn, DPV tự chuyển sang same-origin fallback, không còn dừng ở "Load failed".

Diagnostics:
window.DPVNativeDialogs.fallbackUsed()
window.DPVNativeDialogs.lastError()
