DPV V147.5.1 – WINDOWS STUDIO OPEN HOTFIX

Fixes QR / Barcode Studio button not opening on Windows shell.
Root issue: dedicated overlay used modern CSS (inset/min()) that can fail in IE-compatible Windows WebBrowser.
This patch forces IE-safe top/right/bottom/left geometry and installs a final click handler.
No QR/Barcode engine, Bridge, Core V101, VDP, Cut & Stack, Duplex, or Multi Artboard code is changed.
