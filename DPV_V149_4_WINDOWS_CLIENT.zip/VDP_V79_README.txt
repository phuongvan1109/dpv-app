DPV V79 — STREAM LOW-RAM

Mục tiêu: sửa tình trạng Illustrator trắng/Not Responding và quá chậm của V78 khi chỉ vài record.

Cơ chế mới:
1. Clone nguyên file AI đúng 1 lần.
2. Mỗi record chỉ restore/apply dữ liệu rồi Save PDF đúng artboard gốc.
3. Không duplicate toàn bộ artwork cho từng record.
4. PDF gộp được dựng bằng các trang PDF link trong một document merge nhẹ.
5. Mỗi record chạy thành một lượt JSX riêng, Illustrator có thời gian nhận event giữa các record.

Khuyến nghị: test 3 record trước, sau đó tăng lên 50/100+.
