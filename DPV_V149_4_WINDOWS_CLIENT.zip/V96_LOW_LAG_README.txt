DPV V96 — LOW-LAG PREVIEW / BUILD

- Tính Exact Gap/True-Shape 1 lần trong UI, gửi layout cuối sang Illustrator.
- Preview khuôn và Dàn file không chạy lại solver polygon V95 trong ExtendScript.
- Cache axis-pitch V95 để giảm phép thử contour lặp.
- Preview đọc Bezier geometry trực tiếp, tránh tạo layer tạm/duplicate khuôn trên file nguồn khi không cần.
- FastMode dùng đường link nhẹ cho file vector/text đơn giản; file có ảnh link/raster/mask vẫn dùng Fidelity an toàn.
- Giữ toàn bộ V95 Optimal Exact Gap.
