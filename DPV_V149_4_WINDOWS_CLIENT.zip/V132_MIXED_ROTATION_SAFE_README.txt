DPV V132 — MIXED ROTATION SAFE

Sửa lỗi V131:
- Count tối ưu có thể đúng nhưng Live Preview KHUON_BE vẽ rotated cell bằng contour 0°, nhìn như chồng khuôn.
- V132 gắn angle 0/90 explicit cho mọi cell mixed.
- Thêm kiểm tra pairwise collision + exact Gap X/Y + hard bounds trước khi chấp nhận mixed layout.
- Nếu mixed không an toàn, tự fallback về regular exact grid.

Test chuẩn:
- 54x81 mm, khổ 320x390, lề 10, gap 2 => 21 con hợp lệ (3 rotated trên + 3x5 thẳng + 3 rotated dưới), không chồng.
- 219x30 mm, khổ 320x390, lề 8, gap 2 => 13 con hợp lệ.
