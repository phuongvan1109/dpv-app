DPV® Desktop Beta 0.1.20 — V101 STABLE HARD MARGIN + SMART STAGGER

V101 FIX
- Lề 4 cạnh là HARD LIMIT: bố cục vượt paper - 2*margin bị loại/chặn trước khi xuất.
- Không còn edge-relax ăn vào phần lề.
- Tạo baseline lưới thẳng Exact Gap cho 0/90/180/270.
- Chỉ dùng so-le/interlock nếu số con NHIỀU HƠN baseline. Nếu bằng, ưu tiên lưới ngang/dọc thẳng đều.
- Layout Cache có kiểm tra biên lần hai trong Illustrator Bridge.
- Giữ VDP, Combine PDF, Demi, Preserve Links, Modern UI và Mac Intel Bridge.
