using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Net;
using System.Security.Cryptography;
using Microsoft.Win32;

[assembly: AssemblyTitle("DPV®")]
[assembly: AssemblyProduct("DPV®")]
[assembly: AssemblyCompany("DPV")]
[assembly: AssemblyCopyright("Copyright © DPV® 2026")]
[assembly: AssemblyVersion("0.1.48.92")]

namespace VDPRO
{
    [Flags]
    internal enum FileOpenOptions : uint
    {
        PickFolders = 0x00000020,
        ForceFileSystem = 0x00000040,
        PathMustExist = 0x00000800
    }

    internal enum ShellDisplayName : uint
    {
        FileSystemPath = 0x80058000
    }

    internal enum FileDialogAddPlace : uint
    {
        Bottom = 0,
        Top = 1
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    internal struct FileDialogFilterSpec
    {
        [MarshalAs(UnmanagedType.LPWStr)] public string Name;
        [MarshalAs(UnmanagedType.LPWStr)] public string Spec;
    }

    [ComImport]
    [Guid("DC1C5A9C-E88A-4DDE-A5A1-60F82A20AEF7")]
    internal class FileOpenDialogCom
    {
    }

    [ComImport]
    [Guid("42F85136-DB7E-439C-85F1-E4075D135FC8")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IFileDialog
    {
        [PreserveSig]
        int Show(IntPtr parent);
        void SetFileTypes(uint count, [MarshalAs(UnmanagedType.LPArray)] FileDialogFilterSpec[] filters);
        void SetFileTypeIndex(uint index);
        void GetFileTypeIndex(out uint index);
        void Advise(IntPtr events, out uint cookie);
        void Unadvise(uint cookie);
        void SetOptions(FileOpenOptions options);
        void GetOptions(out FileOpenOptions options);
        void SetDefaultFolder(IShellItem folder);
        void SetFolder(IShellItem folder);
        void GetFolder(out IShellItem folder);
        void GetCurrentSelection(out IShellItem item);
        void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string name);
        void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string name);
        void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string title);
        void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string text);
        void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string label);
        void GetResult(out IShellItem item);
        void AddPlace(IShellItem item, FileDialogAddPlace alignment);
        void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string extension);
        void Close(int result);
        void SetClientGuid(ref Guid guid);
        void ClearClientData();
        void SetFilter(IntPtr filter);
    }

    [ComImport]
    [Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IShellItem
    {
        void BindToHandler(IntPtr bindContext, ref Guid handler, ref Guid riid, out IntPtr result);
        void GetParent(out IShellItem parent);
        void GetDisplayName(ShellDisplayName displayName, out IntPtr name);
        void GetAttributes(uint mask, out uint attributes);
        void Compare(IShellItem item, uint hint, out int order);
    }

    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            try
            {
                EnableModernBrowserMode();
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm());
            }
            catch (Exception ex)
            {
                try
                {
                    string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DPV");
                    Directory.CreateDirectory(dir);
                    File.AppendAllText(Path.Combine(dir, "startup.log"), DateTime.Now.ToString("s") + " STARTUP ERROR: " + ex.ToString() + Environment.NewLine);
                }
                catch { }
                try
                {
                    MessageBox.Show("DPV không khởi động được. Chi tiết: " + ex.Message + "\n\nLog: %LOCALAPPDATA%\\DPV\\startup.log", "DPV®", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch { }
            }
        }

        private static void EnableModernBrowserMode()
        {
            try
            {
                string exe = Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(
                    @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION"))
                {
                    key.SetValue(exe, 11001, RegistryValueKind.DWord);
                }
            }
            catch { }
        }
    }

    public sealed class MainForm : Form
    {
        private readonly WebBrowser browser;
        private readonly string appRoot;
        private readonly IllustratorEngine engine;

        // V148 ACCOUNT / LICENSE GATE. Illustrator Bridge chỉ hoạt động khi
        // session đã được DPV Auth Server xác minh. Frontend không thể chỉ
        // tự đổi biến JS để mở RunIllustrator trên Windows.
        private volatile bool authAuthorized = false;
        private DateTime authAuthorizedUntilUtc = DateTime.MinValue;
        private string authEmail = "";

        public MainForm()
        {
            appRoot = AppDomain.CurrentDomain.BaseDirectory;
            engine = new IllustratorEngine(appRoot);
            Text = "DPV® V148.9.2 — PDF + AI Fidelity · Output Mode · Auto Update";
            Width = 1440;
            Height = 900;
            MinimumSize = new System.Drawing.Size(860, 600);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = System.Drawing.Color.FromArgb(237, 241, 245);
            DoubleBuffered = true;
            string iconPath = Path.Combine(appRoot, "assets", "icon", "DPV.ico");
            try
            {
                if (File.Exists(iconPath))
                {
                    using (System.Drawing.Icon appIcon = new System.Drawing.Icon(iconPath))
                    {
                        Icon = (System.Drawing.Icon)appIcon.Clone();
                    }
                }
            }
            catch
            {
                // Icon branding must never prevent DPV from starting.
            }

            browser = new WebBrowser();
            browser.Dock = DockStyle.Fill;
            browser.ScriptErrorsSuppressed = true;
            browser.IsWebBrowserContextMenuEnabled = false;
            browser.WebBrowserShortcutsEnabled = true;
            browser.ObjectForScripting = new DesktopBridge(this);
            Controls.Add(browser);

            string index = Path.Combine(appRoot, "app", "ui", "index.html");
            if (!File.Exists(index))
            {
                MessageBox.Show("Không tìm thấy giao diện DPV®: " + index, "DPV®", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Shown += delegate { Close(); };
            }
            else
            {
                browser.Navigate(new Uri(index));
            }
        }

        internal IllustratorEngine Engine { get { return engine; } }

        internal bool IsAuthAuthorized
        {
            get { return authAuthorized && DateTime.UtcNow < authAuthorizedUntilUtc; }
        }

        internal void SetAuthAuthorized(string email)
        {
            authAuthorized = true;
            authEmail = email ?? "";
            // Frontend re-validates every 10 minutes. Native gate expires soon
            // after that so revoke trên server có hiệu lực mà không cần restart.
            authAuthorizedUntilUtc = DateTime.UtcNow.AddMinutes(15);
        }

        internal void ClearAuthAuthorized()
        {
            authAuthorized = false;
            authAuthorizedUntilUtc = DateTime.MinValue;
            authEmail = "";
        }

        internal void RunIllustrator(string operation, Func<string> work)
        {
            if (!IsAuthAuthorized)
            {
                string denied = JsonError("DPV Secure: chưa đăng nhập hoặc bản quyền máy chủ đã hết hiệu lực. Hãy đăng nhập lại.");
                try { BeginInvoke((MethodInvoker)delegate { SendResult(operation, denied); }); } catch { }
                return;
            }
            Thread thread = new Thread(delegate()
            {
                string payload;
                Stopwatch profilerClock = Stopwatch.StartNew();
                try { payload = work(); }
                catch (Exception ex) { payload = JsonError(CleanErrorMessage(Unwrap(ex).Message)); }
                profilerClock.Stop();
                if (operation == "build") { payload = AttachNativeProfilerTiming(payload, profilerClock.ElapsedMilliseconds); }

                try
                {
                    BeginInvoke((MethodInvoker)delegate { SendResult(operation, payload); });
                }
                catch { }
            });
            thread.IsBackground = true;
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
        }

        private static string AttachNativeProfilerTiming(string payload, long nativeTotalMs)
        {
            try
            {
                JavaScriptSerializer js = new JavaScriptSerializer();
                Dictionary<string, object> root = js.Deserialize<Dictionary<string, object>>(payload ?? "{}");
                object perfObject; Dictionary<string, object> perf = null;
                if (root.TryGetValue("performance", out perfObject)) { perf = perfObject as Dictionary<string, object>; }
                if (perf == null) { perf = new Dictionary<string, object>(); root["performance"] = perf; }
                perf["nativeTotalMs"] = nativeTotalMs;
                object jsTotalObject;
                if (perf.TryGetValue("totalMs", out jsTotalObject))
                {
                    long jsTotal = 0;
                    try { jsTotal = Convert.ToInt64(jsTotalObject); } catch { jsTotal = 0; }
                    perf["nativeBridgeOverheadMs"] = Math.Max(0, nativeTotalMs - jsTotal);
                }
                return js.Serialize(root);
            }
            catch { return payload; }
        }

        private static Exception Unwrap(Exception ex)
        {
            while (ex.InnerException != null) { ex = ex.InnerException; }
            return ex;
        }

        private static string CleanErrorMessage(string message)
        {
            string value = message ?? "Lỗi không xác định.";
            int scriptDump = value.IndexOf("\n->", StringComparison.Ordinal);
            if (scriptDump >= 0) { value = value.Substring(0, scriptDump); }
            if (value.Length > 700) { value = value.Substring(0, 700) + "…"; }
            return value;
        }

        internal static string JsonError(string message)
        {
            JavaScriptSerializer js = new JavaScriptSerializer();
            Dictionary<string, object> data = new Dictionary<string, object>();
            data["ok"] = false;
            data["error"] = message;
            return js.Serialize(data);
        }

        private void SendResult(string operation, string payload)
        {
            try
            {
                if (browser.Document != null)
                {
                    browser.Document.InvokeScript("VDPRO_receive", new object[] { operation, payload ?? "" });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "DPV® Bridge", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        internal void PushResult(string operation, string payload)
        {
            try { BeginInvoke((MethodInvoker)delegate { SendResult(operation, payload); }); }
            catch { }
        }
    }

    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDispatch)]
    public sealed class DesktopBridge
    {
        private readonly MainForm form;
        private readonly JavaScriptSerializer serializer = new JavaScriptSerializer();
        // V127: giữ một COM reference sống trong suốt phiên DPV. Illustrator là
        // out-of-proc COM server; sau VDP batch có rất nhiều document tạm bị đóng.
        // Giữ reference này tránh trường hợp Illustrator tự kết thúc khi reference
        // cuối cùng của một Call ngắn được Release ngay sau batch.
        private object illustratorKeepAlive = null;
        private readonly object illustratorKeepAliveLock = new object();
        // Chặn riêng hiện tượng WebBrowser phát lại click sau khi hộp thoại PON đóng.
        // lastPonPath giúp lần gọi lặp nhận lại đúng file vừa chọn thay vì mở dialog lần 2
        // hoặc trả chuỗi rỗng làm UI không hiện đường dẫn.
        private bool ponDialogOpen = false;
        private long ponDialogClosedAt = 0;
        private string lastPonPath = "";

        // Tương tự PON: WebBrowser trên một số máy có thể phát lại click sau khi
        // hộp thoại chọn thư mục đóng. Giữ trạng thái ở Native Bridge để chỉ mở
        // một dialog và vẫn trả đúng thư mục vừa chọn cho UI.
        private bool outputDialogOpen = false;
        private long outputDialogClosedAt = 0;
        private string lastOutputPath = "";

        // V113: guard all remaining native file dialogs against duplicate/replayed clicks.
        private bool sourceDialogOpen = false;
        private long sourceDialogClosedAt = 0;
        private bool variableDataDialogOpen = false;
        private long variableDataDialogClosedAt = 0;
        private bool combineDialogOpen = false;
        private long combineDialogClosedAt = 0;

        public DesktopBridge(MainForm owner) { form = owner; serializer.MaxJsonLength = Int32.MaxValue; }

        // Khi đã có domain production, đổi giá trị này thành host thật
        // (ví dụ auth.dpv.vn). Nếu còn placeholder, V148 cho phép localhost/HTTPS
        // setup Cloudflare sẽ hard-code hostname workers.dev trước khi phát hành.
        private const string TrustedAuthHost = "dpv-auth-free.dpvphuongvan.workers.dev";

        private static string MachineDeviceIdV148()
        {
            string raw = "";
            try
            {
                using (RegistryKey k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography"))
                {
                    if (k != null) { object v = k.GetValue("MachineGuid"); if (v != null) raw = Convert.ToString(v); }
                }
            }
            catch { }
            if (String.IsNullOrWhiteSpace(raw)) { raw = Environment.MachineName + "|" + Environment.UserName; }
            raw = "DPV-V148|" + raw;
            using (SHA256 sha = SHA256.Create())
            {
                byte[] h = sha.ComputeHash(Encoding.UTF8.GetBytes(raw));
                StringBuilder sb = new StringBuilder(h.Length * 2);
                for (int i = 0; i < h.Length; i++) sb.Append(h[i].ToString("x2"));
                return sb.ToString();
            }
        }

        public string GetDpvAuthDeviceInfo()
        {
            Dictionary<string, object> d = new Dictionary<string, object>();
            d["deviceId"] = MachineDeviceIdV148();
            d["platform"] = "windows-x64";
            d["appVersion"] = "V148.9.2";
            d["label"] = Environment.MachineName;
            return serializer.Serialize(d);
        }

        public string OpenExternalUrl(string url)
        {
            try
            {
                Uri uri;
                if (!Uri.TryCreate(url ?? "", UriKind.Absolute, out uri) || (uri.Scheme != Uri.UriSchemeHttps && uri.Scheme != Uri.UriSchemeHttp))
                    return MainForm.JsonError("URL đăng nhập không hợp lệ.");
                Process.Start(uri.AbsoluteUri);
                return "{\"ok\":true}";
            }
            catch (Exception ex) { return MainForm.JsonError("Không mở được trình duyệt: " + ex.Message); }
        }

        public string StartDpvAutoUpdate(string downloadUrl, string expectedSha256)
        {
            try
            {
                Uri uri;
                if (!Uri.TryCreate(downloadUrl ?? "", UriKind.Absolute, out uri) || uri.Scheme != Uri.UriSchemeHttps)
                    return MainForm.JsonError("Link cập nhật bắt buộc dùng HTTPS.");
                if (!uri.AbsolutePath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                    return MainForm.JsonError("Auto Update Windows hiện nhận gói ZIP của DPV.");
                string digest = (expectedSha256 ?? "").Trim().ToLowerInvariant();
                if (!System.Text.RegularExpressions.Regex.IsMatch(digest, "^[0-9a-f]{64}$"))
                    return MainForm.JsonError("Auto Update yêu cầu SHA-256 64 ký tự để xác minh gói cài đặt.");

                string root = Path.Combine(Path.GetTempPath(), "DPV_AutoUpdate");
                Directory.CreateDirectory(root);
                string tag = DateTime.UtcNow.ToString("yyyyMMddHHmmss") + "_" + Guid.NewGuid().ToString("N").Substring(0, 8);
                string ps1 = Path.Combine(root, "dpv_update_" + tag + ".ps1");
                string zip = Path.Combine(root, "dpv_update_" + tag + ".zip");
                string extract = Path.Combine(root, "extract_" + tag);
                Func<string, string> psQuote = delegate(string v) { return "'" + (v ?? "").Replace("'", "''") + "'"; };
                StringBuilder ps = new StringBuilder();
                ps.AppendLine("$ErrorActionPreference='Stop'");
                ps.AppendLine("$ProgressPreference='SilentlyContinue'");
                ps.AppendLine("$url=" + psQuote(uri.AbsoluteUri));
                ps.AppendLine("$zip=" + psQuote(zip));
                ps.AppendLine("$dst=" + psQuote(extract));
                ps.AppendLine("$expected=" + psQuote(digest));
                ps.AppendLine("try {");
                ps.AppendLine("  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing");
                ps.AppendLine("  if($expected){ $actual=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant(); if($actual -ne $expected){ throw ('SHA-256 không khớp. Expected '+$expected+' / Actual '+$actual) } }");
                ps.AppendLine("  if(Test-Path -LiteralPath $dst){ Remove-Item -LiteralPath $dst -Recurse -Force }");
                ps.AppendLine("  Expand-Archive -LiteralPath $zip -DestinationPath $dst -Force");
                ps.AppendLine("  $installer=Get-ChildItem -LiteralPath $dst -Recurse -Filter 'DPV_UPDATE_INSTALL_WINDOWS.bat' | Select-Object -First 1");
                ps.AppendLine("  if(-not $installer){ throw 'Không tìm thấy DPV_UPDATE_INSTALL_WINDOWS.bat trong gói cập nhật.' }");
                ps.AppendLine("  Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c',('" + '"' + "'+$installer.FullName+'" + '"' + "')) -WorkingDirectory $installer.DirectoryName");
                ps.AppendLine("} catch { Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'DPV Auto Update','OK','Error') | Out-Null; exit 1 }");
                File.WriteAllText(ps1, ps.ToString(), new UTF8Encoding(false));

                ProcessStartInfo pi = new ProcessStartInfo();
                pi.FileName = "powershell.exe";
                pi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File \"" + ps1 + "\"";
                pi.UseShellExecute = false;
                pi.CreateNoWindow = true;
                Process.Start(pi);

                Thread t = new Thread(delegate()
                {
                    Thread.Sleep(1200);
                    try { form.BeginInvoke((MethodInvoker)delegate { form.Close(); }); } catch { }
                });
                t.IsBackground = true;
                t.Start();
                return "{\"ok\":true,\"message\":\"Đang tải và xác minh bản cập nhật. DPV sẽ tự đóng khi trình cập nhật sẵn sàng.\"}";
            }
            catch (Exception ex) { return MainForm.JsonError("Không bắt đầu được Auto Update: " + ex.Message); }
        }

        public string DpvAuthRequest(string requestJson)
        {
            try
            {
                Dictionary<string, object> input = serializer.Deserialize<Dictionary<string, object>>(requestJson ?? "{}");
                object o;
                string serverUrl = input.TryGetValue("serverUrl", out o) ? Convert.ToString(o) : "";
                string method = input.TryGetValue("method", out o) ? Convert.ToString(o).ToUpperInvariant() : "POST";
                string path = input.TryGetValue("path", out o) ? Convert.ToString(o) : "";
                string body = input.TryGetValue("body", out o) && o != null ? serializer.Serialize(o) : "{}";
                string token = input.TryGetValue("token", out o) ? Convert.ToString(o) : "";
                Uri baseUri;
                if (!Uri.TryCreate((serverUrl ?? "").TrimEnd('/'), UriKind.Absolute, out baseUri)) return MainForm.JsonError("DPV Auth Server URL không hợp lệ.");
                bool local = baseUri.Host == "127.0.0.1" || baseUri.Host == "localhost";
                if (!local && baseUri.Scheme != Uri.UriSchemeHttps) return MainForm.JsonError("Production Auth Server bắt buộc dùng HTTPS.");
                if (TrustedAuthHost.IndexOf("YOUR-", StringComparison.OrdinalIgnoreCase) < 0 && !String.Equals(baseUri.Host, TrustedAuthHost, StringComparison.OrdinalIgnoreCase)) return MainForm.JsonError("Auth Server không nằm trong domain DPV tin cậy.");
                if (String.IsNullOrWhiteSpace(path) || !path.StartsWith("/api/auth/", StringComparison.Ordinal)) return MainForm.JsonError("Auth API path không được phép.");
                if (method != "GET" && method != "POST") return MainForm.JsonError("Auth HTTP method không được phép.");
                try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; } catch { }
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(new Uri(baseUri, path));
                req.Method = method; req.Accept = "application/json"; req.Timeout = 15000; req.ReadWriteTimeout = 15000;
                if (!String.IsNullOrWhiteSpace(token)) req.Headers[HttpRequestHeader.Authorization] = "Bearer " + token;
                if (method == "POST")
                {
                    req.ContentType = "application/json"; byte[] bytes = Encoding.UTF8.GetBytes(body ?? "{}"); req.ContentLength = bytes.Length;
                    using (Stream rs = req.GetRequestStream()) { rs.Write(bytes, 0, bytes.Length); }
                }
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) { return sr.ReadToEnd(); }
            }
            catch (WebException wex)
            {
                try
                {
                    HttpWebResponse resp = wex.Response as HttpWebResponse;
                    if (resp != null) using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) { string raw = sr.ReadToEnd(); if (!String.IsNullOrWhiteSpace(raw)) return raw; }
                }
                catch { }
                return MainForm.JsonError("Không gọi được DPV Auth Server: " + wex.Message);
            }
            catch (Exception ex) { return MainForm.JsonError("DPV Auth Request lỗi: " + ex.Message); }
        }

        public string AuthenticateDpv(string serverUrl, string sessionToken)
        {
            try
            {
                Uri baseUri;
                if (!Uri.TryCreate((serverUrl ?? "").TrimEnd('/'), UriKind.Absolute, out baseUri))
                    return MainForm.JsonError("DPV Auth Server URL không hợp lệ.");
                bool local = baseUri.Host == "127.0.0.1" || baseUri.Host == "localhost";
                if (!local && baseUri.Scheme != Uri.UriSchemeHttps) return MainForm.JsonError("Production Auth Server bắt buộc dùng HTTPS.");
                if (TrustedAuthHost.IndexOf("YOUR-", StringComparison.OrdinalIgnoreCase) < 0 &&
                    !String.Equals(baseUri.Host, TrustedAuthHost, StringComparison.OrdinalIgnoreCase))
                    return MainForm.JsonError("Auth Server không nằm trong domain DPV tin cậy.");
                if (String.IsNullOrWhiteSpace(sessionToken)) return MainForm.JsonError("Thiếu session token.");

                try { ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; } catch { } // TLS 1.2
                Dictionary<string, object> body = new Dictionary<string, object>();
                body["deviceId"] = MachineDeviceIdV148();
                string payload = serializer.Serialize(body);
                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(new Uri(baseUri, "/api/auth/validate"));
                req.Method = "POST"; req.ContentType = "application/json"; req.Accept = "application/json";
                req.Timeout = 12000; req.ReadWriteTimeout = 12000;
                req.Headers[HttpRequestHeader.Authorization] = "Bearer " + sessionToken;
                byte[] bytes = Encoding.UTF8.GetBytes(payload); req.ContentLength = bytes.Length;
                using (Stream rs = req.GetRequestStream()) { rs.Write(bytes, 0, bytes.Length); }
                string raw;
                using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) { raw = sr.ReadToEnd(); }
                Dictionary<string, object> result = serializer.Deserialize<Dictionary<string, object>>(raw ?? "{}");
                object okObj; bool ok = result.TryGetValue("ok", out okObj) && Convert.ToBoolean(okObj);
                if (!ok) { form.ClearAuthAuthorized(); return String.IsNullOrWhiteSpace(raw) ? MainForm.JsonError("Máy chủ từ chối bản quyền.") : raw; }
                string email = ""; object userObj;
                if (result.TryGetValue("user", out userObj))
                {
                    Dictionary<string, object> u = userObj as Dictionary<string, object>; object em;
                    if (u != null && u.TryGetValue("email", out em)) email = Convert.ToString(em);
                }
                form.SetAuthAuthorized(email);
                return raw;
            }
            catch (WebException wex)
            {
                form.ClearAuthAuthorized();
                try
                {
                    HttpWebResponse resp = wex.Response as HttpWebResponse;
                    if (resp != null) using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) { string raw = sr.ReadToEnd(); if (!String.IsNullOrWhiteSpace(raw)) return raw; }
                }
                catch { }
                return MainForm.JsonError("Không xác minh được bản quyền với máy chủ: " + wex.Message);
            }
            catch (Exception ex) { form.ClearAuthAuthorized(); return MainForm.JsonError("DPV Native Auth lỗi: " + ex.Message); }
        }

        public string LogoutDpv()
        {
            form.ClearAuthAuthorized();
            return "{\"ok\":true}";
        }

        public void ConnectIllustrator(bool launchIfNeeded)
        {
            form.RunIllustrator("connect", delegate { return form.Engine.Ping(launchIfNeeded); });
        }

        public void GetActiveSource(string dieHint)
        {
            form.RunIllustrator("activeSource", delegate
            {
                return form.Engine.Call("ANP_activeSourceV11", new string[] { dieHint ?? "KHUON_BE" });
            });
        }

        public void GetManualDieSource()
        {
            form.RunIllustrator("activeSource", delegate
            {
                return form.Engine.Call("ANP_manualSourceV11", new string[0]);
            });
        }

        public string ChooseSourceFiles()
        {
            long now = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;
            if (sourceDialogOpen) { return "[]"; }
            if (sourceDialogClosedAt > 0 && now - sourceDialogClosedAt < 900) { return "[]"; }
            sourceDialogOpen = true;
            try
            {
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Title = "Chọn các file cần dàn trong DPV®";
                    dialog.Filter = "Illustrator/PDF/EPS/SVG|*.ai;*.pdf;*.eps;*.svg|Tất cả file|*.*";
                    dialog.Multiselect = true;
                    dialog.CheckFileExists = true;
                    dialog.RestoreDirectory = true;
                    if (dialog.ShowDialog(form) != DialogResult.OK) { return "[]"; }
                    List<Dictionary<string, string>> files = new List<Dictionary<string, string>>();
                    foreach (string path in dialog.FileNames)
                    {
                        Dictionary<string, string> item = new Dictionary<string, string>();
                        item["path"] = path; item["name"] = Path.GetFileName(path); files.Add(item);
                    }
                    return serializer.Serialize(files);
                }
            }
            finally { sourceDialogOpen = false; sourceDialogClosedAt = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond; }
        }

        public void InspectSourceFiles(string filesJson, string dieHint)
        {
            form.RunIllustrator("inspectSources", delegate
            {
                return form.Engine.Call("ANP_inspectSources", new string[] { filesJson ?? "[]", dieHint ?? "KHUON_BE" });
            });
        }

        public void ListArtboards(string dieHint)
        {
            form.RunIllustrator("listArtboards", delegate
            {
                return form.Engine.Call("ANP_listArtboardsV12", new string[] { dieHint ?? "KHUON_BE" });
            });
        }

        public string ChooseOutputFolder()
        {
            long now = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;

            // Nếu click bị phát lại trong lúc hộp thoại đầu tiên còn mở, bỏ qua
            // để Windows không tạo thêm cửa sổ chọn thư mục thứ hai.
            if (outputDialogOpen)
            {
                return "";
            }

            // Nếu WebBrowser phát lại click ngay sau khi dialog đóng, trả lại
            // đúng kết quả lần vừa rồi thay vì mở dialog lần hai. Khi người dùng
            // Cancel thì lastOutputPath là chuỗi rỗng nên UI cũng không đổi path.
            if (outputDialogClosedAt > 0 && now - outputDialogClosedAt < 1400)
            {
                return lastOutputPath ?? "";
            }

            outputDialogOpen = true;
            try
            {
                string selectedPath = "";
                try
                {
                    selectedPath = ChooseOutputFolderModern();
                }
                catch
                {
                    using (FolderBrowserDialog dialog = new FolderBrowserDialog())
                    {
                        dialog.Description = "Chọn nơi tạo thư mục FILE IN chứa cả file in và khuôn bế";
                        dialog.ShowNewFolderButton = true;
                        selectedPath = dialog.ShowDialog(form) == DialogResult.OK ? dialog.SelectedPath : "";
                    }
                }

                lastOutputPath = selectedPath ?? "";
                return lastOutputPath;
            }
            finally
            {
                outputDialogOpen = false;
                outputDialogClosedAt = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;
            }
        }

        private string ChooseOutputFolderModern()
        {
            object dialogObject = null;
            IShellItem selected = null;
            try
            {
                dialogObject = new FileOpenDialogCom();
                IFileDialog dialog = (IFileDialog)dialogObject;
                FileOpenOptions options;
                dialog.GetOptions(out options);
                dialog.SetOptions(options | FileOpenOptions.PickFolders |
                    FileOpenOptions.ForceFileSystem | FileOpenOptions.PathMustExist);
                dialog.SetTitle("Chọn nơi tạo FILE IN chứa cả file in và khuôn bế");
                dialog.SetOkButtonLabel("Chọn thư mục");

                int result = dialog.Show(form.Handle);
                if (result == unchecked((int)0x800704C7)) { return ""; }
                Marshal.ThrowExceptionForHR(result);

                dialog.GetResult(out selected);
                IntPtr value;
                selected.GetDisplayName(ShellDisplayName.FileSystemPath, out value);
                try { return Marshal.PtrToStringUni(value) ?? ""; }
                finally { Marshal.FreeCoTaskMem(value); }
            }
            finally
            {
                if (selected != null && Marshal.IsComObject(selected)) { Marshal.FinalReleaseComObject(selected); }
                if (dialogObject != null && Marshal.IsComObject(dialogObject)) { Marshal.FinalReleaseComObject(dialogObject); }
            }
        }

        public string ChoosePonFile()
        {
            long now = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;

            // Nếu WebBrowser gọi lại trong lúc dialog đầu tiên vẫn đang mở, bỏ qua
            // hoàn toàn để không sinh hộp thoại thứ hai.
            if (ponDialogOpen)
            {
                return "";
            }

            // Một số máy phát lại click ngay SAU khi dialog đóng. Trong khoảng ngắn
            // này trả lại chính path vừa chọn. Như vậy UI vẫn nhận đúng đường dẫn
            // nhưng không mở thêm OpenFileDialog.
            if (ponDialogClosedAt > 0 && now - ponDialogClosedAt < 1400)
            {
                return lastPonPath ?? "";
            }

            ponDialogOpen = true;
            try
            {
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Title = "Chọn file PON";
                    dialog.Filter = "PON AI/PDF/EPS/SVG|*.ai;*.pdf;*.eps;*.svg|Tất cả file|*.*";
                    dialog.Multiselect = false;

                    if (dialog.ShowDialog(form) == DialogResult.OK)
                    {
                        lastPonPath = dialog.FileName ?? "";
                        return lastPonPath;
                    }

                    return "";
                }
            }
            finally
            {
                ponDialogOpen = false;
                ponDialogClosedAt = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;
            }
        }


        public string ChooseVariableDataFile()
        {
            long now = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;
            if (variableDataDialogOpen) { return ""; }
            if (variableDataDialogClosedAt > 0 && now - variableDataDialogClosedAt < 900) { return ""; }
            variableDataDialogOpen = true;
            try
            {
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Title = "Chọn dữ liệu Variable Data cho DPV®";
                    dialog.Filter = "CSV / TXT|*.csv;*.txt|CSV|*.csv|Text|*.txt|Tất cả file|*.*";
                    dialog.Multiselect = false;
                    dialog.CheckFileExists = true;
                    dialog.RestoreDirectory = true;
                    if (dialog.ShowDialog(form) != DialogResult.OK) { return ""; }

                    return VariableDataJsonV119(dialog.FileName);
                }
            }
            finally { variableDataDialogOpen = false; variableDataDialogClosedAt = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond; }
        }

        private string ReadVariableTextV119(string path)
        {
            byte[] bytes;
            using (FileStream input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            using (MemoryStream buffer = new MemoryStream())
            {
                input.CopyTo(buffer);
                bytes = buffer.ToArray();
            }
            if (bytes == null || bytes.Length == 0) { return ""; }

            // BOM-aware first: UTF-8 / UTF-16 LE / UTF-16 BE.
            if (bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF)
            {
                return Encoding.UTF8.GetString(bytes, 3, bytes.Length - 3);
            }
            if (bytes.Length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE)
            {
                return Encoding.Unicode.GetString(bytes, 2, bytes.Length - 2);
            }
            if (bytes.Length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF)
            {
                return Encoding.BigEndianUnicode.GetString(bytes, 2, bytes.Length - 2);
            }

            // Some Excel exports are UTF-16 without BOM. Detect NUL distribution.
            int evenZero = 0, oddZero = 0, scan = Math.Min(bytes.Length, 4096);
            for (int i = 0; i < scan; i++)
            {
                if (bytes[i] == 0) { if ((i % 2) == 0) { evenZero++; } else { oddZero++; } }
            }
            if (oddZero > 8 && oddZero > evenZero * 2) { return Encoding.Unicode.GetString(bytes); }
            if (evenZero > 8 && evenZero > oddZero * 2) { return Encoding.BigEndianUnicode.GetString(bytes); }

            // Prefer strict UTF-8. If Excel saved ANSI, fall back to Vietnamese CP1258, then system default.
            try
            {
                UTF8Encoding strictUtf8 = new UTF8Encoding(false, true);
                return strictUtf8.GetString(bytes);
            }
            catch
            {
                try { return Encoding.GetEncoding(1258).GetString(bytes); }
                catch { return Encoding.Default.GetString(bytes); }
            }
        }

        private string VariableDataJsonV119(string path)
        {
            if (String.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                Dictionary<string, object> bad = new Dictionary<string, object>();
                bad["ok"] = false; bad["error"] = "File dữ liệu không tồn tại.";
                return serializer.Serialize(bad);
            }
            try
            {
                string text = ReadVariableTextV119(path);
                Dictionary<string, object> data = new Dictionary<string, object>();
                data["ok"] = true;
                data["path"] = path;
                data["folder"] = Path.GetDirectoryName(path) ?? "";
                data["name"] = Path.GetFileName(path);
                data["size"] = new FileInfo(path).Length;
                data["text"] = text;
                return serializer.Serialize(data);
            }
            catch (Exception ex)
            {
                Dictionary<string, object> bad = new Dictionary<string, object>();
                bad["ok"] = false; bad["error"] = "Không đọc được CSV/TXT: " + ex.Message;
                return serializer.Serialize(bad);
            }
        }

        public string ChooseVariableDataPathV119()
        {
            long now = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;
            if (variableDataDialogOpen) { return ""; }
            if (variableDataDialogClosedAt > 0 && now - variableDataDialogClosedAt < 350) { return ""; }
            variableDataDialogOpen = true;
            try
            {
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Title = "Chọn dữ liệu Variable Data cho DPV®";
                    dialog.Filter = "Dữ liệu CSV / TXT / TSV|*.csv;*.txt;*.tsv|CSV|*.csv|Text / TSV|*.txt;*.tsv|Tất cả file|*.*";
                    dialog.Multiselect = false;
                    dialog.CheckFileExists = true;
                    dialog.RestoreDirectory = true;
                    if (dialog.ShowDialog(form) != DialogResult.OK) { return ""; }
                    return dialog.FileName ?? "";
                }
            }
            finally
            {
                variableDataDialogOpen = false;
                variableDataDialogClosedAt = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;
            }
        }

        public string ReadVariableDataFileV119(string path)
        {
            return VariableDataJsonV119(path);
        }

        public string ReadVariableDataFile(string path)
        {
            return VariableDataJsonV119(path);
        }

        private string VariableDataCancelledV120()
        {
            Dictionary<string, object> data = new Dictionary<string, object>();
            data["ok"] = false;
            data["cancelled"] = true;
            return serializer.Serialize(data);
        }

        // V120: do NOT return the selected path back through the same window.external
        // click stack. IE11/WinForms can lose that return value after a modal file dialog.
        // Read the file natively, then post the result back to the UI after the COM call
        // has fully returned.
        public void ChooseVariableDataAsyncV120()
        {
            long now = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;
            if (variableDataDialogOpen) { return; }
            if (variableDataDialogClosedAt > 0 && now - variableDataDialogClosedAt < 350) { return; }
            variableDataDialogOpen = true;
            string payload = VariableDataCancelledV120();
            try
            {
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Title = "Chọn dữ liệu Variable Data cho DPV®";
                    dialog.Filter = "Dữ liệu CSV / TXT / TSV|*.csv;*.txt;*.tsv|CSV|*.csv|Text / TSV|*.txt;*.tsv|Tất cả file|*.*";
                    dialog.Multiselect = false;
                    dialog.CheckFileExists = true;
                    dialog.RestoreDirectory = true;
                    if (dialog.ShowDialog(form) == DialogResult.OK)
                    {
                        string selected = dialog.FileName ?? "";
                        string ext = Path.GetExtension(selected).ToLowerInvariant();
                        if (ext == ".xlsx" || ext == ".xls")
                        {
                            Dictionary<string, object> bad = new Dictionary<string, object>();
                            bad["ok"] = false;
                            bad["error"] = "File đang chọn là Excel XLS/XLSX. Hãy Save As thành CSV UTF-8, CSV, TXT hoặc TSV rồi chọn lại.";
                            payload = serializer.Serialize(bad);
                        }
                        else
                        {
                            payload = VariableDataJsonV119(selected);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Dictionary<string, object> bad = new Dictionary<string, object>();
                bad["ok"] = false;
                bad["error"] = "Không mở/đọc được dữ liệu: " + ex.Message;
                payload = serializer.Serialize(bad);
            }
            finally
            {
                variableDataDialogOpen = false;
                variableDataDialogClosedAt = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;
            }
            form.PushResult("vdpDataSelectedV120", payload);
        }

        public string ReadVariableDataFileV120(string path)
        {
            return VariableDataJsonV119(path);
        }

        public void ScanVariableTargets()
        {
            form.RunIllustrator("vdpTargets", delegate
            {
                return form.Engine.Call("ANP_vdpSelectionV71", new string[0]);
            });
        }

        public void PreviewVariableData(string configJson)
        {
            form.RunIllustrator("vdpPreview", delegate
            {
                return form.Engine.Call("ANP_vdpPreviewV71", new string[] { configJson ?? "{}" });
            });
        }

        public void RestoreVariableData()
        {
            form.RunIllustrator("vdpRestore", delegate
            {
                return form.Engine.Call("ANP_vdpRestoreV71", new string[0]);
            });
        }

        private object AcrobatInvoke(object target, string member, params object[] args)
        {
            if (target == null) { throw new InvalidOperationException("Adobe Acrobat COM chưa sẵn sàng."); }
            return target.GetType().InvokeMember(member, BindingFlags.InvokeMethod, null, target, args);
        }

        private bool AcrobatBool(object value)
        {
            if (value == null) { return false; }
            try { return Convert.ToInt32(value) != 0; }
            catch { try { return Convert.ToBoolean(value); } catch { return false; } }
        }

        private string SafePdfBaseName(string value)
        {
            string name = String.IsNullOrWhiteSpace(value) ? "VDP_ALL" : value.Trim();
            if (name.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase)) { name = name.Substring(0, name.Length - 4); }
            foreach (char c in Path.GetInvalidFileNameChars()) { name = name.Replace(c, '_'); }
            name = name.Trim().Trim('.');
            return String.IsNullOrWhiteSpace(name) ? "VDP_ALL" : name;
        }

        private string UniquePdfPath(string folder, string baseName)
        {
            string safe = SafePdfBaseName(baseName);
            string path = Path.Combine(folder, safe + ".pdf");
            int index = 2;
            while (File.Exists(path))
            {
                path = Path.Combine(folder, safe + "_" + index.ToString() + ".pdf");
                index++;
            }
            return path;
        }


        private sealed class NaturalPdfComparer : IComparer<string>
        {
            public int Compare(string a, string b)
            {
                string sa = Path.GetFileName(a ?? "");
                string sb = Path.GetFileName(b ?? "");
                int ia = 0, ib = 0;
                while (ia < sa.Length && ib < sb.Length)
                {
                    if (Char.IsDigit(sa[ia]) && Char.IsDigit(sb[ib]))
                    {
                        long na = 0, nb = 0;
                        while (ia < sa.Length && Char.IsDigit(sa[ia])) { na = na * 10 + (sa[ia] - '0'); ia++; }
                        while (ib < sb.Length && Char.IsDigit(sb[ib])) { nb = nb * 10 + (sb[ib] - '0'); ib++; }
                        if (na != nb) { return na < nb ? -1 : 1; }
                    }
                    else
                    {
                        char ca = Char.ToUpperInvariant(sa[ia]);
                        char cb = Char.ToUpperInvariant(sb[ib]);
                        if (ca != cb) { return ca < cb ? -1 : 1; }
                        ia++; ib++;
                    }
                }
                if (ia < sa.Length) { return 1; }
                if (ib < sb.Length) { return -1; }
                return StringComparer.OrdinalIgnoreCase.Compare(a ?? "", b ?? "");
            }
        }

        private Dictionary<string, object> MergePdfFilesInsideDpv(IList<string> files, string outputPath, int pagesPerFile, object pageRects, string progressOperation)
        {
            if (files == null || files.Count < 1) { throw new InvalidOperationException("Không có PDF để gộp."); }
            Dictionary<string, object> startConfig = new Dictionary<string, object>();
            startConfig["outputPath"] = Path.GetFullPath(outputPath);
            startConfig["pagesPerFile"] = Math.Max(1, pagesPerFile);
            startConfig["totalFiles"] = files.Count;
            if (pageRects != null) { startConfig["pageRects"] = pageRects; }

            string started = form.Engine.Call("ANP_vdpCombineStartV86", new string[] { serializer.Serialize(startConfig) });
            Dictionary<string, object> startData = serializer.Deserialize<Dictionary<string, object>>(started ?? "{}");
            object okObject;
            if (!startData.TryGetValue("ok", out okObject) || !Convert.ToBoolean(okObject))
            {
                throw new InvalidOperationException(startData.ContainsKey("error") ? Convert.ToString(startData["error"]) : "Không khởi tạo được DPV Combine.");
            }

            try
            {
                for (int i = 0; i < files.Count; i++)
                {
                    string path = Path.GetFullPath(files[i]);
                    if (!File.Exists(path)) { throw new FileNotFoundException("Không tìm thấy PDF cần gộp.", path); }
                    string step = form.Engine.Call("ANP_vdpCombineAddV86", new string[] { path });
                    Dictionary<string, object> stepData = serializer.Deserialize<Dictionary<string, object>>(step ?? "{}");
                    object stepOk;
                    if (!stepData.TryGetValue("ok", out stepOk) || !Convert.ToBoolean(stepOk))
                    {
                        throw new InvalidOperationException(stepData.ContainsKey("error") ? Convert.ToString(stepData["error"]) : "DPV Combine lỗi tại PDF thứ " + (i + 1).ToString() + ".");
                    }
                    if (!String.IsNullOrEmpty(progressOperation)) { form.PushResult(progressOperation, step); }
                    Thread.Sleep(12);
                }

                string finished = form.Engine.Call("ANP_vdpCombineFinishV86", new string[0]);
                Dictionary<string, object> result = serializer.Deserialize<Dictionary<string, object>>(finished ?? "{}");
                object finishOk;
                if (!result.TryGetValue("ok", out finishOk) || !Convert.ToBoolean(finishOk))
                {
                    throw new InvalidOperationException(result.ContainsKey("error") ? Convert.ToString(result["error"]) : "DPV Combine không lưu được PDF cuối.");
                }
                return result;
            }
            catch
            {
                try { form.Engine.Call("ANP_vdpCombineAbortV86", new string[0]); } catch { }
                throw;
            }
        }

        public void CombinePdfFilesDpv()
        {
            long now = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond;
            if (combineDialogOpen) { return; }
            if (combineDialogClosedAt > 0 && now - combineDialogClosedAt < 900) { return; }
            combineDialogOpen = true;
            try
            {
            string[] files;
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Chọn PDF cần Combine trực tiếp trong DPV®";
                dialog.Filter = "PDF|*.pdf|Tất cả file|*.*";
                dialog.Multiselect = true;
                if (dialog.ShowDialog(form) != DialogResult.OK) { form.PushResult("vdpCombineExisting", ""); return; }
                files = dialog.FileNames;
            }
            if (files == null || files.Length < 1) { form.PushResult("vdpCombineExisting", ""); return; }

            string output;
            using (SaveFileDialog save = new SaveFileDialog())
            {
                save.Title = "Lưu PDF Combine - DPV®";
                save.Filter = "PDF|*.pdf";
                save.DefaultExt = "pdf";
                save.AddExtension = true;
                save.FileName = "COMBINED.pdf";
                try { save.InitialDirectory = Path.GetDirectoryName(files[0]); } catch { }
                if (save.ShowDialog(form) != DialogResult.OK) { form.PushResult("vdpCombineExisting", ""); return; }
                output = save.FileName;
            }

            List<string> ordered = new List<string>(files);
            ordered.Sort(new NaturalPdfComparer());
            form.RunIllustrator("vdpCombineExisting", delegate
            {
                try
                {
                    Dictionary<string, object> merged = MergePdfFilesInsideDpv(ordered, output, 1, null, "vdpCombineProgress");
                    return serializer.Serialize(merged);
                }
                catch (Exception ex) { return JsonBatchError(ex.Message); }
            });
            }
            finally { combineDialogOpen = false; combineDialogClosedAt = DateTime.UtcNow.Ticks / TimeSpan.TicksPerMillisecond; }
        }

        private Dictionary<string, object> MergePdfFilesWithAcrobat(IList<string> files, string outputPath)
        {
            Dictionary<string, object> result = new Dictionary<string, object>();
            object acroApp = null;
            object destination = null;
            object source = null;
            int totalPages = 0;
            try
            {
                if (files == null || files.Count < 1) { throw new InvalidOperationException("Không có PDF để gộp."); }
                Type appType = Type.GetTypeFromProgID("AcroExch.App");
                Type docType = Type.GetTypeFromProgID("AcroExch.PDDoc");
                if (appType == null || docType == null)
                {
                    throw new InvalidOperationException("Không tìm thấy Adobe Acrobat Standard/Pro. Chức năng Combine dùng Acrobat COM và không chạy với máy chỉ có Reader.");
                }

                string outputFullPath = Path.GetFullPath(outputPath);
                string outputDir = Path.GetDirectoryName(outputFullPath) ?? "";
                if (!Directory.Exists(outputDir)) { Directory.CreateDirectory(outputDir); }
                if (File.Exists(outputFullPath)) { File.Delete(outputFullPath); }

                acroApp = Activator.CreateInstance(appType);
                try { AcrobatInvoke(acroApp, "Hide"); } catch { }

                destination = Activator.CreateInstance(docType);
                string first = Path.GetFullPath(files[0]);
                if (!File.Exists(first)) { throw new FileNotFoundException("Không tìm thấy PDF đầu tiên.", first); }
                if (!AcrobatBool(AcrobatInvoke(destination, "Open", first)))
                {
                    throw new InvalidOperationException("Acrobat không mở được PDF: " + first);
                }
                totalPages = Convert.ToInt32(AcrobatInvoke(destination, "GetNumPages"));

                for (int i = 1; i < files.Count; i++)
                {
                    string path = Path.GetFullPath(files[i]);
                    if (!File.Exists(path)) { throw new FileNotFoundException("Không tìm thấy PDF record.", path); }
                    source = Activator.CreateInstance(docType);
                    if (!AcrobatBool(AcrobatInvoke(source, "Open", path)))
                    {
                        throw new InvalidOperationException("Acrobat không mở được PDF: " + path);
                    }
                    int sourcePages = Convert.ToInt32(AcrobatInvoke(source, "GetNumPages"));
                    int insertAfter = Convert.ToInt32(AcrobatInvoke(destination, "GetNumPages")) - 1;
                    if (!AcrobatBool(AcrobatInvoke(destination, "InsertPages", insertAfter, source, 0, sourcePages, 0)))
                    {
                        throw new InvalidOperationException("Acrobat không chèn được PDF thứ " + (i + 1).ToString() + ". Hãy dùng Adobe Acrobat Standard/Pro; Reader không hỗ trợ chỉnh sửa/gộp trang qua COM.");
                    }
                    totalPages += sourcePages;
                    try { AcrobatInvoke(source, "Close"); } catch { }
                    if (Marshal.IsComObject(source)) { Marshal.FinalReleaseComObject(source); }
                    source = null;
                }

                // PDSaveFull = 1. Save As sang file mới, không sửa PDF record đầu tiên.
                if (!AcrobatBool(AcrobatInvoke(destination, "Save", 1, outputFullPath)))
                {
                    throw new InvalidOperationException("Acrobat không lưu được file PDF gộp: " + outputFullPath);
                }

                result["ok"] = true;
                result["combinedFile"] = outputFullPath;
                result["combinedPages"] = totalPages;
                result["combinedCount"] = files.Count;
                result["combineEngine"] = "Adobe Acrobat COM";
                return result;
            }
            finally
            {
                try { if (source != null) { AcrobatInvoke(source, "Close"); } } catch { }
                try { if (destination != null) { AcrobatInvoke(destination, "Close"); } } catch { }
                try { if (acroApp != null) { AcrobatInvoke(acroApp, "Exit"); } } catch { }
                try { if (source != null && Marshal.IsComObject(source)) { Marshal.FinalReleaseComObject(source); } } catch { }
                try { if (destination != null && Marshal.IsComObject(destination)) { Marshal.FinalReleaseComObject(destination); } } catch { }
                try { if (acroApp != null && Marshal.IsComObject(acroApp)) { Marshal.FinalReleaseComObject(acroApp); } } catch { }
            }
        }

        public string CombinePdfFilesAcrobat()
        {
            try
            {
                string[] files;
                using (OpenFileDialog dialog = new OpenFileDialog())
                {
                    dialog.Title = "Chọn các PDF cần gộp - DPV®";
                    dialog.Filter = "PDF|*.pdf|Tất cả file|*.*";
                    dialog.Multiselect = true;
                    if (dialog.ShowDialog(form) != DialogResult.OK) { return ""; }
                    files = dialog.FileNames;
                }
                if (files == null || files.Length < 1) { return ""; }

                string output;
                using (SaveFileDialog save = new SaveFileDialog())
                {
                    save.Title = "Lưu PDF gộp - DPV®";
                    save.Filter = "PDF|*.pdf";
                    save.DefaultExt = "pdf";
                    save.AddExtension = true;
                    save.FileName = "COMBINED.pdf";
                    try { save.InitialDirectory = Path.GetDirectoryName(files[0]); } catch { }
                    if (save.ShowDialog(form) != DialogResult.OK) { return ""; }
                    output = save.FileName;
                }

                List<string> ordered = new List<string>(files);
                Dictionary<string, object> merged = MergePdfFilesWithAcrobat(ordered, output);
                return serializer.Serialize(merged);
            }
            catch (Exception ex)
            {
                return JsonBatchError(ex.Message);
            }
        }

        public void BuildVariableData(string configJson)
        {
            form.RunIllustrator("vdpBuild", delegate
            {
                string started = "";
                try
                {
                    Dictionary<string, object> config = serializer.Deserialize<Dictionary<string, object>>(configJson ?? "{}");
                    object combineObject;
                    bool combineAfterExport = config.TryGetValue("combinePdf", out combineObject) && Convert.ToBoolean(combineObject);
                    string combinedName = config.ContainsKey("combinedName") ? Convert.ToString(config["combinedName"]) : "VDP_ALL";

                    object sheetModeObject, sheetCombineObject;
                    bool sheetMode = config.TryGetValue("sheetMode", out sheetModeObject) && Convert.ToBoolean(sheetModeObject);
                    bool combineSheetsAfterExport = sheetMode && config.TryGetValue("combineSheets", out sheetCombineObject) && Convert.ToBoolean(sheetCombineObject);
                    string sheetCombinedName = config.ContainsKey("sheetCombinedName") ? Convert.ToString(config["sheetCombinedName"]) : "VDP_ALL_SHEETS";

                    // V123: không giữ document Combine sheet mở trong suốt batch VDP.
                    // Illustrator chỉ render từng tờ trước. Sau khi batch đã đóng work-copy,
                    // DPV mới Combine các PDF tờ bằng engine V86. Cách này nhẹ RAM và tránh
                    // artboard merge bị lệch khi document khác liên tục được tạo/đóng.
                    if (combineSheetsAfterExport)
                    {
                        config["combineSheets"] = false;
                    }

                    // V86: record mode cũng Combine sau export để ổn định hơn.
                    if (combineAfterExport)
                    {
                        config["exportIndividual"] = true;
                        config["combinePdf"] = false;
                    }
                    string illustratorConfigJson = serializer.Serialize(config);

                    started = form.Engine.Call("ANP_vdpBatchStartV79", new string[] { illustratorConfigJson });
                    Dictionary<string, object> startData = serializer.Deserialize<Dictionary<string, object>>(started ?? "{}");
                    object okObject;
                    bool ok = startData.TryGetValue("ok", out okObject) && Convert.ToBoolean(okObject);
                    if (!ok) { return started; }
                    object totalObject;
                    int total = startData.TryGetValue("total", out totalObject) ? Convert.ToInt32(totalObject) : 0;
                    if (total < 1)
                    {
                        try { form.Engine.Call("ANP_vdpBatchAbortV79", new string[0]); } catch { }
                        return JsonBatchError("Không có record để chạy VDP.");
                    }
                    for (int i = 0; i < total; i++)
                    {
                        string step = form.Engine.Call("ANP_vdpBatchStepV79", new string[0]);
                        Dictionary<string, object> stepData = serializer.Deserialize<Dictionary<string, object>>(step ?? "{}");
                        object stepOkObject;
                        bool stepOk = stepData.TryGetValue("ok", out stepOkObject) && Convert.ToBoolean(stepOkObject);
                        if (!stepOk)
                        {
                            try { form.Engine.Call("ANP_vdpBatchAbortV79", new string[0]); } catch { }
                            return step;
                        }
                        form.PushResult("vdpBuildProgress", step);
                        Thread.Sleep(20);
                    }

                    string finished = form.Engine.Call("ANP_vdpBatchFinishV79", new string[0]);
                    if (!combineAfterExport && !combineSheetsAfterExport) { return finished; }

                    Dictionary<string, object> finalData = serializer.Deserialize<Dictionary<string, object>>(finished ?? "{}");
                    object finalOkObject;
                    bool finalOk = finalData.TryGetValue("ok", out finalOkObject) && Convert.ToBoolean(finalOkObject);
                    if (!finalOk) { return finished; }

                    if (combineAfterExport)
                    {
                        object createdObject;
                        string[] created = finalData.TryGetValue("created", out createdObject) ? serializer.ConvertToType<string[]>(createdObject) : new string[0];
                        if (created == null || created.Length < 1)
                        {
                            return JsonBatchError("Đã xuất record nhưng không nhận được danh sách PDF để Combine.");
                        }
                        object folderObject;
                        string outputFolder = finalData.TryGetValue("outputFolder", out folderObject) ? Convert.ToString(folderObject) : Path.GetDirectoryName(created[0]);
                        string combinedPath = UniquePdfPath(outputFolder, combinedName);

                        object pagesPerRecordObject;
                        int pagesPerRecord = finalData.TryGetValue("pagesPerRecord", out pagesPerRecordObject) ? Math.Max(1, Convert.ToInt32(pagesPerRecordObject)) : 1;
                        object pageRectsObject;
                        finalData.TryGetValue("pageRects", out pageRectsObject);
                        Dictionary<string, object> mergeData = MergePdfFilesInsideDpv(new List<string>(created), combinedPath, pagesPerRecord, pageRectsObject, "vdpCombineProgress");
                        finalData["combinedFile"] = mergeData["combinedFile"];
                        finalData["combinedPages"] = mergeData["combinedPages"];
                        finalData["combinedCount"] = mergeData["combinedCount"];
                        finalData["combineEngine"] = mergeData["combineEngine"];
                        finalData["externalCombine"] = false;
                        finalData["fastMode"] = "RECORD_PDF_THEN_DPV_COMBINE_V86";
                    }

                    if (combineSheetsAfterExport)
                    {
                        object sheetFilesObject;
                        string[] sheetFiles = finalData.TryGetValue("sheetFiles", out sheetFilesObject) ? serializer.ConvertToType<string[]>(sheetFilesObject) : new string[0];
                        if (sheetFiles == null || sheetFiles.Length < 1)
                        {
                            return JsonBatchError("VDP Sheet đã render xong nhưng không nhận được danh sách PDF tờ để Combine.");
                        }
                        object sheetFolderObject;
                        string sheetFolder = finalData.TryGetValue("sheetOutputFolder", out sheetFolderObject) ? Convert.ToString(sheetFolderObject) : Path.GetDirectoryName(sheetFiles[0]);
                        if (String.IsNullOrWhiteSpace(sheetFolder)) { sheetFolder = Path.GetDirectoryName(sheetFiles[0]); }
                        string sheetCombinedPath = UniquePdfPath(sheetFolder, sheetCombinedName);

                        // V125: Combine Sheet KHÔNG được đo khổ từ geometricBounds của artwork.
                        // Lấy trực tiếp paperW/paperH từ cấu hình Dàn file và truyền pageRects
                        // cố định sang engine Combine. Nhờ vậy 330x390 vẫn chính xác 330x390.
                        int sheetPagesPerFile = 1;
                        object sheetPageRects = null;
                        try
                        {
                            Dictionary<string, object> sheetConfigData = null;
                            object sheetConfigObject;
                            if (config.TryGetValue("sheetConfig", out sheetConfigObject))
                            {
                                sheetConfigData = sheetConfigObject as Dictionary<string, object>;
                                if (sheetConfigData == null) { sheetConfigData = serializer.ConvertToType<Dictionary<string, object>>(sheetConfigObject); }
                            }
                            if (sheetConfigData != null)
                            {
                                double paperWmm = sheetConfigData.ContainsKey("paperW") ? Convert.ToDouble(sheetConfigData["paperW"]) : 0.0;
                                double paperHmm = sheetConfigData.ContainsKey("paperH") ? Convert.ToDouble(sheetConfigData["paperH"]) : 0.0;
                                bool duplexSheet = sheetConfigData.ContainsKey("duplexMode") && Convert.ToBoolean(sheetConfigData["duplexMode"]);
                                sheetPagesPerFile = duplexSheet ? 2 : 1;
                                if (paperWmm > 0.0 && paperHmm > 0.0)
                                {
                                    double mmToPt = 72.0 / 25.4;
                                    object[] rects = new object[sheetPagesPerFile];
                                    for (int ri = 0; ri < sheetPagesPerFile; ri++)
                                    {
                                        rects[ri] = new object[] { 0.0, paperHmm * mmToPt, paperWmm * mmToPt, 0.0 };
                                    }
                                    sheetPageRects = rects;
                                }
                            }
                        }
                        catch { sheetPagesPerFile = 1; sheetPageRects = null; }

                        Dictionary<string, object> sheetMergeData = MergePdfFilesInsideDpv(new List<string>(sheetFiles), sheetCombinedPath, sheetPagesPerFile, sheetPageRects, "vdpCombineProgress");
                        finalData["sheetCombinedFile"] = sheetMergeData["combinedFile"];
                        finalData["sheetCombinedPages"] = sheetMergeData["combinedPages"];
                        finalData["sheetCombineEngine"] = sheetMergeData["combineEngine"];
                        finalData["sheetCombineDeferred"] = true;
                        finalData["sheetPagesPerFile"] = sheetPagesPerFile;
                        finalData["fastMode"] = "VDP_SHEET_FIXED_PAPER_COMBINE_V125";
                    }
                    return serializer.Serialize(finalData);
                }
                catch (Exception ex)
                {
                    try { form.Engine.Call("ANP_vdpBatchAbortV79", new string[0]); } catch { }
                    return JsonBatchError(ex.Message);
                }
                finally
                {
                    // V127: luôn yêu cầu Bridge kích hoạt/reopen đúng file AI nguồn
                    // sau VDP, kể cả khi Combine hoặc batch gặp lỗi.
                    try { form.Engine.Call("ANP_vdpEnsurePinnedSourceOpenV127", new string[0]); } catch { }
                }
            });
        }

        private string JsonBatchError(string message)
        {
            Dictionary<string, object> data = new Dictionary<string, object>();
            data["ok"] = false; data["error"] = message; return serializer.Serialize(data);
        }

        public void PreviewInIllustrator(string configJson, string mode)
        {
            form.RunIllustrator("hostPreview", delegate
            {
                string fn = mode == "artboards" ? "ANP_v12Preview" : "ANP_v11Preview";
                return form.Engine.Call(fn, new string[] { configJson ?? "{}" });
            });
        }

        public void OpenDiePreview(string configJson)
        {
            form.RunIllustrator("diePreview", delegate
            {
                return form.Engine.Call("ANP_v14DiePreview", new string[] { configJson ?? "{}" });
            });
        }

        public void OpenManualDiePreview(string configJson)
        {
            form.RunIllustrator("diePreview", delegate
            {
                return form.Engine.Call("ANP_v15ManualDiePreview", new string[] { configJson ?? "{}" });
            });
        }

        public void Build(string configJson, string mode)
        {
            form.RunIllustrator("build", delegate
            {
                string fn = mode == "artboards" ? "ANP_v12Build" : "ANP_v11Build";
                return form.Engine.Call(fn, new string[] { configJson ?? "{}" });
            });
        }

        public string AppVersion() { return "0.1.25-v1492-jobqueue-diag"; }
    }

    internal sealed class IllustratorEngine
    {
        private const string BridgeVersion = "0.1.24-v1491-native-batch-cache";
        private readonly string hostPath;
        private readonly JavaScriptSerializer serializer = new JavaScriptSerializer();
        // V127: giữ một COM reference sống trong suốt phiên DPV. Illustrator là
        // out-of-proc COM server; sau VDP batch có rất nhiều document tạm bị đóng.
        // Giữ reference này tránh trường hợp Illustrator tự kết thúc khi reference
        // cuối cùng của một Call ngắn được Release ngay sau batch.
        private object illustratorKeepAlive = null;
        private readonly object illustratorKeepAliveLock = new object();
        // Chặn riêng hiện tượng WebBrowser phát lại click sau khi hộp thoại PON đóng.
        // lastPonPath giúp lần gọi lặp nhận lại đúng file vừa chọn thay vì mở dialog lần 2
        // hoặc trả chuỗi rỗng làm UI không hiện đường dẫn.
        private bool ponDialogOpen = false;
        private long ponDialogClosedAt = 0;
        private string lastPonPath = "";

        internal IllustratorEngine(string appRoot)
        {
            hostPath = Path.Combine(appRoot, "bridge", "host_bundle.jsx");
        }

        private void PinIllustratorKeepAlive(object app)
        {
            if (app == null) { return; }
            lock (illustratorKeepAliveLock)
            {
                if (illustratorKeepAlive == null) { illustratorKeepAlive = app; }
            }
        }

        private bool IsKeepAliveObject(object app)
        {
            lock (illustratorKeepAliveLock) { return app != null && Object.ReferenceEquals(app, illustratorKeepAlive); }
        }

        internal string Ping(bool launchIfNeeded)
        {
            object app = null;
            try
            {
                app = GetIllustrator(launchIfNeeded);
                PinIllustratorKeepAlive(app);
                object version = GetProperty(app, "Version");
                object name = GetProperty(app, "Name");
                Dictionary<string, object> result = new Dictionary<string, object>();
                result["ok"] = true;
                result["connected"] = true;
                result["name"] = Convert.ToString(name);
                result["version"] = Convert.ToString(version);
                return serializer.Serialize(result);
            }
            finally { if (!IsKeepAliveObject(app)) { Release(app); } }
        }

        internal string Call(string functionName, string[] stringArguments)
        {
            if (!Allowed(functionName)) { throw new InvalidOperationException("Lệnh Bridge không hợp lệ: " + functionName); }
            if (!File.Exists(hostPath)) { throw new FileNotFoundException("Không tìm thấy Illustrator Bridge.", hostPath); }

            object app = null;
            try
            {
                app = GetIllustrator(false);
                PinIllustratorKeepAlive(app);
                string normalized = hostPath.Replace('\\', '/');
                string script = "#target illustrator\n#targetengine \"VDPROBridge\"\n" +
                    "if (typeof VDPRO_BRIDGE_VERSION === 'undefined' || VDPRO_BRIDGE_VERSION !== " + JsQuote(BridgeVersion) +
                    " || typeof " + functionName + " !== 'function') { $.evalFile(new File(" + JsQuote(normalized) + ")); }\n" +
                    "if (typeof " + functionName + " !== 'function') { throw new Error('DPV Bridge chua nap du ham " + functionName + "'); }\n" +
                    "var __vdpro_result = " + functionName + "(" + JoinArguments(stringArguments) + ");\n" +
                    "__vdpro_result;";
                object raw = DoJavaScript(app, script);
                string result = raw == null ? "" : Convert.ToString(raw);
                if (String.IsNullOrWhiteSpace(result)) { throw new InvalidOperationException("Illustrator không trả dữ liệu về DPV®."); }
                return result;
            }
            finally { if (!IsKeepAliveObject(app)) { Release(app); } }
        }

        private static bool Allowed(string name)
        {
            return name == "ANP_activeSourceV11" || name == "ANP_manualSourceV11" ||
                name == "ANP_inspectSources" || name == "ANP_listArtboardsV12" ||
                name == "ANP_v11Preview" || name == "ANP_v12Preview" ||
                name == "ANP_v14DiePreview" || name == "ANP_v15ManualDiePreview" ||
                name == "ANP_v11Build" || name == "ANP_v12Build" ||
                name == "ANP_vdpSelectionV71" || name == "ANP_vdpPreviewV71" ||
                name == "ANP_vdpRestoreV71" || name == "ANP_vdpBuildV71" ||
                name == "ANP_vdpBatchStartV79" || name == "ANP_vdpBatchStepV79" ||
                name == "ANP_vdpBatchFinishV79" || name == "ANP_vdpBatchAbortV79" ||
                name == "ANP_vdpCombineStartV86" || name == "ANP_vdpCombineAddV86" ||
                name == "ANP_vdpCombineFinishV86" || name == "ANP_vdpCombineAbortV86" ||
                name == "ANP_vdpEnsurePinnedSourceOpenV127";
        }

        private static string JoinArguments(string[] args)
        {
            if (args == null || args.Length == 0) { return ""; }
            string[] quoted = new string[args.Length];
            for (int i = 0; i < args.Length; i++) { quoted[i] = JsQuote(args[i]); }
            return String.Join(",", quoted);
        }

        private static string JsQuote(string value)
        {
            value = value ?? "";
            return "'" + value.Replace("\\", "\\\\").Replace("'", "\\'")
                .Replace("\r", "\\r").Replace("\n", "\\n") + "'";
        }

        private static object GetIllustrator(bool launchIfNeeded)
        {
            // A direct ROT lookup can wait forever when Illustrator is busy or has
            // not finished publishing its COM object.  An explicit user connection
            // therefore goes through COM activation first. Illustrator is a
            // single-instance local server, so this attaches to the running app or
            // launches the installed version without blocking on GetActiveObject.
            if (launchIfNeeded)
            {
                Exception last = null;
                string[] progIds = new string[] {
                    "Illustrator.Application",
                    "Illustrator.Application.30",
                    "Illustrator.Application.29",
                    "Illustrator.Application.28"
                };
                for (int i = 0; i < progIds.Length; i++)
                {
                    try
                    {
                        Type type = Type.GetTypeFromProgID(progIds[i], false);
                        if (type != null) { return Activator.CreateInstance(type); }
                    }
                    catch (Exception ex) { last = ex; }
                }
                string detail = last == null ? "COM chưa được đăng ký." : CleanComMessage(last.Message);
                throw new InvalidOperationException(
                    "Không mở được Illustrator 2024–2026 qua COM. Hãy mở Illustrator trước, đóng hộp thoại đang chờ trong Illustrator và chạy DPV cùng quyền với Illustrator. " + detail);
            }

            try { return Marshal.GetActiveObject("Illustrator.Application"); }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    "Chưa nhận được Illustrator đang mở. Hãy chờ Illustrator khởi động xong rồi bấm Kết nối. " + CleanComMessage(ex.Message));
            }
        }

        private static string CleanComMessage(string message)
        {
            string value = String.IsNullOrWhiteSpace(message) ? "" : message.Trim();
            if (value.Length > 180) { value = value.Substring(0, 180) + "…"; }
            return value;
        }

        private static object GetProperty(object target, string property)
        {
            return target.GetType().InvokeMember(property, BindingFlags.GetProperty, null, target, null);
        }

        private static object DoJavaScript(object app, string script)
        {
            BindingFlags flags = BindingFlags.InvokeMethod | BindingFlags.OptionalParamBinding;
            try
            {
                return app.GetType().InvokeMember("DoJavaScript", flags, null, app, new object[] { script });
            }
            catch
            {
                return app.GetType().InvokeMember("DoJavaScript", flags, null, app,
                    new object[] { script, Type.Missing, Type.Missing });
            }
        }

        private static void Release(object comObject)
        {
            try { if (comObject != null && Marshal.IsComObject(comObject)) { Marshal.ReleaseComObject(comObject); } }
            catch { }
        }
    }
}
