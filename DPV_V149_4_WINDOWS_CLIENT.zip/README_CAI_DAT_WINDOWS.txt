DPV V134 SIMPLE INSTALL - WINDOWS

CACH CAI:
1. Chuot phai file ZIP -> Extract All...
2. Mo thu muc vua giai nen.
3. Double-click: CAI_DPV_WINDOWS.bat
4. Cho den khi hien CAI DAT HOAN TAT.

QUAN TRONG:
- KHONG mo file BAT truc tiep khi dang xem noi dung ben trong ZIP.
- Goi nay khong long them ZIP Windows/Mac ben trong, giong cach dong goi cac ban cu.
- Neu Windows hoi SmartScreen, chon More info -> Run anyway (neu co).

Ban nay giu V132 Mixed Rotation Safe + V133 Number Sequence va cac fix VDP/Duplex/QR/Manual Preview hien tai.
