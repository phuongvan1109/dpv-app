@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "AUTH_URL=%~1"
if "%AUTH_URL%"=="" (
  echo.
  echo Nhap URL Cloudflare Worker, vi du: https://dpv-auth-free.tenban.workers.dev
  set /p "AUTH_URL=URL: "
)
if "%AUTH_URL%"=="" exit /b 1
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$u='%AUTH_URL%'.Trim().TrimEnd('/'); try{$uri=[uri]$u}catch{Write-Error 'URL khong hop le';exit 2}; if($uri.Scheme -ne 'https' -and $uri.Host -notin @('127.0.0.1','localhost')){Write-Error 'Production bat buoc HTTPS';exit 3}; $cfg=Join-Path '%~dp0' 'app\ui\dpv_auth_config.js'; $src=Join-Path '%~dp0' 'src\VDPRO.cs'; $c=Get-Content -Raw -LiteralPath $cfg; $c=[regex]::Replace($c,'serverUrl:\s*\"[^\"]*\"','serverUrl: \"'+$u+'\"',1); [IO.File]::WriteAllText($cfg,$c,(New-Object Text.UTF8Encoding($false))); $s=Get-Content -Raw -LiteralPath $src; $s=[regex]::Replace($s,'private const string TrustedAuthHost = \"[^\"]*\";','private const string TrustedAuthHost = \"'+$uri.Host+'\";',1); [IO.File]::WriteAllText($src,$s,(New-Object Text.UTF8Encoding($false))); Write-Host ('Da gan server: '+$u); Write-Host ('Da khoa TrustedAuthHost: '+$uri.Host)"
if errorlevel 1 (
  echo Cau hinh that bai.
  pause
  exit /b 1
)
echo.
echo Hoan tat. Bay gio chay CAI_DPV_V148_1_WINDOWS.bat de compile va cai ban da khoa domain.
pause
