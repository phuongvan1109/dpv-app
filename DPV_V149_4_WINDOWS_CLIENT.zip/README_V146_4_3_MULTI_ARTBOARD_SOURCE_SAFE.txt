DPV V146.4.3 – MULTI ARTBOARD SOURCE SAFE

Built from V146.4.2 stable base.
The stable engine already supports multiple artboards. This patch exposes it clearly in the Source panel without modifying Core/Bridge.

New UI:
- Lấy nhiều artboard đang mở
- Tất cả artboard + KHUON_BE
- Chọn artboard renamed to Chọn nhiều artboard

Each selected artboard is treated as a separate source. DPV auto-detects KHUON_BE per artboard and falls back to artboard bounds when needed.
