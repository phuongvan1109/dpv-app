DPV V92 MODERN UI — WINDOWS

Cài đặt:
1. Giải nén toàn bộ ZIP.
2. Vào thư mục Windows.
3. Chạy install_windows.bat.
4. Mở Illustrator trước rồi mở DPV trên Desktop.

V92 chỉ thay lớp giao diện/shell và cache file UI. Engine dàn V87 được giữ nguyên để hạn chế phát sinh lỗi thuật toán.
