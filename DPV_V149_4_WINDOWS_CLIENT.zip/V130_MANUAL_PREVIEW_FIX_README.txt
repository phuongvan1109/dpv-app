DPV V130 MANUAL PREVIEW FIX

Fix: Nhập kích thước tem → View khuôn trực tiếp qua Illustrator báo “undefined is not an object”.

Nguyên nhân: UI đã có layout V101 đúng nhưng chế độ manual không gửi Layout Cache sang Illustrator; AI chạy lại solver ExtendScript và có thể trả layout undefined.

V130:
- Manual mode cũng gửi Layout Cache V101 x/y/w/h sang Illustrator.
- Illustrator chỉ dựng vector preview từ cache; không chạy solver lần hai.
- PON / CATTP vẫn theo cấu hình hiện tại.
- Có diagnostic theo từng stage nếu Illustrator còn lỗi.
- Không thay thuật toán Core V101.
