DPV® V144 — PRODUCTION PLANNER SAFE · CORE V101 STABLE
======================================================

MỤC TIÊU
- Thêm công cụ tính sản xuất và so sánh layout mà KHÔNG thay Core/Bridge/VDP/Cut & Stack/Duplex/Recovery.
- Stable base: V143.1 Recovery Startup Safe.

VỊ TRÍ
Dàn file → cột "Điều khiển và xem trước" → card "PRODUCTION PLANNER · V144 SAFE".

CHỨC NĂNG
1) Production Calculator
- Số lượng thành phẩm cần.
- Hao hụt dự kiến (%).
- Giá vật liệu / tờ.
- Chi phí in / tờ.
- Chi phí cố định.
- Tự tính: con/tờ, tờ lý thuyết, tờ có bù hao, sản lượng, số dư, số mặt in, tổng diện tích vật liệu, diện tích hao theo hiệu suất layout, tổng chi phí, chi phí / thành phẩm.
- "Nếu +1 con/tờ": cho biết tăng thêm 1 con trên layout có giảm số tờ của job hiện tại hay không.

2) Layout Snapshot A/B/C
- Bấm Tính nhanh trên DPV® trước.
- Lưu A, thay thông số layout, Tính nhanh, lưu B/C.
- DPV so sánh theo số tờ cần cho sản lượng hiện tại; nếu hòa thì ưu tiên số con/tờ và hiệu suất.
- Nút "Áp dụng" chỉ phục hồi các setting layout của snapshot sau khi người dùng chủ động bấm; sau đó DPV Tính nhanh lại, KHÔNG Build Illustrator.

3) Copy tóm tắt sản xuất
- Copy thông tin layout + sản lượng + vật liệu + chi phí để gửi báo giá/ghi chú job.

AN TOÀN / ADDITIVE-ONLY
- Không override VDPROEngine.preview.
- Không override nút Tính nhanh / Build / Bridge / VDP.
- Không dùng MutationObserver trên BODY.
- Chỉ observer các node kết quả: previewCount / efficiency / previewMethod / previewDetails / modeLabel.
- Chỉ ghi localStorage key riêng V144.
- Không thay file runtime V143.1 cũ ngoài index.html thêm đúng 1 CSS loader + 1 JS loader.

LƯU Ý
- Hiệu suất/diện tích hao lấy từ kết quả layout DPV hiện tại. Với chế độ Artboard nhiều nhóm, DPV có thể hiển thị "Theo nhóm" nên diện tích hao sẽ để — thay vì đoán.
- Giá tiền là số người dùng nhập, DPV không gắn đơn vị tiền tệ cố định.

CÀI ĐẶT
- macOS Intel: chạy INSTALL_DPV_V144_MAC_INTEL.command (installer cũ vẫn được giữ nguyên).
- Windows: chạy CAI_DPV_V144_WINDOWS.bat (installer cũ vẫn được giữ nguyên).
