﻿@echo off
call "%~dp0INSTALL.cmd"
exit /b %errorlevel%
