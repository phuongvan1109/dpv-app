DPV V146.2 — QR PIPELINE HOTFIX SAFE

Mục tiêu:
- Sửa Preflight V141 báo giả "Action không được hỗ trợ: qrVector/code128Vector/ean13Vector".
- Sửa QR URL dài không tạo được: engine QR mới hỗ trợ Version 1–20, Level L, khoảng 858 byte UTF-8.
- Thêm nút "Preview mã record hiện tại trong Illustrator" ngay dưới card QR/Barcode.
- Restore Variable Data sẽ dọn các group QR/Code128/EAN13 do DPV sinh ra.

SAFE:
- Không sửa Core V101, packer, multipacker, True Shape, CSV Bridge, Cut & Stack, Duplex, Recovery, Planner, Job Preset.
- Code128 V146 và EAN-13 V146.1 vẫn delegate qua pipeline cũ nguyên trạng.
- Chỉ qrVector đi qua engine V146.2 mới.
