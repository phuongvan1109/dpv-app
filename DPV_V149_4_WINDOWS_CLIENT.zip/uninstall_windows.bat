@echo off
setlocal
set "VDP_TARGET=%LOCALAPPDATA%\DPV"
taskkill /IM DPV.exe /F >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desk=[Environment]::GetFolderPath('Desktop');$name='DPV'+[char]174;$links=@((Join-Path $desk ($name+'.lnk')),(Join-Path $desk 'DPV.lnk'));foreach($p in $links){if(Test-Path -LiteralPath $p){Remove-Item -LiteralPath $p -Force}}" >nul 2>&1
if exist "%VDP_TARGET%" rmdir /S /Q "%VDP_TARGET%"
echo Da go DPV(R) khoi may.
pause
endlocal
