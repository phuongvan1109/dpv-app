DPV V142.3 — DUPLEX NULL-SAFE HOTFIX

Mục tiêu duy nhất:
- Sửa lỗi Dàn 2 mặt AB / 2 artboard trả “null is not an object” trên một số Illustrator/macOS.

Nguyên tắc Stable-first:
- Không thay Core V101, solver, Exact Gap, Mixed Rotation, True Shape, PON/CATTP geometry, VDP, CSV Bridge, UUID mapping, SMART hay Cut & Stack.
- Đường Duplex V61 cũ vẫn chạy TRƯỚC.
- Chỉ khi Illustrator trả nhóm lỗi null/object-invalid, DPV mới fallback:
  1) dựng mặt A bằng pipeline 1 mặt ổn định;
  2) dựng mặt B với chính ANP_duplexLayoutV60 hiện tại;
  3) ghép 2 PDF thành đúng 1 PDF 2 trang A/B.
- Fallback tắt Auto PON/PON file ở 2 trang tạm, chỉ giữ PON CATTP như Duplex gốc.
- Mặt A giữ tiêu đề; mặt B không lặp tiêu đề.

Kết quả Build trả thêm duplexBuildMode:
- DIRECT_V61: đường cũ thành công.
- FALLBACK_2X1PAGE_V1423: đã tự chuyển sang đường an toàn.
