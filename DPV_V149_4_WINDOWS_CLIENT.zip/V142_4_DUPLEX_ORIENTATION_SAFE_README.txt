DPV V142.4 — DUPLEX ORIENTATION SAFE ADDITIVE

MỤC TIÊU:
- Sửa đúng case mặt B trong ảnh: các item mặt A ở 0° phải giữ 0° trên mặt B, không bị xoay ngược 180°.
- Vị trí vật lý A trái ↔ B phải vẫn giữ nguyên theo Duplex Mirror hiện tại.

CÁCH LÀM AN TOÀN:
- KHÔNG sửa Core V101.
- KHÔNG sửa host.jsx / host_bundle.jsx của V142.3.
- KHÔNG sửa Bridge, VDP, CSV, SMART, Cut & Stack.
- Chỉ thêm 1 JS + 1 CSS UI. Module dùng lại 3 mode Duplex đã có sẵn trong stable host.

3 KIỂU MẶT B:
1) Chuẩn AB / khuyến nghị: phản X + A 0° -> B 0°; 90° <-> 270°.
   Đây là kiểu đúng với vùng khoanh đỏ trong ảnh người dùng.
2) Giữ nguyên mọi góc: phản X, 0°->0°, 90°->90°, không xoay thêm.
3) Legacy 180°: phản X + xoay thêm 180°; giữ lại để tương thích job/máy cũ.

V142.4 mặc định UI mới về chế độ (1). Người dùng vẫn có thể chọn lại 180° bất kỳ lúc nào.
