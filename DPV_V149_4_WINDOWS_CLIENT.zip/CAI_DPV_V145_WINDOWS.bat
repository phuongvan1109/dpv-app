@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
set "DPV_SOURCE=%~dp0"
set "DPV_TARGET=%LOCALAPPDATA%\DPV"
set "DPV_EXE=%DPV_TARGET%\DPV.exe"
set "DPV_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%DPV_CSC%" set "DPV_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
echo.
echo ================================================
echo      DPV V145 JOB PRESET PRO SAFE - WINDOWS
echo      V144 STABLE BASE + ADDITIVE UI ONLY
echo ================================================
echo.
if not exist "%DPV_SOURCE%src\VDPRO.cs" (
  echo LOI: Khong tim thay src\VDPRO.cs. Hay Extract All ZIP truoc.
  pause
  exit /b 1
)
if not exist "%DPV_CSC%" (
  echo LOI: Khong tim thay .NET Framework 4.x compiler.
  pause
  exit /b 1
)
taskkill /IM DPV.exe /F >nul 2>&1
taskkill /IM VDPRO.exe /F >nul 2>&1
if not exist "%DPV_TARGET%" mkdir "%DPV_TARGET%"
xcopy "%DPV_SOURCE%app" "%DPV_TARGET%\app\" /E /I /Y /Q >nul
if errorlevel 1 goto COPY_ERROR
xcopy "%DPV_SOURCE%assets" "%DPV_TARGET%\assets\" /E /I /Y /Q >nul
if errorlevel 1 goto COPY_ERROR
xcopy "%DPV_SOURCE%bridge" "%DPV_TARGET%\bridge\" /E /I /Y /Q >nul
if errorlevel 1 goto COPY_ERROR
xcopy "%DPV_SOURCE%src" "%DPV_TARGET%\src\" /E /I /Y /Q >nul
if errorlevel 1 goto COPY_ERROR
for %%F in (README_VI.txt VERSION.txt V144_VERSION.txt V145_VERSION.txt VDP_SAMPLE.csv uninstall_windows.bat) do (
  if exist "%DPV_SOURCE%%%F" copy /Y "%DPV_SOURCE%%%F" "%DPV_TARGET%\%%F" >nul
)
"%DPV_CSC%" /nologo /codepage:65001 /target:winexe /platform:x64 /optimize+ ^
  /out:"%DPV_EXE%" ^
  /win32icon:"%DPV_TARGET%\assets\icon\DPV.ico" ^
  /reference:System.dll ^
  /reference:System.Core.dll ^
  /reference:System.Drawing.dll ^
  /reference:System.Windows.Forms.dll ^
  /reference:System.Web.Extensions.dll ^
  "%DPV_TARGET%\src\VDPRO.cs"
if errorlevel 1 goto COMPILE_ERROR
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell;$n='DPV'+[char]174;$p=Join-Path ([Environment]::GetFolderPath('Desktop')) ($n+'.lnk');$s=$w.CreateShortcut($p);$s.TargetPath='%DPV_EXE%';$s.WorkingDirectory='%DPV_TARGET%';$s.IconLocation='%DPV_EXE%,0';$s.Description=$n;$s.Save()" >nul 2>&1
echo.
echo CAI DAT V145 HOAN TAT.
start "" "%DPV_EXE%"
pause
exit /b 0
:COPY_ERROR
echo LOI SAO CHEP FILE. Hay giai nen ZIP vao thu muc ngan roi chay lai.
pause
exit /b 1
:COMPILE_ERROR
echo LOI TAO DPV.exe. Chup man hinh loi gui de kiem tra.
pause
exit /b 1
