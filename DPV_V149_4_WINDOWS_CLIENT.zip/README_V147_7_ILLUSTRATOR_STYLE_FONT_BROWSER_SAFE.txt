DPV V147.7 – ILLUSTRATOR-STYLE FONT BROWSER SAFE

Built from V147.6 stable base.
UI-only font browser upgrade for Barcode Studio.
- groups Illustrator fonts by Family
- displays Family count and styles
- searchable font list
- live "Sample" preview using installed family
- selecting a style writes its PostScript name back to the existing V147.5 font selector
- barcode engine / Bridge / QR / Code128 / EAN-13 remain unchanged
