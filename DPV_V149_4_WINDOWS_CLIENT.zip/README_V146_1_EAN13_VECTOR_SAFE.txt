DPV V146.1 - EAN-13 VECTOR SAFE

Stable base: DPV V146 QR & Barcode Vector Safe.

THÊM MỚI
- Action VDP: Barcode EAN-13 · Vector.
- Nhập 12 số: DPV tự tính check digit thứ 13.
- Nhập 13 số: DPV kiểm tra checksum; sai sẽ dừng với thông báo rõ.
- Vẽ barcode bằng path vector CMYK 100K, nền trắng, quiet zone 11/7 module.
- Tạo số đọc dưới mã và outline thành vector khi Illustrator cho phép.
- Kích thước mã lấy từ bounds của shape/placeholder đang map.

CÁCH DÙNG
1. Tạo rectangle làm placeholder trong Illustrator (khuyến nghị rộng >= 30 mm).
2. Chọn rectangle > Biến đổi dữ liệu > + Thêm vị trí đang chọn trong AI.
3. Chọn cột CSV chứa 12 hoặc 13 chữ số.
4. Action: Barcode EAN-13 · Vector.
5. Preview record trước, sau đó chạy VDP/VDP Sheet/Cut & Stack như cũ.

SAFE ADDITIVE
- Không sửa app_v146_qr_barcode_vector_safe.js.
- Không sửa Core V101 / packer / multipacker / True Shape / CSV Bridge / Cut & Stack / Duplex / Recovery / Planner / Job Preset.
- host.jsx và host_bundle.jsx chỉ APPEND wrapper V146.1 ở cuối; mọi action khác chuyển nguyên về handler V146 hiện có.

LƯU Ý
- EAN-13 chỉ nhận chữ số 0-9, giữ được số 0 ở đầu nếu CSV đọc giá trị như text.
- Không nên dùng Prefix/Suffix cho EAN-13 vì sẽ làm dữ liệu không còn đúng 12/13 chữ số.
- Nếu CSV/Excel tự biến mã dài thành số khoa học hoặc làm mất số 0 đầu, hãy định dạng cột là Text trước khi xuất CSV.
