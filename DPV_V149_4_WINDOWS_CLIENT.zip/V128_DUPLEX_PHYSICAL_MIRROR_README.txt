DPV V128 DUPLEX PHYSICAL MIRROR

FIX CHÍNH:
- Mặt A: record 1 ở cột trái.
- Mặt B: đúng record 1 phải sang cột phải cùng hàng.
- Công thức phản vị trí: xB = binW - (xA + widthCell).
- Y không đổi; offset X đảo dấu.
- Chế độ mặc định vẫn xoay mặt B đối đầu 180° như trước.
- Sửa cả Dàn file 2 mặt và VDP Sheet 2 mặt.

Không thay solver bố cục Core V101, Exact Gap, True-Shape, PON, CATTP hay VDP mapping.
