DPV V77 — FIDELITY + LEGACY UNITS

Bản này giữ các sửa lỗi VDP fidelity/artboard của V76, nhưng hoàn tác phần ép đơn vị Illustrator sang Millimeters.

Đã hoàn tác:
- DocumentPreset.units = Millimeters
- Hàm tạo document MM riêng của V76

Trở lại cơ chế cũ:
- app.documents.add(...)
- Illustrator dùng đơn vị document mặc định/original
- Engine DPV vẫn tính bằng point và dùng ANP_mm()/ANP_toMm() ở các vị trí cũ, không đổi thuật toán dàn.

Mục đích: tránh rủi ro thay đổi ruler unit ảnh hưởng workflow cũ nhưng vẫn giữ VDP fidelity của V76.
