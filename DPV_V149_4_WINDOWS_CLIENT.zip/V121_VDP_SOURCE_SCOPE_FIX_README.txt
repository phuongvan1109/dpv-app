DPV V121 VDP SOURCE SCOPE FIX

Fix gốc lỗi: "Card nguồn bị lệch phiên bản giao diện" khi CSV/TXT đã được nạp.
Nguyên nhân: khung thông tin CSV #vdpDataInfo dùng chung class .source-card với card Nguồn in, khiến Core V101 syncSources() đọc nhầm CSV thành nguồn dàn và tìm .src-w/.src-h không tồn tại.

V121:
- Core chỉ quét card nguồn bên trong #sourceList.
- Khung CSV đổi sang class riêng vdp-data-info-card.
- Không thay thuật toán dàn V101, PON, True-Shape, Exact Gap hay Bridge Illustrator.
