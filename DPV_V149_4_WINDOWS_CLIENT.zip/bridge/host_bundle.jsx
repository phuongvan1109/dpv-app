#target illustrator
#targetengine "VDPROBridge"

/* ===== bundled engines V97 PROFILE LOW-LAG ===== */
/* Auto Nest Pro - equal rectangle mixed-orientation packer (ES3 compatible). */
var ANPPacker = (function () {
    function n(v, d) {
        var x = Number(v);
        return isNaN(x) ? d : x;
    }

    function fitCount(space, size, gap) {
        if (size <= 0 || space + 0.0001 < size) { return 0; }
        return Math.floor((space + gap + 0.0001) / (size + gap));
    }

    function metrics(items) {
        var i, minX = 1e20, minY = 1e20, right = -1e20, bottom = -1e20;
        if (!items.length) { return { minX: 0, minY: 0, usedW: 0, usedH: 0 }; }
        for (i = 0; i < items.length; i++) {
            minX = Math.min(minX, items[i].x); minY = Math.min(minY, items[i].y);
            right = Math.max(right, items[i].x + items[i].w);
            bottom = Math.max(bottom, items[i].y + items[i].h);
        }
        return { minX: minX, minY: minY, usedW: right - minX, usedH: bottom - minY };
    }

    function trim(items, maxQty) {
        if (maxQty > 0 && items.length > maxQty) {
            return items.slice(0, maxQty);
        }
        return items;
    }

    function center(items, binW, binH, centerY) {
        var i, m = metrics(items);
        var dx = Math.max(0, (binW - m.usedW) / 2 - m.minX);
        var dy = centerY ? Math.max(0, (binH - m.usedH) / 2 - m.minY) : 0;
        for (i = 0; i < items.length; i++) {
            items[i].x += dx;
            items[i].y += dy;
        }
        m = metrics(items);
        return { items: items, usedW: m.usedW, usedH: m.usedH };
    }

    function columnCandidate(binW, binH, w, h, gx, gy, c0, c90, maxQty, cornerClear) {
        var rows0 = fitCount(binH, h, gy);
        var rows90 = fitCount(binH, w, gy);
        var specs = [];
        var i, j, x = 0, y, items = [];

        /* Taller-yield columns first; this creates the 3 horizontal + 1 vertical
           strip seen in common label imposition layouts. */
        /* Cột ngắn được chia đều ra hai mép; cột dài nằm giữa. */
        var outer = [], inner = [], half;
        var height0 = rows0 > 0 ? rows0 * h + (rows0 - 1) * gy : 0;
        var height90 = rows90 > 0 ? rows90 * w + (rows90 - 1) * gy : 0;
        if (cornerClear > 0 ? height90 < height0 : rows90 < rows0) {
            for (i = 0; i < c90; i++) { outer.push({ w: h, h: w, rows: rows90, r: true }); }
            for (i = 0; i < c0; i++) { inner.push({ w: w, h: h, rows: rows0, r: false }); }
        } else {
            for (i = 0; i < c0; i++) { outer.push({ w: w, h: h, rows: rows0, r: false }); }
            for (i = 0; i < c90; i++) { inner.push({ w: h, h: w, rows: rows90, r: true }); }
        }
        half = Math.ceil(outer.length / 2);
        specs = outer.slice(0, half).concat(inner).concat(outer.slice(half));

        for (i = 0; i < specs.length; i++) {
            /* Hai cột ngoài cùng chỉ dùng vùng giữa tờ. Nhờ vậy tem không lấn
               vào bốn vùng PON; các cột giữa vẫn được chạy hết chiều cao. */
            if (cornerClear > 0 && (i === 0 || i === specs.length - 1)) {
                specs[i].rows = Math.min(specs[i].rows,
                    fitCount(Math.max(0, binH - cornerClear * 2), specs[i].h, gy));
            }
            y = Math.max(0, (binH - (specs[i].rows * specs[i].h + (specs[i].rows - 1) * gy)) / 2);
            for (j = 0; j < specs[i].rows; j++) {
                items.push({ x: x, y: y, w: specs[i].w, h: specs[i].h, rotated: specs[i].r, angle: specs[i].r ? 90 : 0, offsetX:0, offsetY:0 });
                y += specs[i].h + gy;
            }
            x += specs[i].w + gx;
        }
        items = trim(items, maxQty);
        return center(items, binW, binH, false);
    }

    function rowCandidate(binW, binH, w, h, gx, gy, r0, r90, maxQty, cornerClear) {
        var cols0 = fitCount(binW, w, gx);
        var cols90 = fitCount(binW, h, gx);
        var specs = [];
        var i, j, x, y = 0, items = [];

        /* Hàng ngắn được chia đều lên trên/dưới, hàng dài nằm giữa. */
        var outer = [], inner = [], half;
        var width0 = cols0 > 0 ? cols0 * w + (cols0 - 1) * gx : 0;
        var width90 = cols90 > 0 ? cols90 * h + (cols90 - 1) * gx : 0;
        if (cornerClear > 0 ? width90 < width0 : cols90 < cols0) {
            for (i = 0; i < r90; i++) { outer.push({ w: h, h: w, cols: cols90, r: true }); }
            for (i = 0; i < r0; i++) { inner.push({ w: w, h: h, cols: cols0, r: false }); }
        } else {
            for (i = 0; i < r0; i++) { outer.push({ w: w, h: h, cols: cols0, r: false }); }
            for (i = 0; i < r90; i++) { inner.push({ w: h, h: w, cols: cols90, r: true }); }
        }
        half = Math.ceil(outer.length / 2);
        specs = outer.slice(0, half).concat(inner).concat(outer.slice(half));

        for (i = 0; i < specs.length; i++) {
            /* Hai hàng trên/dưới chừa phần trái/phải cho PON; các hàng giữa
               vẫn tận dụng toàn bộ chiều rộng vùng in. */
            if (cornerClear > 0 && (i === 0 || i === specs.length - 1)) {
                specs[i].cols = Math.min(specs[i].cols,
                    fitCount(Math.max(0, binW - cornerClear * 2), specs[i].w, gx));
            }
            x = Math.max(0, (binW - (specs[i].cols * specs[i].w + (specs[i].cols - 1) * gx)) / 2);
            for (j = 0; j < specs[i].cols; j++) {
                items.push({ x: x, y: y, w: specs[i].w, h: specs[i].h, rotated: specs[i].r, angle: specs[i].r ? 90 : 0, offsetX:0, offsetY:0 });
                x += specs[i].w + gx;
            }
            y += specs[i].h + gy;
        }
        items = trim(items, maxQty);
        return center(items, binW, binH, false);
    }

    function better(a, b, binW, binH) {
        if (!a) { return b; }
        if (!b) { return a; }
        if (b.items.length !== a.items.length) {
            return b.items.length > a.items.length ? b : a;
        }
        /* Tie-break: compact used area, then narrower layout. */
        var areaA = a.usedW * a.usedH;
        var areaB = b.usedW * b.usedH;
        if (Math.abs(areaA - areaB) > 0.001) { return areaB < areaA ? b : a; }
        return b.usedW < a.usedW ? b : a;
    }

    function pack(cfg) {
        var binW = n(cfg.binW, 0), binH = n(cfg.binH, 0);
        var w = n(cfg.itemW, 0), h = n(cfg.itemH, 0);
        var gx = Math.max(0, n(cfg.gapX, 0)), gy = Math.max(0, n(cfg.gapY, gx));
        var allowRotate = cfg.allowRotate !== false;
        var maxQty = Math.max(0, Math.floor(n(cfg.maxQty, 0)));
        var cornerClear = Math.max(0, n(cfg.cornerClear, 0));
        cornerClear = Math.min(cornerClear, Math.max(0, binW / 2), Math.max(0, binH / 2));
        var best = null, c0, c90, r0, r90, cand;
        var maxC0 = fitCount(binW, w, gx);
        var maxC90 = allowRotate ? fitCount(binW, h, gx) : 0;
        var maxR0 = fitCount(binH, h, gy);
        var maxR90 = allowRotate ? fitCount(binH, w, gy) : 0;

        if (binW <= 0 || binH <= 0 || w <= 0 || h <= 0) {
            return { items: [], count: 0, usedW: 0, usedH: 0, method: "invalid" };
        }

        /* Exhaustively evaluate every mixed column combination. */
        for (c0 = 0; c0 <= maxC0; c0++) {
            for (c90 = 0; c90 <= maxC90; c90++) {
                if (c0 + c90 === 0) { continue; }
                var usedW = c0 * w + c90 * h + (c0 + c90 - 1) * gx;
                if (usedW <= binW + 0.0001) {
                    cand = columnCandidate(binW, binH, w, h, gx, gy, c0, c90, maxQty, cornerClear);
                    cand.method = cornerClear > 0 ? "corner-safe-columns" : "mixed-columns";
                    best = better(best, cand, binW, binH);
                }
            }
        }

        /* Also evaluate horizontal shelf mixtures for wide/short press sheets. */
        for (r0 = 0; r0 <= maxR0; r0++) {
            for (r90 = 0; r90 <= maxR90; r90++) {
                if (r0 + r90 === 0) { continue; }
                var usedH = r0 * h + r90 * w + (r0 + r90 - 1) * gy;
                if (usedH <= binH + 0.0001) {
                    cand = rowCandidate(binW, binH, w, h, gx, gy, r0, r90, maxQty, cornerClear);
                    cand.method = cornerClear > 0 ? "corner-safe-rows" : "mixed-rows";
                    best = better(best, cand, binW, binH);
                }
            }
        }

        if (!best) { best = { items: [], usedW: 0, usedH: 0, method: "none" }; }
        best.count = best.items.length;
        best.efficiency = best.count * w * h / (binW * binH);
        best.cornerSafe = cornerClear > 0;
        best.cornerClear = cornerClear;
        return best;
    }

    return { pack: pack };
}());


/* Auto Nest Pro - MaxRects packer for multiple sizes (ES3 compatible). */
var ANPMultiPacker = (function () {
    function cloneRect(r) { return { x: r.x, y: r.y, w: r.w, h: r.h }; }

    function intersects(a, b) {
        return !(b.x >= a.x + a.w || b.x + b.w <= a.x || b.y >= a.y + a.h || b.y + b.h <= a.y);
    }

    function contains(a, b) {
        return b.x >= a.x && b.y >= a.y && b.x + b.w <= a.x + a.w && b.y + b.h <= a.y + a.h;
    }

    function splitFree(free, used) {
        var out = [];
        if (!intersects(free, used)) { out.push(cloneRect(free)); return out; }
        if (used.x > free.x) { out.push({ x: free.x, y: free.y, w: used.x - free.x, h: free.h }); }
        if (used.x + used.w < free.x + free.w) {
            out.push({ x: used.x + used.w, y: free.y, w: free.x + free.w - (used.x + used.w), h: free.h });
        }
        if (used.y > free.y) { out.push({ x: free.x, y: free.y, w: free.w, h: used.y - free.y }); }
        if (used.y + used.h < free.y + free.h) {
            out.push({ x: free.x, y: used.y + used.h, w: free.w, h: free.y + free.h - (used.y + used.h) });
        }
        return out;
    }

    function prune(rects) {
        var i, j;
        for (i = rects.length - 1; i >= 0; i--) {
            if (rects[i].w <= 0.0001 || rects[i].h <= 0.0001) { rects.splice(i, 1); continue; }
            for (j = rects.length - 1; j >= 0; j--) {
                if (i !== j && contains(rects[j], rects[i])) { rects.splice(i, 1); break; }
            }
        }
        return rects;
    }

    function score(free, w, h, mode) {
        var dw = free.w - w, dh = free.h - h;
        if (mode === "area") { return [free.w * free.h - w * h, Math.min(dw, dh), Math.max(dw, dh)]; }
        return [Math.min(dw, dh), Math.max(dw, dh), free.w * free.h - w * h];
    }

    function scoreLess(a, b) {
        if (!b) { return true; }
        if (a[0] !== b[0]) { return a[0] < b[0]; }
        if (a[1] !== b[1]) { return a[1] < b[1]; }
        return a[2] < b[2];
    }

    function findPosition(freeRects, item, gx, gy, allowRotate, mode) {
        var best = null, bestScore = null, i, f, fw, fh, s;
        var orientations = [{ w: item.w, h: item.h, r: false }];
        if (allowRotate && Math.abs(item.w - item.h) > 0.0001) { orientations.push({ w: item.h, h: item.w, r: true }); }
        var o;
        for (i = 0; i < freeRects.length; i++) {
            f = freeRects[i];
            for (o = 0; o < orientations.length; o++) {
                fw = orientations[o].w + gx; fh = orientations[o].h + gy;
                if (fw <= f.w + 0.0001 && fh <= f.h + 0.0001) {
                    s = score(f, fw, fh, mode);
                    if (scoreLess(s, bestScore)) {
                        bestScore = s;
                        best = {
                            x: f.x, y: f.y,
                            w: orientations[o].w, h: orientations[o].h,
                            fw: fw, fh: fh, rotated: orientations[o].r,
                            sourceIndex: item.sourceIndex, copyIndex: item.copyIndex,
                            originalW: item.w, originalH: item.h
                        };
                    }
                }
            }
        }
        return best;
    }

    function placeOrder(items, cfg, mode) {
        var freeRects = [{ x: 0, y: 0, w: cfg.binW + cfg.gapX, h: cfg.binH + cfg.gapY }];
        var placed = [], skipped = [], i, p, f, next, j;
        var clear = Math.max(0, Number(cfg.cornerClear) || 0), obstacles, oi;
        if (clear > 0) {
            obstacles = [
                {x:0,y:0,w:clear,h:clear},
                {x:cfg.binW-clear,y:0,w:clear+cfg.gapX,h:clear},
                {x:0,y:cfg.binH-clear,w:clear,h:clear+cfg.gapY},
                {x:cfg.binW-clear,y:cfg.binH-clear,w:clear+cfg.gapX,h:clear+cfg.gapY}
            ];
            for (oi = 0; oi < obstacles.length; oi++) {
                next = [];
                for (j = 0; j < freeRects.length; j++) {
                    f = splitFree(freeRects[j], obstacles[oi]);
                    while (f.length) { next.push(f.pop()); }
                }
                freeRects = prune(next);
            }
        }
        for (i = 0; i < items.length; i++) {
            p = findPosition(freeRects, items[i], cfg.gapX, cfg.gapY, cfg.allowRotate, mode);
            if (!p) { skipped.push(items[i]); continue; }
            placed.push(p);
            next = [];
            var used = { x: p.x, y: p.y, w: p.fw, h: p.fh };
            for (j = 0; j < freeRects.length; j++) {
                f = splitFree(freeRects[j], used);
                while (f.length) { next.push(f.pop()); }
            }
            freeRects = prune(next);
        }
        return { items: placed, skipped: skipped };
    }

    function order(items, kind) {
        var a = items.slice(0);
        a.sort(function (x, y) {
            if (kind === "maxside") {
                var d = Math.max(y.w, y.h) - Math.max(x.w, x.h);
                if (d) { return d; }
            } else if (kind === "height") {
                if (y.h !== x.h) { return y.h - x.h; }
            } else if (kind === "width") {
                if (y.w !== x.w) { return y.w - x.w; }
            }
            if (y.w * y.h !== x.w * x.h) { return y.w * y.h - x.w * x.h; }
            return x.sourceIndex - y.sourceIndex;
        });
        return a;
    }

    function usedArea(result) {
        var i, total = 0;
        for (i = 0; i < result.items.length; i++) { total += result.items[i].originalW * result.items[i].originalH; }
        return total;
    }

    function better(a, b) {
        if (!a) { return b; }
        if (b.items.length !== a.items.length) { return b.items.length > a.items.length ? b : a; }
        return usedArea(b) > usedArea(a) ? b : a;
    }

    function centerX(result, binW) {
        var i, minX = 1e20, maxX = -1e20;
        for (i = 0; i < result.items.length; i++) {
            minX = Math.min(minX, result.items[i].x);
            maxX = Math.max(maxX, result.items[i].x + result.items[i].w);
        }
        if (!result.items.length) { return; }
        var dx = Math.max(0, (binW - (maxX - minX)) / 2 - minX);
        for (i = 0; i < result.items.length; i++) { result.items[i].x += dx; }
    }

    function pack(cfg) {
        var kinds = ["area", "maxside", "height", "width"], modes = ["short", "area"];
        var k, m, candidate, best = null;
        for (k = 0; k < kinds.length; k++) {
            for (m = 0; m < modes.length; m++) {
                candidate = placeOrder(order(cfg.items, kinds[k]), cfg, modes[m]);
                best = better(best, candidate);
            }
        }
        if (!best) { best = { items: [], skipped: cfg.items.slice(0) }; }
        if (!(Number(cfg.cornerClear) > 0)) { centerX(best, cfg.binW); }
        best.count = best.items.length;
        best.efficiency = usedArea(best) / (cfg.binW * cfg.binH);
        best.method = "maxrects-mixed-sizes";
        if (Number(cfg.cornerClear) > 0) { best.method = "corner-safe-maxrects-mixed-sizes"; best.cornerSafe = true; }
        return best;
    }

    return { pack: pack };
}());


/* Auto Nest Pro - True Shape nesting engine (ES3 compatible). */
var ANPTrueShape = (function () {
    var EPS = 0.0001;
    function num(v, d) { var n = Number(v); return isNaN(n) ? d : n; }
    function clonePoint(p) { return { x: p.x, y: p.y }; }
    function polygonArea(poly) {
        var i, j, a = 0;
        for (i = 0, j = poly.length - 1; i < poly.length; j = i++) { a += poly[j].x * poly[i].y - poly[i].x * poly[j].y; }
        return Math.abs(a / 2);
    }
    function bounds(poly) {
        var i, minX = 1e20, minY = 1e20, maxX = -1e20, maxY = -1e20;
        for (i = 0; i < poly.length; i++) {
            minX = Math.min(minX, poly[i].x); minY = Math.min(minY, poly[i].y);
            maxX = Math.max(maxX, poly[i].x); maxY = Math.max(maxY, poly[i].y);
        }
        return { minX: minX, minY: minY, maxX: maxX, maxY: maxY, w: maxX - minX, h: maxY - minY };
    }
    function rotateVariant(poly, w, h, angle) {
        var rad = angle * Math.PI / 180, c = Math.cos(rad), s = Math.sin(rad), cx = w / 2, cy = h / 2;
        var out = [], i, dx, dy, b, rect = [
            { x: 0, y: 0 }, { x: w, y: 0 }, { x: w, y: h }, { x: 0, y: h }
        ], rb = [];
        for (i = 0; i < poly.length; i++) {
            dx = poly[i].x - cx; dy = poly[i].y - cy;
            out.push({ x: cx + dx * c - dy * s, y: cy + dx * s + dy * c });
        }
        for (i = 0; i < rect.length; i++) {
            dx = rect[i].x - cx; dy = rect[i].y - cy;
            rb.push({ x: cx + dx * c - dy * s, y: cy + dx * s + dy * c });
        }
        var rbb = bounds(rb), norm = ((Number(angle) % 360) + 360) % 360;
        /* V93 EXACT GAP: strict-gap chỉ dùng các góc vuông. Với 0/90/180/270,
           bbox chuẩn phải lấy từ kích thước geometricBounds thật (rect), không
           lấy từ polygon Bézier sample. Như vậy tọa độ engine == tọa độ vector xuất. */
        if (Math.abs(norm - 0) < 0.001 || Math.abs(norm - 90) < 0.001 || Math.abs(norm - 180) < 0.001 || Math.abs(norm - 270) < 0.001) {
            for (i = 0; i < out.length; i++) { out[i].x -= rbb.minX; out[i].y -= rbb.minY; }
            return { angle: angle, points: out, w: rbb.w, h: rbb.h, offsetX:0, offsetY:0 };
        }
        b = bounds(out);
        for (i = 0; i < out.length; i++) { out[i].x -= b.minX; out[i].y -= b.minY; }
        return { angle: angle, points: out, w: b.w, h: b.h,
            offsetX: rbb.minX - b.minX, offsetY: rbb.minY - b.minY };
    }
    function orientationList(poly, w, h, angles) {
        var out = [], seen = {}, i, a, v, key;
        for (i = 0; i < angles.length; i++) {
            /* 180° không giống 0° với khuôn bất đối xứng (chìa khóa, móc,
               chai...). Giữ đủ vòng 360° để dàn đầu–đuôi so le. */
            a = ((Number(angles[i]) % 360) + 360) % 360;
            v = rotateVariant(poly, w, h, a); key = Math.round(v.w * 100) + "x" + Math.round(v.h * 100) + "@" + Math.round(a * 10);
            if (!seen[key]) { seen[key] = true; out.push(v); }
        }
        return out;
    }
    function translated(poly, x, y) {
        var out = [], i; for (i = 0; i < poly.length; i++) { out.push({ x: poly[i].x + x, y: poly[i].y + y }); } return out;
    }
    function orient(a, b, c) { return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x); }
    function onSeg(a, b, p) {
        return Math.abs(orient(a, b, p)) < EPS && p.x >= Math.min(a.x, b.x) - EPS && p.x <= Math.max(a.x, b.x) + EPS &&
            p.y >= Math.min(a.y, b.y) - EPS && p.y <= Math.max(a.y, b.y) + EPS;
    }
    function segIntersects(a, b, c, d) {
        var o1 = orient(a, b, c), o2 = orient(a, b, d), o3 = orient(c, d, a), o4 = orient(c, d, b);
        if (((o1 > EPS && o2 < -EPS) || (o1 < -EPS && o2 > EPS)) && ((o3 > EPS && o4 < -EPS) || (o3 < -EPS && o4 > EPS))) { return true; }
        return onSeg(a, b, c) || onSeg(a, b, d) || onSeg(c, d, a) || onSeg(c, d, b);
    }
    function pointIn(poly, p) {
        var inside = false, i, j, a, b;
        for (i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            a = poly[i]; b = poly[j]; if (onSeg(a, b, p)) { return true; }
            if (((a.y > p.y) !== (b.y > p.y)) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) { inside = !inside; }
        }
        return inside;
    }
    function pointInStrict(poly, p) {
        var inside = false, i, j, a, b;
        for (i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            a = poly[i]; b = poly[j]; if (onSeg(a, b, p)) { return false; }
            if (((a.y > p.y) !== (b.y > p.y)) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) { inside = !inside; }
        }
        return inside;
    }
    function centroid(poly) {
        var i, j, cross, a = 0, x = 0, y = 0;
        for (i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            cross = poly[j].x * poly[i].y - poly[i].x * poly[j].y; a += cross;
            x += (poly[j].x + poly[i].x) * cross; y += (poly[j].y + poly[i].y) * cross;
        }
        if (Math.abs(a) < EPS) { return clonePoint(poly[0]); }
        return { x: x / (3 * a), y: y / (3 * a) };
    }
    function polygonsOverlap(a, b) {
        var i, j, ni, nj, o1, o2, o3, o4;
        for (i = 0; i < a.length; i++) {
            ni = (i + 1) % a.length;
            for (j = 0; j < b.length; j++) {
                nj = (j + 1) % b.length;
                o1 = orient(a[i], a[ni], b[j]); o2 = orient(a[i], a[ni], b[nj]);
                o3 = orient(b[j], b[nj], a[i]); o4 = orient(b[j], b[nj], a[ni]);
                if (((o1 > EPS && o2 < -EPS) || (o1 < -EPS && o2 > EPS)) && ((o3 > EPS && o4 < -EPS) || (o3 < -EPS && o4 > EPS))) { return true; }
            }
        }
        for (i = 0; i < a.length; i++) { if (pointInStrict(b, a[i])) { return true; } }
        for (i = 0; i < b.length; i++) { if (pointInStrict(a, b[i])) { return true; } }
        if (pointInStrict(a, centroid(b)) || pointInStrict(b, centroid(a))) { return true; }
        var ba = bounds(a), bb = bounds(b), l = Math.max(ba.minX, bb.minX), r = Math.min(ba.maxX, bb.maxX);
        var t = Math.max(ba.minY, bb.minY), bot = Math.min(ba.maxY, bb.maxY), sx, sy, sample;
        if (r - l > EPS && bot - t > EPS) {
            for (i = 1; i <= 4; i++) { for (j = 1; j <= 4; j++) {
                sx = l + (r - l) * i / 5; sy = t + (bot - t) * j / 5; sample = {x:sx,y:sy};
                if (pointInStrict(a, sample) && pointInStrict(b, sample)) { return true; }
            } }
        }
        return false;
    }
    function pointSegDist(p, a, b) {
        var dx = b.x - a.x, dy = b.y - a.y, den = dx * dx + dy * dy, t;
        if (den < EPS) { dx = p.x - a.x; dy = p.y - a.y; return Math.sqrt(dx * dx + dy * dy); }
        t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / den; t = Math.max(0, Math.min(1, t));
        dx = p.x - (a.x + t * dx); dy = p.y - (a.y + t * dy); return Math.sqrt(dx * dx + dy * dy);
    }
    function polyDistance(a, b) {
        var i, j, ni, nj, best = 1e20;
        for (i = 0; i < a.length; i++) {
            ni = (i + 1) % a.length;
            for (j = 0; j < b.length; j++) {
                nj = (j + 1) % b.length;
                if (segIntersects(a[i], a[ni], b[j], b[nj])) { return 0; }
                best = Math.min(best, pointSegDist(a[i], b[j], b[nj]), pointSegDist(b[j], a[i], a[ni]));
            }
        }
        if (pointIn(a, b[0]) || pointIn(b, a[0])) { return 0; }
        return best;
    }
    function fits(v, x, y, placed, binW, binH, gap) {
        if (x < -EPS || y < -EPS || x + v.w > binW + EPS || y + v.h > binH + EPS) { return false; }
        var poly = translated(v.points, x, y), i, p;
        for (i = 0; i < placed.length; i++) {
            p = placed[i];
            if (x > p.x + p.w + gap || p.x > x + v.w + gap || y > p.y + p.h + gap || p.y > y + v.h + gap) { continue; }
            if (!polygonsRespectGapV95(poly,p.poly,gap)) { return false; }
        }
        return poly;
    }
    function addCandidate(out, seen, x, y, binW, binH) {
        x = Math.round(x * 20) / 20; y = Math.round(y * 20) / 20;
        if (x < -EPS || y < -EPS || x > binW + EPS || y > binH + EPS) { return; }
        var k = x + ":" + y; if (!seen[k]) { seen[k] = true; out.push({ x: x, y: y }); }
    }
    function candidatePoints(placed, v, binW, binH, gap, strategy, maxCandidates) {
        var out = [], seen = {}, i, j, k, p, pv, qv, dirs = [[gap,0],[-gap,0],[0,gap],[0,-gap]];
        addCandidate(out, seen, 0, 0, binW, binH); addCandidate(out, seen, binW - v.w, 0, binW, binH);
        addCandidate(out, seen, 0, binH - v.h, binW, binH); addCandidate(out, seen, binW - v.w, binH - v.h, binW, binH);
        for (i = 0; i < placed.length; i++) {
            p = placed[i];
            addCandidate(out, seen, p.x + p.w + gap, p.y, binW, binH);
            addCandidate(out, seen, p.x - v.w - gap, p.y, binW, binH);
            addCandidate(out, seen, p.x, p.y + p.h + gap, binW, binH);
            addCandidate(out, seen, p.x, p.y - v.h - gap, binW, binH);
            for (j = 0; j < p.poly.length; j += Math.max(1, Math.floor(p.poly.length / 4))) {
                pv = p.poly[j];
                for (k = 0; k < v.points.length; k += Math.max(1, Math.floor(v.points.length / 4))) {
                    qv = v.points[k];
                    for (var d = 0; d < dirs.length; d++) {
                        addCandidate(out, seen, pv.x - qv.x + dirs[d][0], pv.y - qv.y + dirs[d][1], binW, binH);
                    }
                }
            }
        }
        out.sort(function (a, b) {
            if (strategy === 1) { return a.x !== b.x ? a.x - b.x : a.y - b.y; }
            if (strategy === 2) { return a.y !== b.y ? b.y - a.y : a.x - b.x; }
            if (strategy === 3) { return a.x !== b.x ? b.x - a.x : a.y - b.y; }
            return a.y !== b.y ? a.y - b.y : a.x - b.x;
        });
        maxCandidates = Math.max(24, Number(maxCandidates) || 180);
        return out.length > maxCandidates ? out.slice(0, maxCandidates) : out;
    }
    function placedBoundsV45(placed) {
        var i, p, minX = 1e20, minY = 1e20, maxX = -1e20, maxY = -1e20;
        if (!placed || !placed.length) { return null; }
        for (i = 0; i < placed.length; i++) {
            p = placed[i]; minX = Math.min(minX, p.x); minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x + p.w); maxY = Math.max(maxY, p.y + p.h);
        }
        return { minX:minX, minY:minY, maxX:maxX, maxY:maxY };
    }
    function compactScoreBoundsV45(x, y, v, pb, strategy) {
        var maxX = x + v.w, maxY = y + v.h, minX = x, minY = y;
        if (pb) {
            minX = Math.min(minX, pb.minX); minY = Math.min(minY, pb.minY);
            maxX = Math.max(maxX, pb.maxX); maxY = Math.max(maxY, pb.maxY);
        }
        if (strategy === 1 || strategy === 3) { return (maxX - minX) * 10000 + (maxY - minY); }
        return (maxY - minY) * 10000 + (maxX - minX);
    }
    function compactScore(x, y, v, placed, strategy) {
        return compactScoreBoundsV45(x, y, v, placedBoundsV45(placed), strategy);
    }
    function greedy(variants, cfg, strategy, shift) {
        var placed = [], limit = cfg.maxQty > 0 ? cfg.maxQty : Math.min(500, Math.ceil(cfg.binW * cfg.binH / Math.max(0.01, cfg.area)) + 8);
        var n, vi, ci, v, pts, poly, best, score, order = variants.slice(0), rotated, placedBox;
        for (n = 0; n < shift; n++) { order.push(order.shift()); }
        while (placed.length < limit) {
            best = null; placedBox = placedBoundsV45(placed);
            for (vi = 0; vi < order.length; vi++) {
                v = order[vi]; pts = candidatePoints(placed, v, cfg.binW, cfg.binH, cfg.gap, strategy, cfg.fast ? 72 : 180);
                for (ci = 0; ci < pts.length; ci++) {
                    poly = fits(v, pts[ci].x, pts[ci].y, placed, cfg.binW, cfg.binH, cfg.gap);
                    if (!poly) { continue; }
                    score = compactScoreBoundsV45(pts[ci].x, pts[ci].y, v, placedBox, strategy) + vi * 0.0001;
                    if (!best || score < best.score) { best = { score: score, v: v, x: pts[ci].x, y: pts[ci].y, poly: poly }; }
                    if (ci > (cfg.fast ? 58 : 150) && best) { break; }
                }
            }
            if (!best) { break; }
            rotated = Math.abs(best.v.angle - 90) < 0.001;
            placed.push({ x: best.x, y: best.y, w: best.v.w, h: best.v.h, angle: best.v.angle,
                rotated: rotated, offsetX: best.v.offsetX, offsetY: best.v.offsetY, poly: best.poly });
        }
        return placed;
    }
    function honeycomb(cfg) {
        var d = Math.max(cfg.shape.w, cfg.shape.h), pitch = d + cfg.gap;
        var rowStep = Math.sqrt(Math.max(0, pitch * pitch - (pitch / 2) * (pitch / 2)));
        var best = [], startParity, y, row, x0, x, items, col, y0;
        /* Luôn so sánh cả lưới vuông vì một số khổ vuông cho kết quả tốt hơn tổ ong. */
        items = [];
        for (y = 0; y + d <= cfg.binH + EPS; y += pitch) { for (x = 0; x + d <= cfg.binW + EPS; x += pitch) {
            items.push({ x:x,y:y,w:d,h:d,angle:0,rotated:false,offsetX:0,offsetY:0 });
            if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
        } if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; } }
        best = items;
        for (startParity = 0; startParity < 2; startParity++) {
            items = []; row = 0; y = 0;
            while (y + d <= cfg.binH + EPS) {
                x0 = ((row + startParity) % 2) ? pitch / 2 : 0; x = x0;
                while (x + d <= cfg.binW + EPS) {
                    items.push({ x: x, y: y, w: d, h: d, angle: 0, rotated: false, offsetX: 0, offsetY: 0 });
                    if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
                    x += pitch;
                }
                if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
                row++; y = row * rowStep;
            }
            if (items.length > best.length) { best = items; }
            items = []; col = 0; x = 0;
            while (x + d <= cfg.binW + EPS) {
                y0 = ((col + startParity) % 2) ? pitch / 2 : 0; y = y0;
                while (y + d <= cfg.binH + EPS) {
                    items.push({ x:x,y:y,w:d,h:d,angle:0,rotated:false,offsetX:0,offsetY:0 });
                    if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
                    y += pitch;
                }
                if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
                col++; x = col * rowStep;
            }
            if (items.length > best.length) { best = items; }
        }
        return { items: best, count: best.length, method: "true-shape-honeycomb", efficiency: best.length * cfg.area / (cfg.binW * cfg.binH) };
    }
    /* Lattice so le: chỉ kiểm tra một cặp khuôn thật để tìm bước hàng, sau đó
       dựng lưới đầu–đuôi. Đây là đường chạy O(n), dùng cho khuôn bất đối xứng
       số lượng lớn thay vì phép thử polygon O(n²) gây lag Illustrator. */

    /* V95 performance: kiểm tra "đủ gap hay chưa" trực tiếp, không tính
       minimum distance của mọi cặp segment khi không cần thiết. */
    function segBoxGapLowerV95(a,b,c,d) {
        var aminX=Math.min(a.x,b.x),amaxX=Math.max(a.x,b.x),aminY=Math.min(a.y,b.y),amaxY=Math.max(a.y,b.y);
        var bminX=Math.min(c.x,d.x),bmaxX=Math.max(c.x,d.x),bminY=Math.min(c.y,d.y),bmaxY=Math.max(c.y,d.y);
        var dx=0,dy=0;
        if(amaxX<bminX){dx=bminX-amaxX;}else if(bmaxX<aminX){dx=aminX-bmaxX;}
        if(amaxY<bminY){dy=bminY-amaxY;}else if(bmaxY<aminY){dy=aminY-bmaxY;}
        return Math.sqrt(dx*dx+dy*dy);
    }
    function polygonsRespectGapV95(a,b,gap) {
        gap=Math.max(0,Number(gap)||0);
        if(gap<=EPS){return !polygonsOverlap(a,b);}
        var i,j,ni,nj,lower,dist;
        for(i=0;i<a.length;i++){
            ni=(i+1)%a.length;
            for(j=0;j<b.length;j++){
                nj=(j+1)%b.length;
                lower=segBoxGapLowerV95(a[i],a[ni],b[j],b[nj]);
                if(lower>=gap-EPS){continue;}
                if(segIntersects(a[i],a[ni],b[j],b[nj])){return false;}
                dist=Math.min(pointSegDist(a[i],b[j],b[nj]),pointSegDist(a[ni],b[j],b[nj]),
                    pointSegDist(b[j],a[i],a[ni]),pointSegDist(b[nj],a[i],a[ni]));
                if(dist<gap-EPS){return false;}
            }
        }
        if(pointIn(a,b[0])||pointIn(b,a[0])){return false;}
        return true;
    }

    function pairFits(a, b, dx, dy, gap) {
        var pa = a.points, pb = translated(b.points, dx, dy), ba = bounds(pa), bb = bounds(pb);
        if (bb.maxX < ba.minX - gap || ba.maxX < bb.minX - gap || bb.maxY < ba.minY - gap || ba.maxY < bb.minY - gap) { return true; }
        return polygonsRespectGapV95(pa,pb,gap);
    }
    /* V94 EXACT ORTHOGONAL GAP
       "Khoảng cách Pon - Ngang/Dọc" là khoảng hở theo TRỤC X/Y, không phải
       khoảng cách Euclid ngắn nhất ở góc cong. V93 dùng polyDistance nên một
       góc cong chéo có thể chạm ngưỡng 2mm trước, làm khe thẳng thực tế thành
       2.2-2.4mm. V94 tìm vị trí TIẾP XÚC theo đúng hướng dịch X/Y rồi cộng đúng
       gap cấu hình. Vì vậy gapX=2 và gapY=2 cho khe thẳng 2.000mm ở cả hai trục. */
    function pairNoOverlapV94(a, b, dx, dy) {
        var pa = a.points, pb = translated(b.points, dx, dy), ba = bounds(pa), bb = bounds(pb);
        if (bb.maxX < ba.minX - EPS || ba.maxX < bb.minX - EPS || bb.maxY < ba.minY - EPS || ba.maxY < bb.minY - EPS) { return true; }
        return !polygonsOverlap(pa, pb);
    }
    function contactPitchXV94(a, b, dy, gap, fast) {
        var span = Math.max(0.25, Math.min(a.w, a.h, b.w, b.h) / (fast ? 36 : 64));
        var hi = a.w + b.w + 1, right = hi, x, found = false, lo = -b.w - 1, i, mid;
        /* đi từ bên phải vào cho tới khi thật sự đụng polygon */
        for (x = hi; x >= lo; x -= span) {
            if (!pairNoOverlapV94(a, b, x, dy)) { found = true; break; }
            right = x;
        }
        if (!found) { return Math.max(a.w, b.w) + Math.max(0, Number(gap) || 0); } /* không có vùng tiếp xúc: dùng pitch bbox an toàn, tránh bước 0 */
        lo = x; hi = right;
        if (hi < lo) { hi = lo + span; }
        for (i = 0; i < 24 && hi - lo > 0.0002; i++) {
            mid = (lo + hi) / 2;
            if (pairNoOverlapV94(a, b, mid, dy)) { hi = mid; } else { lo = mid; }
        }
        return Math.max(0, hi + Math.max(0, Number(gap) || 0));
    }
    function contactPitchYV94(a, b, dx, gap, fast) {
        var span = Math.max(0.25, Math.min(a.w, a.h, b.w, b.h) / (fast ? 36 : 64));
        var hi = a.h + b.h + 1, bottom = hi, y, found = false, lo = -b.h - 1, i, mid;
        for (y = hi; y >= lo; y -= span) {
            if (!pairNoOverlapV94(a, b, dx, y)) { found = true; break; }
            bottom = y;
        }
        if (!found) { return Math.max(a.h, b.h) + Math.max(0, Number(gap) || 0); }
        lo = y; hi = bottom;
        if (hi < lo) { hi = lo + span; }
        for (i = 0; i < 24 && hi - lo > 0.0002; i++) {
            mid = (lo + hi) / 2;
            if (pairNoOverlapV94(a, b, dx, mid)) { hi = mid; } else { lo = mid; }
        }
        return Math.max(0, hi + Math.max(0, Number(gap) || 0));
    }
    function fitsOrthogonalV94(v, x, y, placed, binW, binH) {
        if (x < -EPS || y < -EPS || x + v.w > binW + EPS || y + v.h > binH + EPS) { return false; }
        var poly = translated(v.points, x, y), i, p;
        for (i = 0; i < placed.length; i++) {
            p = placed[i];
            if (x > p.x + p.w + EPS || p.x > x + v.w + EPS || y > p.y + p.h + EPS || p.y > y + v.h + EPS) { continue; }
            if (polygonsOverlap(poly, p.poly)) { return false; }
        }
        return poly;
    }
    function variantAtAngleV34(variants, angle) {
        var i, a = ((Number(angle) % 360) + 360) % 360;
        for (i = 0; i < variants.length; i++) {
            if (Math.abs((((Number(variants[i].angle) % 360) + 360) % 360) - a) < 0.001) { return variants[i]; }
        }
        return null;
    }
    function refineFirstFitV83(testFn, lo, hi) {
        /* Tìm biên tiếp xúc + gap bằng binary search. Safety 0.002mm chỉ để
           tránh sai số float/polyDistance của polygon, không làm thay đổi khe nhìn thấy. */
        var i, mid;
        lo = Math.max(0, Number(lo) || 0); hi = Math.max(lo, Number(hi) || 0);
        for (i = 0; i < 14 && hi - lo > 0.0003; i++) {
            mid = (lo + hi) / 2;
            if (testFn(mid)) { hi = mid; } else { lo = mid; }
        }
        return hi + 0.002;
    }
    function minPitchYV34(v, gap, fast, strictGap) {
        var step = Math.max(strictGap ? 0.08 : 0.2, Math.min(v.w, v.h) / (fast ? (strictGap ? 90 : 36) : (strictGap ? 140 : 64)));
        var y, prev = 0;
        for (y = step; y <= v.h + gap + step * 2; y += step) {
            if (pairFits(v, v, 0, y, gap)) {
                return strictGap ? refineFirstFitV83(function(q){ return pairFits(v, v, 0, q, gap); }, prev, y) : y;
            }
            prev = y;
        }
        return v.h + gap;
    }
    function minPitchXV34(a, b, dy, gap, fast, strictGap) {
        var step = Math.max(strictGap ? 0.08 : 0.2, Math.min(a.w, a.h, b.w, b.h) / (fast ? (strictGap ? 100 : 42) : (strictGap ? 160 : 72)));
        var x, start = strictGap ? step : Math.max(step, Math.min(a.w, b.w) * 0.12), end = a.w + b.w + gap + step, prev = 0;
        for (x = start; x <= end; x += step) {
            if (pairFits(a, b, x, dy, gap)) {
                return strictGap ? refineFirstFitV83(function(q){ return pairFits(a, b, q, dy, gap); }, prev, x) : x;
            }
            prev = x;
        }
        return Math.max(a.w, b.w) + gap;
    }
    function maxAdjacentPitchXV34(a, b, shiftY, pitchY, gap, fast, strictGap) {
        return Math.max(minPitchXV34(a, b, shiftY, gap, fast, strictGap),
            minPitchXV34(a, b, shiftY - pitchY, gap, fast, strictGap),
            minPitchXV34(a, b, shiftY + pitchY, gap, fast, strictGap));
    }
    /* Mẫu cột khóa nhau dành cho khuôn D/vòm/chìa khóa: thử cặp 90°–270°
       và 0°–180°, hai cột kế tiếp dùng bước X riêng. Đây chính là bố cục
       đầu–đuôi trong mẫu người dùng, nhưng vẫn xác thực va chạm polygon thật. */

    /* V95 PROFILE-LATTICE EXACT GAP
       Với KHUÔN ĐẶC BIỆT, tính envelope trái/phải và trên/dưới theo scanline.
       Pitch X/Y được suy ra trực tiếp từ envelope nên không cần quét va chạm
       O(n²) hàng nghìn lần. Solver thử cả dàn theo cột + theo hàng, tất cả
       cặp góc 0/90/180/270 và 8 pha lệch, ưu tiên số con trước. */
    function profileStepV95(a,b){
        var d=Math.max(0.1,Math.min(a.w,a.h,b?b.w:a.w,b?b.h:a.h));
        return Math.max(0.025,Math.min(0.055,d/500));
    }
    function rawScanXRangeV95(v,y){
        var xs=[],p=v.points,i,a,b,lo,hi,t;
        for(i=0;i<p.length;i++){
            a=p[i];b=p[(i+1)%p.length];
            if(Math.abs(Number(a.y)-Number(b.y))<1e-9){continue;}
            lo=Math.min(Number(a.y),Number(b.y));hi=Math.max(Number(a.y),Number(b.y));
            if(y<lo-EPS||y>=hi-EPS){continue;}
            t=(y-Number(a.y))/(Number(b.y)-Number(a.y));xs.push(Number(a.x)+t*(Number(b.x)-Number(a.x)));
        }
        if(!xs.length){return null;} xs.sort(function(a,b){return a-b;}); return [xs[0],xs[xs.length-1]];
    }
    function rawScanYRangeV95(v,x){
        var ys=[],p=v.points,i,a,b,lo,hi,t;
        for(i=0;i<p.length;i++){
            a=p[i];b=p[(i+1)%p.length];
            if(Math.abs(Number(a.x)-Number(b.x))<1e-9){continue;}
            lo=Math.min(Number(a.x),Number(b.x));hi=Math.max(Number(a.x),Number(b.x));
            if(x<lo-EPS||x>=hi-EPS){continue;}
            t=(x-Number(a.x))/(Number(b.x)-Number(a.x));ys.push(Number(a.y)+t*(Number(b.y)-Number(a.y)));
        }
        if(!ys.length){return null;} ys.sort(function(a,b){return a-b;}); return [ys[0],ys[ys.length-1]];
    }
    function ensureProfileV95(v){
        if(v._anpProfileV95){return v._anpProfileV95;}
        var st=profileStepV95(v,v),ny=Math.max(1,Math.ceil(Number(v.h)/st)),nx=Math.max(1,Math.ceil(Number(v.w)/st));
        var L=[],R=[],T=[],B=[],i,p0,p1,p2,lo,hi,y0,y1,yc,x0,x1,xc,eps=Math.min(0.00005,st*0.01);
        for(i=0;i<ny;i++){
            y0=i*st;y1=Math.min(Number(v.h),(i+1)*st);yc=(y0+y1)/2;lo=1e30;hi=-1e30;
            p0=rawScanXRangeV95(v,Math.min(Number(v.h)-eps,y0+eps));p1=rawScanXRangeV95(v,yc);p2=rawScanXRangeV95(v,Math.max(eps,y1-eps));
            if(p0){lo=Math.min(lo,p0[0]);hi=Math.max(hi,p0[1]);}if(p1){lo=Math.min(lo,p1[0]);hi=Math.max(hi,p1[1]);}if(p2){lo=Math.min(lo,p2[0]);hi=Math.max(hi,p2[1]);}
            L[i]=lo===1e30?null:lo;R[i]=hi===-1e30?null:hi;
        }
        for(i=0;i<nx;i++){
            x0=i*st;x1=Math.min(Number(v.w),(i+1)*st);xc=(x0+x1)/2;lo=1e30;hi=-1e30;
            p0=rawScanYRangeV95(v,Math.min(Number(v.w)-eps,x0+eps));p1=rawScanYRangeV95(v,xc);p2=rawScanYRangeV95(v,Math.max(eps,x1-eps));
            if(p0){lo=Math.min(lo,p0[0]);hi=Math.max(hi,p0[1]);}if(p1){lo=Math.min(lo,p1[0]);hi=Math.max(hi,p1[1]);}if(p2){lo=Math.min(lo,p2[0]);hi=Math.max(hi,p2[1]);}
            T[i]=lo===1e30?null:lo;B[i]=hi===-1e30?null:hi;
        }
        v._anpProfileV95={step:st,left:L,right:R,top:T,bottom:B,ny:ny,nx:nx};return v._anpProfileV95;
    }
    function scanXRangeV95(v,y){
        var p=ensureProfileV95(v),i;if(y<0||y>Number(v.h)+EPS){return null;}i=Math.floor(Math.max(0,Math.min(Number(v.h)-EPS,y))/p.step);if(i<0){i=0;}if(i>=p.ny){i=p.ny-1;}if(p.left[i]===null||p.right[i]===null){return null;}return [p.left[i],p.right[i]];
    }
    function scanYRangeV95(v,x){
        var p=ensureProfileV95(v),i;if(x<0||x>Number(v.w)+EPS){return null;}i=Math.floor(Math.max(0,Math.min(Number(v.w)-EPS,x))/p.step);if(i<0){i=0;}if(i>=p.nx){i=p.nx-1;}if(p.top[i]===null||p.bottom[i]===null){return null;}return [p.top[i],p.bottom[i]];
    }
    function profilePitchXV95(a,b,dy,gap){
        var st=profileStepV95(a,b),ys=Math.max(0,Number(dy)),ye=Math.min(Number(a.h),Number(dy)+Number(b.h));
        var y,ra,rb,req=-1e30,seen=false;
        if(ye<=ys+EPS){return 0;}
        for(y=ys+st*0.5;y<ye;y+=st){
            ra=scanXRangeV95(a,y);rb=scanXRangeV95(b,y-Number(dy)); if(!ra||!rb){continue;}
            seen=true; req=Math.max(req,Number(ra[1])+Number(gap)-Number(rb[0]));
        }
        return seen?Math.max(0,req+0.006):0;
    }
    function profilePitchYV95(a,b,dx,gap){
        var st=profileStepV95(a,b),xs=Math.max(0,Number(dx)),xe=Math.min(Number(a.w),Number(dx)+Number(b.w));
        var x,ra,rb,req=-1e30,seen=false;
        if(xe<=xs+EPS){return 0;}
        for(x=xs+st*0.5;x<xe;x+=st){
            ra=scanYRangeV95(a,x);rb=scanYRangeV95(b,x-Number(dx));if(!ra||!rb){continue;}
            seen=true;req=Math.max(req,Number(ra[1])+Number(gap)-Number(rb[0]));
        }
        return seen?Math.max(0,req+0.006):0;
    }
    function profileMaxPXV95(a,b,shift,py,gap){
        var K=Math.min(5,Math.ceil((a.h+b.h)/Math.max(py,0.01))+1),k,r=0;
        for(k=-K;k<=K;k++){r=Math.max(r,profilePitchXV95(a,b,shift+k*py,gap));}return r;
    }
    function profileMaxPYV95(a,b,shift,px,gap){
        var K=Math.min(5,Math.ceil((a.w+b.w)/Math.max(px,0.01))+1),k,r=0;
        for(k=-K;k<=K;k++){r=Math.max(r,profilePitchYV95(a,b,shift+k*px,gap));}return r;
    }
    function profileBetterV95(best,cand){
        if(!cand){return best;}if(!best){return cand;}
        if(cand.items.length!==best.items.length){return cand.items.length>best.items.length?cand:best;}
        var ba=placedBoundsV45(best.items),ca=placedBoundsV45(cand.items),bs=ba?(ba.maxX-ba.minX)*(ba.maxY-ba.minY):1e30,cs=ca?(ca.maxX-ca.minX)*(ca.maxY-ca.minY):1e30;
        return cs<bs?cand:best;
    }
    function profileColumnsV95(cfg,variants){
        var best=null,ai,bi,a,b,py,fi,frac,shift,pAB,pBA,selfX,items,x,col,v,y0,y,limit;
        var fr=[0,0.125,-0.125,0.25,-0.25,0.375,-0.375,0.5,-0.5,0.625,-0.625,0.75,-0.75,0.875,-0.875];
        limit=cfg.maxQty>0?cfg.maxQty:10000;
        for(ai=0;ai<variants.length;ai++){a=variants[ai];for(bi=0;bi<variants.length;bi++){b=variants[bi];
            py=Math.max(profilePitchYV95(a,a,0,cfg.gapY),profilePitchYV95(b,b,0,cfg.gapY));if(!(py>EPS)){continue;}
            selfX=Math.max(profilePitchXV95(a,a,0,cfg.gapX),profilePitchXV95(b,b,0,cfg.gapX));
            for(fi=0;fi<fr.length;fi++){frac=fr[fi];shift=py*frac;pAB=profileMaxPXV95(a,b,shift,py,cfg.gapX);pBA=profileMaxPXV95(b,a,-shift,py,cfg.gapX);
                if(!(pAB+pBA>EPS)||pAB+pBA+0.0001<selfX){continue;}
                items=[];x=0;col=0;
                while(x+((col%2)?b.w:a.w)<=cfg.binW+EPS){v=(col%2)?b:a;y0=(col%2)?shift:0;
                    for(y=y0;y+v.h<=cfg.binH+EPS;y+=py){items.push({x:x,y:y,w:v.w,h:v.h,angle:v.angle,rotated:Math.abs((v.angle%180)-90)<0.001,offsetX:v.offsetX,offsetY:v.offsetY});if(items.length>=limit){break;}}
                    if(items.length>=limit){break;}x+=(col%2)?pBA:pAB;col++;if(col>2000){break;}
                }
                best=profileBetterV95(best,{items:items,count:items.length,method:"true-shape-profile-columns-v95",profileGap:true,pitchY:py});
            }
        }}return best;
    }
    function profileRowsV95(cfg,variants){
        var best=null,ai,bi,a,b,px,fi,frac,shift,pAB,pBA,selfY,items,y,row,v,x0,x,limit;
        var fr=[0,0.125,-0.125,0.25,-0.25,0.375,-0.375,0.5,-0.5,0.625,-0.625,0.75,-0.75,0.875,-0.875];limit=cfg.maxQty>0?cfg.maxQty:10000;
        for(ai=0;ai<variants.length;ai++){a=variants[ai];for(bi=0;bi<variants.length;bi++){b=variants[bi];
            px=Math.max(profilePitchXV95(a,a,0,cfg.gapX),profilePitchXV95(b,b,0,cfg.gapX));if(!(px>EPS)){continue;}
            selfY=Math.max(profilePitchYV95(a,a,0,cfg.gapY),profilePitchYV95(b,b,0,cfg.gapY));
            for(fi=0;fi<fr.length;fi++){frac=fr[fi];shift=px*frac;pAB=profileMaxPYV95(a,b,shift,px,cfg.gapY);pBA=profileMaxPYV95(b,a,-shift,px,cfg.gapY);
                if(!(pAB+pBA>EPS)||pAB+pBA+0.0001<selfY){continue;}
                items=[];y=0;row=0;
                while(y+((row%2)?b.h:a.h)<=cfg.binH+EPS){v=(row%2)?b:a;x0=(row%2)?shift:0;
                    for(x=x0;x+v.w<=cfg.binW+EPS;x+=px){items.push({x:x,y:y,w:v.w,h:v.h,angle:v.angle,rotated:Math.abs((v.angle%180)-90)<0.001,offsetX:v.offsetX,offsetY:v.offsetY});if(items.length>=limit){break;}}
                    if(items.length>=limit){break;}y+=(row%2)?pBA:pAB;row++;if(row>2000){break;}
                }
                best=profileBetterV95(best,{items:items,count:items.length,method:"true-shape-profile-rows-v95",profileGap:true,pitchX:px});
            }
        }}return best;
    }
    function profilePackV95(cfg,variants){
        var a=profileColumnsV95(cfg,variants),b=profileRowsV95(cfg,variants),best=profileBetterV95(a,b);
        if(!best){return {items:[],count:0,method:"true-shape-profile-v95",profileGap:true};}
        best.count=best.items.length;best.strictGap=true;best.profileGap=true;best.efficiency=best.count*cfg.area/Math.max(EPS,cfg.binW*cfg.binH);return best;
    }

    function interlockingColumnsV34(cfg, variants) {
        var pairs = [[90,270],[270,90],[0,180],[180,0]], best = [], bestArea = 1e30, pi, a, b, py;
        var shifts, si, shift, pAB, pBA, twoPitch, items, col, x, y, v, y0, poly, local, limit, bnd, areaScore;
        limit = cfg.maxQty > 0 ? cfg.maxQty : Math.min(10000, Math.ceil(cfg.binW * cfg.binH / Math.max(0.01, cfg.area)) + 12);
        for (pi = 0; pi < pairs.length; pi++) {
            a = variantAtAngleV34(variants, pairs[pi][0]); b = variantAtAngleV34(variants, pairs[pi][1]);
            if (!a || !b) { continue; }
            py = Math.max(minPitchYV34(a, cfg.strictGap ? cfg.gapY : cfg.gap, cfg.fast, cfg.strictGap), minPitchYV34(b, cfg.strictGap ? cfg.gapY : cfg.gap, cfg.fast, cfg.strictGap));
            /* V95: thử thêm 1/4 và 3/4 bước để không mất số con khi khuôn lõm khóa lệch tâm. */
            shifts = cfg.strictGap ? [0, py*0.5,-py*0.5, py*0.25,-py*0.25, py*0.75,-py*0.75, py*0.125,-py*0.125, py*0.375,-py*0.375, py*0.625,-py*0.625, py*0.875,-py*0.875] : [0, py / 2];
            for (si = 0; si < shifts.length; si++) {
                shift = shifts[si];
                pAB = maxAdjacentPitchXV34(a, b, shift, py, cfg.strictGap ? cfg.gapX : cfg.gap, cfg.fast, cfg.strictGap);
                pBA = maxAdjacentPitchXV34(b, a, -shift, py, cfg.strictGap ? cfg.gapX : cfg.gap, cfg.fast, cfg.strictGap);
                twoPitch = pAB + pBA;
                if (!pairFits(a, a, twoPitch, 0, cfg.strictGap ? cfg.gapX : cfg.gap) || !pairFits(b, b, twoPitch, 0, cfg.strictGap ? cfg.gapX : cfg.gap)) { continue; }
                items = []; x = 0; col = 0;
                while (x + ((col % 2) ? b.w : a.w) <= cfg.binW + EPS) {
                    v = (col % 2) ? b : a; y0 = (col % 2) ? shift : 0;
                    for (y = y0; y + v.h <= cfg.binH + EPS; y += py) {
                        local = items.slice(Math.max(0, items.length - Math.ceil(cfg.binH / Math.max(EPS, py)) * 3 - 6));
                        poly = fits(v, x, y, local, cfg.binW, cfg.binH, cfg.gap);
                        if (poly) {
                            items.push({x:x,y:y,w:v.w,h:v.h,angle:v.angle,
                                rotated:Math.abs((v.angle % 180) - 90)<0.001,
                                offsetX:v.offsetX,offsetY:v.offsetY,poly:poly});
                            if (items.length >= limit) { break; }
                        }
                    }
                    if (items.length >= limit) { break; }
                    x += (col % 2) ? pBA : pAB; col++;
                }
                bnd=placedBoundsV45(items); areaScore=bnd?(bnd.maxX-bnd.minX)*(bnd.maxY-bnd.minY):1e30;
                if (items.length > best.length || (items.length === best.length && areaScore < bestArea)) {
                    best = items; bestArea = areaScore;
                    if (cfg.strictGap && Number(cfg.exactTargetCount || 0) > 0 && best.length >= Number(cfg.exactTargetCount)) {
                        return {items:best,count:best.length,method:"true-shape-interlocking-precision-v95",strictGap:true,
                            targetReachedV97:true,efficiency:best.length * cfg.area / Math.max(EPS, cfg.binW * cfg.binH)};
                    }
                }
            }
        }
        return {items:best,count:best.length,method:cfg.strictGap?"true-shape-interlocking-precision-v95":"true-shape-interlocking-columns",
            strictGap:cfg.strictGap===true,efficiency:best.length * cfg.area / Math.max(EPS, cfg.binW * cfg.binH)};
    }
    function staggered(cfg, variants) {
        var best = [], bestMeta = null, ai, bi, a, b, dxs, di, dx, dy, step, found, prev, rowPitch, r, x, y, v, rowItems, limit, local, poly, keep;
        limit = cfg.maxQty > 0 ? cfg.maxQty : Math.min(10000, Math.ceil(cfg.binW * cfg.binH / Math.max(0.01, cfg.area)) + 12);
        for (ai = 0; ai < Math.min(variants.length, 6); ai++) {
            a = variants[ai];
            for (bi = 0; bi < Math.min(variants.length, 6); bi++) {
                b = variants[bi]; dxs = [0, a.w * 0.25, a.w * 0.5, a.w * 0.75];
                for (di = 0; di < dxs.length; di++) {
                    dx = dxs[di]; step = Math.max(cfg.strictGap ? 0.08 : 0.25, Math.min(a.w, a.h, b.w, b.h) / (cfg.fast ? (cfg.strictGap ? 90 : 22) : (cfg.strictGap ? 140 : 42)));
                    found = -1; prev = 0;
                    var yGap = cfg.strictGap ? cfg.gapY : cfg.gap;
                    for (dy = Math.max(cfg.strictGap ? step : gapOrZero(yGap), step); dy <= a.h + b.h + yGap + EPS; dy += step) {
                        if (pairFits(a, b, dx, dy, yGap)) {
                            found = cfg.strictGap ? refineFirstFitV83(function(q){ return pairFits(a, b, dx, q, yGap); }, prev, dy) : dy;
                            break;
                        }
                        prev = dy;
                    }
                    if (found < 0) { continue; }
                    if (!bestMeta || found < bestMeta.dy - EPS || (Math.abs(found - bestMeta.dy) < EPS && dx < bestMeta.dx)) {
                        bestMeta = { a:a, b:b, dx:dx, dy:found };
                    }
                }
            }
        }
        if (!bestMeta) { return {items:[],count:0,method:"true-shape-staggered"}; }
        for (var phase = 0; phase < 2; phase++) {
            var items = [], baseX = phase ? bestMeta.dx : 0;
            for (r = 0, y = 0; y + Math.min(bestMeta.a.h, bestMeta.b.h) <= cfg.binH + EPS; r++, y += bestMeta.dy) {
                v = (r % 2) ? bestMeta.b : bestMeta.a;
                x = baseX + ((r % 2) ? bestMeta.dx : 0);
                rowItems = [];
                rowPitch = cfg.strictGap ? minPitchXV34(v, v, 0, cfg.gapX, cfg.fast, true) : (v.w + cfg.gap);
                while (x + v.w <= cfg.binW + EPS) {
                    keep = Math.min(180, Math.ceil(cfg.binW / Math.max(EPS, Math.min(v.w, bestMeta.a.w, bestMeta.b.w))) + 12);
                    local = items.slice(Math.max(0, items.length - keep));
                    poly = fits(v, x, y, local, cfg.binW, cfg.binH, cfg.gap);
                    if (!poly) { x += rowPitch; continue; }
                    items.push({x:x,y:y,w:v.w,h:v.h,angle:v.angle,rotated:Math.abs((v.angle%180)-90)<EPS,
                        offsetX:v.offsetX,offsetY:v.offsetY,poly:poly});
                    rowItems.push({x:x,v:v}); if (items.length >= limit) { break; }
                    x += rowPitch;
                }
                if (items.length >= limit) { break; }
            }
            if (items.length > best.length) { best = items; }
        }
        return {items:best,count:best.length,method:cfg.strictGap?"true-shape-staggered-precision-v95":"true-shape-staggered",
            strictGap:cfg.strictGap===true,efficiency:best.length * cfg.area / Math.max(EPS, cfg.binW * cfg.binH)};
    }
    function gapOrZero(v) { return Math.max(0, Number(v) || 0); }
    function stripPrivate(items) {
        var out = [], i, p;
        for (i = 0; i < items.length; i++) { p = items[i]; out.push({ x:p.x,y:p.y,w:p.w,h:p.h,angle:p.angle,rotated:p.rotated,offsetX:p.offsetX,offsetY:p.offsetY,
            sourceIndex:p.sourceIndex,copyIndex:p.copyIndex }); }
        return out;
    }
    function mixedAreaV45(item) {
        if (item._anpAreaV45 === undefined) { item._anpAreaV45 = polygonArea(item.shape.points); }
        return Number(item._anpAreaV45);
    }
    function mixedVariantKeyV45(job) {
        var sig = job && job.shape ? String(job.shape.signature || (job.shape.w + "x" + job.shape.h + "#" + job.shape.points.length)) : "shape";
        return String(job.sourceIndex === undefined ? "_" : job.sourceIndex) + "|" + sig;
    }
    function mixedVariantsV45(job, cfg) {
        var cache = cfg._anpVariantCacheV45 || (cfg._anpVariantCacheV45 = {}), key = mixedVariantKeyV45(job);
        if (!cache[key]) { cache[key] = orientationList(job.shape.points, job.shape.w, job.shape.h, cfg.angles); }
        return cache[key];
    }
    function mixedOrder(items, kind) {
        var out = items.slice(0); out.sort(function(a,b) {
            var aa = mixedAreaV45(a), ba = mixedAreaV45(b), d;
            if (kind === 1) { d = Math.max(b.shape.w,b.shape.h)-Math.max(a.shape.w,a.shape.h); if (Math.abs(d)>EPS) { return d; } }
            if (kind === 2) { d = b.shape.h-a.shape.h; if (Math.abs(d)>EPS) { return d; } }
            if (kind === 3) { d = b.shape.w-a.shape.w; if (Math.abs(d)>EPS) { return d; } }
            return ba-aa;
        }); return out;
    }
    function placeMixedOrder(items, cfg, strategy) {
        var placed=[], skipped=[], i, vi, ci, job, variants, pts, poly, best, score, v, placedBox;
        for (i=0;i<items.length;i++) {
            job=items[i]; variants=mixedVariantsV45(job,cfg); best=null; placedBox=placedBoundsV45(placed);
            for (vi=0;vi<variants.length;vi++) {
                v=variants[vi]; pts=candidatePoints(placed,v,cfg.binW,cfg.binH,cfg.gap,strategy,cfg.fast?72:180);
                for (ci=0;ci<pts.length;ci++) {
                    poly=fits(v,pts[ci].x,pts[ci].y,placed,cfg.binW,cfg.binH,cfg.gap); if(!poly){continue;}
                    score=compactScoreBoundsV45(pts[ci].x,pts[ci].y,v,placedBox,strategy)+vi*0.0001;
                    if(!best||score<best.score){best={score:score,v:v,x:pts[ci].x,y:pts[ci].y,poly:poly};}
                    if(ci>(cfg.fast?58:150)&&best){break;}
                }
            }
            if(!best){skipped.push(job);continue;}
            placed.push({x:best.x,y:best.y,w:best.v.w,h:best.v.h,angle:best.v.angle,
                rotated:Math.abs(best.v.angle-90)<0.001,offsetX:best.v.offsetX,offsetY:best.v.offsetY,poly:best.poly,
                sourceIndex:job.sourceIndex,copyIndex:job.copyIndex});
        }
        return {items:placed,skipped:skipped};
    }
    function packMixed(cfg) {
        var best=null,kind,strategy,cand,kindLimit=cfg.fast?2:4,strategyLimit=cfg.fast?2:4;
        /* V4.5: cache góc xoay theo source/shape cho toàn bộ các chiến lược.
           Không đổi hình học hay số candidate; chỉ tránh rotate lại cùng polygon hàng nghìn lần. */
        cfg._anpVariantCacheV45 = {};
        for(kind=0;kind<kindLimit;kind++){for(strategy=0;strategy<strategyLimit;strategy++){
            cand=placeMixedOrder(mixedOrder(cfg.items,kind),cfg,strategy);
            if(!best||cand.items.length>best.items.length){best=cand;}
        }}
        if(!best){best={items:[],skipped:cfg.items.slice(0)};}
        best.items=stripPrivate(best.items);best.count=best.items.length;best.method="true-shape-mixed";
        return best;
    }
    function pack(cfg) {
        var shape = cfg.shape, poly = shape.points, area = polygonArea(poly), angles = cfg.angles || [0, 15, 30, 45, 60, 75, 90];
        var local = { binW:num(cfg.binW,0), binH:num(cfg.binH,0), gap:Math.max(0,num(cfg.gap,0)),
            gapX:Math.max(0,num(cfg.gapX,cfg.gap)), gapY:Math.max(0,num(cfg.gapY,cfg.gap)),
            maxQty:Math.max(0,Math.floor(num(cfg.maxQty,0))), area:area, shape:shape, fast:cfg.fast===true, strictGap:cfg.strictGap===true };
        if (shape.isCircle) { return honeycomb(local); }
        var variants = orientationList(poly, shape.w, shape.h, local.strictGap ? [0,90,180,270] : angles), best = [], strategy, cand, quick = null, interlock = null, bestMethod = "true-shape-polygon";
        /* V98 CACHE HOTFIX:
           Không return sớm ở Profile FAST nữa. Exact mode phải thử TẤT CẢ họ pattern tuần hoàn
           (profile hàng/cột + khóa nhau 90/270, 0/180 + so le) rồi chọn số con lớn nhất.
           Nhờ vậy bật khe đều không tự hy sinh số con chỉ vì solver đầu tiên tìm thấy layout an toàn. */
        if (local.strictGap && cfg.stagger !== false) {
            var profileLayoutV95 = profilePackV95(local, variants), looseCfgV97, looseInterV97, looseStaggerV97, looseTargetV97 = 0;
            if (profileLayoutV95 && profileLayoutV95.count > best.length) {
                best = profileLayoutV95.items; bestMethod = profileLayoutV95.method;
            }
            /* Probe rất nhanh layout "không strict" để biết số con mà người dùng đang thấy khi tắt Exact Gap.
               Nếu exact profile đã bằng/vượt số đó thì không cần chạy polygon search nặng. Nếu chưa bằng,
               dùng số đó làm target và dừng ngay khi exact interlock đạt được cùng số con. */
            looseCfgV97 = {binW:local.binW,binH:local.binH,gap:local.gap,gapX:local.gapX,gapY:local.gapY,
                maxQty:local.maxQty,area:local.area,shape:local.shape,fast:true,strictGap:false};
            looseInterV97 = interlockingColumnsV34(looseCfgV97, variants);
            looseStaggerV97 = staggered(looseCfgV97, variants);
            looseTargetV97 = Math.max(looseInterV97 ? looseInterV97.count : 0, looseStaggerV97 ? looseStaggerV97.count : 0);
            if (best.length < looseTargetV97) {
                local.exactTargetCount = looseTargetV97;
                interlock = interlockingColumnsV34(local, variants);
                if (interlock.count > best.length) { best = interlock.items; bestMethod = interlock.method; }
                if (best.length < looseTargetV97) {
                    quick = staggered(local, variants);
                    if (quick.count > best.length) { best = quick.items; bestMethod = quick.method; }
                }
            }
            if (best.length) {
                return {items:stripPrivate(best),count:best.length,method:"true-shape-auto-max-exact-v97|"+bestMethod,
                    strictGap:true,precisionGap:true,autoMaxExact:true,looseTargetV97:looseTargetV97,
                    efficiency:best.length * area / Math.max(EPS, local.binW * local.binH)};
            }
        }
        if (cfg.stagger !== false) {
            interlock = interlockingColumnsV34(local, variants);
            if (interlock.count > best.length) { best = interlock.items; bestMethod = interlock.method; }
            quick = staggered(local, variants);
            if (quick.count > best.length) { best = quick.items; bestMethod = quick.method; }
            if (local.fast && best.length >= 24) { return {items:stripPrivate(best),count:best.length,method:bestMethod,
                efficiency:best.length * area / Math.max(EPS, local.binW * local.binH)}; }
        }
        var strategyLimit = local.fast ? 2 : 4;
        for (strategy = 0; strategy < strategyLimit; strategy++) {
            cand = greedy(variants, local, strategy, strategy % Math.max(1, variants.length));
            if (cand.length > best.length) { best = cand; bestMethod = "true-shape-polygon"; }
        }
        return { items: stripPrivate(best), count: best.length, method:bestMethod,
            efficiency: best.length * area / (local.binW * local.binH) };
    }
    return { pack: pack, packMixed:packMixed, polygonArea: polygonArea, polyDistance: polyDistance, rotateVariant: rotateVariant, staggered:staggered,
        interlockingColumns:interlockingColumnsV34 };
}());




/*
  DPV® Desktop Bridge v0.1.20
  Illustrator automation host engine
*/

var ANP_STATE = ANP_STATE || { manualDoc: null, manualDie: null };
var VDPRO_BRIDGE_VERSION = "0.1.24-v1491-native-batch-cache";
var ANP_REF_NAME = "__ANP_REFERENCE_BOUNDS__";
var ANP_SAFE_FILE_SEQ_V57 = 0;

function ANP_mm(v) { return Number(v) * 2.834645669291339; }
function ANP_toMm(v) { return Number(v) / 2.834645669291339; }



function ANP_stringify(value) {
    var t = typeof value, i, parts, k;
    if (value === null) { return "null"; }
    if (t === "string") {
        return '"' + value.replace(/\\/g, "\\\\").replace(/\"/g, '\\"')
            .replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t") + '"';
    }
    if (t === "number") { return isFinite(value) ? String(value) : "null"; }
    if (t === "boolean") { return value ? "true" : "false"; }
    if (value instanceof Array) {
        parts = [];
        for (i = 0; i < value.length; i++) { parts.push(ANP_stringify(value[i])); }
        return "[" + parts.join(",") + "]";
    }
    parts = [];
    for (k in value) {
        if (value.hasOwnProperty(k)) { parts.push(ANP_stringify(k) + ":" + ANP_stringify(value[k])); }
    }
    return "{" + parts.join(",") + "}";
}

function ANP_ok(data) {
    data = data || {};
    data.ok = true;
    return ANP_stringify(data);
}

function ANP_fail(error) {
    var message = error && error.message ? error.message : String(error);
    return ANP_stringify({ ok: false, error: message });
}


/* ========================================================================== */
/* V4.8 PERFORMANCE PROFILER                                                  */
/* Đo thời gian thực từng công đoạn ngay trong Illustrator ExtendScript.      */
/* Không thay đổi thuật toán; chỉ ghi nhận thời gian để tìm bottleneck thật.   */
/* ========================================================================== */
function ANP_perfNowV48() {
    return (new Date()).getTime();
}

function ANP_perfStartV48() {
    var now = ANP_perfNowV48();
    return { started:now, last:now, stages:[] };
}

function ANP_perfMarkV48(perf, name) {
    if (!perf) { return 0; }
    var now = ANP_perfNowV48(), elapsed = Math.max(0, now - perf.last);
    perf.stages.push({ name:String(name || "Công đoạn"), ms:elapsed });
    perf.last = now;
    return elapsed;
}

function ANP_perfFinishV48(perf) {
    var total, i, copy = [], top = [], pct;
    if (!perf) { return null; }
    total = Math.max(1, ANP_perfNowV48() - perf.started);
    for (i = 0; i < perf.stages.length; i++) {
        pct = Math.round((Number(perf.stages[i].ms || 0) / total) * 1000) / 10;
        perf.stages[i].percent = pct;
        copy.push({ name:perf.stages[i].name, ms:perf.stages[i].ms, percent:pct });
    }
    copy.sort(function (a, b) { return Number(b.ms || 0) - Number(a.ms || 0); });
    for (i = 0; i < copy.length && i < 3; i++) { top.push(copy[i]); }
    return { totalMs:total, stages:perf.stages, bottlenecks:top, profiler:"V4.9" };
}

function ANP_perfFailV48(error, perf) {
    var message = error && error.message ? error.message : String(error);
    return ANP_stringify({ ok:false, error:message, performance:ANP_perfFinishV48(perf) });
}

function ANP_parse(json) {
    var cfg = eval("(" + json + ")");
    /* FILE KHUÔN luôn phải là vector thật. Không cho cấu hình cũ bật lại
       PlacedItem/Symbol liên kết trong tài liệu khuôn. */
    cfg.dieAsLink = false;
    /* V56: cấu hình cũ không có các trường PON mới vẫn phải chạy an toàn. */
    cfg.cornerPonRed = cfg.cornerPonRed === true;
    cfg.finishCropMarks = cfg.finishCropMarks === true;
    cfg.finishMarkLength = Math.max(0.1, Number(cfg.finishMarkLength) || 6);
    cfg.finishMarkGap = Math.max(0, Number(cfg.finishMarkGap) || 0);
    cfg.duplexMode = cfg.duplexMode === true;
    cfg.duplexFlip = String(cfg.duplexFlip || "tumble180");
    /* V66: "tumble180" là chế độ riêng — mặt B giữ nguyên vị trí từng con
       nhưng LUÔN đối đầu ngược 180° so với mặt A (kể cả con không xoay).
       "abComplementary" (V64) chỉ bù góc theo góc gốc: 0->0, 90->270,
       270->90, nên con không xoay ở mặt A sẽ giữ nguyên chiều ở mặt B —
       KHÔNG dùng cho yêu cầu "mặt B phải đối đầu ngược lại mặt A". */
    if (cfg.duplexFlip === "vertical") { cfg.duplexFlip = "tumble180"; }
    if (cfg.duplexFlip === "horizontal") { cfg.duplexFlip = "turnSide"; }
    if (cfg.duplexFlip !== "abComplementary" && cfg.duplexFlip !== "turnSide" && cfg.duplexFlip !== "tumble180") {
        cfg.duplexFlip = "tumble180";
    }
    if (cfg.duplexMode === true) { cfg.finishCropMarks = true; }
    return cfg;
}

function ANP_round(v, digits) {
    var p = Math.pow(10, digits || 0);
    return Math.round(v * p) / p;
}

function ANP_upper(s) {
    s = String(s || "").toUpperCase();
    s = s.replace(/[ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴ]/g, "A")
         .replace(/[ÈÉẸẺẼÊỀẾỆỂỄ]/g, "E")
         .replace(/[ÌÍỊỈĨ]/g, "I")
         .replace(/[ÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠ]/g, "O")
         .replace(/[ÙÚỤỦŨƯỪỨỰỬỮ]/g, "U")
         .replace(/[ỲÝỴỶỸ]/g, "Y").replace(/Đ/g, "D");
    return s;
}

function ANP_hasDieWord(s, hint) {
    var text = ANP_upper(s), compact, tokenized, keys, i, h;
    if (!text) { return false; }
    compact = text.replace(/[^A-Z0-9]/g, "");
    tokenized = "_" + text.replace(/[^A-Z0-9]+/g, "_") + "_";
    h = ANP_upper(hint).replace(/[^A-Z0-9]/g, "");
    if (h && compact.indexOf(h) >= 0) { return true; }
    keys = ["KHUON", "DIE", "CUTCONTOUR", "KISSCUT", "THANHPHAM"];
    for (i = 0; i < keys.length; i++) {
        if (compact.indexOf(keys[i]) >= 0) { return true; }
    }
    /* “BE” is matched as a token only, so names such as LABEL are not mistaken
       for a die line. */
    if (tokenized.indexOf("_BE_") >= 0 || tokenized.indexOf("_DIE_") >= 0 || tokenized.indexOf("_CUT_") >= 0) { return true; }
    return false;
}

function ANP_colorLooksDie(color, hint) {
    var n;
    if (!color) { return false; }
    try {
        if (color.typename === "SpotColor") {
            n = color.spot ? color.spot.name : "";
            return ANP_hasDieWord(n, hint);
        }
        if (color.typename === "RGBColor") {
            return color.red >= 180 && color.green <= 105 && color.blue <= 105;
        }
        if (color.typename === "CMYKColor") {
            return color.cyan <= 25 && color.magenta >= 70 && color.yellow >= 50 && color.black <= 35;
        }
    } catch (e) {}
    return false;
}

function ANP_itemNamedDie(item, hint) {
    try { if (ANP_hasDieWord(item.name, hint)) { return true; } } catch (e1) {}
    try { if (ANP_hasDieWord(item.note, hint)) { return true; } } catch (e2) {}
    try { if (item.layer && ANP_hasDieWord(item.layer.name, hint)) { return true; } } catch (e3) {}
    try { if (item.parent && ANP_hasDieWord(item.parent.name, hint)) { return true; } } catch (e4) {}
    return false;
}

function ANP_isDieItem(item, hint, inherited) {
    var i;
    if (!item) { return false; }
    inherited = inherited || ANP_itemNamedDie(item, hint);
    try {
        if (item.typename === "PathItem") {
            if (item.name === ANP_REF_NAME) { return false; }
            return inherited || (item.stroked && ANP_colorLooksDie(item.strokeColor, hint));
        }
        if (item.typename === "CompoundPathItem") {
            if (inherited) { return true; }
            for (i = 0; i < item.pathItems.length; i++) {
                if (ANP_isDieItem(item.pathItems[i], hint, false)) { return true; }
            }
        }
    } catch (e) {}
    return false;
}

function ANP_pushUnique(arr, item) {
    var i;
    for (i = 0; i < arr.length; i++) { if (arr[i] === item) { return; } }
    arr.push(item);
}

function ANP_collectAutoDie(item, hint, inherited, out) {
    var i, named;
    if (!item) { return; }
    try {
        if (item.hidden) { return; }
    } catch (e0) {}
    named = inherited || ANP_itemNamedDie(item, hint);
    try {
        if (item.typename === "CompoundPathItem") {
            if (ANP_isDieItem(item, hint, named)) { ANP_pushUnique(out, item); }
            return;
        }
        if (item.typename === "PathItem") {
            if (item.parent && item.parent.typename === "CompoundPathItem") { return; }
            if (ANP_isDieItem(item, hint, named)) { ANP_pushUnique(out, item); }
            return;
        }
        if (item.typename === "GroupItem") {
            for (i = 0; i < item.pageItems.length; i++) {
                ANP_collectAutoDie(item.pageItems[i], hint, named, out);
            }
        }
    } catch (e1) {}
}

function ANP_collectAllVectors(item, out) {
    var i;
    if (!item) { return; }
    try {
        if (item.hidden === true) { return; }
        if (item.typename === "CompoundPathItem") { ANP_pushUnique(out, item); return; }
        if (item.typename === "PathItem") {
            if (!(item.parent && item.parent.typename === "CompoundPathItem")) { ANP_pushUnique(out, item); }
            return;
        }
        if (item.typename === "GroupItem") {
            for (i = 0; i < item.pageItems.length; i++) { ANP_collectAllVectors(item.pageItems[i], out); }
        }
    } catch (e) {}
}

/* Nhận contour khuôn bất kỳ khi file không đặt tên/màu KHUON_BE.
   Ưu tiên đường kín có stroke và không fill (quy cách dieline phổ biến),
   sau đó chọn contour ngoài lớn nhất. Khung chữ nhật trùng artboard bị hạ
   điểm để tránh nhận bleed/artboard thành khuôn vuông. */
function ANP_vectorStyleTierV32(item) {
    var i, tier = 0, closed, stroked, filled;
    if (!item) { return 0; }
    try {
        if (item.typename === "CompoundPathItem") {
            for (i = 0; i < item.pathItems.length; i++) {
                tier = Math.max(tier, ANP_vectorStyleTierV32(item.pathItems[i]));
            }
            return tier;
        }
        if (item.typename !== "PathItem" || item.clipping === true) { return 0; }
        closed = item.closed === true; if (!closed) { return 0; }
        stroked = item.stroked === true; filled = item.filled === true;
        if (stroked && !filled) { return 4; }
        if (stroked) { return 3; }
        if (!filled) { return 2; }
        return 1;
    } catch (e) { return 0; }
}

function ANP_boundsMatchArtboardV32(b, a) {
    if (!b || !a) { return false; }
    var tol = ANP_mm(0.35);
    return Math.abs(b[0] - a[0]) <= tol && Math.abs(b[1] - a[1]) <= tol &&
        Math.abs(b[2] - a[2]) <= tol && Math.abs(b[3] - a[3]) <= tol;
}

/* Phân biệt tên gắn trực tiếp lên contour với tên kế thừa từ group/layer.
   Nếu cả artwork nằm trong layer KHUON_BE, việc coi mọi path là khuôn sẽ làm
   một hình nền vuông thắng contour thật. */
function ANP_dieNameWeightV33(item, hint) {
    var i, p;
    try {
        if (ANP_hasDieWord(item.name, hint) || ANP_hasDieWord(item.note, hint)) { return 4; }
    } catch (e0) {}
    try {
        p = item.parent;
        if (p && p.typename !== "Layer" && ANP_hasDieWord(p.name, hint)) { return 3; }
    } catch (e1) {}
    try { if (item.layer && ANP_hasDieWord(item.layer.name, hint)) { return 2; } } catch (e2) {}
    try {
        if (item.typename === "PathItem" && item.stroked && ANP_colorLooksDie(item.strokeColor, hint)) { return 1; }
        if (item.typename === "CompoundPathItem") {
            for (i = 0; i < item.pathItems.length; i++) {
                if (item.pathItems[i].stroked && ANP_colorLooksDie(item.pathItems[i].strokeColor, hint)) { return 1; }
            }
        }
    } catch (e3) {}
    return 0;
}

/* Chấm điểm TẤT CẢ contour thay vì dừng ngay ở đường đỏ/tên KHUON_BE đầu
   tiên. Nhờ vậy khuôn vòm/chìa khóa/chữ D được chọn thay cho khung nền hoặc
   clipping rectangle. Shape được chọn ở đây là shape duy nhất dùng cho đo,
   nesting, preview và file khuôn xuất. */
function ANP_inferDieV33(sourceItems, artRect, hint) {
    var vectors = [], best = null, bestScore = -1e30, i, item, b, w, h, area, tier, poly, fillRatio, score;
    var nameWeight, artArea = 0, relativeArea, artboardRect;
    try { artArea = Math.max(0.0001, (artRect[2] - artRect[0]) * (artRect[1] - artRect[3])); } catch (eArt) {}
    for (i = 0; i < sourceItems.length; i++) { ANP_collectAllVectors(sourceItems[i], vectors); }
    for (i = 0; i < vectors.length; i++) {
        item = vectors[i]; tier = ANP_vectorStyleTierV32(item); if (!tier) { continue; }
        try { b = item.geometricBounds; } catch (e0) { continue; }
        w = b[2] - b[0]; h = b[1] - b[3]; area = w * h;
        if (w <= ANP_mm(0.5) || h <= ANP_mm(0.5) || area <= 0) { continue; }
        poly = ANP_largestDiePolygonV20([item]);
        if (!poly || poly.length < 3) { continue; }
        fillRatio = Math.abs(ANP_signedAreaV20(poly)) / Math.max(0.0001, area);
        nameWeight = ANP_dieNameWeightV33(item, hint || "");
        relativeArea = artArea > 0 ? Math.min(1.5, area / artArea) : 0;
        artboardRect = ANP_boundsMatchArtboardV32(b, artRect) && fillRatio >= 0.995;
        score = tier * 1e12 + nameWeight * 2e12 + relativeArea * 1e9;
        /* Contour lõm/cong thật được ưu tiên hơn bounding rectangle. */
        if (fillRatio < 0.995) { score += 3e12; }
        /* Khung trùng artboard chỉ bị hạ điểm khi không được đặt tên trực tiếp.
           Một dieline chữ nhật thực sự vẫn hoạt động nếu người dùng đặt tên path. */
        if (artboardRect && nameWeight < 4) { score -= 7e12; }
        if (score > bestScore) { bestScore = score; best = item; }
    }
    return best ? [best] : [];
}

/* Giữ tên cũ để script/Bridge cũ đang gọi không bị gãy. */
function ANP_inferDieV32(sourceItems, artRect) {
    return ANP_inferDieV33(sourceItems, artRect, "KHUON_BE");
}

function ANP_bounds(items) {
    var i, b, left = 1e20, top = -1e20, right = -1e20, bottom = 1e20;
    if (!items || !items.length) { return null; }
    for (i = 0; i < items.length; i++) {
        try {
            b = items[i].geometricBounds;
            left = Math.min(left, b[0]); top = Math.max(top, b[1]);
            right = Math.max(right, b[2]); bottom = Math.min(bottom, b[3]);
        } catch (e) {}
    }
    if (left === 1e20) { return null; }
    return [left, top, right, bottom];
}

function ANP_cubicPointV20(p0, p1, p2, p3, t) {
    var u = 1 - t, uu = u * u, tt = t * t;
    return [uu * u * p0[0] + 3 * uu * t * p1[0] + 3 * u * tt * p2[0] + tt * t * p3[0],
        uu * u * p0[1] + 3 * uu * t * p1[1] + 3 * u * tt * p2[1] + tt * t * p3[1]];
}


function ANP_pointLineDistV95(p, a, b) {
    var dx=Number(b[0])-Number(a[0]), dy=Number(b[1])-Number(a[1]), den=dx*dx+dy*dy, t, qx, qy;
    if (den < 1e-12) { dx=Number(p[0])-Number(a[0]); dy=Number(p[1])-Number(a[1]); return Math.sqrt(dx*dx+dy*dy); }
    t=((Number(p[0])-Number(a[0]))*dx+(Number(p[1])-Number(a[1]))*dy)/den;
    qx=Number(a[0])+t*dx; qy=Number(a[1])+t*dy; dx=Number(p[0])-qx; dy=Number(p[1])-qy; return Math.sqrt(dx*dx+dy*dy);
}
function ANP_flattenCubicV95(p0,p1,p2,p3,tolPt,depth,out) {
    var flat=Math.max(ANP_pointLineDistV95(p1,p0,p3),ANP_pointLineDistV95(p2,p0,p3));
    if (flat<=tolPt || depth>=11) { out.push([Number(p3[0]),Number(p3[1])]); return; }
    var p01=[(p0[0]+p1[0])/2,(p0[1]+p1[1])/2], p12=[(p1[0]+p2[0])/2,(p1[1]+p2[1])/2], p23=[(p2[0]+p3[0])/2,(p2[1]+p3[1])/2];
    var p012=[(p01[0]+p12[0])/2,(p01[1]+p12[1])/2], p123=[(p12[0]+p23[0])/2,(p12[1]+p23[1])/2], pm=[(p012[0]+p123[0])/2,(p012[1]+p123[1])/2];
    ANP_flattenCubicV95(p0,p01,p012,pm,tolPt,depth+1,out); ANP_flattenCubicV95(pm,p123,p23,p3,tolPt,depth+1,out);
}

function ANP_pathPolygonV20(path) {
    var pp,out=[],i,next,p0,p1,p2,p3,seg=[],j,q,gb=null,tolPt=ANP_mm(0.018);
    try { if(!path.closed||path.pathPoints.length<3){return [];} pp=path.pathPoints; try{gb=path.geometricBounds;}catch(eGb){gb=null;} } catch(e){return [];}
    for(i=0;i<pp.length;i++){
        next=(i+1)%pp.length; p0=pp[i].anchor; p1=pp[i].rightDirection; p2=pp[next].leftDirection; p3=pp[next].anchor;
        if(!out.length){out.push([Number(p0[0]),Number(p0[1])]);}
        seg=[]; ANP_flattenCubicV95(p0,p1,p2,p3,tolPt,0,seg);
        for(j=0;j<seg.length;j++){q=seg[j]; if(!out.length||Math.abs(q[0]-out[out.length-1][0])>0.0005||Math.abs(q[1]-out[out.length-1][1])>0.0005){out.push(q);}}
    }
    /* điểm cuối trùng điểm đầu của path closed thì bỏ để tránh segment zero-length */
    if(out.length>2 && Math.abs(out[0][0]-out[out.length-1][0])<0.0005 && Math.abs(out[0][1]-out[out.length-1][1])<0.0005){out.pop();}
    if(gb&&gb.length>=4){out._anpExactBoundsV93=[Number(gb[0]),Number(gb[1]),Number(gb[2]),Number(gb[3])];}
    return out;
}

function ANP_limitPolygonV22(poly, maxPoints) {
    if (!poly) { return []; }
    if (poly.length <= maxPoints) { return poly; }
    var out = [], i, index, last = -1;
    for (i = 0; i < maxPoints; i++) {
        index = Math.floor(i * poly.length / maxPoints);
        if (index !== last) { out.push(poly[index]); last = index; }
    }
    if (poly._anpExactBoundsV93) { out._anpExactBoundsV93 = poly._anpExactBoundsV93; }
    return out;
}

function ANP_signedAreaV20(poly) {
    var i, j, a = 0; for (i = 0, j = poly.length - 1; i < poly.length; j = i++) { a += poly[j][0] * poly[i][1] - poly[i][0] * poly[j][1]; }
    return a / 2;
}

function ANP_largestDiePolygonV20(dieItems) {
    var candidates = [], i, j, p, poly, best = [], bestArea = -1;
    for (i = 0; i < dieItems.length; i++) {
        p = dieItems[i];
        try {
            if (p.typename === "CompoundPathItem") {
                for (j = 0; j < p.pathItems.length; j++) { candidates.push(p.pathItems[j]); }
            } else if (p.typename === "PathItem") { candidates.push(p); }
        } catch (e0) {}
    }
    for (i = 0; i < candidates.length; i++) {
        poly = ANP_limitPolygonV22(ANP_pathPolygonV20(candidates[i]), 720);
        if (poly.length >= 3 && Math.abs(ANP_signedAreaV20(poly)) > bestArea) { best = poly; bestArea = Math.abs(ANP_signedAreaV20(poly)); }
    }
    return best;
}

function ANP_shapeFromDieV20(dieItems, fallbackBounds) {
    var raw = ANP_largestDiePolygonV20(dieItems), b = fallbackBounds, points = [], i, left, top, right, bottom;
    if (raw.length) {
        /* V93: ưu tiên geometricBounds thật của chính contour đã chọn. Polygon chỉ
           dùng cho collision. Không lấy bounds từ các sample Bézier xấp xỉ. */
        if (raw._anpExactBoundsV93 && raw._anpExactBoundsV93.length >= 4) {
            b = raw._anpExactBoundsV93;
        } else {
            left = 1e20; top = -1e20; right = -1e20; bottom = 1e20;
            for (i = 0; i < raw.length; i++) { left = Math.min(left, raw[i][0]); right = Math.max(right, raw[i][0]); top = Math.max(top, raw[i][1]); bottom = Math.min(bottom, raw[i][1]); }
            b = [left, top, right, bottom];
        }
        left = Number(b[0]); top = Number(b[1]);
        for (i = 0; i < raw.length; i++) { points.push({ x: ANP_toMm(raw[i][0] - left), y: ANP_toMm(top - raw[i][1]) }); }
    } else {
        points = [{x:0,y:0},{x:ANP_toMm(b[2]-b[0]),y:0},{x:ANP_toMm(b[2]-b[0]),y:ANP_toMm(b[1]-b[3])},{x:0,y:ANP_toMm(b[1]-b[3])}];
    }
    var w = ANP_toMm(b[2] - b[0]), h = ANP_toMm(b[1] - b[3]), cx = w / 2, cy = h / 2, minR = 1e20, maxR = 0, sumR = 0, r;
    for (i = 0; i < points.length; i++) { r = Math.sqrt(Math.pow(points[i].x - cx, 2) + Math.pow(points[i].y - cy, 2)); minR = Math.min(minR, r); maxR = Math.max(maxR, r); sumR += r; }
    var avgR = points.length ? sumR / points.length : 0;
    var isCircle = raw.length > 8 && Math.abs(w - h) / Math.max(w, h) < 0.02 && avgR > 0 && (maxR - minR) / avgR < 0.035;
    var pointObjects = [], signed = 0, jj;
    for (i = 0; i < points.length; i++) { pointObjects.push(points[i]); jj = (i + 1) % points.length; signed += points[i].x * points[jj].y - points[jj].x * points[i].y; }
    var fillRatio = Math.abs(signed / 2) / Math.max(0.0001, w * h), isRectangle = !isCircle && fillRatio > 0.9995;
    var sig = (isCircle ? "C" : (isRectangle ? "R" : "P")) + "_" + ANP_round(w,2) + "x" + ANP_round(h,2) + "_" + points.length + "_V95_";
    for (i = 0; i < points.length; i += Math.max(1, Math.floor(points.length / 12))) { sig += ANP_round(points[i].x,1) + "," + ANP_round(points[i].y,1) + ";"; }
    return { points: points, w: ANP_round(w, 4), h: ANP_round(h, 4), isCircle: isCircle,
        isRectangle: isRectangle, fillRatio: ANP_round(fillRatio, 5), signature: sig, gapPrecision:"multi-contact-axis-v95" };
}

/* V5.5 — SERIALIZE BÉZIER TRỰC TIẾP TỪ CONTOUR NGUỒN
   Không đưa KHUON_BE qua duplicate cross-document / Static Symbol nữa. Một số
   file AI/PDF biến Path thành PluginItem hoặc Symbol không thể Break Link khi
   chuyển sang DIE-LINK. V5.5 đọc anchor + hai tay nắm ngay trong file nguồn,
   lưu theo tọa độ mm tương đối và dựng lại PathItem thuần ở FILE KHUÔN. */
function ANP_localBezierPointV55(point, left, top) {
    return [ANP_toMm(Number(point[0]) - Number(left)), ANP_toMm(Number(top) - Number(point[1]))];
}

function ANP_serializeBezierPathV55(path, bounds) {
    var pts, out = [], i, point, smooth = false;
    try {
        if (path.clipping === true) { return null; }
        pts = path.pathPoints;
        if (!pts || pts.length < 2) { return null; }
        for (i = 0; i < pts.length; i++) {
            point = pts[i]; smooth = false;
            try { smooth = String(point.pointType).toUpperCase().indexOf("SMOOTH") >= 0; } catch (e0) {}
            out.push({
                a:ANP_localBezierPointV55(point.anchor, bounds[0], bounds[1]),
                l:ANP_localBezierPointV55(point.leftDirection, bounds[0], bounds[1]),
                r:ANP_localBezierPointV55(point.rightDirection, bounds[0], bounds[1]),
                smooth:smooth
            });
        }
        return { closed:path.closed === true, points:out };
    } catch (e1) { return null; }
}

function ANP_collectBezierGeometryV55(item, bounds, out) {
    var i, path;
    if (!item) { return; }
    try {
        if (item.typename === "PathItem") {
            path = ANP_serializeBezierPathV55(item, bounds);
            if (path) { out.push(path); }
            return;
        }
        if (item.typename === "CompoundPathItem") {
            for (i = 0; i < item.pathItems.length; i++) {
                path = ANP_serializeBezierPathV55(item.pathItems[i], bounds);
                if (path) { out.push(path); }
            }
            return;
        }
        if (item.typename === "GroupItem") {
            for (i = 0; i < item.pageItems.length; i++) { ANP_collectBezierGeometryV55(item.pageItems[i], bounds, out); }
        }
    } catch (e) {}
}

function ANP_rectangleDieGeometryV55(bounds, itemW, itemH) {
    /* V147.8.4 MULTI ARTBOARD UNDEFINED FIX:
       Preview artboard không có KHUON_BE có thể truyền bounds=null.
       Bản cũ đọc bounds[2] ngay lập tức => ExtendScript báo
       "undefined is not an object". Nếu bounds không tồn tại, dựng hình chữ
       nhật chuẩn trực tiếp từ kích thước artboard đã biết. */
    var hasBounds = !!(bounds && bounds.length >= 4);
    var w = hasBounds ? ANP_toMm(bounds[2] - bounds[0]) : Number(itemW);
    var h = hasBounds ? ANP_toMm(bounds[1] - bounds[3]) : Number(itemH);
    if (!(w > 0) || !(h > 0)) { return null; }
    return { sourceW:w, sourceH:h, itemW:Number(itemW) || w, itemH:Number(itemH) || h,
        paths:[{ closed:true, points:[
            {a:[0,0],l:[0,0],r:[0,0],smooth:false},
            {a:[w,0],l:[w,0],r:[w,0],smooth:false},
            {a:[w,h],l:[w,h],r:[w,h],smooth:false},
            {a:[0,h],l:[0,h],r:[0,h],smooth:false}
        ] }] };
}

function ANP_dieGeometryV55(dieItems, bounds, itemW, itemH) {
    var paths = [], i, w, h;
    if (!bounds) { return null; }
    for (i = 0; i < (dieItems ? dieItems.length : 0); i++) { ANP_collectBezierGeometryV55(dieItems[i], bounds, paths); }
    w = ANP_toMm(bounds[2] - bounds[0]); h = ANP_toMm(bounds[1] - bounds[3]);
    return { sourceW:w, sourceH:h, itemW:Number(itemW) || w, itemH:Number(itemH) || h, paths:paths };
}

function ANP_intersects(a, b) {
    return !(a[2] < b[0] || a[0] > b[2] || a[1] < b[3] || a[3] > b[1]);
}

function ANP_sourceItems(doc, mode) {
    var result = [], i, item, ab;
    if (mode === "selection") {
        if (!doc.selection || !doc.selection.length) {
            throw new Error("Chưa chọn artwork. Hãy chọn toàn bộ tem hoặc chuyển nguồn sang Artboard hiện tại.");
        }
        for (i = 0; i < doc.selection.length; i++) {
            item = doc.selection[i];
            try { if (item.typename && item.typename !== "TextRange") { ANP_pushUnique(result, item); } } catch (e0) {}
        }
        return result;
    }

    ab = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;
    for (i = 0; i < doc.pageItems.length; i++) {
        item = doc.pageItems[i];
        try {
            if (item.parent && item.parent.typename !== "Layer") { continue; }
            if (item.hidden) { continue; }
            /* V4.0: không lấy lại PON/Tiêu đề do DPV sinh ở lần xuất trước. */
            try { if (item.parent && item.parent.typename === "Layer" && ANP_isGeneratedPonLayerNameV40(item.parent.name)) { continue; } } catch (eLayer) {}
            if (ANP_intersects(item.geometricBounds, ab)) { result.push(item); }
        } catch (e1) {}
    }
    if (!result.length) { throw new Error("Artboard hiện tại không có artwork để dàn."); }
    return result;
}

function ANP_autoDie(sourceItems, hint, artRect) {
    if (!artRect) {
        try { artRect = app.activeDocument.artboards[app.activeDocument.artboards.getActiveArtboardIndex()].artboardRect; } catch (e0) {}
    }
    return ANP_inferDieV33(sourceItems, artRect, hint || "");
}

function ANP_manualDieFor(doc) {
    var out = [], i;
    try {
        if (ANP_STATE.manualDoc !== doc || !ANP_STATE.manualDie) { return out; }
        for (i = 0; i < ANP_STATE.manualDie.length; i++) {
            if (ANP_STATE.manualDie[i] && ANP_STATE.manualDie[i].typename) { out.push(ANP_STATE.manualDie[i]); }
        }
    } catch (e) { out = []; }
    return out;
}

function ANP_getDie(doc, sourceItems, hint, artRect) {
    var die = ANP_manualDieFor(doc);
    if (!die.length) { die = ANP_autoDie(sourceItems, hint, artRect); }
    return die;
}

function ANP_scanSource(mode, hint) {
    try {
        if (!app.documents.length) { throw new Error("Chưa mở file tem trong Illustrator."); }
        var doc = app.activeDocument;
        var source = ANP_sourceItems(doc, mode || "artboard");
        var die = ANP_getDie(doc, source, hint || "");
        var b = ANP_bounds(die);
        if (!b) {
            throw new Error("Không tìm thấy viền bế. Hãy chọn riêng đường bế đỏ rồi bấm ‘Lấy viền bế đang chọn’.");
        }
        return ANP_ok({
            width: ANP_round(ANP_toMm(b[2] - b[0]), 2),
            height: ANP_round(ANP_toMm(b[1] - b[3]), 2),
            dieCount: die.length,
            sourceName: doc.name
        });
    } catch (e) { return ANP_fail(e); }
}

function ANP_setManualDie() {
    try {
        if (!app.documents.length) { throw new Error("Chưa mở file tem trong Illustrator."); }
        var doc = app.activeDocument, i, vectors = [], b;
        if (!doc.selection || !doc.selection.length) {
            throw new Error("Hãy chọn riêng viền bế trên file gốc trước khi bấm nút này.");
        }
        for (i = 0; i < doc.selection.length; i++) { ANP_collectAllVectors(doc.selection[i], vectors); }
        if (!vectors.length) { throw new Error("Đối tượng đang chọn không có đường vector dùng làm khuôn bế."); }
        ANP_STATE.manualDoc = doc;
        ANP_STATE.manualDie = vectors;
        b = ANP_bounds(vectors);
        return ANP_ok({
            width: ANP_round(ANP_toMm(b[2] - b[0]), 2),
            height: ANP_round(ANP_toMm(b[1] - b[3]), 2),
            dieCount: vectors.length,
            sourceName: doc.name
        });
    } catch (e) { return ANP_fail(e); }
}

function ANP_layout(cfg) {
    var binW = cfg.paperW - cfg.margin * 2;
    var binH = cfg.paperH - cfg.margin * 2;
    if (binW <= 0 || binH <= 0) { throw new Error("Lề 4 cạnh đang lớn hơn khổ in."); }
    var layout = ANPPacker.pack({
        binW: binW, binH: binH,
        itemW: cfg.itemW, itemH: cfg.itemH,
        gapX: cfg.gapX, gapY: cfg.gapY,
        allowRotate: cfg.allowRotate,
        maxQty: cfg.maxQty
    });
    if (!layout.count) { throw new Error("Tem lớn hơn vùng in còn lại; không dàn được con nào."); }
    layout.binW = binW; layout.binH = binH;
    ANP_centerLayoutV16(layout, binW, binH);
    return layout;
}

/* Trả về bounding box thật của toàn bộ khuôn đã dàn (đơn vị mm).
   Dùng chính x/y/w/h của shape sau xoay nên không bị lệch bởi bleed của FILE IN. */
function ANP_layoutBoundsV35(items) {
    var i, minX = 1e20, minY = 1e20, maxX = -1e20, maxY = -1e20, item;
    if (!items || !items.length) { return { minX:0, minY:0, maxX:0, maxY:0, usedW:0, usedH:0 }; }
    for (i = 0; i < items.length; i++) {
        item = items[i];
        minX = Math.min(minX, Number(item.x)); minY = Math.min(minY, Number(item.y));
        maxX = Math.max(maxX, Number(item.x) + Number(item.w));
        maxY = Math.max(maxY, Number(item.y) + Number(item.h));
    }
    return { minX:minX, minY:minY, maxX:maxX, maxY:maxY, usedW:maxX-minX, usedH:maxY-minY };
}

/* Kiểm tra một dịch chuyển toàn cụm có còn chừa đúng bốn góc PON hay không.
   Không khóa cứng vào bin vì chế độ edge-relax cố ý được phép ăn nhẹ vào lề
   (tối đa gap) để tăng số con; chỉ bảo vệ chính bốn vùng PON. */
function ANP_cornerShiftValidV35(items, dx, dy, binW, binH, clear) {
    var i, item, x, y, right, bottom, atLeft, atRight, atTop, atBottom;
    if (!(Number(clear) > 0)) { return true; }
    for (i = 0; i < items.length; i++) {
        item = items[i]; x = Number(item.x) + Number(dx); y = Number(item.y) + Number(dy);
        right = x + Number(item.w); bottom = y + Number(item.h);
        atLeft = x < Number(clear) - 0.0001;
        atRight = right > Number(binW) - Number(clear) + 0.0001;
        atTop = y < Number(clear) - 0.0001;
        atBottom = bottom > Number(binH) - Number(clear) + 0.0001;
        if ((atLeft && atTop) || (atRight && atTop) || (atLeft && atBottom) || (atRight && atBottom)) { return false; }
    }
    return true;
}

/* Tìm offset gần tâm tuyệt đối nhất nhưng không phá vùng PON. Hầu hết bài dàn
   dùng chính dx/dy tuyệt đối; các candidate phụ chỉ là hàng rào an toàn cho
   bố cục corner-safe bất đối xứng. */
function ANP_bestCenterShiftV35(layout, binW, binH, desiredX, desiredY) {
    var items = layout.items || [], clear = Number(layout.cornerClear || 0), best = null, i, f, cx, cy, score;
    function consider(x, y) {
        if (!ANP_cornerShiftValidV35(items, x, y, binW, binH, clear)) { return; }
        score = (Number(x) - Number(desiredX)) * (Number(x) - Number(desiredX)) +
            (Number(y) - Number(desiredY)) * (Number(y) - Number(desiredY));
        if (!best || score < best.score) { best = { x:Number(x), y:Number(y), score:score }; }
    }
    consider(desiredX, desiredY);
    if (best && best.score < 0.00000001) { return best; }
    consider(desiredX, 0); consider(0, desiredY); consider(0, 0);
    for (i = 1; i <= 40; i++) {
        f = 1 - i / 40;
        cx = Number(desiredX) * f; cy = Number(desiredY) * f;
        consider(desiredX, cy); consider(cx, desiredY); consider(cx, cy);
    }
    return best || { x:0, y:0, score:0 };
}

/* Canh giữa toàn bộ cụm đã dàn theo tâm ARTBOARD, theo cả ngang và dọc.
   Bản cũ bỏ qua bước này khi bật “Chừa rộng bốn góc PON”, vì vậy các bài
   True-Shape/MaxRects bất đối xứng thường bị lệch sang một phía. V3.5 luôn
   tính lại bounds sau edge-relax rồi canh tâm; FILE IN và KHUÔN dùng cùng
   layout nên luôn trùng tâm với nhau. */
function ANP_centerLayoutV16(layout, binW, binH) {
    var items = layout.items || [], i, b, dx, dy, shift;
    if (!items.length) { return layout; }

    /* Candidate edge-relax được pack trên vùng rộng hơn. Đưa nó về hệ tọa độ
       của vùng in thật trước, rồi mới tính tâm; bước này chỉ chạy một lần. */
    if (layout.cornerSafe === true && layout.cornerSafeCentered !== true) {
        dx = -Number(layout.edgeRelaxX || 0); dy = -Number(layout.edgeRelaxY || 0);
        for (i = 0; i < items.length; i++) { items[i].x += dx; items[i].y += dy; }
        layout.cornerSafeCentered = true;
    }

    b = ANP_layoutBoundsV35(items);
    dx = (Number(binW) - Number(b.usedW)) / 2 - Number(b.minX);
    dy = (Number(binH) - Number(b.usedH)) / 2 - Number(b.minY);

    /* V3.6 CENTER EXACT: ưu tiên tuyệt đối tâm artboard. Corner-safe chỉ quyết
       định cách pack/loại vị trí ở bốn góc, KHÔNG được phép kéo cả cụm lệch
       khỏi tâm sau khi đã dàn. Đây là nguyên nhân các mép trên/dưới đo thực tế
       bị lệch vài mm ở V3.5. */
    layout.centerExact = true;
    for (i = 0; i < items.length; i++) { items[i].x += dx; items[i].y += dy; }
    b = ANP_layoutBoundsV35(items);
    layout.centered = true; layout.usedW = b.usedW; layout.usedH = b.usedH;
    layout.centerDx = Number(dx); layout.centerDy = Number(dy);
    layout.layoutCenterX = (Number(b.minX) + Number(b.maxX)) / 2;
    layout.layoutCenterY = (Number(b.minY) + Number(b.maxY)) / 2;
    return layout;
}

function ANP_preview(json) {
    try {
        var cfg = ANP_parse(json), layout = ANP_layout(cfg), i, rotated = 0;
        for (i = 0; i < layout.items.length; i++) { if (layout.items[i].rotated) { rotated++; } }
        return ANP_ok({
            count: layout.count,
            rotated: rotated,
            normal: layout.count - rotated,
            efficiency: layout.efficiency,
            binW: layout.binW,
            binH: layout.binH,
            method: layout.method,
            methodLabel: layout.method === "mixed-columns" ? "cột xoay hỗn hợp" : "hàng xoay hỗn hợp"
        });
    } catch (e) { return ANP_fail(e); }
}

function ANP_choosePon() {
    try {
        var f = File.openDialog("Chọn file PON", "Adobe Illustrator/PDF:*.ai;*.eps;*.pdf;*.svg,All files:*.*", false);
        if (!f) { return ANP_stringify({ ok: false }); }
        return ANP_ok({ path: f.fsName, name: f.name });
    } catch (e) { return ANP_fail(e); }
}

function ANP_chooseOutput() {
    try {
        var f = Folder.selectDialog("Chọn nơi tạo FILE IN chứa cả file in và khuôn bế");
        if (!f) { return ANP_stringify({ ok: false }); }
        return ANP_ok({ path: f.fsName });
    } catch (e) { return ANP_fail(e); }
}

function ANP_signature(item) {
    var b = item.geometricBounds;
    return { t: item.typename, b: [b[0], b[1], b[2], b[3]] };
}

function ANP_sameBounds(a, b) {
    var tol = 0.2;
    return Math.abs(a[0] - b[0]) < tol && Math.abs(a[1] - b[1]) < tol &&
           Math.abs(a[2] - b[2]) < tol && Math.abs(a[3] - b[3]) < tol;
}

function ANP_matchesSignature(item, signatures) {
    var i, b;
    try { b = item.geometricBounds; } catch (e) { return false; }
    for (i = 0; i < signatures.length; i++) {
        if ((item.typename === signatures[i].t || item.typename === "PathItem") && ANP_sameBounds(b, signatures[i].b)) {
            return true;
        }
    }
    return false;
}

function ANP_removeDieFrom(item, hint, signatures) {
    var i, child;
    if (!item) { return; }
    try {
        if (item.typename === "PathItem" || item.typename === "CompoundPathItem") {
            if (ANP_isDieItem(item, hint, false) || ANP_matchesSignature(item, signatures)) { item.remove(); }
            return;
        }
        if (item.typename === "GroupItem") {
            for (i = item.pageItems.length - 1; i >= 0; i--) {
                child = item.pageItems[i];
                if (child.parent !== item && child.parent.typename !== "GroupItem") { continue; }
                ANP_removeDieFrom(child, hint, signatures);
            }
        }
    } catch (e) {}
}

function ANP_addReference(group, bounds) {
    var p = group.pathItems.rectangle(bounds[1], bounds[0], bounds[2] - bounds[0], bounds[1] - bounds[3]);
    p.name = ANP_REF_NAME;
    p.stroked = false;
    p.filled = false;
    return p;
}

function ANP_makeTemplates(doc, sourceItems, dieItems, dieBounds, hint, printBounds) {
    var temp = doc.layers.add(), printGroup, dieGroup, i, dup, signatures = [], printContentCount = 0;
    temp.name = "__AUTO_NEST_PRO_TEMP__";
    temp.locked = false; temp.visible = true;
    printGroup = temp.groupItems.add(); printGroup.name = "PRINT_TEMPLATE";
    dieGroup = temp.groupItems.add(); dieGroup.name = "DIE_TEMPLATE";

    for (i = 0; i < dieItems.length; i++) { signatures.push(ANP_signature(dieItems[i])); }
    for (i = 0; i < sourceItems.length; i++) {
        try {
            dup = sourceItems[i].duplicate(printGroup, ElementPlacement.PLACEATEND);
            /* V61: không xóa path chỉ vì trùng bounds với KHUON_BE. Với PDF/AI
               có clipping mask, cách cũ có thể xóa luôn clipping path và làm
               PRINT-LINK trắng. Bộ lọc mask-safe chỉ bỏ đúng dieline thật. */
            ANP_removeDieTreeMaskSafeV53(dup, hint, signatures);
        } catch (e0) {}
    }
    try { printContentCount = printGroup.pageItems.length; } catch (eCount) { printContentCount = 0; }
    if (!printContentCount) {
        try { temp.remove(); } catch (eRemove) {}
        throw new Error("Không lấy được nội dung in của artboard. Hãy kiểm tra artwork/clipping mask trong file nguồn.");
    }
    for (i = 0; i < dieItems.length; i++) {
        try { dieItems[i].duplicate(dieGroup, ElementPlacement.PLACEATEND); } catch (e1) {}
    }
    ANP_addReference(printGroup, printBounds || dieBounds);
    ANP_addReference(dieGroup, dieBounds);
    return { layer: temp, printGroup: printGroup, dieGroup: dieGroup };
}

function ANP_findReference(item) {
    var i, found;
    if (!item) { return null; }
    try { if (item.name === ANP_REF_NAME) { return item; } } catch (e0) {}
    try {
        if (item.typename === "GroupItem") {
            for (i = 0; i < item.pageItems.length; i++) {
                found = ANP_findReference(item.pageItems[i]);
                if (found) { return found; }
            }
        }
    } catch (e1) {}
    return null;
}

/* Illustrator báo “Cannot modify a layer that is locked” cả khi layer chỉ
   đang ẩn. Mọi thao tác ghi vào tài liệu đích đều đi qua hàm này để mở khóa,
   hiện layer và đặt đúng activeLayer trước khi tạo PageItem. */
function ANP_prepareTargetLayerV28(doc, layer) {
    if (!layer) { throw new Error("Không tìm thấy layer đích để tạo bản dàn."); }
    try { if (layer.locked) { layer.locked = false; } } catch (e0) {}
    try { if (!layer.visible) { layer.visible = true; } } catch (e1) {}
    try { if (doc && doc.activeLayer !== layer) { doc.activeLayer = layer; } } catch (e2) {}
    return layer;
}

function ANP_unlockTreeV28(container) {
    var i, children = null;
    if (!container) { return; }
    try { if (container.locked) { container.locked = false; } } catch (e0) {}
    try { if (container.typename === "Layer" && !container.visible) { container.visible = true; } } catch (e1) {}
    try {
        if (container.typename === "CompoundPathItem") { children = container.pathItems; }
        else { children = container.pageItems; }
    } catch (e2) { children = null; }
    if (!children) { return; }
    for (i = 0; i < children.length; i++) { ANP_unlockTreeV28(children[i]); }
}

function ANP_placeTemplate(template, targetLayer, placement, cfg, artRect) {
    ANP_prepareTargetLayerV28(targetLayer.parent, targetLayer);
    var instance = template.duplicate(targetLayer, ElementPlacement.PLACEATEND);
    var ref = ANP_findReference(instance), b, sx, sy, targetLeft, targetTop, dx, dy;
    if (!ref) { throw new Error("Không tìm thấy điểm chuẩn khi nhân tem."); }
    b = ref.geometricBounds;
    sx = ANP_mm(cfg.itemW) / (b[2] - b[0]) * 100;
    sy = ANP_mm(cfg.itemH) / (b[1] - b[3]) * 100;
    instance.resize(sx, sy, true, true, true, true, (sx + sy) / 2, Transformation.CENTER);
    var explicitAngle = placement.angle !== undefined;
    var angle = explicitAngle ? Number(placement.angle) : (placement.rotated ? 90 : 0);
    /* Engine dùng trục Y hướng xuống; Illustrator dùng Y hướng lên nên đảo dấu góc. */
    if (Math.abs(angle) > 0.0001) { instance.rotate(explicitAngle ? -angle : angle, true, true, true, true, Transformation.CENTER); }
    ref = ANP_findReference(instance);
    b = ref.geometricBounds;
    targetLeft = artRect[0] + ANP_mm(cfg.margin + placement.x);
    targetTop = artRect[1] - ANP_mm(cfg.margin + placement.y);
    dx = targetLeft + ANP_mm(Number(placement.offsetX || 0)) - b[0];
    dy = targetTop - ANP_mm(Number(placement.offsetY || 0)) - b[1];
    instance.translate(dx, dy);
    ref = ANP_findReference(instance);
    if (ref) { ref.remove(); }
    return instance;
}

function ANP_dieProcessColorV21() {
    var c = new CMYKColor();
    c.cyan = 0; c.magenta = 100; c.yellow = 100; c.black = 0;
    return c;
}

function ANP_removeDieSpotSwatchesV21(doc) {
    var i, name;
    try {
        for (i = doc.spots.length - 1; i >= 0; i--) {
            name = ANP_upper(doc.spots[i].name);
            if (ANP_hasDieWord(name, "KHUON_BE")) {
                try { doc.spots[i].remove(); } catch (e0) {}
            }
        }
    } catch (e) {}
}

function ANP_normalizeDie(item, processColor) {
    var i, p;
    try {
        if (item.typename === "PathItem") {
            item.filled = false; item.stroked = true; item.strokeColor = processColor;
            item.strokeWidth = 0.25; item.strokeOverprint = true;
            return;
        }
        if (item.typename === "CompoundPathItem") {
            for (i = 0; i < item.pathItems.length; i++) { ANP_normalizeDie(item.pathItems[i], processColor); }
            return;
        }
        if (item.typename === "GroupItem") {
            for (i = 0; i < item.pageItems.length; i++) {
                p = item.pageItems[i]; ANP_normalizeDie(p, processColor);
            }
        }
    } catch (e) {}
}

function ANP_black() {
    var c = new CMYKColor(); c.cyan = 0; c.magenta = 0; c.yellow = 0; c.black = 100; return c;
}

/* V57 — SAFE FILE LINK/IMPORT
   Illustrator có thể từ chối `PlacedItem.file` dù File.exists=true khi đường
   dẫn Windows chứa dấu tiếng Việt, nằm trên ổ mạng hoặc file PDF/AI được tạo
   bởi phần mềm khác. Chỉ khi lần gán trực tiếp thất bại mới sao chép sang một
   tên ASCII trong thư mục tạm rồi thử lại, vì vậy luồng bình thường không tốn
   thêm I/O. Với PON, nếu Link vẫn không nhận thì nhập vector bằng createFromFile
   để công việc vẫn tiếp tục và FILE KHUÔN không chứa Link/Symbol. */
function ANP_fileExtV57(file) {
    var n = "", m;
    try { n = String(file.name || ""); } catch (e0) {}
    m = n.match(/\.([A-Za-z0-9]+)$/);
    return m ? String(m[1]).toLowerCase() : "";
}

function ANP_stageAsciiFileV57(file, tag) {
    var ext = ANP_fileExtV57(file), folder = Folder.temp, staged, base, ok, guard = 0;
    if (!ext) { return null; }
    try { if (!folder.exists) { folder.create(); } } catch (e0) {}
    do {
        ANP_SAFE_FILE_SEQ_V57++;
        base = "DPV_V57_" + String(tag || "FILE").replace(/[^A-Za-z0-9_-]/g, "_") + "_" +
            String((new Date()).getTime()) + "_" + String(ANP_SAFE_FILE_SEQ_V57) + "." + ext;
        staged = new File(folder.fsName + "/" + base);
        guard++;
    } while (staged.exists && guard < 20);
    try { ok = file.copy(staged.fsName); } catch (e1) { ok = false; }
    return ok && staged.exists ? staged : null;
}

function ANP_tryPlacedFileV57(doc, layer, file, name) {
    var placed = null;
    try {
        placed = doc.placedItems.add();
        placed.file = file;
        if (name) { placed.name = name; }
        try { placed.move(layer, ElementPlacement.PLACEATEND); } catch (eMove) {}
        return placed;
    } catch (e) {
        try { if (placed) { placed.remove(); } } catch (eRemove) {}
        return null;
    }
}

function ANP_placeFileSafeV57(doc, layer, source, name, allowVectorImport) {
    var src = source instanceof File ? source : new File(String(source || ""));
    var placed, staged = null, imported = null, ext;
    if (!src.exists) { throw new Error("Không tìm thấy file cần Link: " + String(source || "")); }
    placed = ANP_tryPlacedFileV57(doc, layer, src, name);
    if (placed) { return { item:placed, isPlaced:true, source:src, staged:null }; }

    staged = ANP_stageAsciiFileV57(src, name || "LINK");
    if (staged) {
        placed = ANP_tryPlacedFileV57(doc, layer, staged, name);
        if (placed) { return { item:placed, isPlaced:true, source:src, staged:staged }; }
    }

    if (allowVectorImport === true) {
        try {
            imported = layer.groupItems.createFromFile(staged || src);
            if (imported) {
                if (name) { try { imported.name = name + "_VECTOR"; } catch (eName) {} }
                return { item:imported, isPlaced:false, source:src, staged:staged };
            }
        } catch (eImport0) {
            try {
                imported = doc.groupItems.createFromFile(staged || src);
                if (imported) {
                    try { imported.move(layer, ElementPlacement.PLACEATEND); } catch (eMove2) {}
                    if (name) { try { imported.name = name + "_VECTOR"; } catch (eName2) {} }
                    return { item:imported, isPlaced:false, source:src, staged:staged };
                }
            } catch (eImport1) {}
        }
    }

    ext = ANP_fileExtV57(src);
    throw new Error("Illustrator không thể đọc file " + (name || "Link") +
        ". Hãy lưu lại thành PDF tương thích Illustrator hoặc AI có PDF Compatible" +
        (ext ? " (file ." + ext + ")" : "") + ". Đường dẫn: " + src.fsName);
}

function ANP_line(layer, x1, y1, x2, y2, color, width, name) {
    var p = layer.pathItems.add();
    p.setEntirePath([[x1, y1], [x2, y2]]);
    p.closed = false; p.filled = false; p.stroked = true;
    p.strokeColor = color || ANP_black(); p.strokeWidth = Number(width) || 0.75;
    if (name) { try { p.name = name; } catch (eName) {} }
    return p;
}

function ANP_addAutoPon(doc, layer, cfg) {
    ANP_prepareTargetLayerV28(doc, layer);
    var a = doc.artboards[0].artboardRect;
    var inset = ANP_mm(4), len = ANP_mm(8), dot = ANP_mm(2.6), dotOff = ANP_mm(17);
    var L = a[0] + inset, T = a[1] - inset, R = a[2] - inset, B = a[3] + inset;
    var cornerColor = cfg && cfg.cornerPonRed === true ? ANP_dieProcessColorV21() : ANP_black();
    ANP_line(layer, L, T, L + len, T, cornerColor, 0.75, "PON_GOC_DO_TL_H");
    ANP_line(layer, L, T, L, T - len, cornerColor, 0.75, "PON_GOC_DO_TL_V");
    ANP_line(layer, R, T, R - len, T, cornerColor, 0.75, "PON_GOC_DO_TR_H");
    ANP_line(layer, R, T, R, T - len, cornerColor, 0.75, "PON_GOC_DO_TR_V");
    ANP_line(layer, L, B, L + len, B, cornerColor, 0.75, "PON_GOC_DO_BL_H");
    ANP_line(layer, L, B, L, B + len, cornerColor, 0.75, "PON_GOC_DO_BL_V");
    ANP_line(layer, R, B, R - len, B, cornerColor, 0.75, "PON_GOC_DO_BR_H");
    ANP_line(layer, R, B, R, B + len, cornerColor, 0.75, "PON_GOC_DO_BR_V");
    var pts = [
        [a[0] + dotOff, a[1] - inset - dot / 2], [a[2] - dotOff, a[1] - inset - dot / 2],
        [a[0] + dotOff, a[3] + inset + dot / 2], [a[2] - dotOff, a[3] + inset + dot / 2]
    ];
    var i, e;
    for (i = 0; i < pts.length; i++) {
        e = layer.pathItems.ellipse(pts[i][1] + dot / 2, pts[i][0] - dot / 2, dot, dot);
        e.filled = true; e.fillColor = ANP_black(); e.stroked = false;
    }
}

function ANP_addPon(doc, cfg, title, layerName) {
    var layer = doc.layers.add(), f, placed, loaded, a, tf;
    layer.name = layerName || "PON";
    ANP_prepareTargetLayerV28(doc, layer);
    a = doc.artboards[0].artboardRect;
    if (cfg.ponPath) {
        f = new File(cfg.ponPath);
        if (!f.exists) { throw new Error("Không tìm thấy file PON đã chọn: " + cfg.ponPath); }
        loaded = ANP_placeFileSafeV57(doc, layer, f, "PON_LINK", true); placed = loaded.item;
        app.redraw();
        if (cfg.fitPon) { placed.width = a[2] - a[0]; placed.height = a[1] - a[3]; }
        placed.left = a[0] + ((a[2] - a[0]) - placed.width) / 2;
        placed.top = a[1] - ((a[1] - a[3]) - placed.height) / 2;
        placed.name = "PON_LINK";
    } else if (cfg.autoPon) {
        ANP_addAutoPon(doc, layer, cfg);
    }
    if (cfg.addTitle && cfg.header >= 5) {
        tf = layer.textFrames.add(); tf.contents = title;
        tf.position = [a[0] + ANP_mm(cfg.margin), a[1] - ANP_mm(Math.max(4, cfg.margin * 0.6))];
        tf.textRange.characterAttributes.size = 7;
        tf.textRange.characterAttributes.fillColor = ANP_black();
        tf.name = "JOB_INFO";
    }
    return layer;
}

function ANP_safeBase(name) {
    name = String(name || "AUTO_NEST").replace(/\.[^\.]+$/, "");
    name = name.replace(/[\\\/:*?\"<>|]/g, "-").replace(/^\s+|\s+$/g, "");
    return name || "AUTO_NEST";
}

function ANP_uniqueFile(folder, base) {
    var f = new File(folder.fsName + "/" + base + ".ai"), i = 1, suffix;
    while (f.exists) {
        suffix = i < 10 ? "0" + i : String(i);
        f = new File(folder.fsName + "/" + base + "_" + suffix + ".ai"); i++;
    }
    return f;
}

function ANP_uniquePdfFileV29(folder, title) {
    var f = new File(folder.fsName + "/" + title + ".pdf"), i = 1, suffix;
    while (f.exists) {
        suffix = i < 10 ? "0" + i : String(i);
        f = new File(folder.fsName + "/" + title + "_" + suffix + ".pdf"); i++;
    }
    return f;
}

function ANP_pdfTitleFromFileV29(file) {
    var name = "";
    try { name = decodeURI(file.name); } catch (e0) { try { name = file.name; } catch (e1) {} }
    return String(name || "AUTO_NEST").replace(/\.pdf$/i, "");
}

function ANP_saveAI(doc, file) {
    var opt = new IllustratorSaveOptions();
    opt.pdfCompatible = true; opt.compressed = true; opt.embedICCProfile = true;
    doc.saveAs(file, opt);
}

function ANP_savePDFDefault(doc, file, preserveColor) {
    var opt = new PDFSaveOptions(), presets, i, chosen = "";
    try {
        presets = app.PDFPresetsList;
        for (i = 0; i < presets.length; i++) {
            if (ANP_upper(presets[i]).indexOf("ILLUSTRATOR DEFAULT") >= 0) { chosen = presets[i]; break; }
        }
        if (!chosen && presets.length) { chosen = presets[0]; }
        if (chosen) { opt.pDFPreset = chosen; }
    } catch (e) {}
    if (preserveColor) {
        /* Preset máy người dùng vẫn được giữ, nhưng không cho chuyển đổi giá trị
           màu của artwork FILE IN thêm một lần nữa. */
        try { opt.colorConversionID = ColorConversion.None; } catch (eColor0) {}
        try { opt.colorProfileID = ColorProfile.INCLUDEALLPROFILE; } catch (eColor1) {}
    }
    /* V81: FILE DÀN phải giữ Illustrator Editing Capabilities để khi mở lại
       PDF trong Illustrator các PlacedItem vẫn là LINK như các bản V71 ổn định.
       Không dùng preserveEditability=false ở hàm PDF dùng chung. VDP có hàm
       ANP_savePDFRangeV76 riêng nên không bị ảnh hưởng. */
    try { opt.preserveEditability = true; } catch (eEdit) {}
    doc.saveAs(file, opt);
}

/* V61: một FILE IN hai mặt AB là một PDF nhiều trang/artboard, không tách
   thành hai PDF. Illustrator dùng đúng hai artboard đã dựng trong tài liệu. */
function ANP_savePDFMultiArtboardV61(doc, file, preserveColor) {
    var opt = new PDFSaveOptions(), presets, i, chosen = "";
    try {
        presets = app.PDFPresetsList;
        for (i = 0; i < presets.length; i++) {
            if (ANP_upper(presets[i]).indexOf("ILLUSTRATOR DEFAULT") >= 0) { chosen = presets[i]; break; }
        }
        if (!chosen && presets.length) { chosen = presets[0]; }
        if (chosen) { opt.pDFPreset = chosen; }
    } catch (ePreset) {}
    if (preserveColor) {
        try { opt.colorConversionID = ColorConversion.None; } catch (eColor0) {}
        try { opt.colorProfileID = ColorProfile.INCLUDEALLPROFILE; } catch (eColor1) {}
    }
    /* V81: khôi phục đúng policy V71 cho FILE DÀN nhiều artboard.
       Preserve Illustrator Editing Capabilities + saveMultipleArtboards giúp
       PlacedItem/Links tồn tại khi PDF được mở lại bằng Illustrator. */
    try { opt.preserveEditability = true; } catch (eEdit) {}
    try { opt.saveMultipleArtboards = true; } catch (eMulti) {}
    try { opt.artboardRange = "1-" + String(doc.artboards.length); } catch (eRange) {}
    doc.saveAs(file, opt);
}

function ANP_colorModeNameV23(colorSpace) {
    try { return colorSpace === DocumentColorSpace.RGB ? "RGB" : "CMYK"; }
    catch (e) { return "CMYK"; }
}

function ANP_colorSpaceFromModeV23(mode) {
    return ANP_upper(mode) === "RGB" ? DocumentColorSpace.RGB : DocumentColorSpace.CMYK;
}

function ANP_printColorSpaceV23(cfg, links, used) {
    if (cfg.preservePrintColor === false) { return DocumentColorSpace.CMYK; }
    var mode = "", i, next;
    for (i = 0; i < links.length; i++) {
        if (used && !used[i]) { continue; }
        if (!links[i]) { continue; }
        next = links[i].printColorMode || "CMYK";
        if (!mode) { mode = next; }
        else if (ANP_upper(mode) !== ANP_upper(next)) { return DocumentColorSpace.CMYK; }
    }
    return ANP_colorSpaceFromModeV23(mode || "CMYK");
}

function ANP_newDoc(colorSpace, cfg, layerName) {
    var doc = app.documents.add(colorSpace, ANP_mm(cfg.paperW), ANP_mm(cfg.paperH));
    doc.artboards[0].name = layerName;
    doc.layers[0].name = layerName;
    return doc;
}

function ANP_activeArtboardRectV61(doc) {
    var index = 0;
    try { index = doc.artboards.getActiveArtboardIndex(); } catch (e0) { index = 0; }
    return doc.artboards[Math.max(0, Math.min(doc.artboards.length - 1, Number(index) || 0))].artboardRect;
}

function ANP_addDuplexArtboardV61(doc, name) {
    var first = doc.artboards[0].artboardRect, gap = ANP_mm(20);
    var width = Number(first[2]) - Number(first[0]);
    var next = doc.artboards.add([Number(first[2]) + gap, Number(first[1]),
        Number(first[2]) + gap + width, Number(first[3])]);
    next.name = name || "MAT_B";
    return next;
}

function ANP_build(json) {
    var templates = null, printDoc = null, dieDoc = null;
    try {
        if (!app.documents.length) { throw new Error("Chưa mở file tem trong Illustrator."); }
        var cfg = ANP_parse(json), sourceDoc = app.activeDocument;
        var sourceItems = ANP_sourceItems(sourceDoc, cfg.sourceMode || "artboard");
        var dieItems = ANP_getDie(sourceDoc, sourceItems, cfg.dieHint || "",
            sourceDoc.artboards[sourceDoc.artboards.getActiveArtboardIndex()].artboardRect);
        var dieBounds = ANP_bounds(dieItems);
        if (!dieBounds) {
            throw new Error("Không tìm thấy viền bế. Hãy chọn riêng đường bế rồi bấm ‘Lấy viền bế đang chọn’ trước.");
        }
        var layout = ANP_layout(cfg), i, rotated = 0, inst;
        var colorSpace = sourceDoc.documentColorSpace || DocumentColorSpace.CMYK;
        var base = ANP_safeBase(sourceDoc.name);
        var info = base + " - kt " + cfg.itemW + "x" + cfg.itemH + "mm - " + cfg.paperW + "x" + cfg.paperH + " - " + layout.count + "PCS";

        templates = ANP_makeTemplates(sourceDoc, sourceItems, dieItems, dieBounds, cfg.dieHint || "");
        printDoc = ANP_newDoc(colorSpace, cfg, "FILE_IN");
        /* FILE IN đi theo hệ màu nguồn; FILE KHUÔN luôn là Process CMYK. */
        dieDoc = ANP_newDoc(DocumentColorSpace.CMYK, cfg, "FILE_KHUON");
        var printLayer = printDoc.layers[0], dieLayer = dieDoc.layers[0];
        var printRect = printDoc.artboards[0].artboardRect;
        var dieRect = dieDoc.artboards[0].artboardRect;
        var dieColor = ANP_dieProcessColorV21();

        for (i = 0; i < layout.items.length; i++) {
            inst = ANP_placeTemplate(templates.printGroup, printLayer, layout.items[i], cfg, printRect);
            inst.name = "PRINT_" + (i + 1) + (layout.items[i].rotated ? "_R90" : "");
            inst = ANP_placeTemplate(templates.dieGroup, dieLayer, layout.items[i], cfg, dieRect);
            inst.name = "DIE_" + (i + 1) + (layout.items[i].rotated ? "_R90" : "");
            ANP_normalizeDie(inst, dieColor);
            if (layout.items[i].rotated) { rotated++; }
        }

        /* V3.7: kể cả build legacy, khuôn cong/Symbol phải được bung thành stroke vector trước PON. */
        dieLayer.name = "KHUON_BE_DIRTY";
        dieLayer = ANP_finalizeDieStrokeVectorsV37(dieDoc, dieLayer);
        ANP_assertStrokeVectorLayerV37(dieLayer);
        ANP_addPon(printDoc, cfg, "FILE IN - " + info, "PON_LINK");
        ANP_addPon(dieDoc, cfg, "FILE KHUON - " + info, "PON_LINK");
        printLayer.name = "FILE_IN_" + layout.count + "PCS";
        dieLayer.name = "KHUON_BE_" + layout.count + "PCS";
        ANP_removeDieSpotSwatchesV21(dieDoc);

        var saved = false, printPath = "", diePath = "";
        if (cfg.outputPath) {
            var out = new Folder(cfg.outputPath);
            if (!out.exists) { throw new Error("Thư mục xuất không tồn tại."); }
            var pf = ANP_uniqueFile(out, base + "_FILE-IN_" + layout.count + "PCS");
            var df = ANP_uniqueFile(out, base + "_FILE-KHUON_" + layout.count + "PCS");
            ANP_saveAI(printDoc, pf); ANP_saveAI(dieDoc, df);
            saved = true; printPath = pf.fsName; diePath = df.fsName;
        }
        templates.layer.remove(); templates = null;
        printDoc.activate();
        return ANP_ok({
            count: layout.count, rotated: rotated, normal: layout.count - rotated,
            saved: saved, printPath: printPath, diePath: diePath
        });
    } catch (e) {
        try { if (templates && templates.layer) { templates.layer.remove(); } } catch (cleanupError) {}
        return ANP_fail(e);
    }
}

/* ========================================================================== */
/* v1.1 LINKED IMPOSITION                                                     */
/* ========================================================================== */

function ANP_docPath(doc) {
    try { return doc.saved ? doc.fullName.fsName : ""; } catch (e) { return ""; }
}

/* ========================================================================== */
/* V65 FAST ACTIVE DOCUMENT READ                                               */
/*                                                                            */
/* “Lấy file đang mở” chỉ cần metadata để UI phản hồi ngay. Các bản trước gọi */
/* ANP_sourceItems + ANP_getDie, khiến Illustrator duyệt toàn bộ pageItems,    */
/* group và Bézier của file nặng ngay lúc bấm nút. V65 chỉ:                    */
/*  - ưu tiên khuôn người dùng đã chọn;                                        */
/*  - đọc một lượng vector có giới hạn trong layer mang tên KHUON_BE;           */
/*  - nếu file nhỏ, thử nhanh các path được đặt tên/màu khuôn;                  */
/*  - nếu chưa đủ chắc chắn, trả artboard ngay và hoãn quét khuôn đến preview/  */
/*    build. Build KHÔNG bị ép dùng rectangle nên độ chính xác đầu ra giữ nguyên.*/
/* ========================================================================== */

function ANP_fastDocSignatureV65(doc, activeIndex) {
    var pageCount = 0, pathCount = 0, compoundCount = 0, layerCount = 0, manualCount = 0;
    try { pageCount = doc.pageItems.length; } catch (e0) {}
    try { pathCount = doc.pathItems.length; } catch (e1) {}
    try { compoundCount = doc.compoundPathItems.length; } catch (e2) {}
    try { layerCount = doc.layers.length; } catch (e3) {}
    try {
        if (ANP_STATE.manualDoc === doc && ANP_STATE.manualDie) { manualCount = ANP_STATE.manualDie.length; }
    } catch (e4) {}
    return [activeIndex, pageCount, pathCount, compoundCount, layerCount, manualCount].join("|");
}

function ANP_fastNamedLayersV65(layers, hint, out, limit) {
    var i, layer;
    if (!layers || out.length >= limit) { return; }
    for (i = 0; i < layers.length && out.length < limit; i++) {
        try {
            layer = layers[i];
            if (layer.visible === false) { continue; }
            if (ANP_hasDieWord(layer.name, hint)) { out.push(layer); }
            if (layer.layers && layer.layers.length) { ANP_fastNamedLayersV65(layer.layers, hint, out, limit); }
        } catch (e) {}
    }
}

function ANP_fastSampleCollectionV65(collection, hint, out, maxOut, acceptLayerItems) {
    var len = 0, samples, step, i, item, explicit;
    if (!collection || out.length >= maxOut) { return; }
    try { len = collection.length; } catch (e0) { return; }
    if (!len) { return; }
    samples = Math.min(len, Math.max(1, maxOut - out.length));
    step = Math.max(1, Math.floor(len / samples));
    for (i = 0; i < len && out.length < maxOut; i += step) {
        try {
            item = collection[i];
            explicit = ANP_itemNamedDie(item, hint);
            if (!explicit && item.typename === "PathItem" && item.stroked) {
                explicit = ANP_colorLooksDie(item.strokeColor, hint);
            }
            if (acceptLayerItems || explicit) { ANP_pushUnique(out, item); }
        } catch (e1) {}
    }
    /* Luôn thử phần tử cuối vì dieline thường được tạo sau artwork. */
    if (out.length < maxOut && len > 1) {
        try {
            item = collection[len - 1];
            explicit = ANP_itemNamedDie(item, hint);
            if (!explicit && item.typename === "PathItem" && item.stroked) {
                explicit = ANP_colorLooksDie(item.strokeColor, hint);
            }
            if (acceptLayerItems || explicit) { ANP_pushUnique(out, item); }
        } catch (e2) {}
    }
}

function ANP_fastActiveDieV65(doc, hint, artRect) {
    var manual = ANP_manualDieFor(doc), namedLayers = [], candidates = [], i;
    var pathCount = 0, compoundCount = 0;
    if (manual.length) { return { items:manual, deferred:false, mode:"manual" }; }

    /* Duyệt cây layer rất nhẹ; chỉ lấy tối đa 6 layer có tên khuôn. */
    try { ANP_fastNamedLayersV65(doc.layers, hint, namedLayers, 6); } catch (e0) {}
    for (i = 0; i < namedLayers.length && candidates.length < 32; i++) {
        /* Compound trước để không bỏ sót contour ghép. */
        try { ANP_fastSampleCollectionV65(namedLayers[i].compoundPathItems, hint, candidates, 32, true); } catch (e1) {}
        try { ANP_fastSampleCollectionV65(namedLayers[i].pathItems, hint, candidates, 32, true); } catch (e2) {}
    }
    if (candidates.length) {
        candidates = ANP_inferDieV33(candidates, artRect, hint);
        if (candidates.length) { return { items:candidates, deferred:false, mode:"named-layer" }; }
    }

    /* File nhỏ: kiểm tra nhanh tên/màu stroke. File lớn tuyệt đối không quét hết. */
    try { pathCount = doc.pathItems.length; } catch (e3) {}
    try { compoundCount = doc.compoundPathItems.length; } catch (e4) {}
    if (pathCount + compoundCount <= 420) {
        ANP_fastSampleCollectionV65(doc.compoundPathItems, hint, candidates, 96, false);
        ANP_fastSampleCollectionV65(doc.pathItems, hint, candidates, 96, false);
        if (candidates.length) {
            candidates = ANP_inferDieV33(candidates, artRect, hint);
            if (candidates.length) { return { items:candidates, deferred:false, mode:"small-document" }; }
        }
    }
    return { items:[], deferred:true, mode:"artboard-deferred" };
}

function ANP_activeSourceV11(hint) {
    try {
        if (!app.documents.length) { throw new Error("Chưa mở file tem trong Illustrator."); }
        var started = ANP_perfNowV48();
        var doc = app.activeDocument, activeIndex = doc.artboards.getActiveArtboardIndex();
        var activeRect = doc.artboards[activeIndex].artboardRect, normalizedHint = hint || "";
        var signature = ANP_fastDocSignatureV65(doc, activeIndex), cache = ANP_STATE.fastActiveCache;
        if (cache && cache.doc === doc && cache.hint === normalizedHint && cache.signature === signature && cache.source) {
            cache.source.cached = true;
            cache.source.readMs = Math.max(0, ANP_perfNowV48() - started);
            return ANP_ok({ source:cache.source });
        }
        var fastDie = ANP_fastActiveDieV65(doc, normalizedHint, activeRect);
        var die = fastDie.items, b = ANP_bounds(die), fallback = false;
        if (!b) {
            b = activeRect;
            fallback = true;
        }
        var shape = ANP_shapeFromDieV20(die, b);
        var sourceMeta = {
            active: true, path: ANP_docPath(doc), documentName: doc.name, artboardIndex: activeIndex,
            name: doc.artboards[activeIndex].name || ("Artboard " + (activeIndex + 1)),
            width: ANP_round(ANP_toMm(b[2] - b[0]), 2),
            height: ANP_round(ANP_toMm(b[1] - b[3]), 2),
            quantity: 0, dieFallback: fallback, shapeDeferred:fastDie.deferred === true,
            quickRead:true, readMode:fastDie.mode, cached:false,
            readMs:Math.max(0, ANP_perfNowV48() - started), shape: shape
        };
        ANP_STATE.fastActiveCache = { doc:doc, hint:normalizedHint, signature:signature, source:sourceMeta };
        return ANP_ok({ source:sourceMeta });
    } catch (e) { return ANP_fail(e); }
}

function ANP_manualSourceV11() {
    try {
        var result = ANP_parse(ANP_setManualDie());
        if (!result.ok) { throw new Error(result.error); }
        var doc = app.activeDocument, activeIndex = doc.artboards.getActiveArtboardIndex();
        var b = ANP_bounds(ANP_STATE.manualDie || []);
        return ANP_ok({
            source: {
                active: true, path: ANP_docPath(doc), documentName: doc.name, artboardIndex: activeIndex,
                name: doc.artboards[activeIndex].name || ("Artboard " + (activeIndex + 1)),
                width: result.width, height: result.height, quantity: 0, dieFallback: false,
                shape: ANP_shapeFromDieV20(ANP_STATE.manualDie || [], b)
            }
        });
    } catch (e) { return ANP_fail(e); }
}

function ANP_chooseSources() {
    try {
        var picked = File.openDialog("Chọn nhiều file tem", "Adobe artwork:*.ai;*.eps;*.pdf;*.svg,All files:*.*", true);
        if (!picked) { return ANP_stringify({ ok: false }); }
        if (!(picked instanceof Array)) { picked = [picked]; }
        var files = [], i;
        for (i = 0; i < picked.length; i++) { files.push({ path: picked[i].fsName, name: picked[i].name }); }
        return ANP_ok({ files: files });
    } catch (e) { return ANP_fail(e); }
}

function ANP_findOpenDoc(path) {
    var i, p;
    for (i = 0; i < app.documents.length; i++) {
        try { p = app.documents[i].fullName.fsName; if (ANP_upper(p) === ANP_upper(path)) { return app.documents[i]; } } catch (e) {}
    }
    return null;
}

function ANP_inspectSources(json, hint) {
    var original = app.documents.length ? app.activeDocument : null, opened = null;
    try {
        var requested = ANP_parse(json), out = [], i, file, doc, source, die, b, fallback, shape;
        for (i = 0; i < requested.length; i++) {
            file = new File(requested[i].path);
            if (!file.exists) { throw new Error("Không tìm thấy file: " + requested[i].path); }
            doc = ANP_findOpenDoc(file.fsName); opened = null;
            if (!doc) { doc = app.open(file); opened = doc; }
            source = ANP_sourceItems(doc, "artboard");
            die = ANP_autoDie(source, hint || "",
                doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect);
            b = ANP_bounds(die); fallback = false;
            if (!b) { b = doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect; fallback = true; }
            shape = ANP_shapeFromDieV20(die, b);
            var activeIndex = doc.artboards.getActiveArtboardIndex();
            out.push({
                active: false, path: file.fsName, artboardIndex: activeIndex,
                name: doc.artboards[activeIndex].name || ("Artboard " + (activeIndex + 1)),
                width: ANP_round(ANP_toMm(b[2] - b[0]), 2),
                height: ANP_round(ANP_toMm(b[1] - b[3]), 2),
                quantity: 1, dieFallback: fallback, shape: shape
            });
            if (opened) { opened.close(SaveOptions.DONOTSAVECHANGES); opened = null; }
        }
        if (original) { try { original.activate(); } catch (e0) {} }
        return ANP_ok({ sources: out });
    } catch (e) {
        try { if (opened) { opened.close(SaveOptions.DONOTSAVECHANGES); } } catch (e1) {}
        try { if (original) { original.activate(); } } catch (e2) {}
        return ANP_fail(e);
    }
}

function ANP_expandBounds(b, pt) { return [b[0] - pt, b[1] + pt, b[2] + pt, b[3] - pt]; }

function ANP_filterNearDie(items, dieBounds, bleedPt) {
    var out = [], area = ANP_expandBounds(dieBounds, bleedPt + ANP_mm(0.5)), i;
    for (i = 0; i < items.length; i++) {
        try { if (ANP_intersects(items[i].geometricBounds, area)) { out.push(items[i]); } } catch (e) {}
    }
    return out.length ? out : items;
}

function ANP_jobItems(sources, maxQty) {
    var remaining = [], jobs = [], i, keepGoing = true, count = 0;
    for (i = 0; i < sources.length; i++) {
        remaining[i] = Math.max(0, Math.floor(Number(sources[i].quantity)));
    }
    while (keepGoing) {
        keepGoing = false;
        for (i = 0; i < sources.length; i++) {
            if (remaining[i] > 0) {
                jobs.push({ w: Number(sources[i].width), h: Number(sources[i].height), sourceIndex: i, copyIndex: count++ });
                remaining[i]--; keepGoing = true;
                if (maxQty > 0 && jobs.length >= maxQty) { return jobs; }
            }
        }
    }
    return jobs;
}

function ANP_allSameSize(sources) {
    var i, w = Number(sources[0].width), h = Number(sources[0].height);
    for (i = 1; i < sources.length; i++) {
        if (Math.abs(Number(sources[i].width) - w) > 0.01 || Math.abs(Number(sources[i].height) - h) > 0.01) { return false; }
    }
    return true;
}

function ANP_allSameShapeV20(sources) {
    var i, sig = sources.length && sources[0].shape ? sources[0].shape.signature : "";
    if (!sig) { return false; }
    for (i = 1; i < sources.length; i++) { if (!sources[i].shape || sources[i].shape.signature !== sig) { return false; } }
    return true;
}

function ANP_allHaveShapeV20(sources) {
    var i; for (i=0;i<sources.length;i++) { if (!sources[i].shape || !sources[i].shape.points || sources[i].shape.points.length<3) { return false; } }
    return sources.length>0;
}

function ANP_scaledShapeV20(shape, w, h) {
    if (!shape || !shape.points) { return shape; }
    var sx = Number(w) / Math.max(0.0001, Number(shape.w)), sy = Number(h) / Math.max(0.0001, Number(shape.h));
    var points = [], i;
    for (i = 0; i < shape.points.length; i++) { points.push({ x:Number(shape.points[i].x) * sx, y:Number(shape.points[i].y) * sy }); }
    return { points:points, w:Number(w), h:Number(h),
        isCircle:shape.isCircle && Math.abs(Number(w)-Number(h))/Math.max(Number(w),Number(h)) < 0.02,
        isRectangle:shape.isRectangle, fillRatio:Number(shape.fillRatio || 0), signature:shape.signature };
}

function ANP_betterEqualLayoutV21(best, candidate) {
    if (!best) { return candidate; }
    if (!candidate) { return best; }
    if (Number(candidate.count) !== Number(best.count)) {
        return Number(candidate.count) > Number(best.count) ? candidate : best;
    }
    /* Nếu bằng số con thì giữ phương án tôn trọng lề lớn hơn. */
    var bestRelax = Number(best.edgeRelaxX || 0) + Number(best.edgeRelaxY || 0);
    var candRelax = Number(candidate.edgeRelaxX || 0) + Number(candidate.edgeRelaxY || 0);
    return candRelax < bestRelax ? candidate : best;
}

function ANP_cornerClearV30(cfg, binW, binH) {
    if (!cfg || cfg.cornerSafe !== true || cfg.demiMode === true) { return 0; }
    /* V69 FIX: "Chua goc an toan cho PON" gia dinh se co PON 4 goc (L + cham
       tron dang ky) do ANP_addPonV12 ve de len dung khoang trong da chua.
       O che do "PON cat thanh pham" (CATTP)/2 mat AB, ANP_addPonV12 KHONG
       duoc goi - PON chi lay tu bien that cua tung con qua
       ANP_addFinishCropMarksV56 - nen neu van chua goc thi goc do bo trong
       hoan toan, khong co PON nao ca. Vi vay khi finishCropMarks bat, bo qua
       viec chua goc de tem lap kin dung 4 goc va PON tu sinh dung theo mep
       ngoai that nhu layout thuong. */
    if (cfg.finishCropMarks === true) { return 0; }
    var clear = Math.max(0, Number(cfg.cornerZone || 0) - Math.max(0, Number(cfg.margin || 0)));
    return Math.min(clear, Math.max(0, Number(binW) / 2), Math.max(0, Number(binH) / 2));
}

/* Loại mọi vị trí có bounding box giao bốn vùng PON. Packer chữ nhật đã tạo
   bố cục hình chữ thập tối ưu; bước này là hàng rào an toàn cho True-Shape và
   bài ghép nhiều kích thước. */
function ANP_applyCornerSafeLayoutV30(layout, cfg, binW, binH) {
    var clear = ANP_cornerClearV30(cfg, binW, binH), items, kept = [], removed = [];
    var i, item, atLeft, atRight, atTop, atBottom;
    if (!layout || clear <= 0) { return layout; }
    items = layout.items || [];
    for (i = 0; i < items.length; i++) {
        item = items[i];
        atLeft = Number(item.x) < clear - 0.0001;
        atRight = Number(item.x) + Number(item.w) > Number(binW) - clear + 0.0001;
        atTop = Number(item.y) < clear - 0.0001;
        atBottom = Number(item.y) + Number(item.h) > Number(binH) - clear + 0.0001;
        if ((atLeft && atTop) || (atRight && atTop) || (atLeft && atBottom) || (atRight && atBottom)) {
            removed.push(item);
        } else { kept.push(item); }
    }
    layout.items = kept; layout.count = kept.length; layout.cornerRemoved = removed;
    layout.cornerSafe = true; layout.cornerClear = clear;
    if (String(layout.method || "").indexOf("corner-safe") < 0) {
        layout.method = "corner-safe-" + String(layout.method || "layout");
    }
    return layout;
}

function ANP_equalCandidateV21(cfg, w, h, shape, binW, binH, maxQty) {
    return ANPPacker.pack({ binW:binW, binH:binH, itemW:Number(w), itemH:Number(h),
        gapX:Number(cfg.gapX), gapY:Number(cfg.gapY), allowRotate:cfg.allowRotate !== false,
        maxQty:Number(maxQty) || 0, cornerClear:ANP_cornerClearV30(cfg, binW, binH) });
}

/* v2.5: lưới Demi một dao chỉ dùng một hướng cho toàn tờ. Nhờ đó mọi biên
   trùng nhau có thể gộp thành đúng một đường thẳng, không có hai path chồng. */
function ANP_demiCandidateV25(w, h, binW, binH, maxQty, rotated) {
    var cellW = rotated ? Number(h) : Number(w), cellH = rotated ? Number(w) : Number(h);
    var maxCols = Math.floor((Number(binW) + 0.0001) / cellW);
    var maxRows = Math.floor((Number(binH) + 0.0001) / cellH);
    var capacity = Math.max(0, maxCols * maxRows), limit = Math.max(0, Math.floor(Number(maxQty) || 0));
    var qty = limit > 0 ? Math.min(capacity, limit) : capacity;
    var cols = Math.min(maxCols, qty), rows = cols > 0 ? Math.ceil(qty / cols) : 0;
    var items = [], r, c, inRow, startCol, made = 0;
    for (r = 0; r < rows; r++) {
        inRow = Math.min(cols, qty - made);
        startCol = Math.floor((cols - inRow) / 2);
        for (c = 0; c < inRow; c++) {
            items.push({ x:(startCol + c) * cellW, y:r * cellH, w:cellW, h:cellH,
                rotated:rotated === true, angle:rotated ? 90 : 0 });
            made++;
        }
    }
    return { items:items, count:items.length, usedW:cols * cellW, usedH:rows * cellH,
        method:"demi-grid", demiCapacity:capacity, demiCols:cols, demiRows:rows,
        edgeRelaxX:0, edgeRelaxY:0 };
}

function ANP_demiEqualLayoutV25(cfg, w, h, binW, binH, maxQty) {
    var normal = ANP_demiCandidateV25(w, h, binW, binH, maxQty, false), rotated = null, best;
    if (cfg.allowRotate !== false && Math.abs(Number(w) - Number(h)) > 0.0001) {
        rotated = ANP_demiCandidateV25(w, h, binW, binH, maxQty, true);
    }
    best = rotated && rotated.count > normal.count ? rotated : normal;
    best.efficiency = Number(best.count || 0) * Number(w) * Number(h) /
        Math.max(0.0001, Number(binW) * Number(binH));
    best.edgeOptimized = false;
    return best;
}


function ANP_uniformGridCandidateV82(cfg, w, h, binW, binH, maxQty, rotated) {
    var gx=Math.max(0,Number(cfg.gapX)||0), gy=Math.max(0,Number(cfg.gapY)||0);
    var cw=rotated?Number(h):Number(w), ch=rotated?Number(w):Number(h);
    var cols=Math.floor((Number(binW)+gx+0.0001)/(cw+gx)), rows=Math.floor((Number(binH)+gy+0.0001)/(ch+gy));
    var items=[], r,c,usedW,usedH,startX,startY,limit=Math.max(0,Math.floor(Number(maxQty)||0)), out;
    if(cols<1||rows<1){return {items:[],count:0,usedW:0,usedH:0,method:rotated?"uniform-grid-90":"uniform-grid-0",edgeRelaxX:0,edgeRelaxY:0,uniformGap:true};}
    usedW=cols*cw+(cols-1)*gx; usedH=rows*ch+(rows-1)*gy;
    startX=(Number(binW)-usedW)/2; startY=(Number(binH)-usedH)/2;
    for(r=0;r<rows;r++){
        for(c=0;c<cols;c++){
            if(limit>0 && items.length>=limit){break;}
            items.push({x:startX+c*(cw+gx),y:startY+r*(ch+gy),w:cw,h:ch,rotated:rotated===true,angle:rotated?90:0});
        }
        if(limit>0 && items.length>=limit){break;}
    }
    out={items:items,count:items.length,usedW:usedW,usedH:usedH,method:rotated?"uniform-grid-90":"uniform-grid-0",edgeRelaxX:0,edgeRelaxY:0,uniformGap:true};
    out=ANP_applyCornerSafeLayoutV30(out,cfg,binW,binH); out.count=out.items.length;
    out.efficiency=Number(out.count||0)*Number(w)*Number(h)/Math.max(0.0001,Number(binW)*Number(binH));
    return out;
}

function ANP_uniformGridV82(cfg,w,h,binW,binH,maxQty){
    var a=ANP_uniformGridCandidateV82(cfg,w,h,binW,binH,maxQty,false), b=null;
    if(cfg.allowRotate!==false && Math.abs(Number(w)-Number(h))>0.0001){b=ANP_uniformGridCandidateV82(cfg,w,h,binW,binH,maxQty,true);}
    if(!b){return a;}
    if(Number(b.count)!==Number(a.count)){return Number(b.count)>Number(a.count)?b:a;}
    return Number(b.usedW)*Number(b.usedH)<Number(a.usedW)*Number(a.usedH)?b:a;
}

function ANP_equalLayoutV21(cfg, w, h, shape, binW, binH, maxQty) {
    if (cfg.demiMode === true) {
        return ANP_demiEqualLayoutV25(cfg, w, h, binW, binH, maxQty);
    }
    /* V83: KHUÔN ĐẶC BIỆT được phép xoay 0/90/180/270 ngay cả khi bật
       Khoảng cách đều. ANPTrueShape strictGap đo trực tiếp khoảng cách contour. */
    if (cfg.uniformGap === true && cfg.trueShape === true && cfg.specialStagger !== false &&
        shape && shape.isRectangle !== true && shape.points && shape.points.length >= 3) {
        var exactGapXV94 = Math.max(0, Number(cfg.gapX) || 0), exactGapYV94 = Math.max(0, Number(cfg.gapY) || 0);
        var exactLayoutV83 = ANPTrueShape.pack({binW:Number(binW),binH:Number(binH),
            shape:ANP_scaledShapeV20(shape,w,h),gap:Math.max(exactGapXV94,exactGapYV94),gapX:exactGapXV94,gapY:exactGapYV94,angles:ANP_smartAnglesV64(cfg,shape),
            maxQty:Number(maxQty)||0,fast:cfg.fastMode===true,stagger:true,strictGap:true});
        exactLayoutV83 = ANP_applyCornerSafeLayoutV30(exactLayoutV83,cfg,binW,binH);
        exactLayoutV83.count = exactLayoutV83.items.length; exactLayoutV83.uniformGap=true; exactLayoutV83.strictGap=true;
        exactLayoutV83.efficiency = Number(exactLayoutV83.count||0)*Number(w)*Number(h)/Math.max(0.0001,Number(binW)*Number(binH));
        return exactLayoutV83;
    }
    if (cfg.uniformGap === true) {
        return ANP_uniformGridV82(cfg, w, h, binW, binH, maxQty);
    }
    var rx = Math.min(Math.max(0, Number(cfg.gapX) || 0), Math.max(0, Number(cfg.margin) || 0));
    var ry = Math.min(Math.max(0, Number(cfg.gapY) || 0), Math.max(0, Number(cfg.margin) || 0));
    var trials = [{x:0,y:0}], best = null, trueBest = null, i, t, candidate, scaled, trueTrials, angles, skipTrue, j, duplicate;
    var directCircle = cfg.trueShape === true && shape && shape.isCircle === true && shape.points && shape.points.length >= 3;
    if (rx > 0) { trials.push({x:rx,y:0}); }
    if (ry > 0) { trials.push({x:0,y:ry}); }
    if (rx > 0 && ry > 0) { trials.push({x:rx,y:ry}); }
    /* Hình tròn đi thẳng vào bộ xếp tổ ong vì chính bộ này đã so sánh cả lưới
       vuông. Không chạy lại MaxRects giúp bài hàng nghìn con mở rất nhanh. */
    if (!directCircle) {
        for (i = 0; i < trials.length; i++) {
            t = trials[i];
            candidate = ANP_equalCandidateV21(cfg, w, h, shape,
                Number(binW) + t.x * 2, Number(binH) + t.y * 2, maxQty);
            candidate.edgeRelaxX = t.x; candidate.edgeRelaxY = t.y;
            best = ANP_betterEqualLayoutV21(best, candidate);
        }
    }
    /* True-Shape là phần tốn CPU nhất. Fast Mode bỏ qua polygon cho tem gần chữ
       nhật hoặc bài quá nhiều con; hình tròn vẫn dùng tổ ong vì phép tính rất nhẹ. */
    skipTrue = !cfg.trueShape || !shape || shape.isRectangle || !shape.points || shape.points.length < 3;
    if (!skipTrue && cfg.fastMode && cfg.specialStagger === false && !shape.isCircle) {
        if (Number(shape.fillRatio || 0) >= 0.90 || Number(best.count || 0) > 80) { skipTrue = true; }
    }
    if (!skipTrue) {
        scaled = ANP_scaledShapeV20(shape, w, h);
        angles = ANP_smartAnglesV64(cfg, shape);
        trueTrials = trials;
        if (cfg.fastMode && !shape.isCircle) {
            trueTrials = [{x:0,y:0}];
            if (Number(best.edgeRelaxX || 0) > 0 || Number(best.edgeRelaxY || 0) > 0) {
                trueTrials.push({x:Number(best.edgeRelaxX || 0), y:Number(best.edgeRelaxY || 0)});
            }
        }
        for (i = 0; i < trueTrials.length; i++) {
            t = trueTrials[i]; duplicate = false;
            for (j = 0; j < i; j++) {
                if (trueTrials[j].x === t.x && trueTrials[j].y === t.y) { duplicate = true; break; }
            }
            if (duplicate) { continue; }
            candidate = ANPTrueShape.pack({ binW:Number(binW) + t.x * 2, binH:Number(binH) + t.y * 2,
                shape:scaled, gap:Math.max(Number(cfg.gapX), Number(cfg.gapY)), angles:angles,
                maxQty:Number(maxQty) || 0, fast:cfg.fastMode === true, stagger:cfg.specialStagger !== false });
            candidate = ANP_applyCornerSafeLayoutV30(candidate, cfg,
                Number(binW) + t.x * 2, Number(binH) + t.y * 2);
            candidate.edgeRelaxX = t.x; candidate.edgeRelaxY = t.y;
            trueBest = ANP_betterEqualLayoutV21(trueBest, candidate);
        }
    }
    /* Khi đã có KHUON_BE thật, không được để lưới bounding-box thắng chỉ vì
       số con cao hơn; lưới đó có thể chồng khuôn. */
    if (trueBest) { best = trueBest; }
    if (best) {
        best = ANP_applyCornerSafeLayoutV30(best, cfg, binW, binH);
        best.edgeOptimized = Number(best.edgeRelaxX || 0) > 0 || Number(best.edgeRelaxY || 0) > 0;
        best.efficiency = Number(best.count || 0) * Number(w) * Number(h) /
            Math.max(0.0001, Number(binW) * Number(binH));
    }
    return best;
}


/* V97: nhận layout đã được tính một lần ở UI engine. Chỉ giữ các trường cần
   cho placement, không mang polygon vào Bridge để JSON nhỏ và Illustrator nhẹ. */
function ANP_cachedLayoutV99(cfg, expectedW, expectedH) {
    var c = cfg && (cfg.precomputedLayoutV99 || cfg.precomputedLayoutV97), out, i, src, it;
    if (!c || Number(c.version) !== 101 && Number(c.version) !== 99 && Number(c.version) !== 97 || !c.items || !c.items.length) { return null; }
    if (expectedW !== undefined && Number(c.sourceW) > 0 && Math.abs(Number(c.sourceW) - Number(expectedW)) > 0.05) { return null; }
    if (expectedH !== undefined && Number(c.sourceH) > 0 && Math.abs(Number(c.sourceH) - Number(expectedH)) > 0.05) { return null; }
    if (Number(c.sourceCount || 0) > 0 && cfg.sources && Number(c.sourceCount) !== cfg.sources.length) { return null; }
    out = { items:[], count:0, binW:Number(c.binW), binH:Number(c.binH), method:String(c.method || "cached-v99"),
        efficiency:Number(c.efficiency || 0), edgeRelaxX:Number(c.edgeRelaxX || 0), edgeRelaxY:Number(c.edgeRelaxY || 0),
        edgeOptimized:c.edgeOptimized === true, cornerSafe:c.cornerSafe === true, cornerClear:Number(c.cornerClear || 0),
        skipped:[], precomputedV99:true, precomputedV97:true };
    for (i = 0; i < c.items.length; i++) {
        src = c.items[i];
        if (!isFinite(Number(src.x)) || !isFinite(Number(src.y)) || !isFinite(Number(src.w)) || !isFinite(Number(src.h))) { return null; }
        if (cfg.sources && cfg.sources.length && (Number(src.sourceIndex || 0) < 0 || Number(src.sourceIndex || 0) >= cfg.sources.length)) { return null; }
        it = { x:Number(src.x), y:Number(src.y), w:Number(src.w), h:Number(src.h),
            rotated:src.rotated === true,
            offsetX:Number(src.offsetX || 0), offsetY:Number(src.offsetY || 0),
            sourceIndex:Number(src.sourceIndex || 0), copyIndex:Number(src.copyIndex == null ? i : src.copyIndex) };
        if (src.angleExplicit === true) { it.angle = Number(src.angle || 0); }
        out.items.push(it);
    }
    out.count = out.items.length;
    for (i = 0; i < Number(c.skippedCount || 0); i++) { out.skipped.push(1); }
    if (!(out.binW > 0)) { out.binW = Number(cfg.paperW) - Number(cfg.margin) * 2; }
    if (!(out.binH > 0)) { out.binH = Number(cfg.paperH) - Number(cfg.margin) * 2; }
    /* V101 HARD MARGIN FAILSAFE: cache hợp lệ phải nằm trọn trong vùng paper - 2*margin. */
    var minXV101=1e30,minYV101=1e30,maxXV101=-1e30,maxYV101=-1e30,tolV101=0.001,dxV101=0,dyV101=0;
    for(i=0;i<out.items.length;i++){it=out.items[i];minXV101=Math.min(minXV101,it.x);minYV101=Math.min(minYV101,it.y);maxXV101=Math.max(maxXV101,it.x+it.w);maxYV101=Math.max(maxYV101,it.y+it.h);}
    if(maxXV101-minXV101>out.binW+tolV101 || maxYV101-minYV101>out.binH+tolV101){throw new Error("V101: Layout vượt vùng lề cho phép. DPV đã chặn xuất file sai; hãy bấm Tính nhanh lại.");}
    if(minXV101<0){dxV101=-minXV101;}if(maxXV101+dxV101>out.binW){dxV101+=out.binW-(maxXV101+dxV101);}
    if(minYV101<0){dyV101=-minYV101;}if(maxYV101+dyV101>out.binH){dyV101+=out.binH-(maxYV101+dyV101);}
    if(Math.abs(dxV101)>0.000001||Math.abs(dyV101)>0.000001){for(i=0;i<out.items.length;i++){out.items[i].x+=dxV101;out.items[i].y+=dyV101;}}
    for(i=0;i<out.items.length;i++){it=out.items[i];if(it.x<-tolV101||it.y<-tolV101||it.x+it.w>out.binW+tolV101||it.y+it.h>out.binH+tolV101){throw new Error("V101: Có chi tiết vượt lề an toàn. Đã dừng trước khi xuất.");}}
    out.hardMarginV101=true;
    return out;
}

function ANP_layoutV11(cfg) {
    var cachedV99 = ANP_cachedLayoutV99(cfg); if (cachedV99) { return cachedV99; }
    if (cfg && cfg.layoutCacheRequiredV99 === true) { throw new Error("V99 chặn chạy solver nặng trong Illustrator vì Layout Cache bị thiếu/sai. Hãy bấm Tính nhanh lại rồi Preview/Dàn."); }
    var sources = cfg.sources || [], binW = cfg.paperW - cfg.margin * 2;
    var binH = cfg.paperH - cfg.margin * 2, layout, jobs, i;
    if (!sources.length) { throw new Error("Chưa có file tem trong danh sách."); }
    if (binW <= 0 || binH <= 0) { throw new Error("Lề 4 cạnh đang lớn hơn khổ in."); }
    if (cfg.demiMode === true) {
        if (!ANP_allSameSize(sources)) {
            throw new Error("Bế 1 dao Demi chỉ dàn chung các mẫu chữ nhật cùng kích thước.");
        }
        for (i = 0; i < sources.length; i++) {
            if (sources[i].shape && sources[i].shape.isRectangle !== true) {
                throw new Error("Bế 1 dao Demi chỉ dùng cho KHUON_BE hình chữ nhật cạnh thẳng.");
            }
        }
    }

    if (sources.length === 1 && Number(sources[0].quantity) === 0) {
        layout = ANP_equalLayoutV21(cfg, sources[0].width, sources[0].height,
            sources[0].shape, binW, binH, cfg.maxQty);
        for (i = 0; i < layout.items.length; i++) { layout.items[i].sourceIndex = 0; layout.items[i].copyIndex = i; }
        layout.skipped = [];
    } else {
        for (i = 0; i < sources.length; i++) {
            if (Number(sources[i].quantity) < 1) { throw new Error("Khi dàn nhiều file, số lượng của mỗi file phải từ 1 trở lên."); }
        }
        jobs = ANP_jobItems(sources, cfg.maxQty || 0);
        if (!cfg.demiMode && cfg.uniformGap !== true && cfg.trueShape && ANP_allHaveShapeV20(sources) && !(ANP_allSameShapeV20(sources) && ANP_allSameSize(sources)) &&
            !(cfg.fastMode && jobs.length > 80)) {
            for (i=0;i<jobs.length;i++) { jobs[i].shape=ANP_scaledShapeV20(sources[jobs[i].sourceIndex].shape,jobs[i].w,jobs[i].h); }
            layout=ANPTrueShape.packMixed({binW:binW,binH:binH,gap:Math.max(Number(cfg.gapX),Number(cfg.gapY)),
                angles:cfg.allowRotate===false?[0]:ANP_trueAnglesV20(cfg.angleStep),items:jobs,fast:cfg.fastMode===true});
        } else if (ANP_allSameSize(sources)) {
            layout = ANP_equalLayoutV21(cfg, sources[0].width, sources[0].height,
                ANP_allSameShapeV20(sources) ? sources[0].shape : null, binW, binH, jobs.length);
            for (i = 0; i < layout.items.length; i++) {
                layout.items[i].sourceIndex = jobs[i].sourceIndex; layout.items[i].copyIndex = jobs[i].copyIndex;
            }
            layout.skipped = jobs.slice(layout.items.length);
        } else {
            layout = ANPMultiPacker.pack({
                binW: binW, binH: binH, gapX: Number(cfg.gapX), gapY: Number(cfg.gapY),
                allowRotate: cfg.allowRotate !== false, items: jobs,
                cornerClear: ANP_cornerClearV30(cfg, binW, binH)
            });
            layout = ANP_applyCornerSafeLayoutV30(layout, cfg, binW, binH);
        }
    }
    layout = ANP_applyCornerSafeLayoutV30(layout, cfg, binW, binH);
    if (!layout.items.length) { throw new Error("Không có mẫu nào vừa vùng in còn lại hoặc vùng PON bốn góc đang đặt quá lớn."); }
    layout.binW = binW; layout.binH = binH; layout.count = layout.items.length;
    ANP_centerLayoutV16(layout, binW, binH);
    return layout;
}

function ANP_v11Preview(json) {
    try {
        var cfg = ANP_parse(json), layout = ANP_layoutV11(cfg), i, rotated = 0, angled = 0, methodLabel;
        for (i = 0; i < layout.items.length; i++) {
            if (layout.items[i].rotated) { rotated++; }
            if (layout.items[i].angle !== undefined && Math.abs(Number(layout.items[i].angle)) > 0.001) { angled++; }
        }
        methodLabel = layout.method === "true-shape-interlocking-columns-exact" ? "Khuôn đặc biệt xoay 90°/270° · khe đều chính xác" :
            layout.method === "true-shape-staggered-exact" ? "Khuôn đặc biệt xoay · khe đều chính xác" :
            String(layout.method || "").indexOf("uniform-grid") === 0 ? "Lưới đều tuyệt đối · một hướng" :
            layout.method === "demi-grid" ? "Bế 1 dao Demi · lưới thẳng" :
            (String(layout.method || "").indexOf("corner-safe") >= 0 ? "Tối ưu chừa PON bốn góc" :
            (layout.method === "true-shape-honeycomb" ? "True‑Shape tổ ong" :
            (layout.method === "true-shape-polygon" ? "True‑Shape polygon" :
            (layout.method === "true-shape-mixed" ? "True‑Shape nhiều khuôn" :
            (layout.method === "maxrects-mixed-sizes" ? "MaxRects nhiều kích thước" : "cột/hàng xoay tối ưu")))));
        if (layout.edgeOptimized) { methodLabel += " · sát lề " +
            ANP_round(Number(cfg.margin) - Math.max(Number(layout.edgeRelaxX || 0), Number(layout.edgeRelaxY || 0)), 2) + "mm"; }
        return ANP_ok({
            count: layout.count, rotated: rotated, normal: layout.count - rotated,
            angled: angled,
            skipped: layout.skipped ? layout.skipped.length : 0,
            efficiency: layout.efficiency || 0, binW: layout.binW, binH: layout.binH,
            edgeOptimized: layout.edgeOptimized === true,
            edgeMarginX: Number(cfg.margin) - Number(layout.edgeRelaxX || 0),
            edgeMarginY: Number(cfg.margin) - Number(layout.edgeRelaxY || 0),
            cornerSafe: layout.cornerSafe === true,
            cornerZone: Number(cfg.cornerZone || 0),
            methodLabel: methodLabel, ultraLight: ANP_isUltraLightV24(cfg, layout)
        });
    } catch (e) { return ANP_fail(e); }
}

function ANP_uniqueFolder(parent, base) {
    var folder = new Folder(parent.fsName + "/" + base), i = 1, suffix;
    while (folder.exists) {
        suffix = i < 10 ? "0" + i : String(i);
        folder = new Folder(parent.fsName + "/" + base + "_" + suffix); i++;
    }
    if (!folder.create()) { throw new Error("Không tạo được thư mục Link: " + folder.fsName); }
    return folder;
}

function ANP_ensureOutputFolderV31(parent, name) {
    var folder = new Folder(parent.fsName + "/" + name);
    if (!folder.exists && !folder.create()) {
        throw new Error("Không tạo được thư mục đầu ra " + name + ": " + folder.fsName);
    }
    return folder;
}

function ANP_makeSyntheticDie(group, bounds) {
    var p = group.pathItems.rectangle(bounds[1], bounds[0], bounds[2] - bounds[0], bounds[1] - bounds[3]);
    p.filled = false; p.stroked = true; p.strokeWidth = 0.25; p.name = "KHUON_BE_FALLBACK";
    var c = new CMYKColor(); c.cyan = 0; c.magenta = 100; c.yellow = 100; c.black = 0; p.strokeColor = c;
}

function ANP_isGeneratedPonLayerNameV40(name) {
    name = ANP_upper(String(name || "")).replace(/\s+/g, "_");
    return name === "PON" || name === "PON_PROCESS_CMYK" || name === "PON_LINK" ||
        name === "TIEU_DE" || name === "JOB_INFO" || name === "JOB_INFO_CENTER";
}

function ANP_hasGeneratedPonV40(doc) {
    var i;
    try {
        for (i = 0; i < doc.layers.length; i++) {
            if (ANP_isGeneratedPonLayerNameV40(doc.layers[i].name)) { return true; }
        }
    } catch (e) {}
    return false;
}

function ANP_copyDirectPrintSourceV23(sourceDoc, dieBounds, linkFolder, base) {
    var sourceFile, a, pads, minPad, maxPad, padding, dot, ext, target;
    try {
        if (sourceDoc.artboards.length !== 1 || sourceDoc.saved !== true) { return null; }
        sourceFile = sourceDoc.fullName;
        if (!sourceFile || !sourceFile.exists) { return null; }
        a = sourceDoc.artboards[0].artboardRect;
        pads = [ANP_toMm(dieBounds[0] - a[0]), ANP_toMm(a[1] - dieBounds[1]),
            ANP_toMm(a[2] - dieBounds[2]), ANP_toMm(dieBounds[3] - a[3])];
        minPad = Math.min(pads[0], pads[1], pads[2], pads[3]);
        maxPad = Math.max(pads[0], pads[1], pads[2], pads[3]);
        if (minPad < -0.05 || maxPad - minPad > 0.25) { return null; }
        padding = Math.max(0, (pads[0] + pads[1] + pads[2] + pads[3]) / 4);
        dot = sourceFile.name.lastIndexOf("."); ext = dot >= 0 ? sourceFile.name.substring(dot) : ".ai";
        target = new File(linkFolder.fsName + "/" + base + "_PRINT-SOURCE" + ext);
        if (!sourceFile.copy(target.fsName)) { return null; }
        return { file:target, padding:padding };
    } catch (e) { return null; }
}


/* ========================================================================== */
/* V5.3 FIDELITY MASK-SAFE — PRESERVE ORIGINAL ARTWORK EXACTLY                     */
/* ========================================================================== */
/*
   Lý do: copy PageItem/GroupItem sang document PRINT-LINK có thể làm Illustrator
   thay đổi clipping/opacity mask, live effect, placed image hoặc appearance phức
   tạp. V5.3 không rebuild artwork và tuyệt đối bảo vệ clipping mask. Với file AI đã save, DPV copy nguyên file nguồn,
   làm việc trên BẢN COPY, bỏ riêng KHUON_BE/PON do DPV tạo, crop artboard theo
   dieBounds + Bleed trong Link rồi dùng chính file copy đó làm PRINT-LINK.
   Vì artwork không rời document gốc nên clipping mask, opacity mask, live effect,
   blend mode, embedded/linked raster và thứ tự stacking được giữ nguyên tối đa.
*/
function ANP_unlockLayersForFidelityV52(container) {
    var i;
    if (!container) { return; }
    try { container.locked = false; } catch (e0) {}
    try {
        if (container.layers) {
            for (i = 0; i < container.layers.length; i++) { ANP_unlockLayersForFidelityV52(container.layers[i]); }
        }
    } catch (e1) {}
}

function ANP_removeGeneratedPonLayersV52(doc) {
    var i, layer, removed = 0;
    try {
        for (i = doc.layers.length - 1; i >= 0; i--) {
            layer = doc.layers[i];
            try {
                if (ANP_isGeneratedPonLayerNameV40(layer.name)) {
                    layer.locked = false; layer.remove(); removed++;
                }
            } catch (e0) {}
        }
    } catch (e1) {}
    return removed;
}

function ANP_makeDieSignaturesV52(dieItems) {
    var out = [], i;
    for (i = 0; i < (dieItems ? dieItems.length : 0); i++) {
        try { out.push(ANP_signature(dieItems[i])); } catch (e0) {}
    }
    return out;
}

function ANP_dieStyleSafeForRemovalV53(item, hint, signatures) {
    var i, p, b, named = false, matched = false, stroked = false, filled = true;
    if (!item) { return false; }
    try { if (item.hidden === true) { return false; } } catch (eHidden) {}
    try { if (item.typename === "PathItem" && item.clipping === true) { return false; } } catch (eClip) {}
    try { named = ANP_itemNamedDie(item, hint || ""); } catch (eName) {}
    try { matched = ANP_matchesSignature(item, signatures || []); } catch (eSig) {}
    if (item.typename === "PathItem") {
        try { stroked = item.stroked === true; } catch (eS) {}
        try { filled = item.filled === true; } catch (eF) {}
        /* V5.3 CRITICAL: cùng bounds với KHUON_BE KHÔNG đủ để xóa. Clipping mask
           thường có đúng bounds đó. Chỉ xóa path không-fill + có stroke kiểu die,
           hoặc path/layer được đặt tên KHUON_BE rõ ràng. */
        if (named) { return true; }
        if (!matched || !stroked || filled) { return false; }
        try { return ANP_colorLooksDie(item.strokeColor, hint || ""); } catch (eC) { return false; }
    }
    if (item.typename === "CompoundPathItem") {
        if (named) { return true; }
        if (!matched) { return false; }
        try {
            for (i = 0; i < item.pathItems.length; i++) {
                p = item.pathItems[i];
                try { if (p.clipping === true) { return false; } } catch (ePC) {}
                try { if (p.filled === true || p.stroked !== true) { return false; } } catch (ePS) { return false; }
                try { if (!ANP_colorLooksDie(p.strokeColor, hint || "")) { return false; } } catch (eColor) { return false; }
            }
            return item.pathItems.length > 0;
        } catch (eCP) { return false; }
    }
    return false;
}

function ANP_removeDieTreeMaskSafeV53(item, hint, signatures) {
    var i, child;
    if (!item) { return; }
    try {
        /* Không bao giờ chui vào clipping group. Đây là artwork hiển thị thật;
           die line không đáng để đánh đổi việc phá clipping/opacity mask. */
        if (item.typename === "GroupItem") {
            try { if (item.clipped === true) { return; } } catch (eClipped) {}
            if (ANP_itemNamedDie(item, hint || "")) {
                /* Group được đặt tên/layer die rõ ràng mới được xóa nguyên group. */
                item.remove(); return;
            }
            for (i = item.pageItems.length - 1; i >= 0; i--) {
                child = item.pageItems[i];
                ANP_removeDieTreeMaskSafeV53(child, hint, signatures);
            }
            return;
        }
        if (item.typename === "PathItem" || item.typename === "CompoundPathItem") {
            if (ANP_dieStyleSafeForRemovalV53(item, hint, signatures)) { item.remove(); }
        }
    } catch (e0) {}
}

function ANP_removeDieOnlyFromFidelityCopyV53(doc, hint, signatures) {
    var i, item, layer, n;
    ANP_unlockLayersForFidelityV52(doc);
    /* Ưu tiên xóa layer DIE/KHUON_BE riêng biệt. Đây là cách an toàn tuyệt đối
       cho clipping mask nằm trong layer artwork. */
    try {
        for (i = doc.layers.length - 1; i >= 0; i--) {
            layer = doc.layers[i]; n = "";
            try { n = layer.name || ""; } catch (eN) {}
            if (ANP_hasDieWord(n, hint || "")) {
                try { layer.locked = false; layer.remove(); } catch (eL) {}
            }
        }
    } catch (eLayers) {}
    /* Nếu dieline không có layer riêng: chỉ xóa path die có style + bounds phù hợp,
       không xóa path clipping và không recurse vào clipping group. */
    try {
        for (i = doc.pageItems.length - 1; i >= 0; i--) {
            item = doc.pageItems[i];
            try { if (item.parent && item.parent.typename !== "Layer") { continue; } } catch (eParent) {}
            ANP_removeDieTreeMaskSafeV53(item, hint || "", signatures || []);
        }
    } catch (e0) {}
}

function ANP_keepOnlyFidelityArtboardV52(doc, artboardIndex, rect) {
    var i, idx = Math.max(0, Math.min(doc.artboards.length - 1, Number(artboardIndex) || 0));
    doc.artboards.setActiveArtboardIndex(idx);
    doc.artboards[idx].artboardRect = rect;
    /* Xóa artboard khác, KHÔNG xóa artwork. Single artboard khi Place AI sẽ clip
       theo đúng vùng die + bleed nhưng vẫn giữ nguyên cấu trúc object nội bộ. */
    for (i = doc.artboards.length - 1; i >= 0; i--) {
        if (i === idx) { continue; }
        try { doc.artboards[i].remove(); } catch (e0) {}
    }
    try { doc.artboards.setActiveArtboardIndex(0); } catch (e1) {}
}

function ANP_printCropBoundsV64(meta, artboardBounds, dieBounds, bleedPt) {
    var base = meta && meta.useArtboardBounds === true && artboardBounds ? artboardBounds : dieBounds;
    return [base[0] - bleedPt, base[1] + bleedPt, base[2] + bleedPt, base[3] - bleedPt];
}

function ANP_makeFidelityPrintSourceV52(sourceDoc, meta, cfg, dieBounds, dieItems, linkFolder, base) {
    var sourceFile, ext, target, tempDoc = null, activeIndex, bleedPt, cropRect, signatures, artboardBounds;
    try {
        if (cfg.preservePrintColor === false) { return null; }
        /* saved=true đảm bảo bản trên đĩa chính là trạng thái hiện tại; không tự save
           file thiết kế của người dùng. */
        if (!sourceDoc || sourceDoc.saved !== true) { return null; }
        sourceFile = sourceDoc.fullName;
        if (!sourceFile || !sourceFile.exists) { return null; }
        ext = String(sourceFile.name || "").toLowerCase();
        if (ext.length < 3 || ext.substring(ext.length - 3) !== ".ai") { return null; }

        activeIndex = (meta && meta.artboardIndex !== undefined) ? Number(meta.artboardIndex) : sourceDoc.artboards.getActiveArtboardIndex();
        if (activeIndex < 0 || activeIndex >= sourceDoc.artboards.length) { activeIndex = sourceDoc.artboards.getActiveArtboardIndex(); }
        bleedPt = ANP_mm(Math.max(0, Number(cfg.linkBleed) || 0));
        artboardBounds = sourceDoc.artboards[activeIndex].artboardRect;
        cropRect = ANP_printCropBoundsV64(meta, artboardBounds, dieBounds, bleedPt);
        signatures = ANP_makeDieSignaturesV52(dieItems || []);

        target = new File(linkFolder.fsName + "/" + base + "_PRINT-FIDELITY.ai");
        if (target.exists) { try { target.remove(); } catch (eRm) {} }
        if (!sourceFile.copy(target.fsName)) { return null; }

        tempDoc = app.open(target);
        try { tempDoc.artboards.setActiveArtboardIndex(Math.min(activeIndex, tempDoc.artboards.length - 1)); } catch (eAb0) {}
        ANP_removeGeneratedPonLayersV52(tempDoc);
        ANP_removeDieOnlyFromFidelityCopyV53(tempDoc, cfg.dieHint || "", signatures);
        ANP_keepOnlyFidelityArtboardV52(tempDoc, Math.min(activeIndex, tempDoc.artboards.length - 1), cropRect);
        /* V5.3: bắt buộc ghi lại AI với PDF Compatible = TRUE. Illustrator khi
           Place file .AI dùng phần PDF-compatible để render nested raster,
           clipping/opacity mask và live effect. Nếu file gốc lưu PDF Compatible OFF,
           tempDoc.save() có thể khiến Link chỉ còn vector/text và mất ảnh nền. */
        ANP_saveAI(tempDoc, target);
        tempDoc.close(SaveOptions.DONOTSAVECHANGES); tempDoc = null;
        return { file:target, padding:Number(cfg.linkBleed) || 0, fidelity:true };
    } catch (e) {
        try { if (tempDoc) { tempDoc.close(SaveOptions.DONOTSAVECHANGES); } } catch (e0) {}
        try { if (target && target.exists) { target.remove(); } } catch (e1) {}
        return null;
    }
}

function ANP_makeDieTemplateOnlyV52(doc, dieItems, dieBounds) {
    var temp = doc.layers.add(), dieGroup, i;
    temp.name = "__AUTO_NEST_PRO_TEMP__"; temp.locked = false; temp.visible = true;
    dieGroup = temp.groupItems.add(); dieGroup.name = "DIE_TEMPLATE";
    for (i = 0; i < dieItems.length; i++) {
        try { dieItems[i].duplicate(dieGroup, ElementPlacement.PLACEATEND); } catch (e0) {}
    }
    ANP_addReference(dieGroup, dieBounds);
    return { layer:temp, printGroup:null, dieGroup:dieGroup };
}


/* V97 SIMPLE-SOURCE FAST PATH. Với file chỉ gồm vector/text đơn giản, không
   mở + save lại nguyên AI để tạo Fidelity Link. Cross-document template nhẹ
   hơn rất nhiều và không ảnh hưởng các file có ảnh link/mask phức tạp. */
function ANP_isSimpleSourceV96(doc) {
    var i, g, pageCount = 0;
    try { pageCount = doc.pageItems.length; } catch (e0) { return false; }
    if (pageCount > 320) { return false; }
    try { if (doc.placedItems.length > 0 || doc.rasterItems.length > 0 || doc.symbolItems.length > 0) { return false; } } catch (e1) {}
    try { if (doc.graphItems && doc.graphItems.length > 0) { return false; } } catch (e2) {}
    try { if (doc.pluginItems && doc.pluginItems.length > 0) { return false; } } catch (e3) {}
    try {
        for (i = 0; i < doc.groupItems.length; i++) {
            g = doc.groupItems[i];
            try { if (g.clipped === true) { return false; } } catch (e4) {}
            try { if (Number(g.opacity) < 99.999) { return false; } } catch (e5) {}
        }
    } catch (e6) {}
    return true;
}

function ANP_createLinkPair(sourceDoc, meta, cfg, linkFolder) {
    var templates = null, printLinkDoc = null, dieLinkDoc = null;
    try {
        var sourceItems = ANP_sourceItems(sourceDoc, "artboard");
        var dieItems, dieBounds, dieGeometry, fallback = false, artboardBounds, printBounds;
        artboardBounds = sourceDoc.artboards[sourceDoc.artboards.getActiveArtboardIndex()].artboardRect;
        if (meta.forceArtboardDie) {
            dieItems = []; dieBounds = sourceDoc.artboards[sourceDoc.artboards.getActiveArtboardIndex()].artboardRect; fallback = true;
        } else {
            dieItems = meta.active ? ANP_getDie(sourceDoc, sourceItems, cfg.dieHint || "",
                sourceDoc.artboards[sourceDoc.artboards.getActiveArtboardIndex()].artboardRect) :
                ANP_autoDie(sourceItems, cfg.dieHint || "",
                    sourceDoc.artboards[sourceDoc.artboards.getActiveArtboardIndex()].artboardRect);
            dieBounds = ANP_bounds(dieItems);
            if (!dieBounds) { dieBounds = sourceDoc.artboards[sourceDoc.artboards.getActiveArtboardIndex()].artboardRect; fallback = true; }
        }
        printBounds = meta && meta.useArtboardBounds === true ? artboardBounds : dieBounds;
        /* V5.5: đọc Bézier ngay khi sourceDoc còn mở và contour vẫn là PathItem.
           Đây là nguồn duy nhất dùng để dựng FILE KHUÔN ở nhánh mới. */
        dieGeometry = ANP_dieGeometryV55(dieItems, dieBounds, Number(meta.width), Number(meta.height));
        if ((!dieGeometry || !dieGeometry.paths.length) && fallback) {
            dieGeometry = ANP_rectangleDieGeometryV55(dieBounds, Number(meta.width), Number(meta.height));
        }
        var linkNumber = Number(meta._linkIndex) + 1;
        var base = (linkNumber < 10 ? "0" + linkNumber : String(linkNumber)) + "_" + ANP_safeBase(meta.name);
        var printFile = new File(linkFolder.fsName + "/" + base + "_PRINT-LINK.ai");
        var dieFile = new File(linkFolder.fsName + "/" + base + "_DIE-LINK.ai");
        var linkCfg = { itemW: Number(meta.width), itemH: Number(meta.height), margin: Number(cfg.linkBleed), header: 0 };
        var diePad = 1, dieCfg = { itemW: Number(meta.width), itemH: Number(meta.height), margin: diePad, header: 0 };
        var placement = { x: 0, y: 0, rotated: false }, inst, dieColor, direct = null;
        var printColorMode = cfg.preservePrintColor === false ? "CMYK" : ANP_colorModeNameV23(sourceDoc.documentColorSpace);
        var printColorSpace = ANP_colorSpaceFromModeV23(printColorMode), printBleed = Number(cfg.linkBleed);
        var simpleFastV97 = cfg.fastMode === true && ANP_isSimpleSourceV96(sourceDoc);

        /* V5.3 FIDELITY MASK-SAFE: ưu tiên copy nguyên file AI nguồn và chỉ crop artboard.
           Không rebuild PageItem => giữ clipping/opacity mask, live effect, placed image,
           blend/transparency và stacking order chính xác nhất. */
        if (!simpleFastV97) { direct = ANP_makeFidelityPrintSourceV52(sourceDoc, meta, cfg, dieBounds, dieItems, linkFolder, base); }
        if (!direct && cfg.preservePrintColor !== false && !cfg.ponPath && !ANP_hasGeneratedPonV40(sourceDoc)) {
            direct = ANP_copyDirectPrintSourceV23(sourceDoc, printBounds, linkFolder, base);
        }

        /* Nếu Fidelity thành công, chỉ dựng template KHUÔN; không duplicate artwork in
           sang temp group thêm một lần nữa. */
        if (direct && direct.fidelity === true) {
            templates = ANP_makeDieTemplateOnlyV52(sourceDoc, dieItems, dieBounds);
        } else {
            sourceItems = ANP_filterNearDie(sourceItems, printBounds, ANP_mm(cfg.linkBleed));
            templates = ANP_makeTemplates(sourceDoc, sourceItems, dieItems, dieBounds, cfg.dieHint || "", printBounds);
        }
        if (fallback) { ANP_makeSyntheticDie(templates.dieGroup, dieBounds); }

        if (direct) {
            printFile = direct.file; printBleed = Number(direct.padding);
        } else {
            printLinkDoc = app.documents.add(printColorSpace,
                ANP_mm(Number(meta.width) + Number(cfg.linkBleed) * 2),
                ANP_mm(Number(meta.height) + Number(cfg.linkBleed) * 2));
            printLinkDoc.layers[0].name = "PRINT_LINK_PRESERVE_COLOR";
            inst = ANP_placeTemplate(templates.printGroup, printLinkDoc.layers[0], placement, linkCfg, printLinkDoc.artboards[0].artboardRect);
            inst.name = "PRINT_LINK_SOURCE";
            ANP_saveAI(printLinkDoc, printFile); printLinkDoc.close(SaveOptions.DONOTSAVECHANGES); printLinkDoc = null;
        }

        /* Chỉ tạo DIE-LINK cho file rất cũ/đặc biệt không đọc được Path trực tiếp.
           Geometry V5.5 bỏ qua hoàn toàn Symbol/Embed nên vừa nhanh vừa ổn định hơn. */
        if (cfg.finishCropMarks !== true && cfg.demiMode !== true && (!dieGeometry || !dieGeometry.paths.length)) {
            dieLinkDoc = app.documents.add(DocumentColorSpace.CMYK,
                ANP_mm(Number(meta.width) + diePad * 2), ANP_mm(Number(meta.height) + diePad * 2));
            dieLinkDoc.layers[0].name = "KHUON_BE_LINK";
            inst = ANP_placeTemplate(templates.dieGroup, dieLinkDoc.layers[0], placement, dieCfg, dieLinkDoc.artboards[0].artboardRect);
            dieColor = ANP_dieProcessColorV21();
            ANP_normalizeDie(inst, dieColor);
            /* V3.7: DIE-LINK cũng phải là Bezier stroke thật, không để Symbol đi tiếp sang sheet. */
            dieLinkDoc.layers[0].name = "KHUON_BE_LINK_DIRTY";
            var dieLinkVectorLayer = ANP_finalizeDieStrokeVectorsV37(dieLinkDoc, dieLinkDoc.layers[0]);
            ANP_assertStrokeVectorLayerV37(dieLinkVectorLayer);
            ANP_removeDieSpotSwatchesV21(dieLinkDoc);
            ANP_saveAI(dieLinkDoc, dieFile); dieLinkDoc.close(SaveOptions.DONOTSAVECHANGES); dieLinkDoc = null;
        }

        templates.layer.remove(); templates = null;
        return { printPath: printFile.fsName,
            diePath:(cfg.finishCropMarks === true || cfg.demiMode === true || (dieGeometry && dieGeometry.paths.length)) ? "" : dieFile.fsName,
            dieGeometry:dieGeometry, bleed: printBleed, diePad: diePad,
            printColorMode:printColorMode, directPrintSource:direct !== null, fidelityPrintSource:!!(direct && direct.fidelity),
            directBezierGeometry:!!(dieGeometry && dieGeometry.paths.length), simpleFastV97:simpleFastV97 === true };
    } catch (e) {
        try { if (printLinkDoc) { printLinkDoc.close(SaveOptions.DONOTSAVECHANGES); } } catch (e0) {}
        try { if (dieLinkDoc) { dieLinkDoc.close(SaveOptions.DONOTSAVECHANGES); } } catch (e1) {}
        try { if (templates && templates.layer) { templates.layer.remove(); } } catch (e2) {}
        throw e;
    }
}

function ANP_linkMaster(doc, layer, path, name) {
    ANP_prepareTargetLayerV28(doc, layer);
    var p = ANP_placeFileSafeV57(doc, layer, new File(path), name, false).item;
    var a = ANP_activeArtboardRectV61(doc); p.left = a[0]; p.top = a[1];
    return p;
}

function ANP_placeLinked(doc, layer, master, placement, cfg, padding, name, embed) {
    ANP_prepareTargetLayerV28(doc, layer);
    var p = master.duplicate(layer, ElementPlacement.PLACEATEND); p.name = name;
    var explicitAngle = placement.angle !== undefined;
    var angle = explicitAngle ? Number(placement.angle) : (placement.rotated ? 90 : 0);
    if (Math.abs(angle) > 0.0001) { p.rotate(explicitAngle ? -angle : angle, true, true, true, true, Transformation.CENTER); }
    var a = ANP_activeArtboardRectV61(doc);
    var targetLeft = a[0] + ANP_mm(cfg.margin + placement.x);
    var targetTop = a[1] - ANP_mm(cfg.margin + placement.y);
    var rad = angle * Math.PI / 180, padAxis = Number(padding) * (Math.abs(Math.cos(rad)) + Math.abs(Math.sin(rad)));
    var offX = Number(placement.offsetX || 0) - padAxis, offY = Number(placement.offsetY || 0) - padAxis;
    p.left = targetLeft + ANP_mm(offX); p.top = targetTop - ANP_mm(offY);
    if (embed) { p.embed(); }
    return p;
}

/* V4.7: FILE IN phải giữ TỪNG TEM là một PlacedItem Link độc lập.
   Tối ưu bằng cách duplicate một linked master duy nhất và gán position theo batch;
   tuyệt đối không chuyển sang SymbolItem và không gom thành Whole-Sheet Link. */
function ANP_placeIndividualLinkFastV47(doc, layer, master, placement, cfg, padding, name) {
    ANP_prepareTargetLayerV28(doc, layer);
    var p = master.duplicate(layer, ElementPlacement.PLACEATEND);
    if (name) { try { p.name = name; } catch (eName) {} }
    var explicitAngle = placement.angle !== undefined;
    var angle = explicitAngle ? Number(placement.angle) : (placement.rotated ? 90 : 0);
    if (Math.abs(angle) > 0.0001) {
        p.rotate(explicitAngle ? -angle : angle, true, true, true, true, Transformation.CENTER);
    }
    var a = ANP_activeArtboardRectV61(doc);
    var rad = angle * Math.PI / 180;
    var padAxis = Number(padding) * (Math.abs(Math.cos(rad)) + Math.abs(Math.sin(rad)));
    var offX = Number(placement.offsetX || 0) - padAxis;
    var offY = Number(placement.offsetY || 0) - padAxis;
    /* position=[left,top] tránh hai lần cập nhật left/top riêng biệt. */
    p.position = [
        a[0] + ANP_mm(Number(cfg.margin) + Number(placement.x) + offX),
        a[1] - ANP_mm(Number(cfg.margin) + Number(placement.y) + offY)
    ];
    return p;
}

/* V4.9 — FAST BATCH LINKS
   Profiler V4.8 cho thấy việc duplicate từng PlacedItem chiếm phần lớn thời gian.
   Với các hàng/cột lặp lại, chỉ dựng MỘT band mẫu rồi duplicate cả GroupItem.
   Các phần tử con vẫn là từng PlacedItem Link riêng trong Links panel. */
function ANP_v49Key(n) { return String(Math.round(Number(n || 0) * 1000) / 1000); }
function ANP_v49Angle(placement) {
    var a = placement && placement.angle !== undefined ? Number(placement.angle) : (placement && placement.rotated ? 90 : 0);
    if (Math.abs(a) < 0.0001) { a = 0; }
    return a;
}
function ANP_v49EffectiveXY(placement, cfg, padding) {
    var angle = ANP_v49Angle(placement), rad = angle * Math.PI / 180;
    var padAxis = Number(padding || 0) * (Math.abs(Math.cos(rad)) + Math.abs(Math.sin(rad)));
    return {
        x:Number(cfg.margin) + Number(placement.x) + Number(placement.offsetX || 0) - padAxis,
        y:Number(cfg.margin) + Number(placement.y) + Number(placement.offsetY || 0) - padAxis
    };
}
function ANP_v49PlaceRaw(doc, container, master, placement, cfg, padding) {
    var p = master.duplicate(container, ElementPlacement.PLACEATEND);
    var angle = ANP_v49Angle(placement), explicitAngle = placement.angle !== undefined;
    if (Math.abs(angle) > 0.0001) {
        p.rotate(explicitAngle ? -angle : angle, true, true, true, true, Transformation.CENTER);
    }
    var a = doc.artboards[0].artboardRect, xy = ANP_v49EffectiveXY(placement, cfg, padding);
    p.position = [a[0] + ANP_mm(xy.x), a[1] - ANP_mm(xy.y)];
    return p;
}
function ANP_v49MakeBands(records, orientation) {
    var bandsByKey = {}, bands = [], i, r, key, b, j, sig, groups = {}, g, rel, first;
    for (i = 0; i < records.length; i++) {
        r = records[i]; key = ANP_v49Key(orientation === "row" ? r.xy.y : r.xy.x);
        if (!bandsByKey[key]) { bandsByKey[key] = { key:key, items:[] }; bands.push(bandsByKey[key]); }
        bandsByKey[key].items.push(r);
    }
    for (i = 0; i < bands.length; i++) {
        b = bands[i];
        b.items.sort(function (a, z) { return orientation === "row" ? a.xy.x - z.xy.x : a.xy.y - z.xy.y; });
        first = b.items[0]; sig = String(b.items.length) + ":";
        for (j = 0; j < b.items.length; j++) {
            rel = orientation === "row" ? (b.items[j].xy.x - first.xy.x) : (b.items[j].xy.y - first.xy.y);
            sig += ANP_v49Key(rel) + ",";
        }
        b.signature = sig;
        if (!groups[sig]) { groups[sig] = { signature:sig, bands:[] }; }
        groups[sig].bands.push(b);
    }
    var list = [], cost = 0, saved = 0;
    for (key in groups) {
        if (!groups.hasOwnProperty(key)) { continue; }
        g = groups[key];
        g.bands.sort(function (a, z) {
            var aa = a.items[0], zz = z.items[0];
            return orientation === "row" ? aa.xy.y - zz.xy.y : aa.xy.x - zz.xy.x;
        });
        var n = g.bands[0].items.length, m = g.bands.length;
        g.batch = (n >= 2 && m >= 2);
        if (g.batch) { cost += n + (m - 1); saved += n * m - (n + m - 1); }
        else { cost += n * m; }
        list.push(g);
    }
    return { orientation:orientation, groups:list, estimatedOps:cost, savedOps:saved };
}
function ANP_v49BuildBucket(doc, layer, master, records, cfg, padding, stats) {
    if (!records.length) { return; }
    var rows = ANP_v49MakeBands(records, "row"), cols = ANP_v49MakeBands(records, "col");
    var plan = rows.estimatedOps <= cols.estimatedOps ? rows : cols;
    var gi, bi, ii, groupPlan, baseBand, baseRec, prototype, clone, targetBand, targetRec, dx, dy;
    stats.estimatedIndividualOps += records.length;
    stats.estimatedFastOps += plan.estimatedOps;
    stats.savedDuplicateOps += Math.max(0, records.length - plan.estimatedOps);
    if (plan.savedOps > 0) { stats.batchedBuckets++; }
    if (plan.orientation === "row") { stats.rowBuckets++; } else { stats.columnBuckets++; }
    for (gi = 0; gi < plan.groups.length; gi++) {
        groupPlan = plan.groups[gi]; baseBand = groupPlan.bands[0];
        if (!groupPlan.batch) {
            for (bi = 0; bi < groupPlan.bands.length; bi++) {
                for (ii = 0; ii < groupPlan.bands[bi].items.length; ii++) {
                    ANP_v49PlaceRaw(doc, layer, master, groupPlan.bands[bi].items[ii].item, cfg, padding);
                    stats.primitiveLinks++;
                }
            }
            continue;
        }
        prototype = layer.groupItems.add();
        try { prototype.name = "__DPV_LINK_BATCH_" + stats.batchedGroups; } catch (eName) {}
        for (ii = 0; ii < baseBand.items.length; ii++) {
            ANP_v49PlaceRaw(doc, prototype, master, baseBand.items[ii].item, cfg, padding);
            stats.primitiveLinks++;
        }
        baseRec = baseBand.items[0]; stats.batchedGroups++;
        for (bi = 1; bi < groupPlan.bands.length; bi++) {
            targetBand = groupPlan.bands[bi]; targetRec = targetBand.items[0];
            clone = prototype.duplicate(layer, ElementPlacement.PLACEATEND);
            dx = ANP_mm(targetRec.xy.x - baseRec.xy.x);
            dy = -ANP_mm(targetRec.xy.y - baseRec.xy.y);
            if (Math.abs(dx) > 0.0001 || Math.abs(dy) > 0.0001) { clone.translate(dx, dy); }
            stats.groupClones++;
        }
    }
}
function ANP_buildIndividualLinksBatchV49(doc, layer, masters, layout, cfg, links) {
    ANP_prepareTargetLayerV28(doc, layer);
    var stats = { version:"V4.9", total:layout.items.length, primitiveLinks:0, groupClones:0,
        batchedGroups:0, batchedBuckets:0, rowBuckets:0, columnBuckets:0,
        estimatedIndividualOps:0, estimatedFastOps:0, savedDuplicateOps:0, rotated:0 };
    var buckets = {}, bucketList = [], i, item, key, rec, b, s, angle, xy, padding;
    for (i = 0; i < layout.items.length; i++) {
        item = layout.items[i]; s = Number(item.sourceIndex || 0); angle = ANP_v49Angle(item);
        if (Math.abs(angle) > 0.0001) { stats.rotated++; }
        padding = links[s].bleed; xy = ANP_v49EffectiveXY(item, cfg, padding);
        key = String(s) + "|" + ANP_v49Key(angle);
        if (!buckets[key]) { buckets[key] = { sourceIndex:s, angle:angle, records:[] }; bucketList.push(buckets[key]); }
        rec = { item:item, xy:xy, index:i }; buckets[key].records.push(rec);
    }
    for (i = 0; i < bucketList.length; i++) {
        b = bucketList[i];
        ANP_v49BuildBucket(doc, layer, masters[b.sourceIndex], b.records, cfg, links[b.sourceIndex].bleed, stats);
    }
    return stats;
}

function ANP_assertIndividualPrintLinksV47(doc, expected) {
    var links = 0, symbols = 0;
    try { links = doc.placedItems.length; } catch (e0) {}
    try { symbols = doc.symbolItems.length; } catch (e1) {}
    if (symbols > 0) {
        throw new Error("FILE IN còn SymbolItem; V4.7 yêu cầu mỗi tem là Link độc lập.");
    }
    if (Number(expected || 0) > 0 && links < Number(expected)) {
        throw new Error("FILE IN thiếu Link độc lập: " + links + "/" + expected + ".");
    }
    return links;
}

/* V62: kiểm tra riêng từng mặt A/B. Kiểm tra tổng doc không phát hiện được
   trường hợp mặt A đủ Link nhưng toàn bộ Link mặt B bị NaN/chồng ngoài artboard. */
function ANP_assertDuplexSideV62(doc, layer, expected, label) {
    var count = 0, i, item, bounds = ANP_layerTopBoundsV36(layer), a, centerX, centerY, targetX, targetY;
    try {
        for (i = 0; i < layer.pageItems.length; i++) {
            item = layer.pageItems[i];
            if (item.parent === layer && item.typename === "PlacedItem") { count++; }
        }
    } catch (eCount) {}
    if (count !== Number(expected || 0)) {
        throw new Error("Mặt " + label + " thiếu Link: " + count + "/" + expected + ".");
    }
    if (!bounds) { throw new Error("Mặt " + label + " không có artwork để xuất."); }
    a = ANP_activeArtboardRectV61(doc);
    centerX = Number(bounds.centerX); centerY = Number(bounds.centerY);
    targetX = (Number(a[0]) + Number(a[2])) / 2;
    targetY = (Number(a[1]) + Number(a[3])) / 2;
    if (!isFinite(centerX) || !isFinite(centerY) ||
        Math.abs(centerX - targetX) > ANP_mm(0.25) || Math.abs(centerY - targetY) > ANP_mm(0.25)) {
        throw new Error("Artwork mặt " + label + " chưa nằm đúng tâm artboard.");
    }
    return count;
}

function ANP_makeSymbolV22(doc, layer, master, name) {
    var seed = null, symbol = null;
    try {
        ANP_prepareTargetLayerV28(doc, layer);
        seed = master.duplicate(layer, ElementPlacement.PLACEATEND);
        symbol = doc.symbols.add(seed); symbol.name = name;
        try { seed.remove(); } catch (e0) {}
        return symbol;
    } catch (e) {
        try { if (seed) { seed.remove(); } } catch (e1) {}
        return null;
    }
}

function ANP_placeLinkedSymbolV22(doc, layer, symbol, placement, cfg, padding, name) {
    ANP_prepareTargetLayerV28(doc, layer);
    var p = doc.symbolItems.add(symbol); p.move(layer, ElementPlacement.PLACEATEND); p.name = name;
    var explicitAngle = placement.angle !== undefined;
    var angle = explicitAngle ? Number(placement.angle) : (placement.rotated ? 90 : 0);
    if (Math.abs(angle) > 0.0001) { p.rotate(explicitAngle ? -angle : angle, true, true, true, true, Transformation.CENTER); }
    var a = doc.artboards[0].artboardRect;
    var targetLeft = a[0] + ANP_mm(cfg.margin + placement.x);
    var targetTop = a[1] - ANP_mm(cfg.margin + placement.y);
    var rad = angle * Math.PI / 180, padAxis = Number(padding) * (Math.abs(Math.cos(rad)) + Math.abs(Math.sin(rad)));
    var offX = Number(placement.offsetX || 0) - padAxis, offY = Number(placement.offsetY || 0) - padAxis;
    p.left = targetLeft + ANP_mm(offX); p.top = targetTop - ANP_mm(offY);
    return p;
}

/* v2.4: từ 500 con trở lên dùng đường chạy siêu nhẹ. Layer được ẩn trong lúc
   dựng, SymbolItem không gán tên riêng và FILE IN cuối chỉ chứa một SHEET-LINK. */
function ANP_isUltraLightV24(cfg, layout) {
    return cfg.fastMode === true && layout && layout.items && layout.items.length >= 500;
}

function ANP_isPrintUltraFastV46(cfg, layout) {
    /* V4.6: chỉ FILE IN chuyển sang Whole-Sheet Link sớm. Không dùng ngưỡng này
       cho KHUÔN/preview để giữ cách dựng vector truyền thống. */
    return cfg.fastMode === true && layout && layout.items && layout.items.length >= 80;
}

function ANP_placeLinkedSymbolUltraV24(doc, layer, symbol, placement, cfg, padding) {
    ANP_prepareTargetLayerV28(doc, layer);
    var p = doc.symbolItems.add(symbol);
    try { p.move(layer, ElementPlacement.PLACEATEND); } catch (eMove) {}
    var explicitAngle = placement.angle !== undefined;
    var angle = explicitAngle ? Number(placement.angle) : (placement.rotated ? 90 : 0);
    if (Math.abs(angle) > 0.0001) {
        p.rotate(explicitAngle ? -angle : angle, true, true, true, true, Transformation.CENTER);
    }
    var a = doc.artboards[0].artboardRect;
    var rad = angle * Math.PI / 180;
    var padAxis = Number(padding) * (Math.abs(Math.cos(rad)) + Math.abs(Math.sin(rad)));
    var offX = Number(placement.offsetX || 0) - padAxis;
    var offY = Number(placement.offsetY || 0) - padAxis;
    p.position = [a[0] + ANP_mm(Number(cfg.margin) + Number(placement.x) + offX),
        a[1] - ANP_mm(Number(cfg.margin) + Number(placement.y) + offY)];
    return p;
}

function ANP_placeWholeSheetLinkV24(doc, layer, file) {
    ANP_prepareTargetLayerV28(doc, layer);
    var p = ANP_placeFileSafeV57(doc, layer, file, "ULTRA_LIGHT_SHEET_LINK", false).item;
    var a = doc.artboards[0].artboardRect;
    p.left = a[0]; p.top = a[1];
    layer.name = "FILE_IN_1_SHEET_LINK";
    return p;
}

function ANP_ultraSheetFileV24(folder, base, count) {
    base = ANP_safeBase(base || "PRINT");
    if (base.length > 48) { base = base.substring(0, 48); }
    return ANP_uniqueFile(folder, base + "_" + count + "PCS_SHEET-LINK");
}

function ANP_makeTemplateSymbolV22(doc, layer, template, name, dieColor) {
    var seed = null, ref = null, symbol = null;
    try {
        ANP_prepareTargetLayerV28(doc, layer);
        seed = template.duplicate(layer, ElementPlacement.PLACEATEND);
        ref = ANP_findReference(seed); if (ref) { ref.remove(); }
        ANP_normalizeDie(seed, dieColor);
        symbol = doc.symbols.add(seed); symbol.name = name;
        try { seed.remove(); } catch (e0) {}
        return symbol;
    } catch (e) {
        try { if (seed) { seed.remove(); } } catch (e1) {}
        return null;
    }
}

function ANP_placeTemplateSymbolV22(doc, layer, symbol, placement, cfg, name) {
    ANP_prepareTargetLayerV28(doc, layer);
    var p = doc.symbolItems.add(symbol); p.move(layer, ElementPlacement.PLACEATEND); p.name = name;
    var b = p.geometricBounds, sx = ANP_mm(cfg.itemW) / Math.max(0.001, b[2] - b[0]) * 100;
    var sy = ANP_mm(cfg.itemH) / Math.max(0.001, b[1] - b[3]) * 100;
    p.resize(sx, sy, true, true, true, true, (sx + sy) / 2, Transformation.CENTER);
    var explicitAngle = placement.angle !== undefined;
    var angle = explicitAngle ? Number(placement.angle) : (placement.rotated ? 90 : 0);
    if (Math.abs(angle) > 0.0001) { p.rotate(explicitAngle ? -angle : angle, true, true, true, true, Transformation.CENTER); }
    b = p.geometricBounds;
    var a = doc.artboards[0].artboardRect;
    var targetLeft = a[0] + ANP_mm(cfg.margin + placement.x + Number(placement.offsetX || 0));
    var targetTop = a[1] - ANP_mm(cfg.margin + placement.y + Number(placement.offsetY || 0));
    p.translate(targetLeft - b[0], targetTop - b[1]);
    return p;
}

function ANP_canFastVectorDieV22(cfg, layout, shape) {
    /* Tròn/chữ nhật được dựng trực tiếp từ hình học cơ bản ở mọi số lượng.
       Cách này nhanh hơn hẳn tạo link rồi embed từng con và vẫn là vector thật. */
    return layout && layout.items && layout.items.length > 0 &&
        shape && (shape.isCircle === true || (shape.isRectangle === true && shape.points && shape.points.length <= 4));
}

function ANP_fastVectorShapeForSourcesV30(sources) {
    var first = sources && sources.length ? sources[0].shape : null, i, shape, kind;
    if (!first || !(first.isCircle === true || (first.isRectangle === true && first.points && first.points.length <= 4))) {
        return null;
    }
    kind = first.isCircle === true ? "circle" : "rectangle";
    for (i = 1; i < sources.length; i++) {
        shape = sources[i].shape;
        if (!shape || (kind === "circle" && shape.isCircle !== true) ||
            (kind === "rectangle" && !(shape.isRectangle === true && shape.points && shape.points.length <= 4))) {
            return null;
        }
    }
    return first;
}

function ANP_assertVectorDieV30(doc) {
    var linked = 0, symbols = 0;
    try { linked = doc.placedItems.length; } catch (e0) {}
    try { symbols = doc.symbolItems.length; } catch (e1) {}
    if (linked > 0 || symbols > 0) {
        throw new Error("FILE KHUÔN còn đối tượng Link/Symbol; đã dừng xuất để tránh lỗi máy bế.");
    }
    return true;
}

function ANP_compoundEllipseV24(compound, top, left, width, height) {
    var p = compound.pathItems.add(), cx = left + width / 2, cy = top - height / 2;
    var kx = width * 0.2761423749, ky = height * 0.2761423749, pts;
    p.setEntirePath([[cx, top], [left + width, cy], [cx, top - height], [left, cy]]);
    p.closed = true; pts = p.pathPoints;
    pts[0].leftDirection = [cx - kx, top]; pts[0].rightDirection = [cx + kx, top];
    pts[1].leftDirection = [left + width, cy + ky]; pts[1].rightDirection = [left + width, cy - ky];
    pts[2].leftDirection = [cx + kx, top - height]; pts[2].rightDirection = [cx - kx, top - height];
    pts[3].leftDirection = [left, cy - ky]; pts[3].rightDirection = [left, cy + ky];
    try {
        pts[0].pointType = PointType.SMOOTH; pts[1].pointType = PointType.SMOOTH;
        pts[2].pointType = PointType.SMOOTH; pts[3].pointType = PointType.SMOOTH;
    } catch (ePoint) {}
    return p;
}

function ANP_compoundRectangleV24(compound, top, left, width, height) {
    var p = compound.pathItems.add();
    p.setEntirePath([[left, top], [left + width, top], [left + width, top - height], [left, top - height]]);
    p.closed = true; return p;
}

function ANP_buildFastVectorDieV22(doc, layer, layout, cfg, shape) {
    var a = doc.artboards[0].artboardRect, color = ANP_dieProcessColorV21();
    var i, item, left, top, p, w, h, ultra = ANP_isUltraLightV24(cfg, layout), compound = null;
    ANP_prepareTargetLayerV28(doc, layer);
    if (ultra) { compound = layer.compoundPathItems.add(); }
    for (i = 0; i < layout.items.length; i++) {
        item = layout.items[i];
        left = a[0] + ANP_mm(Number(cfg.margin) + Number(item.x) + Number(item.offsetX || 0));
        top = a[1] - ANP_mm(Number(cfg.margin) + Number(item.y) + Number(item.offsetY || 0));
        w = ANP_mm(Number(item.w)); h = ANP_mm(Number(item.h));
        if (compound && shape.isCircle) {
            p = ANP_compoundEllipseV24(compound, top, left, w, h);
        } else if (compound) {
            p = ANP_compoundRectangleV24(compound, top, left, w, h);
        } else if (shape.isCircle) {
            p = layer.pathItems.ellipse(top, left, w, h);
        } else {
            p = layer.pathItems.rectangle(top, left, w, h);
        }
        if (!ultra) { p.name = "DIE_" + (i + 1); }
        ANP_normalizeDie(p, color);
    }
    if (compound) { compound.name = "KHUON_BE_COMPOUND_" + layout.items.length + "PCS"; }
    layer.visible = true;
    layer.name = (compound ? "KHUON_BE_COMPOUND_ULTRA_" : "KHUON_BE_VECTOR_FAST_") + layout.items.length + "PCS";
    ANP_removeDieSpotSwatchesV21(doc);
    return true;
}

function ANP_demiAddEdgeV25(buckets, axis, pos, start, end) {
    var rounded = Math.round(Number(pos) * 1000) / 1000;
    var key = axis + "_" + rounded, bucket = buckets[key];
    if (!bucket) { bucket = buckets[key] = { axis:axis, pos:rounded, ranges:[] }; }
    bucket.ranges.push({ start:Math.min(Number(start), Number(end)), end:Math.max(Number(start), Number(end)) });
}

function ANP_demiMergedV25(buckets, axis) {
    var out = [], key, bucket, ranges, i, current, next, tolerance = 0.002;
    for (key in buckets) {
        if (!buckets.hasOwnProperty(key)) { continue; }
        bucket = buckets[key]; if (bucket.axis !== axis) { continue; }
        ranges = bucket.ranges; ranges.sort(function (a, b) { return a.start - b.start; });
        if (!ranges.length) { continue; }
        current = { start:ranges[0].start, end:ranges[0].end };
        for (i = 1; i < ranges.length; i++) {
            next = ranges[i];
            if (next.start <= current.end + tolerance) { current.end = Math.max(current.end, next.end); }
            else { out.push({ pos:bucket.pos, start:current.start, end:current.end }); current = { start:next.start, end:next.end }; }
        }
        out.push({ pos:bucket.pos, start:current.start, end:current.end });
    }
    out.sort(function (a, b) { return a.pos - b.pos || a.start - b.start; });
    return out;
}

/* Dữ liệu thuần mm, dùng được cả khi test ngoài Illustrator. Các cạnh chung
   được hợp nhất, các đoạn thẳng kề nhau cũng gộp thành một nhát dao. */
function ANP_demiGridDataV25(layout, cfg) {
    var buckets = {}, items = layout.items || [], i, item, x1, x2, y1, y2;
    for (i = 0; i < items.length; i++) {
        item = items[i];
        x1 = Number(item.x) + Number(item.offsetX || 0); x2 = x1 + Number(item.w);
        y1 = Number(item.y) + Number(item.offsetY || 0); y2 = y1 + Number(item.h);
        ANP_demiAddEdgeV25(buckets, "V", x1, y1, y2); ANP_demiAddEdgeV25(buckets, "V", x2, y1, y2);
        ANP_demiAddEdgeV25(buckets, "H", y1, x1, x2); ANP_demiAddEdgeV25(buckets, "H", y2, x1, x2);
    }
    return { vertical:ANP_demiMergedV25(buckets, "V"), horizontal:ANP_demiMergedV25(buckets, "H"),
        extend:Math.max(0, Number(cfg.demiExtend) || 0) };
}

function ANP_demiLineV25(layer, points, color, name) {
    var p = layer.pathItems.add(); p.setEntirePath(points); p.closed = false;
    p.filled = false; p.stroked = true; p.strokeWidth = 0.25; p.strokeColor = color; p.name = name;
    try { p.strokeOverprint = true; } catch (e) {}
    return p;
}

function ANP_buildDemiGridV25(doc, layer, layout, cfg) {
    var data = ANP_demiGridDataV25(layout, cfg), a = doc.artboards[0].artboardRect;
    var color = ANP_dieProcessColorV21(), e = data.extend, i, s, x, y1, y2, y, x1, x2;
    /* Illustrator không cho thêm PathItem vào layer đang ẩn/khóa và báo
       “Target layer cannot be modified”. Lưới Demi chỉ có vài chục đường nên
       không cần ẩn layer trong lúc dựng. */
    ANP_prepareTargetLayerV28(doc, layer);
    for (i = 0; i < data.vertical.length; i++) {
        s = data.vertical[i]; x = a[0] + ANP_mm(Number(cfg.margin) + s.pos);
        y1 = a[1] - ANP_mm(Number(cfg.margin) + s.start - e);
        y2 = a[1] - ANP_mm(Number(cfg.margin) + s.end + e);
        ANP_demiLineV25(layer, [[x, y1], [x, y2]], color, "DEMI_V_" + (i + 1));
    }
    for (i = 0; i < data.horizontal.length; i++) {
        s = data.horizontal[i]; y = a[1] - ANP_mm(Number(cfg.margin) + s.pos);
        x1 = a[0] + ANP_mm(Number(cfg.margin) + s.start - e);
        x2 = a[0] + ANP_mm(Number(cfg.margin) + s.end + e);
        ANP_demiLineV25(layer, [[x1, y], [x2, y]], color, "DEMI_H_" + (i + 1));
    }
    layer.visible = true; layer.name = "KHUON_BE_DEMI_1_DAO_" + layout.items.length + "PCS";
    ANP_removeDieSpotSwatchesV21(doc);
    return { vertical:data.vertical.length, horizontal:data.horizontal.length };
}

function ANP_isWhiteColor(c) {
    try {
        if (c.typename === "SpotColor") {
            if (Number(c.tint) <= 0.1) { return true; }
            return c.spot && c.spot.color ? ANP_isWhiteColor(c.spot.color) : false;
        }
        if (c.typename === "CMYKColor") { return c.cyan < 1 && c.magenta < 1 && c.yellow < 1 && c.black < 1; }
        if (c.typename === "RGBColor") { return c.red > 250 && c.green > 250 && c.blue > 250; }
        if (c.typename === "GrayColor") { return c.gray < 1; }
    } catch (e) {}
    return false;
}

function ANP_makePonProcessBlack(item) {
    var i;
    try {
        if (item.typename === "PathItem") {
            if (item.stroked) { item.strokeColor = ANP_black(); }
            if (item.filled && !ANP_isWhiteColor(item.fillColor)) { item.fillColor = ANP_black(); }
            return;
        }
        if (item.typename === "CompoundPathItem") {
            for (i = 0; i < item.pathItems.length; i++) { ANP_makePonProcessBlack(item.pathItems[i]); }
            return;
        }
        if (item.typename === "GroupItem") {
            for (i = 0; i < item.pageItems.length; i++) { ANP_makePonProcessBlack(item.pageItems[i]); }
            return;
        }
        if (item.typename === "TextFrame") {
            item.textRange.characterAttributes.fillColor = ANP_black();
        }
    } catch (e) {}
}

function ANP_addCenteredTitle(layer, doc, cfg, title) {
    if (!cfg.addTitle || cfg.header < 5) { return; }
    ANP_prepareTargetLayerV28(doc, layer);
    var a = ANP_activeArtboardRectV61(doc), centerX = (a[0] + a[2]) / 2;
    var tf = layer.textFrames.add(), titleY;
    tf.contents = title; tf.textRange.characterAttributes.size = 7; tf.textRange.characterAttributes.fillColor = ANP_black();
    tf.name = "JOB_INFO_CENTER";
    titleY = a[1] - ANP_mm(Math.max(4, cfg.margin * 0.6));
    try { tf.textRange.paragraphAttributes.justification = Justification.CENTER; } catch (eJust) {}
    tf.position = [centerX, titleY];
    /* V5.8: Illustrator có phiên bản vẫn coi position của PointText là điểm
       bắt đầu dù Paragraph đặt CENTER. Dùng width đồng bộ của chính TextFrame
       để khóa tâm hình học vào tâm artboard; không app.redraw nên không làm
       chậm sheet có nhiều PlacedItem Link. */
    try { tf.left = centerX - Number(tf.width) / 2; } catch (eWidth) {
        try {
            var tb = tf.geometricBounds;
            tf.translate(centerX - (Number(tb[0]) + Number(tb[2])) / 2, 0);
        } catch (eBounds) {}
    }
}

function ANP_addPonV11(doc, cfg, title) {
    var layer = doc.layers.add(), a = doc.artboards[0].artboardRect, placed, loaded, f, i;
    layer.name = "PON_PROCESS_CMYK";
    ANP_prepareTargetLayerV28(doc, layer);
    if (cfg.ponPath) {
        f = new File(cfg.ponPath);
        if (!f.exists) { throw new Error("Không tìm thấy file PON: " + cfg.ponPath); }
        loaded = ANP_placeFileSafeV57(doc, layer, f, "PON_SOURCE", true); placed = loaded.item;
        /* V4.9: ExtendScript DOM là đồng bộ; width/height và embed không cần ép
           app.redraw(). Hai redraw này từng làm sheet nhiều Link đứng/lì hàng chục giây. */
        if (cfg.fitPon) { placed.width = a[2] - a[0]; placed.height = a[1] - a[3]; }
        placed.left = a[0] + ((a[2] - a[0]) - placed.width) / 2;
        placed.top = a[1] - ((a[1] - a[3]) - placed.height) / 2;
        placed.name = "PON_SOURCE";
        if (cfg.ponProcessBlack) {
            if (loaded.isPlaced) { placed.embed(); }
            ANP_unlockTreeV28(layer);
            for (i = 0; i < layer.pageItems.length; i++) { ANP_makePonProcessBlack(layer.pageItems[i]); }
        }
    } else if (cfg.autoPon) { ANP_addAutoPon(doc, layer, cfg); }
    ANP_addCenteredTitle(layer, doc, cfg, title);
    return layer;
}

/* V4.0: không được mặc định coi activeDocument là file nguồn. Sau một lần
   xuất, Illustrator thường đang đứng ở FILE IN vừa tạo; nếu bấm xuất lần nữa
   thì bản cũ lấy chính FILE IN (đã có PON) làm nguồn và PON bị nhân đôi. */
function ANP_normFsV40(value) {
    var s = String(value || "").replace(/\\/g, "/");
    try { if ($.os && String($.os).toLowerCase().indexOf("windows") >= 0) { s = s.toLowerCase(); } } catch (e) {}
    return s;
}

function ANP_docMatchesMetaV40(doc, meta) {
    var docPath = "", metaPath = ANP_normFsV40(meta && meta.path), docName = "";
    if (!doc || !meta) { return false; }
    try { docPath = ANP_normFsV40(ANP_docPath(doc)); } catch (e0) {}
    if (metaPath) { return !!docPath && docPath === metaPath; }
    try { docName = String(doc.name || ""); } catch (e1) {}
    if (meta.documentName) { return docName === String(meta.documentName); }
    /* File chưa save: chỉ tin manualDoc nếu nó đúng object đã ghi nhận. */
    try { if (ANP_STATE.manualDoc === doc) { return true; } } catch (e2) {}
    return false;
}

function ANP_sourceDocForMeta(meta, originalDoc) {
    var doc, f;
    if (meta.active && ANP_docMatchesMetaV40(originalDoc, meta)) { return { doc: originalDoc, opened: false }; }
    if (meta.path) {
        f = new File(meta.path); if (!f.exists) { throw new Error("Không tìm thấy file nguồn: " + meta.path); }
        doc = ANP_findOpenDoc(f.fsName);
        if (doc) { return { doc: doc, opened: false }; }
        return { doc: app.open(f), opened: true };
    }
    /* Nguồn chưa lưu nhưng vẫn còn mở: tìm đúng documentName, không dùng FILE IN đang active. */
    if (meta.documentName) {
        var i;
        for (i = 0; i < app.documents.length; i++) {
            try { if (String(app.documents[i].name) === String(meta.documentName)) { return { doc: app.documents[i], opened: false }; } } catch (e3) {}
        }
    }
    throw new Error("Không xác định được file nguồn gốc. Hãy quay lại file thiết kế và bấm ‘Lấy file đang mở’ lần nữa.");
}

function ANP_v11Build(json) {
    var printDoc = null, dieDoc = null, currentOpened = null, perf = ANP_perfStartV48();
    try {
        var cfg = ANP_parse(json), originalDoc = app.documents.length ? app.activeDocument : null;
        var cropOnly = cfg.finishCropMarks === true;
        var includeDie = !cropOnly && String(cfg.outputMode || "both") !== "print_only";
        if (!originalDoc && cfg.sources.length && cfg.sources[0].active) { throw new Error("File nguồn đang mở không còn tồn tại."); }
        if (!cfg.outputPath) { throw new Error("Chế độ Link cần chọn thư mục xuất để lưu các file liên kết."); }
        var out = new Folder(cfg.outputPath); if (!out.exists) { throw new Error("Thư mục xuất không tồn tại."); }
        var layout = ANP_layoutV11(cfg), jobBase = ANP_safeBase(cfg.sources.length === 1 ?
            cfg.sources[0].name : (cfg.jobName || "GHEP_" + cfg.sources.length + "_MAU"));
        ANP_perfMarkV48(perf, layout.precomputedV99 === true ? "01. Layout Cache V99 STABLE · không chạy solver Illustrator" : "01. Tính bố cục / True-Shape");

        var linkFolder = ANP_uniqueFolder(out, jobBase + "_LINK_FILES");
        var links = [], used = [], i, s, holder;
        for (i = 0; i < layout.items.length; i++) { used[layout.items[i].sourceIndex] = true; }
        for (s = 0; s < cfg.sources.length; s++) {
            if (!used[s]) { continue; }
            cfg.sources[s]._linkIndex = s;
            holder = ANP_sourceDocForMeta(cfg.sources[s], originalDoc); currentOpened = holder.opened ? holder.doc : null;
            links[s] = ANP_createLinkPair(holder.doc, cfg.sources[s], cfg, linkFolder);
            if (holder.opened) { holder.doc.close(SaveOptions.DONOTSAVECHANGES); currentOpened = null; }
        }
        ANP_perfMarkV48(perf, "02. Tạo PRINT-LINK / DIE-LINK nguồn");

        /* Không ép artwork in sang CMYK. */
        printDoc = ANP_newDoc(ANP_printColorSpaceV23(cfg, links, used), cfg, "FILE_IN_LINKED");
        dieDoc = includeDie ? ANP_newDoc(DocumentColorSpace.CMYK, cfg, "FILE_KHUON_VECTOR_CMYK") : null;
        var printLayer = printDoc.layers[0], dieLayer = dieDoc ? dieDoc.layers[0] : null, item, rotated = 0;
        ANP_perfMarkV48(perf, cropOnly ? "03. Tạo document FILE IN CATTP" : (includeDie ? "03. Tạo document FILE IN + KHUÔN" : "03. Tạo document chỉ FILE IN"));

        var printMasters = [], dieVectorMasters = [];
        var useSymbols = false; /* V4.8 giữ policy V4.7: FILE IN luôn là PlacedItem Link riêng. */
        var ultraLight = false;
        var demiDie = cfg.demiMode === true;
        var fastVectorShape = ANP_fastVectorShapeForSourcesV30(cfg.sources);
        var fastVectorDie = includeDie && !demiDie && ANP_canFastVectorDieV22(cfg, layout, fastVectorShape);
        for (s = 0; s < cfg.sources.length; s++) {
            if (!used[s]) { continue; }
            printMasters[s] = ANP_linkMaster(printDoc, printLayer, links[s].printPath, "__PRINT_LINK_MASTER_" + s);
            if (includeDie && !fastVectorDie && !demiDie) {
                dieVectorMasters[s] = (links[s].dieGeometry && links[s].dieGeometry.paths && links[s].dieGeometry.paths.length) ?
                    ANP_makeVectorDieMasterFromGeometryV55(dieDoc, links[s].dieGeometry, s) :
                    ANP_makeVectorDieMasterV45(dieDoc, links[s].diePath, s);
            }
        }
        ANP_prepareTargetLayerV28(printDoc, printLayer);
        if (dieLayer) { ANP_prepareTargetLayerV28(dieDoc, dieLayer); }
        ANP_perfMarkV48(perf, "04. Chuẩn bị Link Master + Vector Master");

        /* V4.9: batch các hàng/cột lặp bằng Group duplicate. Mỗi tem con vẫn là
           PlacedItem Link riêng; chỉ giảm số lần gọi DOM duplicate trực tiếp. */
        var linkBuildStatsV49 = ANP_buildIndividualLinksBatchV49(printDoc, printLayer, printMasters, layout, cfg, links);
        rotated = linkBuildStatsV49.rotated;
        ANP_perfMarkV48(perf, "05. Dựng FILE IN - Batch Link riêng V4.9");

        if (includeDie) {
            if (demiDie) {
                ANP_buildDemiGridV25(dieDoc, dieLayer, layout, cfg);
            } else if (fastVectorDie) {
                ANP_buildFastVectorDieV22(dieDoc, dieLayer, layout, cfg, fastVectorShape);
            } else {
                for (i = 0; i < layout.items.length; i++) {
                    item = layout.items[i];
                    ANP_placeVectorDieMasterV45(dieDoc, dieLayer, dieVectorMasters[item.sourceIndex].group, item, cfg,
                        "DIE_" + (i + 1) + "_" + ANP_safeBase(cfg.sources[item.sourceIndex].name));
                }
            }
        }
        ANP_perfMarkV48(perf, includeDie ? "06. Dựng KHUÔN stroke vector" : "06. Bỏ qua FILE KHUÔN theo lựa chọn");

        for (s = 0; s < cfg.sources.length; s++) {
            try { if (printMasters[s]) { printMasters[s].remove(); } } catch (eMaster1) {}
            try { if (dieVectorMasters[s]) { ANP_removeVectorMasterV45(dieVectorMasters[s]); } } catch (eMaster2) {}
        }
        printLayer.visible = true; if (dieLayer) { dieLayer.visible = true; }
        printLayer.name = "FILE_IN_INDIVIDUAL_LINKS_V47_" + layout.count + "PCS";
        ANP_assertIndividualPrintLinksV47(printDoc, layout.count);
        if (dieLayer && !fastVectorDie && !demiDie) { dieLayer.name = "KHUON_BE_VECTOR_MASTER_V45_" + layout.count + "PCS"; }
        if (dieLayer) { ANP_assertStrokeVectorLayerV37(dieLayer); }
        ANP_perfMarkV48(perf, "07. Dọn Master + kiểm tra Link/Vector");

        var exactCenterFix = includeDie ? ANP_exactCenterPairV36(printDoc, printLayer, dieDoc, dieLayer) :
            ANP_exactCenterSingleV36(printDoc, printLayer);
        ANP_perfMarkV48(perf, includeDie ? "08. Center Exact FILE IN + KHUÔN" : "08. Center Exact FILE IN");

        var outputTitles = ANP_v11OutputTitlesV29(cfg, layout, jobBase);
        var printOutputFolder = ANP_ensureOutputFolderV31(out, "FILE IN");
        var dieOutputFolder = printOutputFolder;
        var pf = ANP_uniquePdfFileV29(printOutputFolder, outputTitles.print);
        var df = includeDie ? ANP_uniquePdfFileV29(dieOutputFolder, outputTitles.die) : null;
        outputTitles.print = ANP_pdfTitleFromFileV29(pf);
        ANP_perfMarkV48(perf, "09. Chuẩn bị tên file + thư mục xuất");

        var ponCacheV50 = null;
        if (cfg.ponPath) { ponCacheV50 = ANP_makePonCacheV50(cfg, linkFolder); }
        ANP_perfMarkV48(perf, "10A. Chuẩn bị PON Cache K100 4 góc V5.0");

        var printPonLayerV56;
        if (ponCacheV50) { printPonLayerV56 = ANP_addPonCacheV50(printDoc, cfg, ponCacheV50, outputTitles.print, false); }
        else { printPonLayerV56 = ANP_addPonV12(printDoc, cfg, outputTitles.print, false); }
        ANP_addFinishCropMarksV56(printDoc, printPonLayerV56, layout, cfg, exactCenterFix);
        ANP_perfMarkV48(perf, "10B. Gắn PON cache + tiêu đề FILE IN");

        /* V5.1: PON cache chỉ dùng cho FILE IN nặng. FILE KHUÔN bắt buộc
           không được chứa PlacedItem/Symbol, vì vậy dựng PON vector trực tiếp
           bằng pipeline V12 trên dieDoc nhẹ. Cách này vẫn nhanh và đảm bảo
           đầu ra máy bế chỉ còn vector thật. */
        if (includeDie) {
            var diePonLayerV56 = ANP_addPonV12(dieDoc, cfg, "", true);
            ANP_addFinishCropMarksV56(dieDoc, diePonLayerV56, layout, cfg, exactCenterFix);
            ANP_assertVectorDieV30(dieDoc);
        }
        ANP_perfMarkV48(perf, includeDie ? "11. Gắn PON VECTOR + kiểm tra FILE KHUÔN" : "11. Hoàn tất PON FILE IN");

        ANP_savePDFDefault(printDoc, pf, cfg.preservePrintColor !== false);
        ANP_perfMarkV48(perf, "12. Lưu PDF FILE IN");

        if (includeDie) { ANP_savePDFDefault(dieDoc, df, false); }
        ANP_perfMarkV48(perf, includeDie ? "13. Lưu PDF FILE KHUÔN" : "13. Không xuất FILE KHUÔN");

        try {
            if (cfg.sources && cfg.sources.length && cfg.sources[0].active) {
                var sourceReturn = ANP_sourceDocForMeta(cfg.sources[0], originalDoc);
                if (sourceReturn && sourceReturn.doc) { sourceReturn.doc.activate(); }
            } else if (originalDoc && !(String(originalDoc.name || "").indexOf("FILE_IN") === 0)) {
                originalDoc.activate();
            }
        } catch (eFocus) {}
        ANP_perfMarkV48(perf, "14. Hoàn tất / trả focus Illustrator");
        var performanceV48 = ANP_perfFinishV48(perf);
        if (performanceV48) { performanceV48.buildStats = linkBuildStatsV49; }
        return ANP_ok({
            count: layout.count, rotated: rotated, normal: layout.count - rotated,
            skipped: layout.skipped ? layout.skipped.length : 0,
            saved: true, printFileCount:1, dieFileCount:includeDie ? 1 : 0, cattp:cropOnly,
            printPath: pf.fsName, diePath: df ? df.fsName : "", linkFolder: linkFolder.fsName,
            printFolder: printOutputFolder.fsName, dieFolder: dieOutputFolder.fsName,
            ultraLight: ultraLight, centerExact:true,
            centerCorrectionXmm:ANP_round(ANP_toMm(exactCenterFix.dx || 0), 3),
            centerCorrectionYmm:ANP_round(ANP_toMm(exactCenterFix.dy || 0), 3),
            performance:performanceV48, layoutCachedV99:layout.precomputedV99 === true, layoutCachedV97:layout.precomputedV97 === true
        });
    } catch (e) {
        try { if (currentOpened) { currentOpened.close(SaveOptions.DONOTSAVECHANGES); } } catch (e0) {}
        return ANP_perfFailV48(e, perf);
    }
}

/* ========================================================================== */
/* v1.2 ARTBOARD BATCH + SIZE GROUP OUTPUT                                    */
/* ========================================================================== */

function ANP_sourceItemsAtArtboard(doc, artboardIndex) {
    var previous = doc.artboards.getActiveArtboardIndex();
    doc.artboards.setActiveArtboardIndex(artboardIndex);
    var result = ANP_sourceItems(doc, "artboard");
    doc.artboards.setActiveArtboardIndex(previous);
    return result;
}

function ANP_dieForArtboard(doc, artboardIndex, hint) {
    var source = ANP_sourceItemsAtArtboard(doc, artboardIndex);
    var a = doc.artboards[artboardIndex].artboardRect;
    var candidates = ANP_autoDie(source, hint || "", a);
    var aw = a[2] - a[0], ah = a[1] - a[3], valid = [], i, b, cx, cy, area, best = null, bestArea = -1;
    for (i = 0; i < candidates.length; i++) {
        try {
            b = candidates[i].geometricBounds; cx = (b[0] + b[2]) / 2; cy = (b[1] + b[3]) / 2;
            if (cx < a[0] || cx > a[2] || cy > a[1] || cy < a[3]) { continue; }
            if ((b[2] - b[0]) > aw * 1.1 || (b[1] - b[3]) > ah * 1.1) { continue; }
            area = (b[2] - b[0]) * (b[1] - b[3]);
            if (area > bestArea) { best = candidates[i]; bestArea = area; }
        } catch (e) {}
    }
    if (best) { valid.push(best); }
    return valid;
}

function ANP_dieMatchesArtboardV64(bounds, artboardRect) {
    var tolerance = ANP_mm(0.5);
    if (!bounds || !artboardRect) { return false; }
    return Math.abs(Number(bounds[0]) - Number(artboardRect[0])) <= tolerance &&
        Math.abs(Number(bounds[1]) - Number(artboardRect[1])) <= tolerance &&
        Math.abs(Number(bounds[2]) - Number(artboardRect[2])) <= tolerance &&
        Math.abs(Number(bounds[3]) - Number(artboardRect[3])) <= tolerance;
}

function ANP_listArtboardsV12(hint) {
    try {
        if (!app.documents.length) { throw new Error("Chưa mở file nhiều artboard trong Illustrator."); }
        var doc = app.activeDocument, list = [], i, die, b, a, fallback, shape, artboardRect;
        for (i = 0; i < doc.artboards.length; i++) {
            a = doc.artboards[i]; artboardRect = a.artboardRect;
            die = ANP_dieForArtboard(doc, i, hint || ""); b = ANP_bounds(die);
            fallback = !ANP_dieMatchesArtboardV64(b, artboardRect);
            /* Kích thước thành phẩm của chế độ Chọn artboard LUÔN lấy từ
               artboardRect. Dieline/bleed nằm tràn ra ngoài không được phép làm
               artboard 105x148 biến thành 109x152. */
            shape = fallback ? ANP_shapeFromDieV20([], artboardRect) : ANP_shapeFromDieV20(die, b);
            list.push({
                artboardIndex: i, displayIndex: i + 1, name: a.name || ("Artboard " + (i + 1)),
                width: ANP_round(ANP_toMm(artboardRect[2] - artboardRect[0]), 2),
                height: ANP_round(ANP_toMm(artboardRect[1] - artboardRect[3]), 2),
                dieFallback: fallback, useArtboardBounds:true, selected: true, shape: shape
            });
        }
        return ANP_ok({ documentName: doc.name, artboards: list });
    } catch (e) { return ANP_fail(e); }
}

function ANP_groupArtboardsV12(artboards) {
    var groups = [], i, j, a, found;
    for (i = 0; i < artboards.length; i++) {
        a = artboards[i]; found = null;
        for (j = 0; j < groups.length; j++) {
            if (Math.abs(Number(groups[j].width) - Number(a.width)) <= 0.05 &&
                Math.abs(Number(groups[j].height) - Number(a.height)) <= 0.05 &&
                (!a.shape || !groups[j].shape || a.shape.signature === groups[j].shape.signature)) { found = groups[j]; break; }
        }
        if (!found) {
            found = { groupNumber: groups.length + 1, width: Number(a.width), height: Number(a.height), shape: a.shape || null, artboards: [] };
            groups.push(found);
        }
        found.artboards.push(a);
    }
    return groups;
}

function ANP_trueAnglesV20(step) {
    var out = [], a, s = Math.max(5, Math.min(90, Number(step) || 15));
    for (a = 0; a < 360; a += s) { out.push(a); }
    if (out[out.length - 1] !== 90 && 90 % s !== 0) { out.push(90); }
    if (out[out.length - 1] !== 180 && 180 % s !== 0) { out.push(180); }
    return out;
}

function ANP_shapeAxisSymmetricV64(shape, axis) {
    var points = shape && shape.points ? shape.points : [], w = Number(shape && shape.w), h = Number(shape && shape.h);
    var tolerance = Math.max(0.15, Math.min(Math.max(w, 0.15), Math.max(h, 0.15)) * 0.015);
    var i, j, tx, ty, found;
    if (points.length < 3 || !isFinite(w) || !isFinite(h)) { return false; }
    for (i = 0; i < points.length; i++) {
        tx = axis === "x" ? w - Number(points[i].x) : Number(points[i].x);
        ty = axis === "y" ? h - Number(points[i].y) : Number(points[i].y);
        found = false;
        for (j = 0; j < points.length; j++) {
            if (Math.abs(Number(points[j].x) - tx) <= tolerance &&
                Math.abs(Number(points[j].y) - ty) <= tolerance) { found = true; break; }
        }
        if (!found) { return false; }
    }
    return true;
}

function ANP_smartAnglesV64(cfg, shape) {
    if (cfg.allowRotate === false) { return [0]; }
    if (cfg.fastMode !== true) { return ANP_trueAnglesV20(cfg.angleStep); }
    if (shape && shape.isCircle === true) { return [0]; }
    /* Khuôn vòm/D đối xứng chỉ có bốn hướng có ý nghĩa. Giảm 72 lượt thử
       (bước 5°) xuống 4 mà vẫn giữ đủ phương án khóa so le 0/90/180/270. */
    if (ANP_shapeAxisSymmetricV64(shape, "x") || ANP_shapeAxisSymmetricV64(shape, "y")) {
        return [0, 90, 180, 270];
    }
    return [0, 45, 90, 135, 180, 225, 270, 315];
}

function ANP_cachedArtboardLayoutV1483(cfg, w, h, shape) {
    /* V148.4 CACHE HARDENED:
       Do NOT route a per-group artboard cache through ANP_cachedLayoutV99.
       That generic cache validator assumes a full source list and on some
       Illustrator/ExtendScript builds can throw the opaque Safari-style
       "undefined is not an object" before the native solver fallback runs.
       Convert the compact group cache directly and validate every field. */
    var list = null, i, j, e, c, sig, out, src, it;
    try { list = cfg ? cfg.precomputedArtboardLayoutsV1483 : null; } catch (eList) { list = null; }
    if (!list || typeof list.length === "undefined" || Number(list.length) < 1) { return null; }
    sig = String(shape && shape.signature || "");
    for (i = 0; i < Number(list.length); i++) {
        try { e = list[i]; } catch (eEntry) { e = null; }
        if (!e) { continue; }
        try { c = e.layout; } catch (eLayout) { c = null; }
        if (!c || !c.items || typeof c.items.length === "undefined" || Number(c.items.length) < 1) { continue; }
        if (Math.abs(Number(e.width) - Number(w)) > 0.05 || Math.abs(Number(e.height) - Number(h)) > 0.05) { continue; }
        if (sig && String(e.shapeSignature || "") && sig !== String(e.shapeSignature || "")) { continue; }
        out = {items:[], count:0, binW:Number(c.binW), binH:Number(c.binH), method:String(c.method || "artboard-cache-v1484"),
            efficiency:Number(c.efficiency || 0), edgeRelaxX:Number(c.edgeRelaxX || 0), edgeRelaxY:Number(c.edgeRelaxY || 0),
            edgeOptimized:c.edgeOptimized === true, cornerSafe:c.cornerSafe === true, cornerClear:Number(c.cornerClear || 0),
            skipped:[], precomputedV99:true, precomputedArtboardV1483:true, cacheHardenedV1484:true};
        for (j = 0; j < Number(c.items.length); j++) {
            try { src = c.items[j]; } catch (eItemRead) { src = null; }
            if (!src) { out = null; break; }
            if (!isFinite(Number(src.x)) || !isFinite(Number(src.y)) || !isFinite(Number(src.w)) || !isFinite(Number(src.h))) { out = null; break; }
            it = {x:Number(src.x), y:Number(src.y), w:Number(src.w), h:Number(src.h),
                rotated:src.rotated === true, offsetX:Number(src.offsetX || 0), offsetY:Number(src.offsetY || 0),
                sourceIndex:0, copyIndex:Number(src.copyIndex == null ? j : src.copyIndex)};
            if (src.angleExplicit === true || (src.angle !== undefined && src.angle !== null && isFinite(Number(src.angle)))) {
                it.angle = Number(src.angle || 0);
            }
            out.items.push(it);
        }
        if (!out || !out.items.length) { continue; }
        out.count = out.items.length;
        if (!(out.binW > 0)) { out.binW = Number(cfg.paperW) - Number(cfg.margin) * 2; }
        if (!(out.binH > 0)) { out.binH = Number(cfg.paperH) - Number(cfg.margin) * 2; }
        if (!(out.binW > 0) || !(out.binH > 0)) { continue; }
        /* Keep the cached layout inside the hard printable bin. */
        var minX=1e30,minY=1e30,maxX=-1e30,maxY=-1e30,dx=0,dy=0,tol=0.002;
        for (j=0;j<out.items.length;j++) { it=out.items[j]; minX=Math.min(minX,it.x); minY=Math.min(minY,it.y); maxX=Math.max(maxX,it.x+it.w); maxY=Math.max(maxY,it.y+it.h); }
        if (maxX-minX > out.binW+tol || maxY-minY > out.binH+tol) { continue; }
        if (minX < 0) { dx=-minX; } if (maxX+dx > out.binW) { dx += out.binW-(maxX+dx); }
        if (minY < 0) { dy=-minY; } if (maxY+dy > out.binH) { dy += out.binH-(maxY+dy); }
        if (Math.abs(dx)>0.000001 || Math.abs(dy)>0.000001) { for (j=0;j<out.items.length;j++) { out.items[j].x += dx; out.items[j].y += dy; } }
        return out;
    }
    return null;
}

function ANP_artboardLayoutV12(cfg, w, h, shape) {
    var cachedGroupV1483 = null, cachedV99 = null, cacheErrorV1484 = null;
    try { cachedGroupV1483 = ANP_cachedArtboardLayoutV1483(cfg, w, h, shape); }
    catch (eCacheV1484) { cacheErrorV1484 = eCacheV1484; cachedGroupV1483 = null; }
    if (cachedGroupV1483 && cachedGroupV1483.items && cachedGroupV1483.items.length) { return cachedGroupV1483; }

    /* A global V99 cache is valid for file/manual mode only. Mixed artboards
       use one cache per group. Never let a stale global cache kill the artboard
       pipeline before its guarded solver/fallback can run. */
    if (!cfg || String(cfg.mode || "") !== "artboards") {
        try { cachedV99 = ANP_cachedLayoutV99(cfg, w, h); } catch (eGlobalCacheV1484) { cacheErrorV1484 = eGlobalCacheV1484; cachedV99 = null; }
        if (cachedV99) { return cachedV99; }
        if (cfg && cfg.layoutCacheRequiredV99 === true) { throw new Error("V99 chặn chạy solver nặng trong Illustrator vì Layout Cache không khớp kích thước khuôn. Hãy bấm Tính nhanh lại."); }
    }

    var binW = Number(cfg.paperW) - Number(cfg.margin) * 2, binH = Number(cfg.paperH) - Number(cfg.margin) * 2;
    var layout = null, solverError = null, fallbackError = null;
    if (!(binW > 0) || !(binH > 0)) { throw new Error("Vùng dàn không hợp lệ cho nhóm " + w + "x" + h + " mm."); }
    if (cfg.demiMode === true && shape && shape.isRectangle !== true) {
        throw new Error("Bế 1 dao Demi chỉ dùng cho KHUON_BE hình chữ nhật cạnh thẳng.");
    }
    try { layout = ANP_equalLayoutV21(cfg, w, h, shape, binW, binH, Number(cfg.maxQty) || 0); }
    catch (eSolver) { solverError = eSolver; layout = null; }

    /* Hard fallback: conservative bounding-box packing. */
    if (!layout || !layout.items || !layout.items.length) {
        try {
            layout = ANP_equalCandidateV21(cfg, w, h, null, binW, binH, Number(cfg.maxQty) || 0);
            layout = ANP_applyCornerSafeLayoutV30(layout, cfg, binW, binH);
            if (layout) { layout.fallbackRectV1484 = true; }
        } catch (eFallback) { fallbackError = eFallback; layout = null; }
    }
    if (!layout || !layout.items || !layout.items.length) {
        throw new Error("Không tạo được bố cục nhóm " + w + "x" + h + " mm" +
            (cacheErrorV1484 ? " | Cache: " + String(cacheErrorV1484 && cacheErrorV1484.message ? cacheErrorV1484.message : cacheErrorV1484) : "") +
            (solverError ? " | Solver: " + String(solverError && solverError.message ? solverError.message : solverError) : "") +
            (fallbackError ? " | Fallback: " + String(fallbackError && fallbackError.message ? fallbackError.message : fallbackError) : "") + ".");
    }
    layout.binW = Number(binW); layout.binH = Number(binH); layout.count = layout.items.length;
    ANP_centerLayoutV16(layout, binW, binH);
    layout.cacheRecoveredV1484 = cacheErrorV1484 ? true : false;
    return layout;
}

/* V64: in CATTP hai mặt dùng đúng một bố cục. Quy tắc AB chuẩn giữ nguyên
   tọa độ từng con và chỉ bù góc mặt B theo góc mặt A; tuyệt đối không mirror. */
function ANP_validateDuplexV60(cfg, selected, groups) {
    if (cfg.duplexMode !== true) { return false; }
    if (cfg.finishCropMarks !== true) { throw new Error("In 2 mặt chỉ dùng với PON cắt theo thành phẩm."); }
    if (!selected || selected.length !== 2) {
        throw new Error("In 2 mặt cần chọn đúng 2 artboard: mặt trước rồi mặt sau.");
    }
    groups = groups || ANP_groupArtboardsV12(selected);
    if (groups.length !== 1 || groups[0].artboards.length !== 2) {
        throw new Error("Hai artboard in 2 mặt phải cùng kích thước thành phẩm.");
    }
    return true;
}

function ANP_duplexLayoutV60(layout, cfg, isBack) {
    var out = {}, key, i, source, item, sourceAngle, flip = String(cfg.duplexFlip || "abComplementary");
    /* Phòng trường hợp một caller cũ gọi thẳng hàm bố cục mà chưa đi qua
       ANP_parse: vẫn chuẩn hoá tên chế độ cũ về tên hiện hành.
       V66 FIX: "vertical"/"tumble180" TRƯỚC ĐÂY bị gộp nhầm vào
       "abComplementary" (khiến con không xoay — vd. khuôn vuông góc 0° —
       thì mặt B giữ y hệt mặt A, không "đối đầu ngược lại" như yêu cầu).
       Từ V66, "tumble180" là chế độ riêng: mặt B giữ nguyên vị trí từng con
       nhưng LUÔN xoay thêm 180° so với mặt A, bất kể góc gốc là bao nhiêu. */
    if (flip === "vertical") { flip = "tumble180"; }
    if (flip === "horizontal") { flip = "turnSide"; }
    if (flip !== "abComplementary" && flip !== "turnSide" && flip !== "tumble180") { flip = "abComplementary"; }
    var binW = Number(layout && layout.binW), binH = Number(layout && layout.binH);
    if (!isFinite(binW) || binW <= 0) { binW = Number(cfg.paperW) - Number(cfg.margin) * 2; }
    if (!isFinite(binH) || binH <= 0) { binH = Number(cfg.paperH) - Number(cfg.margin) * 2; }
    if (!isFinite(binW) || !isFinite(binH) || binW <= 0 || binH <= 0) {
        throw new Error("Không xác định được vùng dàn AB. Hãy kiểm tra khổ in và lề 4 cạnh.");
    }
    for (key in layout) { if (layout.hasOwnProperty(key) && key !== "items") { out[key] = layout[key]; } }
    out.binW = binW; out.binH = binH;
    out.items = [];
    for (i = 0; i < layout.items.length; i++) {
        source = layout.items[i]; item = {};
        for (key in source) { if (source.hasOwnProperty(key)) { item[key] = source[key]; } }
        if (isBack && flip === "abComplementary") {
            /* V126 DUPLEX MIRROR FIX:
               Mặt B phải phản vị trí theo trục ngang của tờ khi lật cạnh:
               A bên TRÁI -> B cùng record bên PHẢI, A bên PHẢI -> B bên TRÁI.
               Đồng thời vẫn giữ quy tắc góc bù: 0->0, 90->270, 270->90.
               Đây là cặp A/B sản xuất đúng khi nhìn từng mặt theo chiều đọc.
               V65 FIX: ANP_placeTemplate chỉ đảo dấu góc khi item có "angle"
               tường minh (quy ước Y-down của engine vs Y-up của Illustrator).
               Với item chỉ có cờ "rotated" (không có "angle" tường minh —
               đúng trường hợp khuôn chữ nhật dẹt xoay 90/270 do packer thường
               tạo ra), mặt trước KHÔNG bị đảo dấu khi dựng hình. Vì hàm này
               luôn gán "angle" tường minh cho mặt sau (nên mặt sau LUÔN bị
               đảo dấu khi dựng hình), nếu mặt trước vốn không tường minh thì
               phải giữ nguyên dấu góc bù (không đảo lần nữa), nếu không hai
               lần đảo dấu sẽ triệt tiêu nhau và mặt sau xoay giống hệt mặt
               trước thay vì bù ngược lại — đây là lỗi "xoay sai hướng" với
               khuôn chữ nhật 90/270 độ. */
            item.x = binW - (Number(source.x) + Number(source.w));
            item.y = Number(source.y);
            item.offsetX = -Number(source.offsetX || 0);
            item.offsetY = Number(source.offsetY || 0);
            var sourceAngleWasExplicit = source.angle !== undefined;
            sourceAngle = sourceAngleWasExplicit ? Number(source.angle) : (source.rotated ? 90 : 0);
            item.angle = sourceAngleWasExplicit
                ? (((-sourceAngle) % 360 + 360) % 360)
                : ((sourceAngle % 360 + 360) % 360);
        } else if (isBack && flip === "turnSide") {
            item.x = binW - (Number(source.x) + Number(source.w));
            item.offsetX = -Number(source.offsetX || 0);
        } else if (isBack && flip === "tumble180") {
            /* V128 DUPLEX PHYSICAL MIRROR:
               Khi lật tờ sang mặt B, vị trí vật lý bắt buộc phản theo trục X:
               A1 bên trái -> B1 bên phải, A bên phải -> B bên trái.
               V126 chỉ phản X ở abComplementary/turnSide nên chế độ mặc định
               tumble180 vẫn giữ B1 bên trái. V128 sửa dứt điểm: tumble180 cũng
               mirror X, nhưng vẫn giữ quy tắc xoay đối đầu 180° của chế độ này.
               source.w/source.h ở Layout V101 là kích thước chiếm chỗ sau xoay,
               nên công thức binW-(x+w) phản đúng tâm cell cho cả 0° và 90°. */
            item.x = binW - (Number(source.x) + Number(source.w));
            item.y = Number(source.y);
            item.offsetX = -Number(source.offsetX || 0);
            item.offsetY = Number(source.offsetY || 0);
            var tumbleAngleWasExplicit = source.angle !== undefined;
            sourceAngle = tumbleAngleWasExplicit ? Number(source.angle) : (source.rotated ? 90 : 0);
            item.angle = tumbleAngleWasExplicit
                ? (((sourceAngle - 180) % 360 + 360) % 360)
                : (((-sourceAngle - 180) % 360 + 360) % 360);
        }
        if (!isFinite(Number(item.x)) || !isFinite(Number(item.y)) ||
            !isFinite(Number(item.w)) || !isFinite(Number(item.h))) {
            throw new Error("Tọa độ dàn AB không hợp lệ tại con số " + (i + 1) + ".");
        }
        out.items.push(item);
    }
    out.duplex = true; out.duplexBack = isBack === true; out.duplexFlip = flip;
    out.duplexBackRotation = 0;
    out.duplexAngleRule = flip === "abComplementary" ? "mirror-x-plus-inverse-front-angle" :
        flip === "tumble180" ? "opposite-180-every-item" : "legacy-turn-side";
    out.count = out.items.length;
    return out;
}

/* Tạo tài liệu xem trước chỉ có khuôn bế, không lưu/không xuất file. */
function ANP_v14DiePreview(json) {
    var sourceDoc = null, previousArtboard = 0, temp = null, previewDoc = null;
    try {
        var cfg = ANP_parse(json), selected = cfg.artboards || [];
        if (!app.documents.length) { throw new Error("Chưa mở file nguồn trong Illustrator."); }
        sourceDoc = app.activeDocument; previousArtboard = sourceDoc.artboards.getActiveArtboardIndex();
        if (!selected.length && cfg.sources && cfg.sources.length === 1 && cfg.sources[0].active) {
            selected = [{ artboardIndex: previousArtboard,
                name: sourceDoc.artboards[previousArtboard].name || ("Artboard " + (previousArtboard + 1)),
                width: Number(cfg.sources[0].width), height: Number(cfg.sources[0].height),
                shape:cfg.sources[0].shape || null }];
        }
        if (!selected.length) { throw new Error("Hãy chọn một file đang mở hoặc các artboard cần xem trước khuôn."); }
        var groups = ANP_groupArtboardsV12(selected), g, i, meta, die, bounds, layout;
        var made = [], layer, template, inst, dieColor, rect, a, symbol, useSymbols, fastVectorPreview,
            dieGeometry, vectorMaster, directGeometryPreview, ponLayerV56, centerFixV56;
        for (g = 0; g < groups.length; g++) {
            meta = groups[g].artboards[0]; sourceDoc.activate();
            sourceDoc.artboards.setActiveArtboardIndex(Number(meta.artboardIndex));
            die = ANP_dieForArtboard(sourceDoc, Number(meta.artboardIndex), cfg.dieHint || "");
            bounds = ANP_bounds(die); a = sourceDoc.artboards[Number(meta.artboardIndex)].artboardRect;
            /* V97: đọc geometry trực tiếp. Không tạo temp layer/duplicate khuôn trên
               file nguồn nếu geometry đã đọc được — tránh Illustrator redraw và lag. */
            template = null; temp = null;
            dieGeometry = ANP_dieGeometryV55(die, bounds, groups[g].width, groups[g].height);
            if ((!dieGeometry || !dieGeometry.paths.length) && !die.length) {
                /* V147.8.4: không có KHUON_BE => bounds=null. Fallback phải lấy
                   artboardRect hiện tại (a), không được dereference bounds rỗng. */
                dieGeometry = ANP_rectangleDieGeometryV55(a, groups[g].width, groups[g].height);
            }
            try { layout = ANP_artboardLayoutV12(cfg, groups[g].width, groups[g].height, groups[g].shape); } catch (eLayoutDieV1484) { throw new Error("Die Preview nhóm " + groups[g].groupNumber + " [" + groups[g].width + "x" + groups[g].height + "mm] layout lỗi: " + String(eLayoutDieV1484 && eLayoutDieV1484.message ? eLayoutDieV1484.message : eLayoutDieV1484)); }
            previewDoc = ANP_newDoc(DocumentColorSpace.CMYK, cfg, "XEM_TRUOC_KHUON_" + groups[g].groupNumber);
            layer = previewDoc.layers[0]; layer.name = "KHUON_BE_PREVIEW_" + layout.items.length + "PCS";
            dieColor = ANP_dieProcessColorV21();
            cfg.itemW = groups[g].width; cfg.itemH = groups[g].height;
            fastVectorPreview = cfg.demiMode === true || ANP_canFastVectorDieV22(cfg, layout, groups[g].shape);
            symbol = null; vectorMaster = null; directGeometryPreview = false;
            if (cfg.demiMode === true) {
                ANP_buildDemiGridV25(previewDoc, layer, layout, cfg);
            } else if (fastVectorPreview) {
                ANP_buildFastVectorDieV22(previewDoc, layer, layout, cfg, groups[g].shape);
            } else if (dieGeometry && dieGeometry.paths && dieGeometry.paths.length) {
                vectorMaster = ANP_makeVectorDieMasterFromGeometryV55(previewDoc, dieGeometry, "PREVIEW_" + g);
                for (i = 0; i < layout.items.length; i++) {
                    ANP_placeVectorDieMasterV45(previewDoc, layer, vectorMaster.group, layout.items[i], cfg, "DIE_PREVIEW_" + (i + 1));
                }
                ANP_removeVectorMasterV45(vectorMaster); vectorMaster = null;
                layer.name = "KHUON_BE_PREVIEW_GEOMETRY_V55_" + layout.items.length + "PCS";
                directGeometryPreview = true;
            } else {
                /* Chỉ fallback sang template khi thật sự không đọc được geometry. */
                temp = sourceDoc.layers.add(); temp.name = "__ANP_PREVIEW_TEMP__";
                template = temp.groupItems.add(); template.name = "DIE_PREVIEW_TEMPLATE";
                if (die.length) { for (i = 0; i < die.length; i++) { die[i].duplicate(template, ElementPlacement.PLACEATEND); } }
                else { bounds = a; rect = template.pathItems.rectangle(a[1], a[0], a[2]-a[0], a[1]-a[3]); rect.filled=false; rect.stroked=true; rect.strokeWidth=0.25; }
                ANP_addReference(template, bounds);
                useSymbols = cfg.fastMode === true && layout.items.length >= 120;
                symbol = useSymbols ? ANP_makeTemplateSymbolV22(previewDoc, layer, template,
                    "ANP_DIE_PREVIEW_FAST_SYMBOL", dieColor) : null;
                ANP_prepareTargetLayerV28(previewDoc, layer);
                for (i = 0; i < layout.items.length; i++) {
                    if (symbol) {
                        ANP_placeTemplateSymbolV22(previewDoc, layer, symbol, layout.items[i], cfg, "DIE_PREVIEW_" + (i + 1));
                    } else {
                        inst = ANP_placeTemplate(template, layer, layout.items[i], cfg, previewDoc.artboards[0].artboardRect);
                        ANP_normalizeDie(inst, dieColor); inst.name = "DIE_PREVIEW_" + (i + 1);
                    }
                }
                layer.visible = true;
            }
            if (!fastVectorPreview && !directGeometryPreview) {
                layer.name = "KHUON_BE_PREVIEW_DIRTY";
                layer = ANP_finalizeDieStrokeVectorsV37(previewDoc, layer);
            }
            ANP_assertStrokeVectorLayerV37(layer);
            centerFixV56 = ANP_exactCenterSingleV36(previewDoc, layer);
            ponLayerV56 = ANP_addPonV12(previewDoc, cfg, "", true);
            ANP_addFinishCropMarksV56(previewDoc, ponLayerV56, layout, cfg, centerFixV56);
            ANP_removeDieSpotSwatchesV21(previewDoc);
            if (temp) { temp.remove(); temp = null; }
            made.push({ groupNumber: groups[g].groupNumber, count: layout.items.length,
                width: groups[g].width, height: groups[g].height,
                fastPreview:fastVectorPreview || directGeometryPreview || symbol !== null, demi:cfg.demiMode === true,
                ultraLight:ANP_isUltraLightV24(cfg, layout) });
        }
        sourceDoc.artboards.setActiveArtboardIndex(previousArtboard);
        if (previewDoc) { previewDoc.activate(); }
        return ANP_ok({ groupCount: made.length, groups: made, saved: false, layoutCachedV99:!!(cfg.precomputedLayoutV99), layoutCachedV97:!!(cfg.precomputedLayoutV97) });
    } catch (e) {
        try { if (vectorMaster) { ANP_removeVectorMasterV45(vectorMaster); } } catch (eMaster) {}
        try { if (temp) { temp.remove(); } } catch (e0) {}
        try { if (sourceDoc) { sourceDoc.artboards.setActiveArtboardIndex(previousArtboard); } } catch (e1) {}
        return ANP_fail(e);
    }
}

/* Xem trực tiếp khuôn nhập bằng kích thước thủ công. Không cần file nguồn,
   không lưu file và chỉ tạo KHUON_BE Process CMYK cùng PON bốn góc. */
function ANP_v15ManualDiePreview(json) {
    var previewDoc = null, stage = "đọc cấu hình";
    try {
        var cfg = ANP_parse(json), sources = cfg.sources || [];
        if (!sources.length) { throw new Error("Chưa có kích thước tem thủ công."); }
        var source = sources[0], shape = source.shape, layout, layer, ponLayer = null, centerFixV56 = {dx:0,dy:0};
        if (!shape || (!shape.isCircle && !shape.isRectangle)) {
            throw new Error("Xem trực tiếp chỉ nhận tem tròn hoặc tem chữ nhật nhập thủ công.");
        }
        if (cfg.demiMode === true && shape.isCircle === true) {
            throw new Error("Tem tròn không dùng chế độ bế 1 dao Demi.");
        }

        /* V130 MANUAL PREVIEW CACHE FIX:
           Không chạy solver ExtendScript lần hai cho chế độ nhập kích thước.
           UI đã tính chính xác layout bằng Core V101 khi người dùng nhập W/H.
           Dùng đúng cache x/y/w/h đó để Preview AI vừa nhanh vừa tránh lỗi
           'undefined is not an object' của nhánh solver cũ trên một số AI 2024-2026. */
        stage = "đọc Layout Cache V101";
        layout = ANP_cachedLayoutV99(cfg, Number(source.width), Number(source.height));
        if (!layout || !layout.items || !layout.items.length) {
            throw new Error("Thiếu Layout Cache cho kích thước thủ công. Hãy bấm ‘Tính nhanh trên DPV®’ rồi View khuôn lại.");
        }

        stage = "tạo document preview";
        previewDoc = ANP_newDoc(DocumentColorSpace.CMYK, cfg, "XEM_TRUOC_KHUON_THU_CONG");
        if (!previewDoc || !previewDoc.layers || !previewDoc.layers.length) {
            throw new Error("Illustrator không tạo được document preview.");
        }
        layer = previewDoc.layers[0];
        cfg.itemW = Number(source.width); cfg.itemH = Number(source.height);

        stage = "dựng khuôn vector";
        if (cfg.demiMode === true) {
            ANP_buildDemiGridV25(previewDoc, layer, layout, cfg);
        } else {
            ANP_buildFastVectorDieV22(previewDoc, layer, layout, cfg, shape);
        }
        layer.name = "KHUON_BE_PREVIEW_" + layout.items.length + "PCS";

        /* Center là bước phụ. Preview thủ công phải mở được ngay cả khi một
           phiên bản Illustrator trả bounds chậm/khác cho CompoundPath. */
        stage = "căn giữa khuôn";
        try { centerFixV56 = ANP_exactCenterSingleV36(previewDoc, layer); }
        catch (eCenterV130) { centerFixV56 = {dx:0,dy:0}; }

        stage = "dựng PON";
        if (cfg.ponPath || cfg.autoPon === true) {
            ponLayer = ANP_addPonV12(previewDoc, cfg, "", true);
            if (ponLayer) { ponLayer.name = "PON"; }
        }

        stage = "dựng PON cắt thành phẩm";
        if (cfg.finishCropMarks === true && ponLayer) {
            ANP_addFinishCropMarksV56(previewDoc, ponLayer, layout, cfg, centerFixV56);
        }
        ANP_removeDieSpotSwatchesV21(previewDoc);
        previewDoc.activate();
        return ANP_ok({ count:layout.items.length, method:layout.method, saved:false,
            manual:true, shape:shape.isCircle ? "circle" : "rectangle",
            layoutCache:true, previewEngine:"V130_MANUAL_CACHE",
            ultraLight:ANP_isUltraLightV24(cfg, layout) });
    } catch (e) {
        try { if (previewDoc) { previewDoc.close(SaveOptions.DONOTSAVECHANGES); } } catch (e0) {}
        return ANP_fail(new Error("V130 Manual Preview · " + stage + ": " + (e && e.message ? e.message : String(e))));
    }
}

function ANP_v12Preview(json) {
    try {
        var cfg = ANP_parse(json), groups = ANP_groupArtboardsV12(cfg.artboards || []), out = [], i, layout;
        if (!groups.length) { throw new Error("Chưa chọn artboard nào."); }
        ANP_validateDuplexV60(cfg, cfg.artboards || [], groups);
        for (i = 0; i < groups.length; i++) {
            try { layout = ANP_artboardLayoutV12(cfg, groups[i].width, groups[i].height, groups[i].shape); } catch (eLayoutV1484) { throw new Error("Nhóm " + groups[i].groupNumber + " [" + groups[i].width + "x" + groups[i].height + "mm] tính layout lỗi: " + String(eLayoutV1484 && eLayoutV1484.message ? eLayoutV1484.message : eLayoutV1484)); }
            out.push({
                groupNumber: groups[i].groupNumber, width: groups[i].width, height: groups[i].height,
                printFiles: groups[i].artboards.length, dieFiles: cfg.finishCropMarks === true ? 0 : 1, countPerSheet: layout.items.length,
                method: layout.method, edgeOptimized: layout.edgeOptimized === true,
                edgeMarginX: Number(cfg.margin) - Number(layout.edgeRelaxX || 0),
                edgeMarginY: Number(cfg.margin) - Number(layout.edgeRelaxY || 0),
                ultraLight: ANP_isUltraLightV24(cfg, layout)
            });
        }
        return ANP_ok({ groups: out, groupCount: groups.length,
            printFileCount:cfg.duplexMode === true ? 1 : cfg.artboards.length,
            pageCount:cfg.duplexMode === true ? 2 : cfg.artboards.length,
            dieFileCount:cfg.finishCropMarks === true ? 0 : groups.length, cattp:cfg.finishCropMarks === true,
            duplex:cfg.duplexMode === true, duplexFlip:cfg.duplexFlip });
    } catch (e) { return ANP_fail(e); }
}

function ANP_sendLayerBottom(doc, layer) {
    ANP_prepareTargetLayerV28(doc, layer);
    try {
        if (doc.layers.length > 1) { layer.move(doc.layers[doc.layers.length - 1], ElementPlacement.PLACEAFTER); }
    } catch (e) {
        try { layer.zOrder(ZOrderMethod.SENDTOBACK); } catch (e2) {}
    }
}

function ANP_removeGeneratedPonLayersV40(doc) {
    var i, layer;
    try {
        for (i = doc.layers.length - 1; i >= 0; i--) {
            layer = doc.layers[i];
            try {
                if (ANP_isGeneratedPonLayerNameV40(layer.name)) {
                    layer.locked = false; layer.visible = true; layer.remove();
                }
            } catch (e0) {}
        }
    } catch (e1) {}
}


/* ========================================================================== */
/* V5.1 FAST PON CACHE + DIE VECTOR FIX                                                        */
/*                                                                            */
/* Bottleneck đo thật ở V4.9: thêm PON vào FILE IN có nhiều PlacedItem Link   */
/* làm Illustrator mất ~20s vì phải embed + duyệt/recolor/prune PON ngay trên */
/* document nặng. V5.0 xử lý PON đúng 1 lần trong document tạm cực nhẹ, lưu   */
/* thành PDF vector K100 4 góc, rồi chỉ PLACE cache đó vào FILE IN/KHUÔN.     */
/* Output PDF vẫn vector; không raster, không làm thay đổi từng Print Link.   */
/* ========================================================================== */
function ANP_makePonCacheV50(cfg, folder) {
    var src, cacheFile, tempDoc = null, layer, placed, loaded, a, i, base;
    if (!cfg || !cfg.ponPath) { return null; }
    src = new File(cfg.ponPath);
    if (!src.exists) { throw new Error("Không tìm thấy file PON: " + cfg.ponPath); }
    base = "__DPV_PON_CACHE_V50_" + ANP_safeBase(src.name) + "_" +
        String(cfg.paperW).replace(/[^0-9\.]/g, "_") + "x" + String(cfg.paperH).replace(/[^0-9\.]/g, "_");
    cacheFile = new File(folder.fsName + "/" + base + ".pdf");
    try {
        tempDoc = ANP_newDoc(DocumentColorSpace.CMYK, cfg, "PON_CACHE_V50");
        layer = tempDoc.layers[0]; layer.name = "PON_CACHE_V50";
        ANP_prepareTargetLayerV28(tempDoc, layer);
        a = tempDoc.artboards[0].artboardRect;
        loaded = ANP_placeFileSafeV57(tempDoc, layer, src, "PON_SOURCE_CACHE_V57", true);
        placed = loaded.item;
        if (cfg.fitPon) {
            placed.width = a[2] - a[0];
            placed.height = a[1] - a[3];
        }
        placed.left = a[0] + ((a[2] - a[0]) - placed.width) / 2;
        placed.top = a[1] - ((a[1] - a[3]) - placed.height) / 2;
        placed.name = "PON_SOURCE_CACHE_V50";

        /* Chỉ embed/recolor/prune ở document tạm nhẹ, tuyệt đối không làm việc
           này trên FILE IN có 50–500 linked artwork. */
        if (loaded.isPlaced) { placed.embed(); }
        ANP_unlockTreeV28(layer);
        for (i = 0; i < layer.pageItems.length; i++) { ANP_makePonProcessBlack(layer.pageItems[i]); }
        ANP_cleanPonCornersV15(tempDoc, layer);
        ANP_recolorCornerPonV56(tempDoc, layer, cfg);

        /* PDF cache giữ nguyên vector và dùng artboard làm crop box, nhờ đó khi
           đặt vào output chỉ cần scale 1 lần theo artboard, không cần embed. */
        ANP_savePDFDefault(tempDoc, cacheFile, false);
        tempDoc.close(SaveOptions.DONOTSAVECHANGES); tempDoc = null;
        return cacheFile;
    } catch (e) {
        try { if (tempDoc) { tempDoc.close(SaveOptions.DONOTSAVECHANGES); } } catch (eClose) {}
        throw e;
    }
}

function ANP_addPonCacheV50(doc, cfg, cacheFile, title, omitTitle) {
    var layer, placed, a, titleLayer;
    if (!cacheFile || !cacheFile.exists) { return ANP_addPonV12(doc, cfg, title, omitTitle); }
    ANP_removeGeneratedPonLayersV40(doc);
    layer = doc.layers.add(); layer.name = "PON";
    ANP_prepareTargetLayerV28(doc, layer);
    a = doc.artboards[0].artboardRect;
    placed = ANP_placeFileSafeV57(doc, layer, cacheFile, "PON_CACHE_LINK_V57", true).item;
    /* Cache PDF có cùng artboard với output. Ép đúng kích thước để tránh khác
       PDF crop preference giữa các máy Illustrator, nhưng không embed. */
    placed.width = a[2] - a[0];
    placed.height = a[1] - a[3];
    placed.left = a[0];
    placed.top = a[1];
    placed.name = "PON_CACHE_LINK_V50";
    ANP_sendLayerBottom(doc, layer);
    if (!omitTitle && cfg.addTitle && cfg.header >= 5) {
        titleLayer = doc.layers.add(); titleLayer.name = "TIEU_DE";
        ANP_addCenteredTitle(titleLayer, doc, cfg, title);
    }
    return layer;
}

function ANP_addPonV12(doc, cfg, title, omitTitle) {
    var oldAddTitle = cfg.addTitle, oldBlack = cfg.ponProcessBlack, titleLayer;
    /* Idempotent: dù hàm bị gọi lại, một document chỉ có đúng 1 bộ PON. */
    ANP_removeGeneratedPonLayersV40(doc);
    cfg.addTitle = false; cfg.ponProcessBlack = true;
    var layer = ANP_addPonV11(doc, cfg, "");
    cfg.addTitle = oldAddTitle; cfg.ponProcessBlack = oldBlack;
    layer.name = "PON";
    ANP_cleanPonCornersV15(doc, layer);
    ANP_recolorCornerPonV56(doc, layer, cfg);
    ANP_sendLayerBottom(doc, layer);
    if (!omitTitle && oldAddTitle && cfg.header >= 5) {
        titleLayer = doc.layers.add(); titleLayer.name = "TIEU_DE";
        ANP_addCenteredTitle(titleLayer, doc, cfg, title);
    }
    return layer;
}

function ANP_isCornerBoundsV15(b, a, zonePt) {
    var cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
    var nearX = Math.min(Math.abs(cx - a[0]), Math.abs(cx - a[2])) <= zonePt;
    var nearY = Math.min(Math.abs(cy - a[1]), Math.abs(cy - a[3])) <= zonePt;
    return nearX && nearY;
}

function ANP_visiblePonItemV15(item) {
    var i, p;
    try {
        if (item.typename === "PathItem") {
            return !item.clipping && ((item.stroked && Number(item.strokeWidth) > 0) || item.filled);
        }
        if (item.typename === "CompoundPathItem") {
            for (i = 0; i < item.pathItems.length; i++) {
                p = item.pathItems[i];
                if (!p.clipping && ((p.stroked && Number(p.strokeWidth) > 0) || p.filled)) { return true; }
            }
        }
    } catch (e) {}
    return false;
}

function ANP_prunePonContainerV15(container, artRect, zonePt) {
    var i, item;
    for (i = container.pageItems.length - 1; i >= 0; i--) {
        item = container.pageItems[i];
        try {
            if (item.typename === "GroupItem") {
                ANP_prunePonContainerV15(item, artRect, zonePt);
                if (!item.pageItems.length) { item.remove(); }
            } else if (item.typename === "PathItem" || item.typename === "CompoundPathItem") {
                if (!ANP_visiblePonItemV15(item) || !ANP_isCornerBoundsV15(item.geometricBounds, artRect, zonePt)) { item.remove(); }
            } else {
                item.remove();
            }
        } catch (e0) { try { item.remove(); } catch (e1) {} }
    }
}

function ANP_cleanPonCornersV15(doc, layer) {
    var a = doc.artboards[0].artboardRect;
    ANP_prepareTargetLayerV28(doc, layer);
    ANP_unlockTreeV28(layer);
    ANP_prunePonContainerV15(layer, a, ANP_mm(35));
    layer.name = "PON_4_GOC";
    return layer;
}

/* V56 — PON GÓC ĐỎ + PON CẮT THÀNH PHẨM
   Chỉ đổi các nét hở của dấu L ở bốn góc sang Process Red C0 M100 Y100 K0.
   Chấm tròn đăng ký là path kín/fill nên luôn giữ Process K100. */
function ANP_recolorCornerPonItemV56(item, artRect, color) {
    var i, b, w, h, ratio, pointCount, looksRegistrationDot;
    try {
        if (item.typename === "PathItem") {
            b = item.geometricBounds;
            w = Math.abs(Number(b[2]) - Number(b[0])); h = Math.abs(Number(b[1]) - Number(b[3]));
            ratio = Math.min(w, h) / Math.max(0.001, Math.max(w, h));
            try { pointCount = item.pathPoints.length; } catch (ePoints) { pointCount = 0; }
            looksRegistrationDot = item.closed === true && ratio >= 0.72 && pointCount > 0 && pointCount <= 8;
            if (!item.clipping && !looksRegistrationDot &&
                ANP_isCornerBoundsV15(b, artRect, ANP_mm(14))) {
                if (item.stroked) { item.strokeColor = color; }
                if (item.filled && !ANP_isWhiteColor(item.fillColor)) { item.fillColor = color; }
            }
            return;
        }
        if (item.typename === "CompoundPathItem") {
            for (i = 0; i < item.pathItems.length; i++) {
                ANP_recolorCornerPonItemV56(item.pathItems[i], artRect, color);
            }
            return;
        }
        if (item.typename === "GroupItem" || item.typename === "Layer") {
            for (i = 0; i < item.pageItems.length; i++) {
                ANP_recolorCornerPonItemV56(item.pageItems[i], artRect, color);
            }
        }
    } catch (e) {}
}

function ANP_recolorCornerPonV56(doc, layer, cfg) {
    var i;
    if (!cfg || cfg.cornerPonRed !== true || !doc || !layer) { return layer; }
    ANP_prepareTargetLayerV28(doc, layer); ANP_unlockTreeV28(layer);
    for (i = 0; i < layer.pageItems.length; i++) {
        ANP_recolorCornerPonItemV56(layer.pageItems[i], doc.artboards[0].artboardRect, ANP_dieProcessColorV21());
    }
    return layer;
}

function ANP_axisUniqueV56(values, tolerance) {
    var copy = values.slice(0), out = [], i, v, tol = Math.max(0.0001, Number(tolerance) || 0.05);
    copy.sort(function (a, b) { return Number(a) - Number(b); });
    for (i = 0; i < copy.length; i++) {
        v = Number(copy[i]);
        if (!out.length || Math.abs(v - out[out.length - 1]) > tol) { out.push(v); }
    }
    return out;
}

function ANP_finishCropSubtractV59(start, end, blockers, tolerance, mergeTolerance) {
    var tol = Math.max(0.0001, Number(tolerance) || 0.05), clips = [], out = [];
    /* V70 FIX: mergeTolerance (mac dinh = tol neu khong truyen) dung de "bac
       cau" qua cac khe ho NHO giua nhieu vat can lien ke (vi du khe gapY
       binh thuong giua cac con TRONG CHINH cot/hang xoay 90 do, khi cot do
       ghep voi cot khac co so hang/cao do khac nhau - kieu "mixed-columns").
       Neu khong bac cau, moi khe ho noi bo rat nho do bi hieu nham la "thieu
       vat lieu" va sinh them mot vet PON con giua 2 cot, de len FILE IN du
       do chi la khoang cach gapY/gapX binh thuong, khong phai bien that can
       cat. Cac doan lech that su (vi du dau/cuoi 2 cot khong bang nhau) van
       lon hon han mergeTolerance nen van duoc giu nguyen PON nhu yeu cau. */
    var mtol = Math.max(tol, Number(mergeTolerance) || tol);
    var i, b, cursor, merged = [];
    for (i = 0; i < blockers.length; i++) {
        b = [Math.max(start, Number(blockers[i][0])), Math.min(end, Number(blockers[i][1]))];
        if (b[1] > b[0] + tol) { clips.push(b); }
    }
    clips.sort(function (a, b2) { return a[0] - b2[0]; });
    for (i = 0; i < clips.length; i++) {
        b = clips[i];
        if (!merged.length || b[0] > merged[merged.length - 1][1] + mtol) { merged.push([b[0], b[1]]); }
        else { merged[merged.length - 1][1] = Math.max(merged[merged.length - 1][1], b[1]); }
    }
    cursor = start;
    for (i = 0; i < merged.length; i++) {
        if (merged[i][0] > cursor + mtol) { out.push([cursor, merged[i][0]]); }
        cursor = Math.max(cursor, merged[i][1]);
    }
    if (end > cursor + mtol) { out.push([cursor, end]); }
    return out;
}

function ANP_finishCropAddMarkV59(list, x, y, tolerance) {
    var i, tol = Math.max(0.0001, Number(tolerance) || 0.05);
    for (i = 0; i < list.length; i++) {
        if (Math.abs(Number(list[i].x) - Number(x)) <= tol &&
            Math.abs(Number(list[i].y) - Number(y)) <= tol) { return; }
    }
    list.push({ x:Number(x), y:Number(y) });
}

function ANP_finishCropAddSegmentsV59(list, segments, fixed, horizontal, tolerance) {
    var i;
    for (i = 0; i < segments.length; i++) {
        if (horizontal) {
            ANP_finishCropAddMarkV59(list, segments[i][0], fixed, tolerance);
            ANP_finishCropAddMarkV59(list, segments[i][1], fixed, tolerance);
        } else {
            ANP_finishCropAddMarkV59(list, fixed, segments[i][0], tolerance);
            ANP_finishCropAddMarkV59(list, fixed, segments[i][1], tolerance);
        }
    }
}

/* V5.9: dựng PON từ toàn bộ đường bao bậc thang của bố cục, không chỉ bốn
   cạnh cực trị. Khoảng hở hàng/cột được xem như một mối ghép nên không sinh
   PON vào giữa các tem; riêng các đoạn biên sole/protrusion vẫn được giữ đủ. */
function ANP_finishCropAdjacentLimitV69(baseGap, tol, dimA, dimB) {
    /* V69 FIX: bài ghép nhiều khổ/nhiều size khác nhau trên cùng 1 tờ có thể
       có khe hở thực tế giữa các con của khổ phụ KHÁC với cfg.gapX/gapY
       (vốn chỉ đúng cho khổ chính). Nếu chỉ so với đúng gapX/gapY cấu hình,
       khe hở thực nhưng lớn hơn cấu hình sẽ bị hiểu nhầm là "không liền kề"
       và sinh nhầm PON vào giữa ruột — đúng lỗi PON kẻ ngang giữa các con
       xếp chồng trong một cột hẹp khác kích thước. Nới thêm tối đa 20% cạnh
       ngắn hơn của 2 ô (đủ để bắt khe hở lệch cấu hình, vẫn nhỏ hơn nhiều so
       với khoảng cách thật giữa 2 nhóm khác nhau) làm ngưỡng "liền kề". Biên
       ngoài cùng của cả bài dàn không bị ảnh hưởng vì đã có bước bảo đảm
       riêng (V68) chạy sau, không phụ thuộc kết quả nhận diện liền kề này. */
    return Math.max(baseGap, tol + 0.2 * Math.max(0, Math.min(dimA, dimB)));
}

function ANP_finishCropDataV56(layout, cfg) {
    var items = layout && layout.items ? layout.items : [], margin = Number(cfg && cfg.margin) || 0;
    var boxes = [], minX = 1e20, minY = 1e20, maxX = -1e20, maxY = -1e20;
    var topX = [], bottomX = [], leftY = [], rightY = [];
    var topMarks = [], bottomMarks = [], leftMarks = [], rightMarks = [];
    var i, j, item, box, other, blockers, segments, gap, tol = 0.3, limit;
    var gapX = Math.max(0, Number(cfg && cfg.gapX) || 0) + tol;
    var gapY = Math.max(0, Number(cfg && cfg.gapY) || 0) + tol;
    for (i = 0; i < items.length; i++) {
        item = items[i];
        /* x/y là bounding-box thành phẩm sau xoay. Không cộng offset lần nữa,
           nếu không PON cắt thành phẩm sẽ lệch khỏi khuôn True-Shape. */
        box = {
            left:margin + Number(item.x || 0),
            top:margin + Number(item.y || 0)
        };
        box.right = box.left + Number(item.w || 0);
        box.bottom = box.top + Number(item.h || 0);
        if (!(box.right > box.left) || !(box.bottom > box.top)) { continue; }
        boxes.push(box);
        minX = Math.min(minX, box.left); minY = Math.min(minY, box.top);
        maxX = Math.max(maxX, box.right); maxY = Math.max(maxY, box.bottom);
    }
    if (!boxes.length) {
        return { left:0, top:0, right:0, bottom:0, boxes:[], topX:[], bottomX:[], leftY:[], rightY:[],
            topMarks:[], bottomMarks:[], leftMarks:[], rightMarks:[] };
    }
    for (i = 0; i < boxes.length; i++) {
        box = boxes[i];
        blockers = [];
        for (j = 0; j < boxes.length; j++) { if (j !== i) {
            other = boxes[j]; gap = box.top - other.bottom;
            limit = ANP_finishCropAdjacentLimitV69(gapY, tol, box.bottom - box.top, other.bottom - other.top);
            if (gap >= -tol && gap <= limit) { blockers.push([other.left, other.right]); }
        } }
        segments = ANP_finishCropSubtractV59(box.left, box.right, blockers, tol, gapX);
        ANP_finishCropAddSegmentsV59(topMarks, segments, box.top, true, tol);

        blockers = [];
        for (j = 0; j < boxes.length; j++) { if (j !== i) {
            other = boxes[j]; gap = other.top - box.bottom;
            limit = ANP_finishCropAdjacentLimitV69(gapY, tol, box.bottom - box.top, other.bottom - other.top);
            if (gap >= -tol && gap <= limit) { blockers.push([other.left, other.right]); }
        } }
        segments = ANP_finishCropSubtractV59(box.left, box.right, blockers, tol, gapX);
        ANP_finishCropAddSegmentsV59(bottomMarks, segments, box.bottom, true, tol);

        blockers = [];
        for (j = 0; j < boxes.length; j++) { if (j !== i) {
            other = boxes[j]; gap = box.left - other.right;
            limit = ANP_finishCropAdjacentLimitV69(gapX, tol, box.right - box.left, other.right - other.left);
            if (gap >= -tol && gap <= limit) { blockers.push([other.top, other.bottom]); }
        } }
        segments = ANP_finishCropSubtractV59(box.top, box.bottom, blockers, tol, gapY);
        ANP_finishCropAddSegmentsV59(leftMarks, segments, box.left, false, tol);

        blockers = [];
        for (j = 0; j < boxes.length; j++) { if (j !== i) {
            other = boxes[j]; gap = other.left - box.right;
            limit = ANP_finishCropAdjacentLimitV69(gapX, tol, box.right - box.left, other.right - other.left);
            if (gap >= -tol && gap <= limit) { blockers.push([other.top, other.bottom]); }
        } }
        segments = ANP_finishCropSubtractV59(box.top, box.bottom, blockers, tol, gapY);
        ANP_finishCropAddSegmentsV59(rightMarks, segments, box.right, false, tol);
    }
    /* V68 FIX: đảm bảo 4 phía ngoài cùng của cả bài dàn (biên trên/dưới/
       trái/phải tuyệt đối, tức box chạm minY/maxY/minX/maxX) LUÔN có đủ 2
       điểm pon cắt (trái+phải với biên trên/dưới, trên+dưới với biên
       trái/phải) — không phụ thuộc kết quả loại-bỏ-đoạn-liền-kề ở trên.
       Layout trộn cỡ ô (cột hẹp/cao xen cột rộng/thấp — kiểu ảnh người
       dùng báo lỗi) có thể khiến thuật toán che-đoạn phía trên tính sai
       lệch nhỏ do khác chiều cao dòng, làm rớt mất pon ở đúng góc ngoài.
       Thêm hẳn (union, có dedupe qua ANP_finishCropAddMarkV59) để không
       bao giờ thiếu pon ở 4 phía ngoài, trong khi pon ở ruột (giữa các ô
       liền kề nội bộ) vẫn bị ẩn như cũ vì các box không chạm biên ngoài
       không bị đụng tới ở đây. */
    for (i = 0; i < boxes.length; i++) {
        box = boxes[i];
        if (Math.abs(box.top - minY) <= tol) {
            ANP_finishCropAddMarkV59(topMarks, box.left, box.top, tol);
            ANP_finishCropAddMarkV59(topMarks, box.right, box.top, tol);
        }
        if (Math.abs(box.bottom - maxY) <= tol) {
            ANP_finishCropAddMarkV59(bottomMarks, box.left, box.bottom, tol);
            ANP_finishCropAddMarkV59(bottomMarks, box.right, box.bottom, tol);
        }
        if (Math.abs(box.left - minX) <= tol) {
            ANP_finishCropAddMarkV59(leftMarks, box.left, box.top, tol);
            ANP_finishCropAddMarkV59(leftMarks, box.left, box.bottom, tol);
        }
        if (Math.abs(box.right - maxX) <= tol) {
            ANP_finishCropAddMarkV59(rightMarks, box.right, box.top, tol);
            ANP_finishCropAddMarkV59(rightMarks, box.right, box.bottom, tol);
        }
    }
    for (i = 0; i < topMarks.length; i++) { if (Math.abs(topMarks[i].y - minY) <= tol) { topX.push(topMarks[i].x); } }
    for (i = 0; i < bottomMarks.length; i++) { if (Math.abs(bottomMarks[i].y - maxY) <= tol) { bottomX.push(bottomMarks[i].x); } }
    for (i = 0; i < leftMarks.length; i++) { if (Math.abs(leftMarks[i].x - minX) <= tol) { leftY.push(leftMarks[i].y); } }
    for (i = 0; i < rightMarks.length; i++) { if (Math.abs(rightMarks[i].x - maxX) <= tol) { rightY.push(rightMarks[i].y); } }
    return {
        left:minX, top:minY, right:maxX, bottom:maxY, boxes:boxes,
        topX:ANP_axisUniqueV56(topX, tol), bottomX:ANP_axisUniqueV56(bottomX, tol),
        leftY:ANP_axisUniqueV56(leftY, tol), rightY:ANP_axisUniqueV56(rightY, tol),
        topMarks:topMarks, bottomMarks:bottomMarks, leftMarks:leftMarks, rightMarks:rightMarks
    };
}

function ANP_finishCropLineV56(layer, x1, y1, x2, y2, name) {
    var p = ANP_line(layer, x1, y1, x2, y2, ANP_black(), 0.25, name);
    try { p.strokeOverprint = true; } catch (e) {}
    return p;
}

function ANP_finishCropVerticalTickHitsV70(boxes, x, y0, y1, tol) {
    /* V70 FIX: kiểm tra "va chạm" trước khi vẽ tick DỌC (PON trên/dưới, tại
       một x cố định, kéo dài theo y). Trục x là một điểm (không co giãn),
       trục y là đoạn tick thật (co nhẹ 2 đầu bằng tol để không tự đụng nếu
       chạm đúng biên do sai số làm tròn). Dùng "b.left<=x && b.right>=x" để
       vẫn bắt đúng trường hợp mép con hàng xóm nằm SÁT ĐÚNG tại x (biên
       chung giữa 2 cột) — vì trong layout trộn cỡ (cột cao/thấp xen nhau),
       một tick hợp lệ vẫn có thể rơi đúng vào vật liệu của con hàng xóm đã
       có mặt sớm hơn ở đúng vị trí đó; khi đó thà bỏ tick còn hơn đè lên
       FILE IN. */
    var i, b, top = Math.min(y0, y1) + tol, bot = Math.max(y0, y1) - tol;
    if (bot <= top) { bot = top + 0.001; }
    for (i = 0; i < boxes.length; i++) {
        b = boxes[i];
        if (b.left <= x && b.right >= x && b.top < bot && b.bottom > top) { return true; }
    }
    return false;
}

function ANP_finishCropHorizontalTickHitsV70(boxes, y, x0, x1, tol) {
    /* Tương tự ANP_finishCropVerticalTickHitsV70 nhưng cho tick NGANG
       (PON trái/phải, tại một y cố định, kéo dài theo x). */
    var i, b, lo = Math.min(x0, x1) + tol, hi = Math.max(x0, x1) - tol;
    if (hi <= lo) { hi = lo + 0.001; }
    for (i = 0; i < boxes.length; i++) {
        b = boxes[i];
        if (b.top <= y && b.bottom >= y && b.left < hi && b.right > lo) { return true; }
    }
    return false;
}

function ANP_addFinishCropMarksV56(doc, ponLayer, layout, cfg, centerFix) {
    if (!cfg || cfg.finishCropMarks !== true || !ponLayer || !layout || !layout.items || !layout.items.length) {
        return 0;
    }
    var data = ANP_finishCropDataV56(layout, cfg), a = ANP_activeArtboardRectV61(doc);
    var lenMM = Math.max(0.1, Number(cfg.finishMarkLength) || 6);
    var gapMM = Math.max(0, Number(cfg.finishMarkGap) || 0);
    var len = ANP_mm(lenMM);
    var gap = ANP_mm(gapMM);
    var dx = Number(centerFix && centerFix.dx) || 0, dy = Number(centerFix && centerFix.dy) || 0;
    var guard = 0.25, hitTol = 0.05, count = 0, i, x, y, start, end, mark;
    ANP_prepareTargetLayerV28(doc, ponLayer); ANP_unlockTreeV28(ponLayer);

    /* V68: quay lại dùng ĐỦ biên thật của từng con (topMarks/bottomMarks/
       leftMarks/rightMarks) — bắt buộc phải giữ để layout so le/lồi lõm
       (cột dài nằm giữa, 2 bên ngắn hơn — kiểu "corner-safe"/mixed-columns)
       vẫn có PON tại các đoạn bậc thang, không chỉ ở 4 mép ngoài cùng của
       cả tờ. V67 từng bỏ các đoạn này nên PON bị thiếu ở chỗ lồi/lõm.
       Dung sai xác định "liền kề" (tol trong ANP_finishCropDataV56) đã
       được nới rộng để tránh lặp lại lỗi PON lọt vào giữa ở layout lưới
       đều (do sai số làm tròn khi dựng bố cục). V70: mỗi tick còn được
       kiểm tra va chạm trước khi vẽ, vì trong layout trộn cỡ, một tick hợp
       lệ vẫn có thể rơi đúng vào vật liệu của con hàng xóm cao/thấp hơn —
       bỏ tick đó thay vì đè lên FILE IN. */
    for (i = 0; i < data.topMarks.length; i++) {
        mark = data.topMarks[i];
        if (ANP_finishCropVerticalTickHitsV70(data.boxes, mark.x, mark.y - gapMM - lenMM, mark.y - gapMM, hitTol)) { continue; }
        y = a[1] - ANP_mm(mark.y) + dy;
        start = y + gap; end = Math.min(start + len, a[1] - guard);
        if (end > start + 0.01) {
            x = a[0] + ANP_mm(mark.x) + dx;
            ANP_finishCropLineV56(ponLayer, x, start, x, end, "PON_CAT_TREN_" + (i + 1)); count++;
        }
    }
    for (i = 0; i < data.bottomMarks.length; i++) {
        mark = data.bottomMarks[i];
        if (ANP_finishCropVerticalTickHitsV70(data.boxes, mark.x, mark.y + gapMM, mark.y + gapMM + lenMM, hitTol)) { continue; }
        y = a[1] - ANP_mm(mark.y) + dy;
        start = y - gap; end = Math.max(start - len, a[3] + guard);
        if (end < start - 0.01) {
            x = a[0] + ANP_mm(mark.x) + dx;
            ANP_finishCropLineV56(ponLayer, x, start, x, end, "PON_CAT_DUOI_" + (i + 1)); count++;
        }
    }
    for (i = 0; i < data.leftMarks.length; i++) {
        mark = data.leftMarks[i];
        if (ANP_finishCropHorizontalTickHitsV70(data.boxes, mark.y, mark.x - gapMM - lenMM, mark.x - gapMM, hitTol)) { continue; }
        x = a[0] + ANP_mm(mark.x) + dx;
        start = x - gap; end = Math.max(start - len, a[0] + guard);
        if (end < start - 0.01) {
            y = a[1] - ANP_mm(mark.y) + dy;
            ANP_finishCropLineV56(ponLayer, start, y, end, y, "PON_CAT_TRAI_" + (i + 1)); count++;
        }
    }
    for (i = 0; i < data.rightMarks.length; i++) {
        mark = data.rightMarks[i];
        if (ANP_finishCropHorizontalTickHitsV70(data.boxes, mark.y, mark.x + gapMM, mark.x + gapMM + lenMM, hitTol)) { continue; }
        x = a[0] + ANP_mm(mark.x) + dx;
        start = x + gap; end = Math.min(start + len, a[2] - guard);
        if (end > start + 0.01) {
            y = a[1] - ANP_mm(mark.y) + dy;
            ANP_finishCropLineV56(ponLayer, start, y, end, y, "PON_CAT_PHAI_" + (i + 1)); count++;
        }
    }
    return count;
}

function ANP_isCleanDiePath(path) {
    try {
        if (!path.stroked || path.clipping || Number(path.strokeWidth) <= 0) { return false; }
        if (path.strokeColor && path.strokeColor.typename === "SpotColor") {
            return ANP_hasDieWord(path.strokeColor.spot.name, "KHUON_BE");
        }
        return ANP_colorLooksDie(path.strokeColor, "KHUON_BE") || ANP_hasDieWord(path.name, "KHUON_BE");
    } catch (e) { return false; }
}


/* V3.6 — hiệu chỉnh tâm lần cuối bằng chính geometricBounds Illustrator.
   Engine chỉ biết tọa độ lý thuyết; sau rotate/embed/link/Symbol, Illustrator có
   thể phát sinh sai số thực tế vài point/mm. Hàm này đo đối tượng THẬT sau khi
   đã dựng và dịch toàn bộ artwork về đúng tâm artboard. */
function ANP_layerTopBoundsV36(layer) {
    var i, item, b, minX = 1e20, minY = 1e20, maxX = -1e20, maxY = -1e20, found = false;
    if (!layer) { return null; }
    for (i = 0; i < layer.pageItems.length; i++) {
        item = layer.pageItems[i];
        try {
            /* Chỉ lấy root item để không đếm/dịch lặp children trong Group/Compound. */
            if (item.parent !== layer) { continue; }
            if (item.hidden) { continue; }
            b = item.geometricBounds;
            minX = Math.min(minX, Number(b[0]));
            maxY = Math.max(maxY, Number(b[1]));
            maxX = Math.max(maxX, Number(b[2]));
            minY = Math.min(minY, Number(b[3]));
            found = true;
        } catch (e0) {}
    }
    if (!found) { return null; }
    return { left:minX, top:maxY, right:maxX, bottom:minY,
        centerX:(minX + maxX) / 2, centerY:(maxY + minY) / 2 };
}

function ANP_translateLayerRootsV36(layer, dx, dy) {
    var i, item;
    if (!layer || (Math.abs(Number(dx)) < 0.00001 && Math.abs(Number(dy)) < 0.00001)) { return; }
    ANP_prepareTargetLayerV28(layer.parent, layer);
    for (i = layer.pageItems.length - 1; i >= 0; i--) {
        item = layer.pageItems[i];
        try { if (item.parent === layer) { item.translate(Number(dx), Number(dy)); } } catch (e0) {}
    }
}

function ANP_exactCenterShiftV36(doc, layer) {
    var b = ANP_layerTopBoundsV36(layer), a, targetX, targetY;
    if (!b || !doc || !doc.artboards.length) { return { dx:0, dy:0, ok:false }; }
    a = ANP_activeArtboardRectV61(doc);
    targetX = (Number(a[0]) + Number(a[2])) / 2;
    targetY = (Number(a[1]) + Number(a[3])) / 2;
    return { dx:targetX - Number(b.centerX), dy:targetY - Number(b.centerY), ok:true };
}

/* Dùng KHUÔN làm chuẩn tuyệt đối rồi áp cùng một vector dịch cho FILE IN.
   Chạy 2 pass để triệt luôn sai số làm tròn/refresh của Illustrator. */
function ANP_exactCenterPairV36(printDoc, printLayer, dieDoc, dieLayer) {
    var shift = ANP_exactCenterShiftV36(dieDoc, dieLayer);
    /* V5.8: các phép duplicate/rotate/translate của Illustrator DOM là đồng bộ.
       Một lần đo bounds + một vector dịch là đủ; bỏ hai app.redraw toàn sheet
       và pass kiểm tra lặp vốn là nút thắt lớn nhất khi có nhiều Link. */
    if (shift.ok && (Math.abs(shift.dx) >= 0.001 || Math.abs(shift.dy) >= 0.001)) {
        ANP_translateLayerRootsV36(dieLayer, shift.dx, shift.dy);
        ANP_translateLayerRootsV36(printLayer, shift.dx, shift.dy);
        return { dx:Number(shift.dx), dy:Number(shift.dy), ok:true };
    }
    return { dx:0, dy:0, ok:shift.ok };
}

function ANP_exactCenterSingleV36(doc, layer) {
    var shift = ANP_exactCenterShiftV36(doc, layer);
    if (shift.ok && (Math.abs(shift.dx) >= 0.001 || Math.abs(shift.dy) >= 0.001)) {
        ANP_translateLayerRootsV36(layer, shift.dx, shift.dy);
        return { dx:Number(shift.dx), dy:Number(shift.dy) };
    }
    return { dx:0, dy:0 };
}

function ANP_cleanDieLayerV13(doc, dirtyLayer) {
    var roots = [], i, p, root, clean = doc.layers.add(), dieColor;
    ANP_prepareTargetLayerV28(doc, dirtyLayer);
    ANP_unlockTreeV28(dirtyLayer);
    clean.name = "KHUON_BE_CLEAN";
    ANP_prepareTargetLayerV28(doc, clean);
    for (i = 0; i < doc.pathItems.length; i++) {
        p = doc.pathItems[i];
        try {
            if (p.layer !== dirtyLayer || !ANP_isCleanDiePath(p)) { continue; }
            root = (p.parent && p.parent.typename === "CompoundPathItem") ? p.parent : p;
            ANP_pushUnique(roots, root);
        } catch (e0) {}
    }
    if (!roots.length) { clean.remove(); throw new Error("Không tìm thấy dieline KHUON_BE sau khi bung khuôn."); }
    for (i = 0; i < roots.length; i++) {
        try { roots[i].duplicate(clean, ElementPlacement.PLACEATEND); } catch (e1) {}
    }
    dirtyLayer.remove();
    clean.name = "KHUON_BE";
    dieColor = ANP_dieProcessColorV21();
    for (i = 0; i < clean.pageItems.length; i++) { ANP_normalizeDie(clean.pageItems[i], dieColor); }
    ANP_removeDieSpotSwatchesV21(doc);
    return clean;
}


/* V3.7 — FILE KHUÔN luôn phải là stroke vector thật.
   Một số khuôn cong/vòm được Illustrator lưu dưới dạng Static Symbol sau khi
   duplicate/embed.  Máy bế cần PathItem/CompoundPathItem thật, không Symbol.
   Quy trình dưới đây: embed mọi link -> Break Link mọi Symbol -> copy từng
   Bezier path sang layer sạch -> ép Fill=None + Stroke Process CMYK. */
function ANP_embedAllPlacedV37(doc) {
    var pass, i, before = 0, after = 0, item;
    for (pass = 0; pass < 12; pass++) {
        try { before = doc.placedItems.length; } catch (e0) { before = 0; }
        if (!before) { break; }
        for (i = before - 1; i >= 0; i--) {
            try {
                item = doc.placedItems[i];
                try { item.locked = false; } catch (e1) {}
                try { item.hidden = false; } catch (e2) {}
                item.embed();
            } catch (e3) {}
        }
        try { app.redraw(); } catch (e4) {}
        try { after = doc.placedItems.length; } catch (e5) { after = 0; }
        if (!after || after >= before) { break; }
    }
    try { return doc.placedItems.length; } catch (e6) { return 0; }
}

function ANP_breakAllSymbolsV37(doc) {
    var pass, i, before = 0, after = 0, item;
    /* breakLink() biến Static/Dynamic Symbol instance thành artwork thường.
       Duyệt ngược vì collection thay đổi ngay sau mỗi lần breakLink. */
    for (pass = 0; pass < 16; pass++) {
        try { before = doc.symbolItems.length; } catch (e0) { before = 0; }
        if (!before) { break; }
        for (i = before - 1; i >= 0; i--) {
            try {
                item = doc.symbolItems[i];
                try { item.locked = false; } catch (e1) {}
                try { item.hidden = false; } catch (e2) {}
                item.breakLink();
            } catch (e3) {}
        }
        try { app.redraw(); } catch (e4) {}
        try { after = doc.symbolItems.length; } catch (e5) { after = 0; }
        if (!after) { break; }
        /* Illustrator đôi lúc chỉ bung một phần Symbol mỗi pass. Chỉ dừng khi
           hoàn toàn không có tiến triển ở hai vòng liên tiếp. */
        if (after >= before && pass >= 1) { break; }
    }
    try { return doc.symbolItems.length; } catch (e6) { return 0; }
}

function ANP_isInsideLayerV37(item, layer) {
    var p = item, guard = 0;
    while (p && guard < 80) {
        if (p === layer) { return true; }
        try { p = p.parent; } catch (e) { p = null; }
        guard++;
    }
    return false;
}

function ANP_cloneBezierPathV37(path, layer) {
    var q = null, i, pts, anchors = [];
    try {
        q = path.duplicate(layer, ElementPlacement.PLACEATEND);
        return q;
    } catch (e0) {}
    /* Fallback cho path nằm trong Compound/Symbol sau Break Link: dựng lại cả
       anchor + tay nắm Bezier, vì chỉ setEntirePath sẽ làm cung cong thành đa giác. */
    try {
        pts = path.pathPoints;
        for (i = 0; i < pts.length; i++) { anchors.push([Number(pts[i].anchor[0]), Number(pts[i].anchor[1])]); }
        q = layer.pathItems.add();
        q.setEntirePath(anchors);
        q.closed = path.closed === true;
        for (i = 0; i < pts.length && i < q.pathPoints.length; i++) {
            try { q.pathPoints[i].leftDirection = [Number(pts[i].leftDirection[0]), Number(pts[i].leftDirection[1])]; } catch (e1) {}
            try { q.pathPoints[i].rightDirection = [Number(pts[i].rightDirection[0]), Number(pts[i].rightDirection[1])]; } catch (e2) {}
            try { q.pathPoints[i].pointType = pts[i].pointType; } catch (e3) {}
        }
        return q;
    } catch (e4) {
        try { if (q) { q.remove(); } } catch (e5) {}
        return null;
    }
}

function ANP_forceStrokePathV37(path, color, index) {
    try {
        path.filled = false;
        path.stroked = true;
        path.strokeColor = color;
        path.strokeWidth = 0.25;
        path.strokeOverprint = true;
        path.opacity = 100;
        path.name = "KHUON_BE_VECTOR_" + index;
    } catch (e) {}
    return path;
}

/* V5.4 — Illustrator không bảo đảm artwork sinh ra bởi SymbolItem.breakLink()
   vẫn nằm trong layer chứa Symbol ban đầu. Static Symbol/Plugin artwork có thể
   bung Bézier Path sang layer đang active, làm bộ lọc V3.7 bỏ sót toàn bộ khuôn.
   Chụp danh sách Path trước khi Embed/Break và sau đó nhận cả:
   1) Path thật sự còn nằm trong dirtyLayer; hoặc
   2) Path mới xuất hiện sau khi bung Symbol, dù Illustrator đặt nó ở layer khác.
   Danh sách tham chiếu giúp không lấy nhầm Path của các master khuôn đã tạo trước. */
function ANP_snapshotPathRefsV54(doc) {
    var refs = [], i;
    try {
        for (i = 0; i < doc.pathItems.length; i++) { refs.push(doc.pathItems[i]); }
    } catch (e) {}
    return refs;
}

function ANP_pathRefExistedV54(path, refs) {
    var i;
    for (i = 0; i < refs.length; i++) {
        try { if (refs[i] === path) { return true; } } catch (e) {}
    }
    return false;
}

function ANP_pushBezierPathV54(paths, path) {
    var i;
    for (i = 0; i < paths.length; i++) {
        try { if (paths[i] === path) { return; } } catch (e0) {}
    }
    paths.push(path);
}

function ANP_collectReleasedBezierPathsV54(doc, dirtyLayer, beforePaths) {
    var paths = [], i, p, inside, released;
    try {
        for (i = 0; i < doc.pathItems.length; i++) {
            p = doc.pathItems[i];
            try {
                if (p.clipping || !p.pathPoints || p.pathPoints.length < 2) { continue; }
                inside = ANP_isInsideLayerV37(p, dirtyLayer);
                released = !ANP_pathRefExistedV54(p, beforePaths);
                if (inside || released) { ANP_pushBezierPathV54(paths, p); }
            } catch (e0) {}
        }
    } catch (e1) {}
    return paths;
}

function ANP_removeReleasedPathsOutsideLayerV54(paths, dirtyLayer, beforePaths) {
    var i, p;
    for (i = paths.length - 1; i >= 0; i--) {
        p = paths[i];
        try {
            if (!ANP_isInsideLayerV37(p, dirtyLayer) && !ANP_pathRefExistedV54(p, beforePaths)) {
                p.remove();
            }
        } catch (e) {}
    }
}

function ANP_finalizeDieStrokeVectorsV37(doc, dirtyLayer) {
    var clean, paths = [], beforePaths, i, p, q, color, remainPlaced, remainSymbols, created = 0;
    if (!doc || !dirtyLayer) { throw new Error("Không có layer khuôn để chuyển sang stroke vector."); }
    ANP_prepareTargetLayerV28(doc, dirtyLayer);
    ANP_unlockTreeV28(dirtyLayer);

    /* Phải snapshot trước Embed/Break để phân biệt Path của khuôn vừa bung với
       artwork vector đã tồn tại trong document. */
    beforePaths = ANP_snapshotPathRefsV54(doc);

    remainPlaced = ANP_embedAllPlacedV37(doc);
    remainSymbols = ANP_breakAllSymbolsV37(doc);
    /* Break Link có thể sinh thêm placed/symbol lồng nhau. Chạy thêm một lượt. */
    if (remainPlaced || remainSymbols) {
        ANP_embedAllPlacedV37(doc);
        ANP_breakAllSymbolsV37(doc);
    }
    try { app.redraw(); } catch (eRedraw) {}

    /* Không chỉ quét dirtyLayer: Break Link có thể thả Path sang active layer. */
    paths = ANP_collectReleasedBezierPathsV54(doc, dirtyLayer, beforePaths);
    if (!paths.length) {
        throw new Error("KHUÔN BẾ không có Bézier Path thật sau Embed/Break Symbol. Hãy Expand artwork khuôn hoặc kiểm tra contour nguồn.");
    }

    clean = doc.layers.add(); clean.name = "KHUON_BE_VECTOR_STROKE";
    ANP_prepareTargetLayerV28(doc, clean);
    color = ANP_dieProcessColorV21();
    for (i = 0; i < paths.length; i++) {
        q = ANP_cloneBezierPathV37(paths[i], clean);
        if (q) { ANP_forceStrokePathV37(q, color, i + 1); created++; }
    }
    if (!created) {
        try { clean.remove(); } catch (eNoClone0) {}
        throw new Error("Đã tìm thấy contour nhưng Illustrator không thể tạo Bézier Path vector cho KHUÔN BẾ.");
    }
    /* Xóa Path mới bị Break Link thả ra ngoài layer tạm để FILE KHUÔN chỉ còn
       bản clone stroke CMYK sạch, không còn artwork thừa hoặc đối tượng vô hình. */
    ANP_removeReleasedPathsOutsideLayerV54(paths, dirtyLayer, beforePaths);
    try { dirtyLayer.remove(); } catch (e2) {}
    clean.name = "KHUON_BE";
    ANP_removeDieSpotSwatchesV21(doc);
    try { app.redraw(); } catch (e3) {}

    /* Không cho phép FILE KHUÔN tiếp tục nếu còn Static Symbol/Link. */
    try { if (doc.symbolItems.length > 0) { throw new Error("KHUÔN BẾ vẫn còn Static Symbol sau Break Link."); } } catch (e4) {
        if (String(e4).indexOf("Static Symbol") >= 0) { throw e4; }
    }
    try { if (doc.placedItems.length > 0) { throw new Error("KHUÔN BẾ vẫn còn Link sau Embed."); } } catch (e5) {
        if (String(e5).indexOf("vẫn còn Link") >= 0) { throw e5; }
    }
    return clean;
}

/* V4.5 PERFORMANCE — VECTOR MASTER ONCE
   DIE-LINK V3.7 đã là stroke vector sạch. Thay vì duplicate Link -> Embed ->
   Break Symbol cho TỪNG con rồi quét lại toàn bộ path, chỉ import/embed DIE-LINK
   đúng MỘT LẦN cho mỗi nguồn, tạo một vector master, sau đó duplicate vector
   master trực tiếp. Hình học/Bezier/góc xoay/khoảng cách giữ nguyên tuyệt đối. */
function ANP_groupLayerRootsV45(layer, name) {
    var group = layer.groupItems.add(), roots = [], i, item;
    group.name = name || "__DIE_VECTOR_MASTER_GROUP__";
    for (i = 0; i < layer.pageItems.length; i++) {
        item = layer.pageItems[i];
        try { if (item !== group && item.parent === layer) { roots.push(item); } } catch (e0) {}
    }
    for (i = 0; i < roots.length; i++) {
        try { roots[i].move(group, ElementPlacement.PLACEATEND); } catch (e1) {}
    }
    if (!group.pageItems.length) { try { group.remove(); } catch (e2) {} return null; }
    return group;
}

function ANP_makeVectorDieMasterV45(doc, diePath, key) {
    var dirty, placed, clean, group, f = new File(diePath), a;
    if (!f.exists) { throw new Error("Không tìm thấy DIE-LINK để tạo Vector Master: " + diePath); }
    dirty = doc.layers.add(); dirty.name = "__DIE_MASTER_DIRTY_V45_" + key;
    ANP_prepareTargetLayerV28(doc, dirty);
    placed = ANP_placeFileSafeV57(doc, dirty, f, "DIE_VECTOR_MASTER_V57", false).item;
    a = doc.artboards[0].artboardRect; placed.left = a[0]; placed.top = a[1];
    /* Finalize chạy trên CHỈ một DIE-LINK nên Embed/Break/Bezier clone chỉ xảy ra 1 lần/source. */
    clean = ANP_finalizeDieStrokeVectorsV37(doc, dirty);
    clean.name = "__DIE_VECTOR_MASTER_V45_" + key;
    group = ANP_groupLayerRootsV45(clean, "__DIE_VECTOR_MASTER_GROUP_V45_" + key);
    if (!group) { try { clean.remove(); } catch (e1) {} throw new Error("Không tạo được Vector Master từ DIE-LINK."); }
    return { layer:clean, group:group };
}

/* V5.5 — tạo Vector Master trực tiếp từ geometry đã đọc ở file nguồn.
   Không Place DIE-LINK, không Embed, không Symbol và không PluginItem. */
function ANP_makeVectorDieMasterFromGeometryV55(doc, geometry, key) {
    var layer, group, art, sx, sy, i, j, src, q, anchors, p, color, created = 0;
    if (!geometry || !geometry.paths || !geometry.paths.length) {
        throw new Error("KHUÔN BẾ không có dữ liệu Bézier nguồn để dựng stroke vector.");
    }
    if (!(Number(geometry.sourceW) > 0) || !(Number(geometry.sourceH) > 0)) {
        throw new Error("Kích thước geometry KHUÔN BẾ không hợp lệ.");
    }
    layer = doc.layers.add(); layer.name = "__DIE_MASTER_GEOMETRY_V55_" + key;
    ANP_prepareTargetLayerV28(doc, layer);
    group = layer.groupItems.add(); group.name = "__DIE_VECTOR_MASTER_GROUP_V55_" + key;
    art = doc.artboards[0].artboardRect;
    sx = (Number(geometry.itemW) || Number(geometry.sourceW)) / Number(geometry.sourceW);
    sy = (Number(geometry.itemH) || Number(geometry.sourceH)) / Number(geometry.sourceH);
    color = ANP_dieProcessColorV21();
    for (i = 0; i < geometry.paths.length; i++) {
        src = geometry.paths[i]; anchors = []; q = null;
        if (!src.points || src.points.length < 2) { continue; }
        for (j = 0; j < src.points.length; j++) {
            p = src.points[j];
            anchors.push([art[0] + ANP_mm(Number(p.a[0]) * sx), art[1] - ANP_mm(Number(p.a[1]) * sy)]);
        }
        try {
            q = group.pathItems.add(); q.setEntirePath(anchors); q.closed = src.closed === true;
            for (j = 0; j < src.points.length && j < q.pathPoints.length; j++) {
                p = src.points[j];
                q.pathPoints[j].leftDirection = [art[0] + ANP_mm(Number(p.l[0]) * sx), art[1] - ANP_mm(Number(p.l[1]) * sy)];
                q.pathPoints[j].rightDirection = [art[0] + ANP_mm(Number(p.r[0]) * sx), art[1] - ANP_mm(Number(p.r[1]) * sy)];
                try { q.pathPoints[j].pointType = p.smooth ? PointType.SMOOTH : PointType.CORNER; } catch (ePointType) {}
            }
            ANP_forceStrokePathV37(q, color, created + 1); created++;
        } catch (ePath) { try { if (q) { q.remove(); } } catch (eRemove) {} q = null; }
    }
    if (!created) {
        try { layer.remove(); } catch (eLayer) {}
        throw new Error("Không dựng được Bézier Path vector trực tiếp từ contour KHUON_BE.");
    }
    ANP_removeDieSpotSwatchesV21(doc);
    return { layer:layer, group:group, directGeometry:true, pathCount:created };
}

function ANP_placeVectorDieMasterV45(doc, targetLayer, masterGroup, placement, cfg, name) {
    var instance, explicitAngle, angle, a, b, targetLeft, targetTop, dx, dy;
    ANP_prepareTargetLayerV28(doc, targetLayer);
    instance = masterGroup.duplicate(targetLayer, ElementPlacement.PLACEATEND);
    try { instance.name = name || "DIE_VECTOR"; } catch (e0) {}
    explicitAngle = placement.angle !== undefined;
    angle = explicitAngle ? Number(placement.angle) : (placement.rotated ? 90 : 0);
    /* Engine Y hướng xuống, Illustrator Y hướng lên: giữ cùng quy tắc ANP_placeLinked. */
    if (Math.abs(angle) > 0.0001) {
        instance.rotate(explicitAngle ? -angle : angle, true, true, true, true, Transformation.CENTER);
    }
    b = instance.geometricBounds; a = doc.artboards[0].artboardRect;
    /* V5.8 OUTPUT SYNC: x/y của True-Shape đã là góc trái/trên của bounding-box
       polygon SAU XOAY. offsetX/offsetY chỉ dùng để căn artwork hình chữ nhật
       của PRINT-LINK quanh contour thật; cộng lại ở Vector Master sẽ dịch khuôn
       lần thứ hai và làm bố cục 9 con chỉ còn thấy 6 con trên artboard. */
    targetLeft = a[0] + ANP_mm(Number(cfg.margin) + Number(placement.x));
    targetTop = a[1] - ANP_mm(Number(cfg.margin) + Number(placement.y));
    dx = targetLeft - Number(b[0]); dy = targetTop - Number(b[1]);
    instance.translate(dx, dy);
    return instance;
}

function ANP_removeVectorMasterV45(master) {
    if (!master) { return; }
    try { if (master.layer) { master.layer.remove(); } } catch (e0) {}
}

function ANP_assertStrokeVectorLayerV37(layer) {
    var i, item, pathCount = 0;
    if (!layer) { throw new Error("Không tìm thấy layer KHUON_BE vector."); }
    for (i = 0; i < layer.pageItems.length; i++) {
        item = layer.pageItems[i];
        try {
            if (item.typename === "PathItem") {
                if (item.clipping) { continue; }
                if (!item.stroked || item.filled) { throw new Error("KHUÔN BẾ có path không phải Stroke-only."); }
                pathCount++;
            } else if (item.typename === "CompoundPathItem") {
                pathCount += item.pathItems.length;
            } else if (item.typename === "GroupItem") {
                /* Fast-vector/Demi có thể group; Symbol/Placed thì tuyệt đối cấm. */
            } else if (item.typename === "SymbolItem" || item.typename === "PlacedItem" || item.typename === "RasterItem") {
                throw new Error("KHUÔN BẾ còn " + item.typename + "; yêu cầu stroke vector thuần.");
            }
        } catch (e0) {
            if (String(e0).indexOf("KHUÔN BẾ") >= 0) { throw e0; }
        }
    }
    if (!pathCount && layer.pageItems.length === 0) { throw new Error("Layer KHUON_BE không có vector stroke."); }
    return true;
}

function ANP_cleanTitleV15(title) {
    title = String(title || "").replace(/[\\\/:*?\"<>|]/g, "-").replace(/^\s+|\s+$/g, "");
    return title || "AUTO_NEST";
}

/* V148.9: STT tên file tùy chọn. Tăng thành phần số cuối cùng để hỗ trợ
   1.12 -> 1.13 -> 1.14 và 2.10 -> 2.11...; để trống giữ numbering cũ. */
function ANP_sequenceNumberV1489(startValue, offset, fallbackValue) {
    var raw = String(startValue || "").replace(/\s+/g, ""), parts, last, width, n, out;
    if (!raw) { return String(fallbackValue == null ? "" : fallbackValue); }
    if (!/^\d+(?:\.\d+)*$/.test(raw)) { return String(fallbackValue == null ? raw : fallbackValue); }
    parts = raw.split("."); last = String(parts[parts.length - 1] || "0"); width = last.length;
    n = parseInt(last, 10); if (isNaN(n)) { return String(fallbackValue == null ? raw : fallbackValue); }
    n += Math.max(0, Math.floor(Number(offset) || 0)); out = String(n);
    while (out.length < width) { out = "0" + out; }
    parts[parts.length - 1] = out;
    return parts.join(".");
}

function ANP_printTitleV15(number, documentName, artboardName, w, h, cfg, pcs, sideLabel) {
    var abBase = ANP_safeBase(artboardName || "ARTBOARD");
    var cattp = cfg && cfg.finishCropMarks === true ? " - CATTP" : "";
    var side = sideLabel ? " - " + String(sideLabel) : "";
    return ANP_cleanTitleV15(number + ". FILE IN" + cattp + side + " - " + abBase + " - KT TEM " +
        w + "X" + h + "MM - " + cfg.paperW + "X" + cfg.paperH + " - " + pcs + "PCS");
}

function ANP_dieTitleV15(number, w, h, cfg, pcs) {
    return ANP_cleanTitleV15(number + ". KHUÔN BẾ - KT " + w + "X" + h + "MM - " +
        cfg.paperW + "X" + cfg.paperH + " - " + pcs + "PCS");
}

/* Đồng bộ quy cách lưu tên của AutoNestPro 2.5.1 cho cả chế độ file thường.
   Một kích thước dùng đúng mẫu 1.1/1; bài ghép nhiều kích thước ghi rõ để
   không tạo tên khuôn sai kích thước thực tế. */
function ANP_v11OutputTitlesV29(cfg, layout, jobBase) {
    var sources = cfg.sources || [], first = sources.length ? sources[0] : {};
    var sameSize = sources.length > 0, i, name, sizeText, printTitle, dieTitle, printNum, dieNum;
    for (i = 1; i < sources.length; i++) {
        if (Math.abs(Number(sources[i].width) - Number(first.width)) > 0.05 ||
            Math.abs(Number(sources[i].height) - Number(first.height)) > 0.05) { sameSize = false; break; }
    }
    name = ANP_safeBase(sources.length === 1 ? first.name : jobBase);
    printNum = ANP_sequenceNumberV1489(cfg.outputPrintStart, 0, cfg.finishCropMarks === true ? "1" : "1.1");
    dieNum = ANP_sequenceNumberV1489(cfg.outputDieStart, 0, "1");
    if (sameSize) {
        printTitle = ANP_printTitleV15(printNum, "", name, first.width, first.height, cfg, layout.count);
        dieTitle = ANP_dieTitleV15(dieNum, first.width, first.height, cfg, layout.count);
    } else {
        sizeText = "NHIỀU KÍCH THƯỚC";
        printTitle = ANP_cleanTitleV15(printNum + ". FILE IN" + (cfg.finishCropMarks === true ? " - CATTP - " : " - ") +
            name + " - KT TEM " + sizeText + " - " +
            cfg.paperW + "X" + cfg.paperH + " - " + layout.count + "PCS");
        dieTitle = ANP_cleanTitleV15(dieNum + ". KHUÔN BẾ - KT " + sizeText + " - " +
            cfg.paperW + "X" + cfg.paperH + " - " + layout.count + "PCS");
    }
    return { print:printTitle, die:dieTitle };
}

/* V68: tối giản theo yêu cầu — chỉ hiện trên artboard MẶT A, không lặp lại
   trên MẶT B, và bỏ phần "A <tên> - B <tên>" (không cần thiết vì chỉ còn
   một dòng tiêu đề cho cả file 2 mặt).
   Mẫu: 1. FILE IN - 2 MẶT - CATTP - [TÊN ARTBOARD] - KT TEM [KÍCH THƯỚC] -
        [KHỔ ARTBOARD] - [SỐ LƯỢNG] PCS */
function ANP_duplexOutputTitleV61(cfg, group, frontMeta, backMeta, pcs) {
    var front = ANP_safeBase(frontMeta && frontMeta.name ? frontMeta.name : "MAT_A");
    var number = ANP_sequenceNumberV1489(cfg.outputPrintStart, 0, "1");
    return ANP_cleanTitleV15(number + ". FILE IN - 2 MẶT - CATTP - " + front +
        " - KT TEM " + group.width + "X" + group.height + "MM - " +
        cfg.paperW + "X" + cfg.paperH + " - " + pcs + "PCS");
}

/* V61 — một document, hai artboard và một PDF hai trang.
   Mỗi artboard có artwork Link riêng, PON CATTP riêng và title riêng. Không gọi
   ANP_addPonV12 nên không thể phát sinh dấu L bốn góc hay chấm tròn đăng ký. */
function ANP_buildDuplexPrintSheetV61(cfg, metas, links, layouts, outFile, title) {
    var printSpace = ANP_printColorSpaceV23(cfg, links, null);
    var doc = ANP_newDoc(printSpace, cfg, "MAT_A"), side, layer, master, i, centerFix, cropLayer, titleLayer;
    var expectedLinks = 0, markCount;
    try {
        doc.artboards[0].name = "MAT_A";
        ANP_addDuplexArtboardV61(doc, "MAT_B");
        for (side = 0; side < 2; side++) {
            doc.artboards.setActiveArtboardIndex(side);
            layer = side === 0 ? doc.layers[0] : doc.layers.add();
            layer.name = side === 0 ? "FILE_IN_MAT_A_LINKS" : "FILE_IN_MAT_B_LINKS";
            ANP_prepareTargetLayerV28(doc, layer);
            master = ANP_linkMaster(doc, layer, links[side].printPath, side === 0 ? "__MASTER_A" : "__MASTER_B");
            for (i = 0; i < layouts[side].items.length; i++) {
                ANP_placeIndividualLinkFastV47(doc, layer, master, layouts[side].items[i], cfg,
                    links[side].bleed, (side === 0 ? "A_" : "B_") + "PRINT_" + (i + 1));
            }
            master.remove(); master = null; layer.visible = true;
            expectedLinks += layouts[side].items.length;
            centerFix = ANP_exactCenterSingleV36(doc, layer);
            ANP_assertDuplexSideV62(doc, layer, layouts[side].items.length, side === 0 ? "A" : "B");

            cropLayer = doc.layers.add();
            cropLayer.name = side === 0 ? "PON_CATTP_MAT_A" : "PON_CATTP_MAT_B";
            markCount = ANP_addFinishCropMarksV56(doc, cropLayer, layouts[side], cfg, centerFix);
            if (!markCount) { throw new Error("Không tạo được PON CATTP cho mặt " + (side === 0 ? "A" : "B") + "."); }

            if (side === 0 && cfg.addTitle && cfg.header >= 5) {
                titleLayer = doc.layers.add();
                titleLayer.name = "TIEU_DE_MAT_A";
                ANP_addCenteredTitle(titleLayer, doc, cfg, title);
            }
        }
        ANP_assertIndividualPrintLinksV47(doc, expectedLinks);
        ANP_savePDFMultiArtboardV61(doc, outFile, cfg.preservePrintColor !== false);
        doc.close(SaveOptions.DONOTSAVECHANGES);
    } catch (e) {
        try { if (master) { master.remove(); } } catch (eMaster) {}
        try { doc.close(SaveOptions.DONOTSAVECHANGES); } catch (eClose) {}
        throw e;
    }
}



/* ========================================================================== */
/* V142.3 DUPLEX NULL-SAFE FALLBACK                                           */
/*                                                                            */
/* Stable-first policy: the original ANP_buildDuplexPrintSheetV61 remains     */
/* untouched and is always attempted first. Some Illustrator/macOS builds can */
/* throw a generic "null is not an object" while constructing the second      */
/* artboard/PlacedItem tree. Only for that object-invalid family of errors,    */
/* fall back to two proven single-side CATTP renders and merge the two PDFs.   */
/* Core V101 layout + ANP_duplexLayoutV60 are not recalculated or changed.     */
/* ========================================================================== */
function ANP_duplexNullObjectErrorV1423(e) {
    var s = "";
    try { s = String(e && e.message ? e.message : e); } catch (e0) { s = ""; }
    s = s.toLowerCase();
    return s.indexOf("null is not an object") >= 0 ||
        s.indexOf("undefined is not an object") >= 0 ||
        s.indexOf("object is invalid") >= 0 ||
        s.indexOf("invalid object") >= 0 ||
        s.indexOf("no such element") >= 0;
}

function ANP_copyCfgV1423(cfg) {
    var out = {}, k;
    cfg = cfg || {};
    for (k in cfg) { if (cfg.hasOwnProperty(k)) { out[k] = cfg[k]; } }
    return out;
}

function ANP_duplexTempPdfV1423(folder, label) {
    var f, n = 0, stamp = String((new Date()).getTime());
    folder = folder && folder.exists ? folder : Folder.temp;
    do {
        n++;
        f = new File(folder.fsName + "/DPV_V1423_DUPLEX_" + label + "_" + stamp + "_" + n + ".pdf");
    } while (f.exists && n < 40);
    try { if (f.exists) { f.remove(); } } catch (e0) {}
    return f;
}

function ANP_mergeDuplexSidePdfsV1423(cfg, pdfA, pdfB, outFile, colorSpace) {
    var ctx = null, pageRect, paperW = Number(cfg.paperW), paperH = Number(cfg.paperH);
    if (!pdfA || !pdfA.exists || !pdfB || !pdfB.exists) {
        throw new Error("V142.3 Duplex fallback: thiếu PDF tạm mặt A/B.");
    }
    if (!(paperW > 0) || !(paperH > 0)) {
        throw new Error("V142.3 Duplex fallback: khổ in không hợp lệ.");
    }
    pageRect = [0, ANP_mm(paperH), ANP_mm(paperW), 0];
    try {
        ctx = ANP_vdpMergeBeginV79([pageRect], 2, colorSpace || DocumentColorSpace.CMYK);
        ANP_vdpMergeAddPdfV79(ctx, pdfA);
        ANP_vdpMergeAddPdfV79(ctx, pdfB);
        if (!ctx || !ctx.doc || !ctx.doc.artboards || ctx.doc.artboards.length !== 2) {
            throw new Error("V142.3 Duplex fallback: không dựng đủ 2 trang A/B.");
        }
        try { ctx.doc.artboards[0].name = "MAT_A"; } catch (eNameA) {}
        try { ctx.doc.artboards[1].name = "MAT_B"; } catch (eNameB) {}
        ANP_savePDFMultiArtboardV61(ctx.doc, outFile, cfg.preservePrintColor !== false);
    } finally {
        try { ANP_vdpMergeClosePrefsV79(ctx); } catch (ePrefs) {}
        try { if (ctx && ctx.doc) { ctx.doc.close(SaveOptions.DONOTSAVECHANGES); } } catch (eClose) {}
    }
    if (!outFile || !outFile.exists) {
        throw new Error("V142.3 Duplex fallback: PDF 2 trang chưa được tạo.");
    }
    return true;
}

function ANP_buildDuplexPrintSheetFallbackV1423(cfg, metas, links, layouts, outFile, title, tempFolder) {
    var cfgA = ANP_copyCfgV1423(cfg), cfgB = ANP_copyCfgV1423(cfg);
    var pdfA = ANP_duplexTempPdfV1423(tempFolder, "A"), pdfB = ANP_duplexTempPdfV1423(tempFolder, "B");
    var colorSpace = ANP_printColorSpaceV23(cfg, links || [], null);
    try {
        if (!metas || metas.length < 2 || !links || links.length < 2 || !layouts || layouts.length < 2) {
            throw new Error("V142.3 Duplex fallback: thiếu dữ liệu A/B.");
        }
        if (!links[0] || !links[0].printPath || !links[1] || !links[1].printPath) {
            throw new Error("V142.3 Duplex fallback: thiếu PRINT-LINK mặt A/B.");
        }
        if (!layouts[0] || !layouts[0].items || !layouts[0].items.length ||
            !layouts[1] || !layouts[1].items || !layouts[1].items.length) {
            throw new Error("V142.3 Duplex fallback: layout A/B rỗng.");
        }

        /* Duplex production policy: only CATTP marks, never auto/corner/file PON. */
        cfgA.ponPath = ""; cfgA.autoPon = false; cfgA.fitPon = false; cfgA.cornerPonRed = false;
        cfgB.ponPath = ""; cfgB.autoPon = false; cfgB.fitPon = false; cfgB.cornerPonRed = false;
        cfgA.finishCropMarks = true; cfgB.finishCropMarks = true;
        cfgA.duplexMode = false; cfgB.duplexMode = false;
        cfgA.addTitle = cfg.addTitle === true;
        cfgB.addTitle = false;

        ANP_buildPrintSheetV12(cfgA, metas[0], links[0], layouts[0], pdfA, title || "");
        if (!pdfA.exists) { throw new Error("V142.3 Duplex fallback: mặt A chưa xuất được PDF tạm."); }
        ANP_buildPrintSheetV12(cfgB, metas[1], links[1], layouts[1], pdfB, "");
        if (!pdfB.exists) { throw new Error("V142.3 Duplex fallback: mặt B chưa xuất được PDF tạm."); }
        ANP_mergeDuplexSidePdfsV1423(cfg, pdfA, pdfB, outFile, colorSpace);
        return true;
    } finally {
        try { if (pdfA && pdfA.exists) { pdfA.remove(); } } catch (eA) {}
        try { if (pdfB && pdfB.exists) { pdfB.remove(); } } catch (eB) {}
    }
}

function ANP_buildDuplexPrintSheetSafeV1423(cfg, metas, links, layouts, outFile, title, tempFolder) {
    var directError = null;
    try {
        ANP_buildDuplexPrintSheetV61(cfg, metas, links, layouts, outFile, title);
        return "DIRECT_V61";
    } catch (e) {
        directError = e;
        if (!ANP_duplexNullObjectErrorV1423(e)) { throw e; }
    }
    try {
        ANP_buildDuplexPrintSheetFallbackV1423(cfg, metas, links, layouts, outFile, title, tempFolder);
        return "FALLBACK_2X1PAGE_V1423";
    } catch (fallbackError) {
        throw new Error("Duplex direct lỗi: " +
            String(directError && directError.message ? directError.message : directError) +
            " | Duplex fallback V142.3 lỗi: " +
            String(fallbackError && fallbackError.message ? fallbackError.message : fallbackError));
    }
}

function ANP_buildPrintSheetV12(cfg, artboardMeta, link, layout, outFile, title) {
    var printSpace = cfg.preservePrintColor === false ? DocumentColorSpace.CMYK :
        ANP_colorSpaceFromModeV23(link.printColorMode);
    var doc = ANP_newDoc(printSpace, cfg, "FILE_IN"), ultraLight = false;
    try {
        var layer = doc.layers[0], master = ANP_linkMaster(doc, layer, link.printPath, "__PRINT_MASTER"), i;
        ANP_prepareTargetLayerV28(doc, layer);
        for (i = 0; i < layout.items.length; i++) {
            ANP_placeIndividualLinkFastV47(doc, layer, master, layout.items[i], cfg, link.bleed, "PRINT_" + (i + 1));
        }
        master.remove(); layer.visible = true; layer.name = "FILE_IN_INDIVIDUAL_LINKS_V47";
        ANP_assertIndividualPrintLinksV47(doc, layout.items.length);
        /* Artboard batch: canh lại bằng bounds thực trước khi lưu/sheet-link. */
        var centerFixV56 = ANP_exactCenterSingleV36(doc, layer);
        var ponLayerV56 = ANP_addPonV12(doc, cfg, title, false);
        ANP_addFinishCropMarksV56(doc, ponLayerV56, layout, cfg, centerFixV56);
        ANP_savePDFDefault(doc, outFile, cfg.preservePrintColor !== false);
        doc.close(SaveOptions.DONOTSAVECHANGES);
    } catch (e) {
        try { doc.close(SaveOptions.DONOTSAVECHANGES); } catch (e0) {}
        throw e;
    }
}

function ANP_buildDieSheetV12(cfg, link, layout, outFile, title, shape) {
    var doc = ANP_newDoc(DocumentColorSpace.CMYK, cfg, "FILE_KHUON");
    var vectorMaster = null;
    try {
        var layer = doc.layers[0], demiDie = cfg.demiMode === true;
        var fastVectorDie = !demiDie && ANP_canFastVectorDieV22(cfg, layout, shape), i;
        ANP_prepareTargetLayerV28(doc, layer);
        if (demiDie) {
            ANP_buildDemiGridV25(doc, layer, layout, cfg);
        } else if (fastVectorDie) {
            ANP_buildFastVectorDieV22(doc, layer, layout, cfg, shape);
        } else {
            vectorMaster = (link.dieGeometry && link.dieGeometry.paths && link.dieGeometry.paths.length) ?
                ANP_makeVectorDieMasterFromGeometryV55(doc, link.dieGeometry, "ARTBOARD") :
                ANP_makeVectorDieMasterV45(doc, link.diePath, "ARTBOARD");
            for (i = 0; i < layout.items.length; i++) {
                ANP_placeVectorDieMasterV45(doc, layer, vectorMaster.group, layout.items[i], cfg, "DIE_" + (i + 1));
            }
            ANP_removeVectorMasterV45(vectorMaster); vectorMaster = null;
            layer.name = "KHUON_BE_VECTOR_MASTER_V45_" + layout.items.length + "PCS";
        }
        layer.visible = true;
        ANP_assertStrokeVectorLayerV37(layer);
        var centerFixV56 = ANP_exactCenterSingleV36(doc, layer);
        var ponLayerV56 = ANP_addPonV12(doc, cfg, "", true);
        ANP_addFinishCropMarksV56(doc, ponLayerV56, layout, cfg, centerFixV56);
        ANP_assertVectorDieV30(doc);
        ANP_savePDFDefault(doc, outFile, false); doc.close(SaveOptions.DONOTSAVECHANGES);
    } catch (e) {
        try { if (vectorMaster) { ANP_removeVectorMasterV45(vectorMaster); } } catch (eMaster) {}
        try { doc.close(SaveOptions.DONOTSAVECHANGES); } catch (e0) {}
        throw e;
    }
}

function ANP_v12Build(json) {
    var originalDoc = null, previousArtboard = 0, previousManualDoc = ANP_STATE.manualDoc, previousManualDie = ANP_STATE.manualDie;
    try {
        var cfg = ANP_parse(json), selected = cfg.artboards || [];
        if (!app.documents.length) { throw new Error("File nhiều artboard không còn mở."); }
        if (!selected.length) { throw new Error("Chưa chọn artboard nào để dàn."); }
        if (!cfg.outputPath) { throw new Error("Hãy chọn thư mục xuất."); }
        originalDoc = app.activeDocument; previousArtboard = originalDoc.artboards.getActiveArtboardIndex();
        var outRoot = new Folder(cfg.outputPath); if (!outRoot.exists) { throw new Error("Thư mục xuất không tồn tại."); }
        var jobBase = ANP_safeBase(cfg.jobName || originalDoc.name);
        var jobFolder = ANP_uniqueFolder(outRoot, jobBase + "_DAN_ARTBOARD");
        var printOutputFolder = ANP_ensureOutputFolderV31(jobFolder, "FILE IN");
        var dieOutputFolder = printOutputFolder;
        var linkFolder = new Folder(jobFolder.fsName + "/LINK_FILES");
        if (!linkFolder.create()) { throw new Error("Không tạo được thư mục LINK_FILES."); }
        var groups = ANP_groupArtboardsV12(selected), g, a, meta, die, link, layout, sheetLayout, groupLink = null;
        var duplex = ANP_validateDuplexV60(cfg, selected, groups);
        var includeDie = !duplex && cfg.finishCropMarks !== true && String(cfg.outputMode || "both") !== "print_only";
        var printCount = 0, dieCount = 0, ultraGroupCount = 0, created = [], printFile, dieFile, title, number, dieMeta;
        var duplexMetas = [], duplexLinks = [], duplexLayouts = [], duplexBuildMode = "";

        if (duplex) {
            g = 0; try { layout = ANP_artboardLayoutV12(cfg, groups[0].width, groups[0].height, groups[0].shape); } catch (eDuplexLayoutV1484) { throw new Error("Duplex nhóm 1 [" + groups[0].width + "x" + groups[0].height + "mm] layout lỗi: " + String(eDuplexLayoutV1484 && eDuplexLayoutV1484.message ? eDuplexLayoutV1484.message : eDuplexLayoutV1484)); }
            if (ANP_isUltraLightV24(cfg, layout)) { ultraGroupCount++; }
            for (a = 0; a < 2; a++) {
                meta = groups[0].artboards[a]; originalDoc.artboards.setActiveArtboardIndex(Number(meta.artboardIndex));
                die = ANP_dieForArtboard(originalDoc, Number(meta.artboardIndex), cfg.dieHint || "");
                ANP_STATE.manualDoc = originalDoc; ANP_STATE.manualDie = die;
                meta.active = true; meta._linkIndex = a; meta.useArtboardBounds = true;
                meta.forceArtboardDie = meta.dieFallback === true || !die.length;
                link = ANP_createLinkPair(originalDoc, meta, cfg, linkFolder);
                duplexMetas.push(meta); duplexLinks.push(link);
                duplexLayouts.push(ANP_duplexLayoutV60(layout, cfg, a === 1));
            }
            title = ANP_duplexOutputTitleV61(cfg, groups[0], duplexMetas[0], duplexMetas[1], layout.items.length);
            printFile = new File(printOutputFolder.fsName + "/" + title + ".pdf");
            duplexBuildMode = ANP_buildDuplexPrintSheetSafeV1423(cfg, duplexMetas, duplexLinks, duplexLayouts, printFile, title, linkFolder);
            created.push(printFile.fsName); printCount = 1;
        } else {
            for (g = 0; g < groups.length; g++) {
                try { layout = ANP_artboardLayoutV12(cfg, groups[g].width, groups[g].height, groups[g].shape); } catch (eLayoutBuildV1484) { throw new Error("Build nhóm " + groups[g].groupNumber + " [" + groups[g].width + "x" + groups[g].height + "mm] layout lỗi: " + String(eLayoutBuildV1484 && eLayoutBuildV1484.message ? eLayoutBuildV1484.message : eLayoutBuildV1484)); } groupLink = null;
                if (ANP_isUltraLightV24(cfg, layout)) { ultraGroupCount++; }
                for (a = 0; a < groups[g].artboards.length; a++) {
                    meta = groups[g].artboards[a]; originalDoc.artboards.setActiveArtboardIndex(Number(meta.artboardIndex));
                    die = ANP_dieForArtboard(originalDoc, Number(meta.artboardIndex), cfg.dieHint || "");
                    ANP_STATE.manualDoc = originalDoc; ANP_STATE.manualDie = die;
                    meta.active = true; meta._linkIndex = printCount; meta.useArtboardBounds = true;
                    meta.forceArtboardDie = meta.dieFallback === true || !die.length;
                    try { link = ANP_createLinkPair(originalDoc, meta, cfg, linkFolder); }
                    catch (eLinkV1483) { throw new Error("Artboard " + String(meta.displayIndex || (Number(meta.artboardIndex)+1)) + " [" + groups[g].width + "x" + groups[g].height + "mm] tạo LINK lỗi: " + String(eLinkV1483 && eLinkV1483.message ? eLinkV1483.message : eLinkV1483)); }
                    if (!link || !link.printPath) { throw new Error("Artboard " + String(meta.displayIndex || (Number(meta.artboardIndex)+1)) + " không tạo được PRINT-LINK."); }
                    if (!groupLink) { groupLink = link; }
                    number = ANP_sequenceNumberV1489(cfg.outputPrintStart, printCount,
                        cfg.finishCropMarks === true ? String(printCount + 1) : groups[g].groupNumber + "." + (a + 1));
                    title = ANP_printTitleV15(number, originalDoc.name, meta.name, groups[g].width,
                        groups[g].height, cfg, layout.items.length, "");
                    printFile = new File(printOutputFolder.fsName + "/" + title + ".pdf");
                    try { ANP_buildPrintSheetV12(cfg, meta, link, layout, printFile, title); }
                    catch (ePrintV1483) { throw new Error("Artboard " + String(meta.displayIndex || (Number(meta.artboardIndex)+1)) + " xuất FILE IN lỗi: " + String(ePrintV1483 && ePrintV1483.message ? ePrintV1483.message : ePrintV1483)); }
                    created.push(printFile.fsName); printCount++;
                }
                if (includeDie) {
                    dieMeta = groups[g].artboards[0];
                    title = ANP_dieTitleV15(ANP_sequenceNumberV1489(cfg.outputDieStart, dieCount, String(groups[g].groupNumber)), groups[g].width,
                        groups[g].height, cfg, layout.items.length);
                    dieFile = new File(dieOutputFolder.fsName + "/" + title + ".pdf");
                    if (!groupLink) { throw new Error("Nhóm " + groups[g].width + "x" + groups[g].height + " mm chưa tạo được Link khuôn."); }
                    try { ANP_buildDieSheetV12(cfg, groupLink, layout, dieFile, "", groups[g].shape); }
                    catch (eDieV1483) { throw new Error("Nhóm " + groups[g].width + "x" + groups[g].height + " mm xuất FILE KHUÔN lỗi: " + String(eDieV1483 && eDieV1483.message ? eDieV1483.message : eDieV1483)); }
                    created.push(dieFile.fsName); dieCount++;
                }
            }
        }
        ANP_STATE.manualDoc = previousManualDoc; ANP_STATE.manualDie = previousManualDie;
        originalDoc.artboards.setActiveArtboardIndex(previousArtboard); originalDoc.activate();
        return ANP_ok({
            outputFolder: jobFolder.fsName, printFileCount: printCount, dieFileCount: dieCount,
            printFolder: printOutputFolder.fsName, dieFolder: dieOutputFolder.fsName,
            groupCount: groups.length, ultraGroupCount: ultraGroupCount, cattp:cfg.finishCropMarks === true,
            duplex:duplex, duplexFlip:cfg.duplexFlip, duplexBuildMode:duplexBuildMode || (duplex ? "DIRECT_V61" : ""), pageCount:duplex ? 2 : printCount,
            created: created
        });
    } catch (e) {
        try { ANP_STATE.manualDoc = previousManualDoc; ANP_STATE.manualDie = previousManualDie; } catch (e0) {}
        try { if (originalDoc) { originalDoc.artboards.setActiveArtboardIndex(previousArtboard); originalDoc.activate(); } } catch (e1) {}
        return ANP_fail(e);
    }
}


/* ===== V71 VARIABLE DATA / SMARTSTREAM-LIKE ===== */
var ANP_VDP_SESSION_V71 = ANP_VDP_SESSION_V71 || { docKey:"", originals:{}, wasSaved:false };
var ANP_VDP_SEQ_V71 = ANP_VDP_SEQ_V71 || 0;


/* V80: khóa file nguồn VDP theo document/UUID đã chọn, không phụ thuộc tab đang active.
   Tránh trường hợp user vừa mở PDF kết quả hoặc Illustrator đổi activeDocument sang
   work/merge document rồi BatchStart hiểu nhầm PDF đó là file nguồn. */
var ANP_VDP_SOURCE_V80 = ANP_VDP_SOURCE_V80 || { path:"", name:"", docKey:"" };

function ANP_vdpPathV80(doc) {
    try { return doc.fullName ? String(doc.fullName.fsName || "") : ""; } catch (e) {}
    return "";
}

function ANP_vdpIsAiDocV80(doc) {
    var p = ANP_vdpPathV80(doc), n = "";
    try { n = String(doc.name || ""); } catch (e0) {}
    p = String(p || n).toLowerCase();
    return /\.ai$/i.test(p.replace(/^\s+|\s+$/g, ""));
}

function ANP_vdpRememberSourceV80(doc) {
    if (!doc) { return; }
    try { ANP_VDP_SOURCE_V80.path = ANP_vdpPathV80(doc); } catch (e0) {}
    try { ANP_VDP_SOURCE_V80.name = String(doc.name || ""); } catch (e1) {}
    try { ANP_VDP_SOURCE_V80.docKey = ANP_vdpDocKeyV71(doc); } catch (e2) {}
}

function ANP_vdpDocMatchesMappingsV80(doc, mappings) {
    var i, id, found = 0;
    if (!doc || !mappings || !mappings.length) { return false; }
    for (i = 0; i < mappings.length; i++) {
        id = String(mappings[i].targetId || "");
        if (!id) { continue; }
        try { if (ANP_vdpFindByTokenV71(doc, id)) { found++; } else { return false; } }
        catch (e0) { return false; }
    }
    return found > 0;
}

function ANP_vdpResolveSourceDocV80(mappings) {
    var i, d, p = String(ANP_VDP_SOURCE_V80.path || ""), active = null, candidate = null;
    try { active = app.activeDocument; } catch (e0) { active = null; }

    /* 1) Ưu tiên đúng path đã khóa lúc user chọn đối tượng. */
    if (p) {
        for (i = 0; i < app.documents.length; i++) {
            d = app.documents[i];
            try { if (ANP_vdpPathV80(d).toLowerCase() === p.toLowerCase()) { return d; } } catch (e1) {}
        }
    }

    /* 2) Tìm document .AI đang mở có đầy đủ UUID/target mapping. */
    for (i = 0; i < app.documents.length; i++) {
        d = app.documents[i];
        if (!ANP_vdpIsAiDocV80(d)) { continue; }
        if (ANP_vdpDocMatchesMappingsV80(d, mappings)) { return d; }
    }

    /* 3) Nếu active là .AI và chứa mapping thì dùng nó. */
    if (active && ANP_vdpIsAiDocV80(active) && ANP_vdpDocMatchesMappingsV80(active, mappings)) { return active; }

    /* 4) Nếu file nguồn đã khóa bị đóng nhưng path còn tồn tại, mở lại đúng .AI đó. */
    if (p && /\.ai$/i.test(p)) {
        try {
            var f = new File(p);
            if (f.exists) {
                d = app.open(f);
                if (ANP_vdpDocMatchesMappingsV80(d, mappings)) { return d; }
                try { d.close(SaveOptions.DONOTSAVECHANGES); } catch (eClose) {}
            }
        } catch (e2) {}
    }

    /* 5) Không tự chọn PDF/EPS/SVG làm nguồn Fidelity. */
    return null;
}

function ANP_vdpDocKeyV71(doc) {
    var p = "";
    try { p = doc.fullName.fsName; } catch (e0) { try { p = doc.name; } catch (e1) {} }
    return String(p || "") + "|" + String(doc.pageItems.length);
}

function ANP_vdpTokenV71() {
    ANP_VDP_SEQ_V71++;
    return "DPVVDP_" + String((new Date()).getTime()) + "_" + String(ANP_VDP_SEQ_V71);
}

function ANP_vdpNoteTokenV71(note) {
    var s = String(note || ""), pos = s.indexOf("DPVVDP:"), tail, end;
    if (pos < 0) { return ""; }
    tail = s.substring(pos + 7); end = tail.indexOf("\n");
    if (end >= 0) { tail = tail.substring(0, end); }
    return tail.replace(/^\s+|\s+$/g, "");
}

function ANP_vdpGetTokenV71(item) {
    var note = "", name = "", token = "", found = "";
    try { note = String(item.note || ""); } catch (e0) {}
    found = ANP_vdpNoteTokenV71(note); if (found) { return found; }
    try { name = String(item.name || ""); } catch (e1) {}
    if (name.indexOf("__DPVVDP_") === 0) { return name.substring(9); }
    token = ANP_vdpTokenV71();
    try { item.note = note + (note ? "\n" : "") + "DPVVDP:" + token; return token; } catch (e2) {}
    try { item.name = "__DPVVDP_" + token; return token; } catch (e3) {}
    return token;
}

function ANP_vdpFindByTokenV71(doc, token) {
    var i, it, note, name, uuid;
    token = String(token || "");
    if (token.indexOf("UUID:") === 0) {
        uuid = token.substring(5);
        try { it = doc.getPageItemFromUuid(uuid); if (it) { return it; } } catch (eUuid) {}
        /* Fallback scan UUID nếu getPageItemFromUuid không trả về do document vừa mở. */
        for (i = 0; i < doc.pageItems.length; i++) {
            try { if (String(doc.pageItems[i].uuid || "") === uuid) { return doc.pageItems[i]; } } catch (eUuid2) {}
        }
        return null;
    }
    for (i = 0; i < doc.pageItems.length; i++) {
        it = doc.pageItems[i]; note = ""; name = "";
        try { note = String(it.note || ""); } catch (e0) {}
        if (ANP_vdpNoteTokenV71(note) === token) { return it; }
        try { name = String(it.name || ""); } catch (e1) {}
        if (name === "__DPVVDP_" + token) { return it; }
    }
    return null;
}

function ANP_vdpSupportedV71(item) {
    var t = ""; try { t = String(item.typename || ""); } catch (e) {}
    return t === "TextFrame" || t === "PlacedItem" || t === "RasterItem" ||
        t === "PathItem" || t === "CompoundPathItem" || t === "GroupItem" || t === "SymbolItem";
}

function ANP_vdpFlattenSelectionV71(item, out) {
    var i, t = "";
    if (!item) { return; }
    try { t = String(item.typename || ""); } catch (e0) {}
    if (t === "GroupItem") {
        try {
            for (i = 0; i < item.pageItems.length; i++) { ANP_vdpFlattenSelectionV71(item.pageItems[i], out); }
            return;
        } catch (e1) {}
    }
    if (ANP_vdpSupportedV71(item)) { out.push(item); }
}

function ANP_vdpLabelV71(item, index) {
    var n = "", t = "", c = "";
    try { n = String(item.name || ""); } catch (e0) {}
    try { t = String(item.typename || "Object"); } catch (e1) { t = "Object"; }
    if (n && n.indexOf("__DPVVDP_") !== 0) { return n; }
    if (t === "TextFrame") {
        try { c = String(item.contents || "").replace(/[\r\n]+/g, " "); if (c.length > 34) { c = c.substring(0, 34) + "…"; } } catch (e2) {}
        if (c) { return c; }
    }
    return t + " " + String(index + 1);
}

function ANP_vdpSuggestedActionV71(item) {
    var t = String(item.typename || "");
    if (t === "TextFrame") { return "text"; }
    if (t === "PlacedItem") { return "image"; }
    if (t === "PathItem" || t === "CompoundPathItem") { return "fillColor"; }
    return "visibility";
}

function ANP_vdpSelectionV71() {
    try {
        if (!app.documents.length) { throw new Error("Chưa mở tài liệu Illustrator."); }
        var doc = app.activeDocument, sel = doc.selection, flat = [], out = [], i, item, token;
        if (!sel || !sel.length) { throw new Error("Hãy chọn Text, ảnh link, shape hoặc group trong Illustrator trước."); }
        for (i = 0; i < sel.length; i++) { ANP_vdpFlattenSelectionV71(sel[i], flat); }
        if (!flat.length) { throw new Error("Không tìm thấy đối tượng phù hợp trong vùng đang chọn."); }
        var seen = {};
        for (i = 0; i < flat.length; i++) {
            item = flat[i]; token = "";
            /* Illustrator 2024-2026 có PageItem.uuid. Dùng UUID read-only để map
               mà KHÔNG ghi note/name vào file thiết kế, giúp tài liệu không bị dirty. */
            try { if (item.uuid) { token = "UUID:" + String(item.uuid); } } catch (eUuid) { token = ""; }
            if (!token) { token = ANP_vdpGetTokenV71(item); }
            if (seen[token]) { continue; } seen[token] = true;
            out.push({ id:token, label:ANP_vdpLabelV71(item, i), itemType:String(item.typename || "Object"), action:ANP_vdpSuggestedActionV71(item) });
        }
        ANP_vdpRememberSourceV80(doc);
        return ANP_ok({ targets:out, documentName:doc.name, documentPath:ANP_vdpPathV80(doc), sourcePinned:true, count:out.length });
    } catch (e) { return ANP_fail(e); }
}

function ANP_vdpColorDescriptorV71(color) {
    if (!color) { return { model:"none" }; }
    var t = ""; try { t = String(color.typename || ""); } catch (e0) {}
    if (t === "RGBColor") { return { model:"rgb", r:Number(color.red), g:Number(color.green), b:Number(color.blue) }; }
    if (t === "CMYKColor") { return { model:"cmyk", c:Number(color.cyan), m:Number(color.magenta), y:Number(color.yellow), k:Number(color.black) }; }
    if (t === "GrayColor") { return { model:"gray", g:Number(color.gray) }; }
    return { model:"none" };
}

function ANP_vdpColorFromDescriptorV71(d) {
    var c;
    if (!d) { return null; }
    if (d.model === "rgb") { c = new RGBColor(); c.red=d.r; c.green=d.g; c.blue=d.b; return c; }
    if (d.model === "cmyk") { c = new CMYKColor(); c.cyan=d.c; c.magenta=d.m; c.yellow=d.y; c.black=d.k; return c; }
    if (d.model === "gray") { c = new GrayColor(); c.gray=d.g; return c; }
    return null;
}

function ANP_vdpGetFillColorV71(item) {
    var t = String(item.typename || "");
    if (t === "TextFrame") { return item.textRange.characterAttributes.fillColor; }
    if (t === "PathItem") { return item.fillColor; }
    if (t === "CompoundPathItem" && item.pathItems && item.pathItems.length) { return item.pathItems[0].fillColor; }
    return null;
}

function ANP_vdpSetFillColorV71(item, color) {
    var t = String(item.typename || "");
    if (t === "TextFrame") { item.textRange.characterAttributes.fillColor = color; return true; }
    if (t === "PathItem") { try { item.filled = true; } catch (e0) {} item.fillColor = color; return true; }
    if (t === "CompoundPathItem" && item.pathItems && item.pathItems.length) {
        try { item.pathItems[0].filled = true; } catch (e1) {}
        item.pathItems[0].fillColor = color; return true;
    }
    return false;
}



/* V138 NO-STROKE + V137 EXACT TEXT TEMPLATE FIDELITY
   Mỗi TextFrame VDP giữ một snapshot typography RIÊNG theo targetId. Không lấy style
   từ record vừa chạy trước đó. Sau khi đổi contents, style được áp lại trên toàn bộ
   TextRange VÀ từng Character để Illustrator không rơi về font/size mặc định.
   Mục tiêu: artboard A có chữ lớn và artboard B có chữ nhỏ vẫn giữ đúng độc lập. */
var ANP_VDP_TEXT_STYLE_CACHE_V137 = {};

/* V138 NO-STROKE FIDELITY
   Illustrator may report a non-zero strokeWeight even when text strokeColor is NoColor.
   Re-applying that weight after replacing contents can activate Illustrator's default black
   stroke. V138 records whether a real stroke exists and explicitly restores NoColor when not. */
function ANP_vdpTextHasRealStrokeV138(ca) {
    var c, t = "", w = 0;
    if (!ca) { return false; }
    try { c = ca.strokeColor; t = String(c ? (c.typename || "") : ""); } catch (e0) { t = ""; }
    try { w = Number(ca.strokeWeight); } catch (e1) { w = 0; }
    if (!t || t === "NoColor") { return false; }
    return w > 0;
}

function ANP_vdpClearTextStrokeV138(ca) {
    if (!ca) { return false; }
    try { ca.strokeColor = new NoColor(); } catch (e0) {}
    try { ca.strokeWeight = 0; } catch (e1) {}
    try { ca.overprintStroke = false; } catch (e2) {}
    return true;
}

function ANP_vdpCaptureTextStyleV137(tf) {
    var s = {}, tr, ca, pa, f;
    if (!tf || String(tf.typename || "") !== "TextFrame") { return s; }
    try { tr = tf.textRange; ca = (tf.characters && tf.characters.length) ? tf.characters[0].characterAttributes : tr.characterAttributes; pa = tr.paragraphAttributes; } catch (e0) { return s; }
    try { f = ca.textFont; s.fontName = f ? String(f.name || "") : ""; s.fontFamily = f ? String(f.family || "") : ""; s.fontStyle = f ? String(f.style || "") : ""; } catch (e1) {}
    try { s.size = Number(ca.size); } catch (e2) {}
    try { s.leading = Number(ca.leading); } catch (e3) {}
    try { s.autoLeading = ca.autoLeading === true; } catch (e4) {}
    try { s.tracking = Number(ca.tracking); } catch (e5) {}
    try { s.horizontalScale = Number(ca.horizontalScale); } catch (e6) {}
    try { s.verticalScale = Number(ca.verticalScale); } catch (e7) {}
    try { s.baselineShift = Number(ca.baselineShift); } catch (e8) {}
    try { s.rotation = Number(ca.rotation); } catch (e9) {}
    try { s.fill = ANP_vdpColorDescriptorV71(ca.fillColor); } catch (e10) {}
    try { s.strokeEnabledV138 = ANP_vdpTextHasRealStrokeV138(ca); } catch (e11a) { s.strokeEnabledV138 = false; }
    if (s.strokeEnabledV138) {
        try { s.stroke = ANP_vdpColorDescriptorV71(ca.strokeColor); } catch (e11) {}
        try { s.strokeWeight = Number(ca.strokeWeight); } catch (e12) {}
    } else {
        s.stroke = { model:"none" };
        s.strokeWeight = 0;
    }
    try { s.overprintFill = ca.overprintFill === true; } catch (e13) {}
    try { s.overprintStroke = ca.overprintStroke === true; } catch (e14) {}
    try { s.capitalization = ca.capitalization; } catch (e15) {}
    try { s.baselinePosition = ca.baselinePosition; } catch (e16) {}
    try { s.justification = pa.justification; } catch (e17) {}
    try { s.autoLeadingAmount = Number(pa.autoLeadingAmount); } catch (e18) {}
    try { s.firstLineIndent = Number(pa.firstLineIndent); } catch (e19) {}
    try { s.leftIndent = Number(pa.leftIndent); } catch (e20) {}
    try { s.rightIndent = Number(pa.rightIndent); } catch (e21) {}
    try { s.spaceBefore = Number(pa.spaceBefore); } catch (e22) {}
    try { s.spaceAfter = Number(pa.spaceAfter); } catch (e23) {}
    try { s.direction = pa.direction; } catch (e24) {}
    try { s.kind = tf.kind; } catch (e25) {}
    return s;
}

function ANP_vdpFindFontV137(s) {
    var i, f;
    if (!s) { return null; }
    if (s.fontName) { try { return app.textFonts.getByName(String(s.fontName)); } catch (e0) {} }
    if (s.fontFamily || s.fontStyle) {
        try {
            for (i = 0; i < app.textFonts.length; i++) {
                f = app.textFonts[i];
                if ((!s.fontFamily || String(f.family || "") === String(s.fontFamily)) && (!s.fontStyle || String(f.style || "") === String(s.fontStyle))) { return f; }
            }
        } catch (e1) {}
    }
    return null;
}

function ANP_vdpApplyCharStyleV137(ca, s) {
    var font, c;
    if (!ca || !s) { return false; }
    font = ANP_vdpFindFontV137(s); if (font) { try { ca.textFont = font; } catch (e0) {} }
    if (s.size > 0) { try { ca.size = Number(s.size); } catch (e1) {} }
    if (s.autoLeading !== undefined) { try { ca.autoLeading = s.autoLeading === true; } catch (e2) {} }
    if (!s.autoLeading && s.leading > 0) { try { ca.leading = Number(s.leading); } catch (e3) {} }
    if (!isNaN(s.tracking)) { try { ca.tracking = Number(s.tracking); } catch (e4) {} }
    if (s.horizontalScale > 0) { try { ca.horizontalScale = Number(s.horizontalScale); } catch (e5) {} }
    if (s.verticalScale > 0) { try { ca.verticalScale = Number(s.verticalScale); } catch (e6) {} }
    if (!isNaN(s.baselineShift)) { try { ca.baselineShift = Number(s.baselineShift); } catch (e7) {} }
    if (!isNaN(s.rotation)) { try { ca.rotation = Number(s.rotation); } catch (e8) {} }
    if (s.fill) { c = ANP_vdpColorFromDescriptorV71(s.fill); if (c) { try { ca.fillColor = c; } catch (e9) {} } }
    if (s.strokeEnabledV138 === false || (s.stroke && s.stroke.model === "none")) {
        ANP_vdpClearTextStrokeV138(ca);
    } else if (s.strokeEnabledV138 === true) {
        if (s.stroke) { c = ANP_vdpColorFromDescriptorV71(s.stroke); if (c) { try { ca.strokeColor = c; } catch (e10) {} } }
        if (!isNaN(s.strokeWeight) && Number(s.strokeWeight) > 0) { try { ca.strokeWeight = Number(s.strokeWeight); } catch (e11) {} }
    }
    if (s.overprintFill !== undefined) { try { ca.overprintFill = s.overprintFill === true; } catch (e12) {} }
    if (s.overprintStroke !== undefined) { try { ca.overprintStroke = s.overprintStroke === true; } catch (e13) {} }
    if (s.capitalization !== undefined) { try { ca.capitalization = s.capitalization; } catch (e14) {} }
    if (s.baselinePosition !== undefined) { try { ca.baselinePosition = s.baselinePosition; } catch (e15) {} }
    return true;
}

function ANP_vdpApplyParagraphStyleV137(pa, s) {
    if (!pa || !s) { return false; }
    if (s.justification !== undefined) { try { pa.justification = s.justification; } catch (e0) {} }
    if (s.autoLeadingAmount > 0) { try { pa.autoLeadingAmount = Number(s.autoLeadingAmount); } catch (e1) {} }
    if (!isNaN(s.firstLineIndent)) { try { pa.firstLineIndent = Number(s.firstLineIndent); } catch (e2) {} }
    if (!isNaN(s.leftIndent)) { try { pa.leftIndent = Number(s.leftIndent); } catch (e3) {} }
    if (!isNaN(s.rightIndent)) { try { pa.rightIndent = Number(s.rightIndent); } catch (e4) {} }
    if (!isNaN(s.spaceBefore)) { try { pa.spaceBefore = Number(s.spaceBefore); } catch (e5) {} }
    if (!isNaN(s.spaceAfter)) { try { pa.spaceAfter = Number(s.spaceAfter); } catch (e6) {} }
    if (s.direction !== undefined) { try { pa.direction = s.direction; } catch (e7) {} }
    return true;
}

function ANP_vdpApplyTextStyleV137(tf, s) {
    var tr, i;
    if (!tf || !s || String(tf.typename || "") !== "TextFrame") { return false; }
    try { tr = tf.textRange; } catch (e0) { return false; }
    try { ANP_vdpApplyCharStyleV137(tr.characterAttributes, s); } catch (e1) {}
    /* Illustrator đôi lúc không propagate style từ TextRange xuống text mới.
       Áp lại từng character là chậm hơn chút nhưng rất ổn định và text VDP thường ngắn. */
    try { for (i = 0; i < tf.characters.length; i++) { ANP_vdpApplyCharStyleV137(tf.characters[i].characterAttributes, s); } } catch (e2) {}
    try { ANP_vdpApplyParagraphStyleV137(tr.paragraphAttributes, s); } catch (e3) {}
    try { for (i = 0; i < tf.paragraphs.length; i++) { ANP_vdpApplyParagraphStyleV137(tf.paragraphs[i].paragraphAttributes, s); } } catch (e4) {}
    return true;
}

function ANP_vdpSetTextExactV137(tf, newText, exactStyle) {
    var st = exactStyle || ANP_vdpCaptureTextStyleV137(tf);
    try { tf.contents = String(newText == null ? "" : newText); } catch (e0) { throw e0; }
    ANP_vdpApplyTextStyleV137(tf, st);
    return true;
}

/* Compatibility alias: các nhánh cũ gọi tên V136 vẫn được route sang engine V137. */
function ANP_vdpSetTextPreserveStyleV136(tf, newText) { return ANP_vdpSetTextExactV137(tf, newText, null); }

function ANP_vdpCaptureOneV71(doc, mapping) {
    var id = String(mapping.targetId || ""), item, t, o, col;
    if (!id || ANP_VDP_SESSION_V71.originals[id]) { return; }
    item = ANP_vdpFindByTokenV71(doc, id); if (!item) { return; }
    t = String(item.typename || ""); o = { type:t };
    try { o.hidden = item.hidden === true; } catch (e0) { o.hidden = false; }
    if (t === "TextFrame") { try { o.text = String(item.contents || ""); o.textStyleV137 = ANP_vdpCaptureTextStyleV137(item); ANP_VDP_TEXT_STYLE_CACHE_V137[id] = o.textStyleV137; } catch (e1) {} }
    if (t === "PlacedItem") { try { o.file = item.file ? item.file.fsName : ""; } catch (e2) {} }
    try {
        col = ANP_vdpGetFillColorV71(item);
        o.fill = ANP_vdpColorDescriptorV71(col);
    } catch (e3) {}
    ANP_VDP_SESSION_V71.originals[id] = o;
}

function ANP_vdpEnsureSessionV71(doc, mappings) {
    var key = ANP_vdpDocKeyV71(doc), i, wasSaved = false;
    if (ANP_VDP_SESSION_V71.docKey !== key) {
        try { wasSaved = doc.saved === true; } catch (eSaved0) { wasSaved = false; }
        ANP_VDP_SESSION_V71 = { docKey:key, originals:{}, wasSaved:wasSaved };
    }
    for (i = 0; i < mappings.length; i++) { ANP_vdpCaptureOneV71(doc, mappings[i]); }
}

function ANP_vdpRestoreDocV71(doc) {
    var id, o, item, c;
    if (!doc || ANP_VDP_SESSION_V71.docKey !== ANP_vdpDocKeyV71(doc)) { return 0; }
    var count = 0;
    for (id in ANP_VDP_SESSION_V71.originals) {
        if (!ANP_VDP_SESSION_V71.originals.hasOwnProperty(id)) { continue; }
        o = ANP_VDP_SESSION_V71.originals[id]; item = ANP_vdpFindByTokenV71(doc, id); if (!item) { continue; }
        try { item.hidden = o.hidden === true; } catch (e0) {}
        if (o.type === "TextFrame" && o.text !== undefined) { try { ANP_vdpSetTextExactV137(item, o.text, o.textStyleV137 || ANP_VDP_TEXT_STYLE_CACHE_V137[id] || null); } catch (e1) {} }
        if (o.type === "PlacedItem" && o.file) { try { item.relink(new File(o.file)); } catch (e2) {} }
        if (o.fill) {
            c = ANP_vdpColorFromDescriptorV71(o.fill);
            if (c) { try { ANP_vdpSetFillColorV71(item, c); } catch (e3) {} }
        }
        count++;
    }
    /* Preview bắt đầu từ file đã Save và đã restore đúng state gốc thì cố giữ
       trạng thái clean. Nếu Illustrator không cho set saved, lệnh này tự bỏ qua. */
    if (count > 0 && ANP_VDP_SESSION_V71.wasSaved === true) { try { doc.saved = true; } catch (eSaved1) {} }
    return count;
}

function ANP_vdpTruthyV71(value) {
    var s = String(value == null ? "" : value).toLowerCase().replace(/^\s+|\s+$/g, "");
    return !(s === "" || s === "0" || s === "false" || s === "no" || s === "off" || s === "hide" || s === "ẩn");
}

function ANP_vdpParseColorV71(value) {
    var s = String(value == null ? "" : value).replace(/^\s+|\s+$/g, ""), m, c, a;
    if (!s) { return null; }
    m = /^#?([0-9a-f]{6})$/i.exec(s);
    if (m) { c = new RGBColor(); c.red=parseInt(m[1].substr(0,2),16); c.green=parseInt(m[1].substr(2,2),16); c.blue=parseInt(m[1].substr(4,2),16); return c; }
    if (/^rgb\s*\(/i.test(s)) { a=s.replace(/[^0-9.,-]/g,"").split(","); if(a.length>=3){c=new RGBColor();c.red=Number(a[0]);c.green=Number(a[1]);c.blue=Number(a[2]);return c;} }
    if (/^cmyk\s*\(/i.test(s)) { a=s.replace(/[^0-9.,-]/g,"").split(","); if(a.length>=4){c=new CMYKColor();c.cyan=Number(a[0]);c.magenta=Number(a[1]);c.yellow=Number(a[2]);c.black=Number(a[3]);return c;} }
    a=s.split(","); if(a.length===3){c=new RGBColor();c.red=Number(a[0]);c.green=Number(a[1]);c.blue=Number(a[2]);return c;}
    if(a.length===4){c=new CMYKColor();c.cyan=Number(a[0]);c.magenta=Number(a[1]);c.yellow=Number(a[2]);c.black=Number(a[3]);return c;}
    return null;
}

function ANP_vdpResolveImageV71(value, sourceFolder) {
    var raw = String(value == null ? "" : value).replace(/^\s+|\s+$/g, ""), f;
    if (!raw) { return null; }
    f = new File(raw); if (f.exists) { return f; }
    if (sourceFolder) { f = new File(String(sourceFolder) + "/" + raw); if (f.exists) { return f; } }
    return null;
}

function ANP_vdpApplyOneV71(doc, mapping, record, sourceFolder) {
    var item = ANP_vdpFindByTokenV71(doc, String(mapping.targetId || "")), field = String(mapping.field || ""), action = String(mapping.action || "text"), value, file, color;
    if (!item || !field) { return false; }
    value = record && record[field] !== undefined ? record[field] : "";
    if (action === "text") {
        if (String(item.typename) !== "TextFrame") { throw new Error("Kênh Text không trỏ tới TextFrame: " + String(mapping.label || mapping.targetId)); }
        ANP_vdpSetTextExactV137(item, String(mapping.prefix || "") + String(value == null ? "" : value) + String(mapping.suffix || ""), ANP_VDP_TEXT_STYLE_CACHE_V137[String(mapping.targetId || "")] || null); return true;
    }
    if (action === "image") {
        if (String(item.typename) !== "PlacedItem") { throw new Error("Kênh Image hiện yêu cầu ảnh Linked/PlacedItem: " + String(mapping.label || mapping.targetId)); }
        file = ANP_vdpResolveImageV71(value, sourceFolder); if (!file) { throw new Error("Không tìm thấy ảnh: " + String(value)); }
        var oldBounds = null, oldW = 0, oldH = 0;
        try { oldBounds = item.geometricBounds; oldW = Number(oldBounds[2] - oldBounds[0]); oldH = Number(oldBounds[1] - oldBounds[3]); } catch (eImg0) {}
        item.relink(file);
        if (oldBounds && oldW > 0 && oldH > 0) { try { item.width = oldW; item.height = oldH; item.position = [oldBounds[0], oldBounds[1]]; } catch (eImg1) {} }
        return true;
    }
    if (action === "visibility") { item.hidden = !ANP_vdpTruthyV71(value); return true; }
    if (action === "fillColor") {
        color = ANP_vdpParseColorV71(value); if (!color) { throw new Error("Màu không hợp lệ: " + String(value) + ". Dùng #RRGGBB, R,G,B hoặc C,M,Y,K."); }
        if (!ANP_vdpSetFillColorV71(item, color)) { throw new Error("Đối tượng không hỗ trợ Fill Color: " + String(mapping.label || mapping.targetId)); }
        return true;
    }
    return false;
}

function ANP_vdpApplyRecordV71(doc, mappings, record, sourceFolder, skipRedraw) {
    var i, applied = 0;
    for (i = 0; i < mappings.length; i++) { if (ANP_vdpApplyOneV71(doc, mappings[i], record, sourceFolder)) { applied++; } }
    if (!skipRedraw) { try { app.redraw(); } catch (e) {} }
    return applied;
}

/* ===== V141 VDP PREFLIGHT PRO — READ ONLY ===== */
function ANP_vdpPreflightV141(cfg, doc) {
    var mappings = cfg.mappings || [], records = [], parsed = null, sourceFolder = String(cfg.sourceFolder || ""),
        start = 1, end = 0, offset = Number(cfg.recordOffset || 0), i, j, m, item, action, field, value, file,
        targetFound = 0, missingTargetCount = 0, typeErrorCount = 0, imageChecked = 0, imageMissingCount = 0,
        colorChecked = 0, colorInvalidCount = 0, missingTargets = [], typeErrors = [], imageMissing = [], colorInvalid = [],
        maxSamples = 24, recNo, c = null;
    if (cfg.dataPath) { parsed = ANP_vdpReadDataFileV71(String(cfg.dataPath)); records = parsed.records || []; }
    else { records = cfg.records || []; }
    start = Math.max(1, Math.floor(Number(cfg.from || 1)));
    end = Math.min(records.length, Math.max(start, Math.floor(Number(cfg.to || records.length))));
    for (i = 0; i < mappings.length; i++) {
        m = mappings[i] || {}; action = String(m.action || "text"); field = String(m.field || "");
        item = ANP_vdpFindByTokenV71(doc, String(m.targetId || ""));
        if (!item) {
            missingTargetCount++;
            if (missingTargets.length < maxSamples) { missingTargets.push({ label:String(m.label || m.targetId || ("Target " + String(i + 1))), targetId:String(m.targetId || "") }); }
            continue;
        }
        targetFound++;
        if (action === "text" && String(item.typename) !== "TextFrame") {
            typeErrorCount++;
            if (typeErrors.length < maxSamples) { typeErrors.push({ label:String(m.label || m.targetId), expected:"TextFrame", actual:String(item.typename) }); }
        }
        if (action === "image" && String(item.typename) !== "PlacedItem") {
            typeErrorCount++;
            if (typeErrors.length < maxSamples) { typeErrors.push({ label:String(m.label || m.targetId), expected:"PlacedItem", actual:String(item.typename) }); }
        }
        if (!field) { continue; }
        if (action === "image") {
            for (j = start - 1; j < end; j++) {
                value = records[j] && records[j][field] !== undefined ? records[j][field] : "";
                imageChecked++; file = ANP_vdpResolveImageV71(value, sourceFolder);
                if (!file) {
                    imageMissingCount++; recNo = j + 1 + offset;
                    if (imageMissing.length < maxSamples) { imageMissing.push({ recordNumber:recNo, field:field, value:String(value == null ? "" : value) }); }
                }
            }
        } else if (action === "fillColor") {
            for (j = start - 1; j < end; j++) {
                value = records[j] && records[j][field] !== undefined ? records[j][field] : "";
                colorChecked++; c = null;
                try { c = ANP_vdpParseColorV71(value); } catch (eColor) { c = null; }
                if (!c) {
                    colorInvalidCount++; recNo = j + 1 + offset;
                    if (colorInvalid.length < maxSamples) { colorInvalid.push({ recordNumber:recNo, field:field, value:String(value == null ? "" : value) }); }
                }
            }
        }
    }
    return ANP_ok({
        preflightV141:true, checkedRecords:Math.max(0, end - start + 1), targetCount:mappings.length, targetFound:targetFound,
        missingTargetCount:missingTargetCount, missingTargets:missingTargets, typeErrorCount:typeErrorCount, typeErrors:typeErrors,
        imageChecked:imageChecked, imageMissingCount:imageMissingCount, imageMissing:imageMissing,
        colorChecked:colorChecked, colorInvalidCount:colorInvalidCount, colorInvalid:colorInvalid,
        documentName:String(doc.name || "")
    });
}

function ANP_vdpPreviewV71(json) {
    try {
        if (!app.documents.length) { throw new Error("Chưa mở tài liệu Illustrator."); }
        var cfg = eval("(" + json + ")"), doc = app.activeDocument, mappings = cfg.mappings || [], record = cfg.record || {};
        if (cfg.preflightV141 === true || String(cfg.preflightV141) === "true") { return ANP_vdpPreflightV141(cfg, doc); }
        if (!mappings.length) { throw new Error("Chưa có kênh biến đổi."); }
        ANP_vdpEnsureSessionV71(doc, mappings); ANP_vdpRestoreDocV71(doc);
        var applied = ANP_vdpApplyRecordV71(doc, mappings, record, String(cfg.sourceFolder || ""));
        return ANP_ok({ applied:applied, recordNumber:Number(cfg.recordNumber || 1), documentName:doc.name });
    } catch (e) { return ANP_fail(e); }
}

function ANP_vdpRestoreV71() {
    try {
        if (!app.documents.length) { throw new Error("Chưa mở tài liệu Illustrator."); }
        var doc = app.activeDocument, count = ANP_vdpRestoreDocV71(doc); try { app.redraw(); } catch (e0) {}
        return ANP_ok({ restored:count });
    } catch (e) { return ANP_fail(e); }
}

function ANP_vdpSafeNameV71(value) {
    var s = String(value == null ? "" : value).replace(/[\\\/:*?"<>|]+/g, "_").replace(/^\s+|\s+$/g, "");
    if (!s) { s = "record"; } if (s.length > 90) { s = s.substring(0,90); } return s;
}

function ANP_vdpUniquePdfV71(folder, base) {
    var f = new File(folder.fsName + "/" + base + ".pdf"), i = 2;
    while (f.exists) { f = new File(folder.fsName + "/" + base + "_" + String(i) + ".pdf"); i++; }
    return f;
}

function ANP_vdpDetectDelimiterV71(text) {
    var first = String(text || "").replace(/^\ufeff/, "").split(/\r?\n/)[0] || "", candidates = [",",";","\t"], best = ",", bestCount = -1, i, j, q, count, ch;
    for (i = 0; i < candidates.length; i++) {
        q = false; count = 0;
        for (j = 0; j < first.length; j++) { ch = first.charAt(j); if (ch === '"') { q = !q; } else if (!q && ch === candidates[i]) { count++; } }
        if (count > bestCount) { bestCount = count; best = candidates[i]; }
    }
    return best;
}

function ANP_vdpParseDelimitedV71(text) {
    text = String(text || "").replace(/^\ufeff/, "");
    var delimiter = ANP_vdpDetectDelimiterV71(text), rows = [], row = [], cell = "", quote = false, i, ch, next, headers = [], used = {}, base, h, n, r, obj, records = [], j;
    for (i = 0; i < text.length; i++) {
        ch = text.charAt(i); next = i + 1 < text.length ? text.charAt(i + 1) : "";
        if (ch === '"') { if (quote && next === '"') { cell += '"'; i++; } else { quote = !quote; } }
        else if (ch === delimiter && !quote) { row.push(cell); cell = ""; }
        else if ((ch === "\n" || ch === "\r") && !quote) {
            if (ch === "\r" && next === "\n") { i++; }
            row.push(cell); cell = "";
            if (row.length > 1 || String(row[0] || "").replace(/\s/g, "")) { rows.push(row); }
            row = [];
        } else { cell += ch; }
    }
    if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
    if (!rows.length) { return { headers:[], records:[] }; }
    for (i = 0; i < rows[0].length; i++) {
        base = String(rows[0][i] || "").replace(/^\s+|\s+$/g, "") || ("FIELD_" + String(i + 1)); h = base; n = 2;
        while (used[h]) { h = base + "_" + String(n); n++; }
        used[h] = true; headers.push(h);
    }
    for (i = 1; i < rows.length; i++) {
        r = rows[i]; obj = {};
        for (j = 0; j < headers.length; j++) { obj[headers[j]] = r[j] !== undefined ? r[j] : ""; }
        records.push(obj);
    }
    return { headers:headers, records:records };
}

function ANP_vdpReadDataFileV71(path) {
    var f = new File(String(path || "")), text, parsed;
    if (!f.exists) { throw new Error("Không tìm thấy file dữ liệu: " + String(path || "")); }
    try { f.encoding = "UTF-8"; } catch (e0) {}
    if (!f.open("r")) { throw new Error("Không mở được file dữ liệu: " + f.fsName); }
    try { text = f.read(); } finally { try { f.close(); } catch (e1) {} }
    parsed = ANP_vdpParseDelimitedV71(text);
    if (!parsed.headers.length) { throw new Error("File dữ liệu không có header."); }
    return parsed;
}


/* V72: tạo bản sao làm việc bằng cách tạo document mới rồi duplicate các PageItem
   sang document mới. Illustrator DOM không có Document.duplicate() ổn định như PageItem. */
function ANP_vdpTopLevelV72(item) {
    var p = null, t = "";
    try { p = item.parent; t = String(p.typename || ""); } catch (e0) {}
    return t === "Layer";
}

function ANP_vdpEffectiveHiddenV72(item) {
    var cur = item, t = "";
    try {
        while (cur) {
            t = String(cur.typename || "");
            if (t === "Layer") { if (cur.visible === false) { return true; } }
            else if (cur.hidden === true) { return true; }
            cur = cur.parent;
            if (String(cur && cur.typename || "") === "Document") { break; }
        }
    } catch (e0) {}
    return false;
}



function ANP_vdpNormFsPathV75(p) {
    var s = String(p || "").replace(/\\/g, "/");
    try { s = decodeURI(s); } catch (e0) {}
    return s.toLowerCase();
}

function ANP_vdpSyncPlacedLinkV75(sourceItem, copiedItem) {
    var sp = "", dp = "", f = null;
    try {
        if (String(sourceItem.typename || "") !== "PlacedItem") { return false; }
        if (String(copiedItem.typename || "") !== "PlacedItem") { return false; }
        try { sp = sourceItem.file ? sourceItem.file.fsName : ""; } catch (e0) { sp = ""; }
        if (!sp) { return false; }
        f = new File(sp); if (!f.exists) { return false; }
        try { dp = copiedItem.file ? copiedItem.file.fsName : ""; } catch (e1) { dp = ""; }
        /* V75: chỉ relink khi thật sự cần. Không embed: embed() có thể thay thế
           PlacedItem và làm handle cp mất hiệu lực trước khi dịch vị trí. */
        if (ANP_vdpNormFsPathV75(dp) !== ANP_vdpNormFsPathV75(sp)) {
            try { copiedItem.relink(f); } catch (e2) { return false; }
        }
        return true;
    } catch (e) {}
    return false;
}

function ANP_vdpRepairLinksRecursiveV75(sourceItem, copiedItem) {
    var st = "", dt = "", i, sl = 0, dl = 0, limit = 0;
    try { st = String(sourceItem.typename || ""); } catch (e0) {}
    try { dt = String(copiedItem.typename || ""); } catch (e1) {}
    if (st === "PlacedItem" && dt === "PlacedItem") {
        ANP_vdpSyncPlacedLinkV75(sourceItem, copiedItem);
        return;
    }
    if (st === "GroupItem" && dt === "GroupItem") {
        try { sl = sourceItem.pageItems.length; } catch (e2) { sl = 0; }
        try { dl = copiedItem.pageItems.length; } catch (e3) { dl = 0; }
        limit = sl < dl ? sl : dl;
        for (i = 0; i < limit; i++) {
            try { ANP_vdpRepairLinksRecursiveV75(sourceItem.pageItems[i], copiedItem.pageItems[i]); } catch (e4) {}
        }
    }
}

function ANP_vdpExactMoveCopyV75(sourceItem, copiedItem, dx, dy) {
    var p = null, l = null, t = null;
    dx = Number(dx || 0); dy = Number(dy || 0);
    try { p = sourceItem.position; } catch (e0) { p = null; }
    if (p && p.length >= 2) {
        try { copiedItem.position = [Number(p[0]) + dx, Number(p[1]) + dy]; return true; } catch (e1) {}
    }
    try { l = Number(sourceItem.left); t = Number(sourceItem.top); } catch (e2) { l = null; t = null; }
    if (l !== null && t !== null && !isNaN(l) && !isNaN(t)) {
        try { copiedItem.left = l + dx; copiedItem.top = t + dy; return true; } catch (e3) {}
    }
    try { copiedItem.translate(dx, dy); return true; } catch (e4) {}
    return false;
}

function ANP_vdpBoundsIntersectUnionV75(item, m) {
    var b = null, l, t, r, bot;
    if (!m) { return true; }
    try { b = item.visibleBounds; } catch (e0) { try { b = item.geometricBounds; } catch (e1) { b = null; } }
    if (!b || b.length < 4) { return true; }
    l = Number(b[0]); t = Number(b[1]); r = Number(b[2]); bot = Number(b[3]);
    if (r < Number(m.minL) || l > Number(m.maxR) || t < Number(m.minB) || bot > Number(m.maxT)) { return false; }
    return true;
}

function ANP_vdpCloneDocumentV72(sourceDoc) {
    var colorSpace = DocumentColorSpace.CMYK, firstRect, w, h, dst = null, i, it, cp, rect;
    try {
        try { colorSpace = sourceDoc.documentColorSpace; } catch (e0) {}
        firstRect = sourceDoc.artboards[0].artboardRect;
        w = Math.abs(Number(firstRect[2]) - Number(firstRect[0]));
        h = Math.abs(Number(firstRect[1]) - Number(firstRect[3]));
        if (!(w > 0)) { w = 100; } if (!(h > 0)) { h = 100; }
        dst = app.documents.add(colorSpace, w, h);
        try { dst.artboards[0].artboardRect = [Number(firstRect[0]), Number(firstRect[1]), Number(firstRect[2]), Number(firstRect[3])]; } catch (e1) {}
        for (i = 1; i < sourceDoc.artboards.length; i++) {
            rect = sourceDoc.artboards[i].artboardRect;
            dst.artboards.add([Number(rect[0]), Number(rect[1]), Number(rect[2]), Number(rect[3])]);
        }
        try { dst.rulerOrigin = sourceDoc.rulerOrigin; } catch (e2) {}
        for (i = 0; i < sourceDoc.pageItems.length; i++) {
            it = sourceDoc.pageItems[i];
            if (!ANP_vdpTopLevelV72(it)) { continue; }
            var hiddenBefore = ANP_vdpEffectiveHiddenV72(it), itemLocked = false, itemHidden = false, cur = null, layers = [], states = [], k, lt;
            try { itemLocked = it.locked === true; } catch (eLock0) {}
            try { itemHidden = it.hidden === true; } catch (eHide0) {}
            try {
                cur = it.parent;
                while (cur && String(cur.typename || "") !== "Document") {
                    lt = String(cur.typename || "");
                    if (lt === "Layer") { layers.push(cur); states.push({ visible:cur.visible !== false, locked:cur.locked === true }); try { cur.visible = true; } catch (eVis1) {} try { cur.locked = false; } catch (eLock1) {} }
                    cur = cur.parent;
                }
                try { it.locked = false; } catch (eLock2) {}
                try { it.hidden = false; } catch (eHide2) {}
                cp = it.duplicate(dst, ElementPlacement.PLACEATEND);
                try { ANP_vdpRepairLinksRecursiveV75(it, cp); } catch (eFixLinks0) {}
                try { ANP_vdpExactMoveCopyV75(it, cp, 0, 0); } catch (eExact0) {}
                try { cp.hidden = hiddenBefore; } catch (eCpHidden) {}
                try { cp.note = it.note; } catch (eNote) {}
                try { cp.name = it.name; } catch (eName) {}
            } catch (eDup) {
                throw new Error("Không sao chép được artwork để xuất PDF: " + String(eDup));
            } finally {
                try { it.hidden = itemHidden; } catch (eHide3) {}
                try { it.locked = itemLocked; } catch (eLock3) {}
                for (k = layers.length - 1; k >= 0; k--) { try { layers[k].visible = states[k].visible; } catch (eVis4) {} try { layers[k].locked = states[k].locked; } catch (eLock4) {} }
            }
        }
        try { dst.artboards.setActiveArtboardIndex(sourceDoc.artboards.getActiveArtboardIndex()); } catch (e8) {}
        return dst;
    } catch (e) {
        try { if (dst) { dst.close(SaveOptions.DONOTSAVECHANGES); } } catch (eClose) {}
        throw e;
    }
}

function ANP_vdpArtboardRectsV72(doc) {
    var out = [], i, r;
    for (i = 0; i < doc.artboards.length; i++) { r = doc.artboards[i].artboardRect; out.push([Number(r[0]),Number(r[1]),Number(r[2]),Number(r[3])]); }
    return out;
}


/* ===== V78 AUTO-SAVE FIDELITY SAME-DOCUMENT COMBINED PDF =====
   Mục tiêu: không rebuild/cross-document artwork khi gộp VDP. DPV mở một bản copy
   nguyên file AI nguồn (nếu file đã Save), apply record trên template gốc rồi
   duplicate snapshot NGAY TRONG CÙNG DOCUMENT. Cách này giữ clipping/opacity mask,
   live effect, linked image, symbol/plugin item và layer appearance tốt hơn. */
function ANP_vdpCloneFidelityV78(sourceDoc, outputFolder) {
    var sourceFile = null, ext = "", target = null, tempDoc = null, stamp, savedNow = false;
    try {
        if (!sourceDoc) { throw new Error("Không có document nguồn."); }
        try { sourceFile = sourceDoc.fullName; } catch (e0) { sourceFile = null; }
        if (!sourceFile || !sourceFile.exists) {
            throw new Error("File Illustrator chưa có đường dẫn. Hãy Save As .AI một lần trước khi chạy VDP.");
        }
        ext = String(sourceFile.name || "").toLowerCase();
        if (!(ext.length >= 3 && ext.substring(ext.length - 3) === ".ai")) {
            throw new Error("VDP Fidelity cần file nguồn .AI. Hãy Save As .AI rồi chạy lại.");
        }

        /* V78 FIX: Preview/Restore làm Illustrator đánh dấu document là modified dù
           nội dung đã được khôi phục. V76/V77 kiểm tra sourceDoc.saved===true nên
           nút Chạy có thể không chạy sau khi Preview. Ở đây tự Save file AI hiện tại
           sau khi Build đã Restore nội dung gốc, rồi mới tạo work-copy fidelity. */
        try {
            if (sourceDoc.saved !== true) {
                sourceDoc.save();
                savedNow = true;
            }
        } catch (eSave) {
            throw new Error("Không thể tự Save file AI trước khi chạy VDP: " + String(eSave) + ". Hãy Ctrl+S / Save As .AI rồi thử lại.");
        }

        /* fullName có thể được refresh sau save. */
        try { sourceFile = sourceDoc.fullName; } catch (e1) {}
        if (!sourceFile || !sourceFile.exists) { throw new Error("Không đọc được file AI sau khi Save."); }

        stamp = String((new Date()).getTime());
        target = new File(outputFolder.fsName + "/.__DPV_V80_WORK_" + stamp + ".ai");
        if (target.exists) { try { target.remove(); } catch (eRm) {} }
        if (!sourceFile.copy(target.fsName)) { throw new Error("Không tạo được bản work-copy VDP trong thư mục xuất."); }
        tempDoc = app.open(target);
        return { doc:tempDoc, tempFile:target, fidelity:true, autoSaved:savedNow };
    } catch (e2) {
        try { if (tempDoc) { tempDoc.close(SaveOptions.DONOTSAVECHANGES); } } catch (eClose) {}
        try { if (target && target.exists) { target.remove(); } } catch (eDel) {}
        throw e2;
    }
}

function ANP_vdpTemplateTopItemsV76(doc) {
    var out = [], i, it;
    for (i = 0; i < doc.pageItems.length; i++) {
        it = doc.pageItems[i];
        if (ANP_vdpTopLevelV72(it)) { out.push(it); }
    }
    return out;
}

function ANP_vdpBeginSameDocCombinedV76(doc, pageRects, recordCount, templateItems) {
    var totalPages = pageRects.length * recordCount, m = ANP_vdpCombinedMetricsV73(pageRects), cols;
    if (!pageRects.length || recordCount < 1) { throw new Error("Không có artboard để tạo PDF gộp."); }
    if (totalPages > 950) { throw new Error("PDF gộp có " + totalPages + " trang, vượt giới hạn an toàn 950 artboard. Hãy chia record thành nhiều nhóm."); }
    cols = Math.ceil(Math.sqrt(recordCount * (m.height / m.width)));
    if (cols < 1) { cols = 1; } if (cols > recordCount) { cols = recordCount; }
    return { doc:doc, pageRects:pageRects, metrics:m, cols:cols, gap:ANP_mm(8), pageCount:pageRects.length,
        recordCount:recordCount, templateItems:templateItems || [], snapshots:[], originalArtboardCount:pageRects.length };
}

function ANP_vdpSameDocShiftV76(ctx, recordIndex) {
    var row = Math.floor(recordIndex / ctx.cols), col = recordIndex % ctx.cols;
    return { dx:col * (ctx.metrics.width + ctx.gap), dy:-row * (ctx.metrics.height + ctx.gap) };
}

function ANP_vdpAddRecordArtboardsV76(ctx, recordIndex) {
    var sh = ANP_vdpSameDocShiftV76(ctx, recordIndex), i, r, dr, ab;
    if (recordIndex === 0) {
        for (i = 0; i < ctx.originalArtboardCount; i++) {
            try { ctx.doc.artboards[i].name = "VDP_R0001_AB" + String(i + 1); } catch (eName0) {}
        }
        return sh;
    }
    for (i = 0; i < ctx.pageRects.length; i++) {
        r = ctx.pageRects[i];
        dr = [Number(r[0])+sh.dx, Number(r[1])+sh.dy, Number(r[2])+sh.dx, Number(r[3])+sh.dy];
        ab = ctx.doc.artboards.add(dr);
        try { ab.name = "VDP_R" + (recordIndex + 1 < 10 ? "000" : recordIndex + 1 < 100 ? "00" : recordIndex + 1 < 1000 ? "0" : "") + String(recordIndex + 1) + "_AB" + String(i + 1); } catch (eName1) {}
        ctx.pageCount++;
    }
    return sh;
}

function ANP_vdpSnapshotRecordV76(ctx, recordIndex) {
    var sh = ANP_vdpAddRecordArtboardsV76(ctx, recordIndex), i, it, cp, itemLocked, itemHidden, layer = null,
        layerLocked = false, layerVisible = true, desiredHidden = false, copied = 0;
    for (i = 0; i < ctx.templateItems.length; i++) {
        it = ctx.templateItems[i]; if (!it) { continue; }
        itemLocked = false; itemHidden = false; layer = null; layerLocked = false; layerVisible = true;
        try { itemLocked = it.locked === true; } catch (e0) {}
        try { itemHidden = it.hidden === true; } catch (e1) {}
        desiredHidden = itemHidden;
        try { layer = it.parent; if (String(layer.typename || "") !== "Layer") { layer = null; } } catch (e2) { layer = null; }
        if (layer) {
            try { layerLocked = layer.locked === true; } catch (e3) {}
            try { layerVisible = layer.visible !== false; } catch (e4) {}
        }
        try {
            if (layer) { try { layer.locked = false; } catch (e5) {} try { layer.visible = true; } catch (e6) {} }
            try { it.locked = false; } catch (e7) {}
            try { it.hidden = false; } catch (e8) {}
            cp = it.duplicate(it, ElementPlacement.PLACEAFTER);
            if (recordIndex !== 0) {
                try { cp.translate(Number(sh.dx), Number(sh.dy)); }
                catch (eMove0) { if (!ANP_vdpExactMoveCopyV75(it, cp, Number(sh.dx), Number(sh.dy))) { throw eMove0; } }
            }
            /* Ẩn snapshot trong lúc vòng lặp còn chạy để PDF riêng chỉ thấy template
               của record hiện tại. Sau khi xóa template mới restore hidden gốc. */
            try { cp.hidden = true; } catch (eHideCp) {}
            ctx.snapshots.push({ item:cp, hidden:desiredHidden });
            copied++;
        } catch (eDup) {
            throw new Error("Không snapshot được artwork VDP (" + String(it.typename || "Object") + "): " + String(eDup));
        } finally {
            try { it.hidden = itemHidden; } catch (e9) {}
            try { it.locked = itemLocked; } catch (e10) {}
            if (layer) { try { layer.visible = layerVisible; } catch (e11) {} try { layer.locked = layerLocked; } catch (e12) {} }
        }
    }
    return copied;
}

function ANP_vdpFinalizeSameDocV76(ctx) {
    var i, s;
    /* Xóa template gốc; chỉ còn snapshot đã đóng băng dữ liệu từng record. */
    for (i = ctx.templateItems.length - 1; i >= 0; i--) {
        try { if (ctx.templateItems[i]) { ctx.templateItems[i].remove(); } } catch (e0) {}
    }
    for (i = 0; i < ctx.snapshots.length; i++) {
        s = ctx.snapshots[i];
        try { if (s && s.item) { s.item.hidden = s.hidden === true; } } catch (e1) {}
    }
    return ctx.pageCount;
}

function ANP_savePDFRangeV76(doc, file, range, preserveColor) {
    var opt = new PDFSaveOptions(), presets, i, chosen = "", wantedRange = String(range || ""), multi = false;
    try {
        presets = app.PDFPresetsList;
        for (i = 0; i < presets.length; i++) { if (ANP_upper(presets[i]).indexOf("ILLUSTRATOR DEFAULT") >= 0) { chosen = presets[i]; break; } }
        if (!chosen && presets.length) { chosen = presets[0]; }
        if (chosen) { opt.pDFPreset = chosen; }
    } catch (ePreset) {}
    if (preserveColor) {
        try { opt.colorConversionID = ColorConversion.None; } catch (eColor0) {}
        try { opt.colorProfileID = ColorProfile.INCLUDEALLPROFILE; } catch (eColor1) {}
    }
    /* V84: artboardRange một mình không đủ ổn định trên Illustrator 2024-2026.
       Bắt buộc bật saveMultipleArtboards để PDF thực sự có đủ trang. */
    try { multi = doc && doc.artboards && doc.artboards.length > 1; } catch (eMulti0) { multi = false; }
    try { opt.preserveEditability = false; } catch (eEdit) {}
    try { opt.saveMultipleArtboards = multi === true; } catch (eMulti1) {}
    try { opt.artboardRange = wantedRange; } catch (eRange) {}
    doc.saveAs(file, opt);
}


/* V75 EXACT ARTBOARD FAST COMBINED PDF
   - Không còn xuất PDF tạm từng record rồi import ngược PDF vào Illustrator.
   - Chỉ clone tài liệu làm việc 1 lần, restore/apply record trên cùng workDoc.
   - Khi cần PDF gộp, copy artwork trực tiếp vào 1 document nhiều artboard rồi save PDF 1 lần.
   Điều này giảm mạnh I/O ổ đĩa, PDF parsing và số lần clone document. */

/* ===== V140.1 VDP WORK-COPY TARGET REBIND HOTFIX =====
   Illustrator có thể cấp UUID mới khi cùng một file .AI được mở dưới dạng work-copy
   trong lúc file nguồn vẫn đang mở. Mapping VDP trên UI vì vậy vẫn đúng ở sourceDoc
   nhưng UUID đó không còn tồn tại trong workDoc, làm Batch/VDP Sheet dừng ngay khi
   capture state. Hotfix này chỉ rebind target TRONG work-copy; không ghi note/name
   vào file AI nguồn và không thay Core V101/layout/PON/duplex. */
function ANP_vdpItemBoundsV140(item) {
    var b = null;
    try { b = item.geometricBounds; } catch (e0) { try { b = item.visibleBounds; } catch (e1) { b = null; } }
    if (!b || b.length < 4) { return null; }
    return [Number(b[0]), Number(b[1]), Number(b[2]), Number(b[3])];
}

function ANP_vdpBoundsDeltaV140(a, b) {
    if (!a || !b || a.length < 4 || b.length < 4) { return 1e30; }
    return Math.abs(Number(a[0]) - Number(b[0])) + Math.abs(Number(a[1]) - Number(b[1])) +
        Math.abs(Number(a[2]) - Number(b[2])) + Math.abs(Number(a[3]) - Number(b[3]));
}

function ANP_vdpLayerNameV140(item) {
    try { return String(item.layer && item.layer.name || ''); } catch (e0) {}
    return '';
}

function ANP_vdpPlacedPathV140(item) {
    try { if (String(item.typename || '') === 'PlacedItem' && item.file) { return String(item.file.fsName || ''); } } catch (e0) {}
    return '';
}

function ANP_vdpFindSourceIndexV140(doc, item) {
    var i, u = '';
    if (!doc || !item) { return -1; }
    try { u = String(item.uuid || ''); } catch (e0) { u = ''; }
    for (i = 0; i < doc.pageItems.length; i++) {
        try { if (doc.pageItems[i] === item) { return i; } } catch (e1) {}
        if (u) { try { if (String(doc.pageItems[i].uuid || '') === u) { return i; } } catch (e2) {} }
    }
    return -1;
}

function ANP_vdpParallelItemV140(sourceDoc, workDoc, sourceItem) {
    var srcType = '', srcBounds = null, srcName = '', srcText = '', srcLayer = '', srcFile = '', srcIndex = -1,
        i, it, t = '', b = null, d = 1e30, score = 0, best = null, bestScore = -1e30, n = '', txt = '', layer = '', fp = '';
    if (!sourceDoc || !workDoc || !sourceItem) { return null; }
    try { srcType = String(sourceItem.typename || ''); } catch (e0) { srcType = ''; }
    srcBounds = ANP_vdpItemBoundsV140(sourceItem);
    try { srcName = String(sourceItem.name || ''); } catch (e1) { srcName = ''; }
    if (srcType === 'TextFrame') { try { srcText = String(sourceItem.contents || ''); } catch (e2) { srcText = ''; } }
    srcLayer = ANP_vdpLayerNameV140(sourceItem);
    srcFile = ANP_vdpPlacedPathV140(sourceItem);
    srcIndex = ANP_vdpFindSourceIndexV140(sourceDoc, sourceItem);

    /* Fast path: bản copy AI thông thường giữ nguyên thứ tự pageItems. */
    if (srcIndex >= 0 && srcIndex < workDoc.pageItems.length) {
        try {
            it = workDoc.pageItems[srcIndex];
            t = String(it.typename || '');
            if (t === srcType) {
                b = ANP_vdpItemBoundsV140(it); d = ANP_vdpBoundsDeltaV140(srcBounds, b);
                if (d <= 2.0) { return it; }
                if (srcType === 'TextFrame') { try { if (String(it.contents || '') === srcText) { return it; } } catch (eFastText) {} }
            }
        } catch (eFast) {}
    }

    /* Fallback: chấm điểm type + bounds + text/link + name/layer. */
    for (i = 0; i < workDoc.pageItems.length; i++) {
        it = workDoc.pageItems[i];
        try { t = String(it.typename || ''); } catch (e3) { t = ''; }
        if (t !== srcType) { continue; }
        score = 0;
        b = ANP_vdpItemBoundsV140(it); d = ANP_vdpBoundsDeltaV140(srcBounds, b);
        if (d <= 0.25) { score += 120; }
        else if (d <= 2.0) { score += 80; }
        else if (d <= 8.0) { score += 25; }
        if (i === srcIndex) { score += 30; }
        try { n = String(it.name || ''); } catch (e4) { n = ''; }
        if (srcName && n === srcName) { score += 18; }
        layer = ANP_vdpLayerNameV140(it); if (srcLayer && layer === srcLayer) { score += 12; }
        if (srcType === 'TextFrame') {
            try { txt = String(it.contents || ''); } catch (e5) { txt = ''; }
            if (txt === srcText) { score += 55; }
        }
        if (srcType === 'PlacedItem') {
            fp = ANP_vdpPlacedPathV140(it); if (srcFile && fp === srcFile) { score += 55; }
        }
        if (score > bestScore) { bestScore = score; best = it; }
    }
    return bestScore >= 55 ? best : null;
}

function ANP_vdpUniqueTargetCountV140(mappings) {
    var seen = {}, i, id, n = 0;
    if (!mappings) { return 0; }
    for (i = 0; i < mappings.length; i++) {
        id = String(mappings[i].targetId || '');
        if (id && !seen[id]) { seen[id] = true; n++; }
    }
    return n;
}

function ANP_vdpRebindMappingsV140(sourceDoc, workDoc, mappings) {
    var cacheOld = [], cacheNew = [], i, j, m, oldId = '', newId = '', src = null, dst = null, rebound = 0, failed = 0;
    if (!mappings) { mappings = []; }
    for (i = 0; i < mappings.length; i++) {
        m = mappings[i]; oldId = String(m.targetId || '');
        if (!oldId) { continue; }
        /* Nếu token/UUID vẫn tồn tại trong work-copy thì giữ nguyên. */
        if (ANP_vdpFindByTokenV71(workDoc, oldId)) { continue; }
        newId = '';
        for (j = 0; j < cacheOld.length; j++) { if (cacheOld[j] === oldId) { newId = cacheNew[j]; break; } }
        if (!newId) {
            src = ANP_vdpFindByTokenV71(sourceDoc, oldId);
            if (src) { dst = ANP_vdpParallelItemV140(sourceDoc, workDoc, src); }
            else { dst = null; }
            if (dst) {
                try { if (dst.uuid) { newId = 'UUID:' + String(dst.uuid); } } catch (eUuid) { newId = ''; }
                if (!newId) { try { newId = ANP_vdpGetTokenV71(dst); } catch (eToken) { newId = ''; } }
            }
            cacheOld.push(oldId); cacheNew.push(newId);
        }
        if (newId) { m.targetId = newId; rebound++; }
        else { failed++; }
    }
    return { rebound:rebound, failed:failed, targets:ANP_vdpUniqueTargetCountV140(mappings) };
}

function ANP_vdpCaptureStateV73(doc, mappings) {
    var out = [], seen = {}, i, m, id, item, t, o, col;
    for (i = 0; i < mappings.length; i++) {
        m = mappings[i]; id = String(m.targetId || "");
        if (!id || seen[id]) { continue; }
        seen[id] = true; item = ANP_vdpFindByTokenV71(doc, id); if (!item) { continue; }
        t = String(item.typename || ""); o = { id:id, type:t, hidden:false, text:null, file:"", fill:null };
        try { o.hidden = item.hidden === true; } catch (e0) {}
        if (t === "TextFrame") { try { o.text = String(item.contents || ""); o.textStyleV137 = ANP_vdpCaptureTextStyleV137(item); ANP_VDP_TEXT_STYLE_CACHE_V137[id] = o.textStyleV137; } catch (e1) {} }
        if (t === "PlacedItem") { try { o.file = item.file ? item.file.fsName : ""; } catch (e2) {} }
        try { col = ANP_vdpGetFillColorV71(item); o.fill = ANP_vdpColorDescriptorV71(col); } catch (e3) {}
        out.push(o);
    }
    return out;
}

function ANP_vdpRestoreStateV73(doc, state) {
    var i, o, item, c, count = 0;
    for (i = 0; i < state.length; i++) {
        o = state[i]; item = ANP_vdpFindByTokenV71(doc, String(o.id || "")); if (!item) { continue; }
        try { item.hidden = o.hidden === true; } catch (e0) {}
        if (o.type === "TextFrame" && o.text !== null) { try { ANP_vdpSetTextExactV137(item, o.text, o.textStyleV137 || ANP_VDP_TEXT_STYLE_CACHE_V137[String(o.id || "")] || null); } catch (e1) {} }
        if (o.type === "PlacedItem" && o.file) { try { item.relink(new File(o.file)); } catch (e2) {} }
        if (o.fill) { c = ANP_vdpColorFromDescriptorV71(o.fill); if (c) { try { ANP_vdpSetFillColorV71(item, c); } catch (e3) {} } }
        count++;
    }
    return count;
}

function ANP_vdpCombinedMetricsV73(pageRects) {
    var minL = 1e30, maxR = -1e30, maxT = -1e30, minB = 1e30, i, r;
    for (i = 0; i < pageRects.length; i++) {
        r = pageRects[i];
        if (Number(r[0]) < minL) { minL = Number(r[0]); }
        if (Number(r[2]) > maxR) { maxR = Number(r[2]); }
        if (Number(r[1]) > maxT) { maxT = Number(r[1]); }
        if (Number(r[3]) < minB) { minB = Number(r[3]); }
    }
    if (!(maxR > minL)) { maxR = minL + 100; }
    if (!(maxT > minB)) { maxT = minB + 100; }
    return { minL:minL, maxR:maxR, maxT:maxT, minB:minB, width:maxR-minL, height:maxT-minB };
}

function ANP_vdpBeginCombinedV73(pageRects, recordCount, colorSpace) {
    var totalPages = pageRects.length * recordCount, m = ANP_vdpCombinedMetricsV73(pageRects), cols, gap = 24;
    if (!pageRects.length || recordCount < 1) { throw new Error("Không có trang để gộp PDF."); }
    if (totalPages > 950) { throw new Error("PDF gộp có " + totalPages + " trang, vượt giới hạn an toàn 950 artboard. Hãy chia record thành nhiều nhóm."); }
    cols = Math.ceil(Math.sqrt(recordCount * (m.height / m.width)));
    if (cols < 1) { cols = 1; } if (cols > recordCount) { cols = recordCount; }
    return { doc:null, pageRects:pageRects, colorSpace:colorSpace || DocumentColorSpace.CMYK, metrics:m, cols:cols, gap:gap, pageCount:0, recordCount:recordCount };
}

function ANP_vdpCombinedShiftV73(ctx, recordIndex) {
    var row = Math.floor(recordIndex / ctx.cols), col = recordIndex % ctx.cols;
    var cellLeft = col * (ctx.metrics.width + ctx.gap), cellTop = -row * (ctx.metrics.height + ctx.gap);
    return { dx:cellLeft - ctx.metrics.minL, dy:cellTop - ctx.metrics.maxT };
}

function ANP_vdpAddCombinedArtboardsV73(ctx, recordIndex) {
    var sh = ANP_vdpCombinedShiftV73(ctx, recordIndex), i, r, dr, w, h;
    for (i = 0; i < ctx.pageRects.length; i++) {
        r = ctx.pageRects[i]; dr = [Number(r[0])+sh.dx, Number(r[1])+sh.dy, Number(r[2])+sh.dx, Number(r[3])+sh.dy];
        if (!ctx.doc) {
            w = Math.abs(dr[2]-dr[0]); h = Math.abs(dr[1]-dr[3]); if (!(w > 0)) { w = 100; } if (!(h > 0)) { h = 100; }
            ctx.doc = app.documents.add(ctx.colorSpace, w, h);
            try { ctx.doc.artboards[0].artboardRect = dr; } catch (e0) {}
        } else { ctx.doc.artboards.add(dr); }
        ctx.pageCount++;
    }
    return sh;
}

function ANP_vdpCopyArtworkShiftV73(sourceDoc, destDoc, dx, dy, sourceMetrics) {
    var i, it, cp, hiddenBefore, itemLocked, itemHidden, cur, layers, states, k, lt, copied = 0;
    for (i = 0; i < sourceDoc.pageItems.length; i++) {
        it = sourceDoc.pageItems[i]; if (!ANP_vdpTopLevelV72(it)) { continue; }
        /* Bỏ object hoàn toàn nằm ngoài vùng artboard gốc: giảm copy rác và tránh
           object stray kéo PDF/preview lệch. */
        if (!ANP_vdpBoundsIntersectUnionV75(it, sourceMetrics)) { continue; }
        hiddenBefore = ANP_vdpEffectiveHiddenV72(it); itemLocked = false; itemHidden = false; cur = null; layers = []; states = [];
        try { itemLocked = it.locked === true; } catch (eLock0) {}
        try { itemHidden = it.hidden === true; } catch (eHide0) {}
        try {
            cur = it.parent;
            while (cur && String(cur.typename || "") !== "Document") {
                lt = String(cur.typename || "");
                if (lt === "Layer") { layers.push(cur); states.push({ visible:cur.visible !== false, locked:cur.locked === true }); try { cur.visible = true; } catch (eVis1) {} try { cur.locked = false; } catch (eLock1) {} }
                cur = cur.parent;
            }
            try { it.locked = false; } catch (eLock2) {}
            try { it.hidden = false; } catch (eHide2) {}
            cp = it.duplicate(destDoc, ElementPlacement.PLACEATEND);
            /* V75: relink nhưng KHÔNG embed. Sau đó ép đúng tọa độ tuyệt đối
               source + shift, không dựa vào vị trí Illustrator tự đặt khi duplicate. */
            try { ANP_vdpRepairLinksRecursiveV75(it, cp); } catch (eFixLinks1) {}
            if (!ANP_vdpExactMoveCopyV75(it, cp, Number(dx), Number(dy))) {
                throw new Error("Không đặt đúng tọa độ artwork khi gộp PDF.");
            }
            try { cp.hidden = hiddenBefore; } catch (eCpHidden) {}
            try { cp.note = it.note; } catch (eNote) {}
            try { cp.name = it.name; } catch (eName) {}
            copied++;
        } catch (eDup) {
            throw new Error("Không sao chép được artwork vào PDF gộp nhanh: " + String(eDup));
        } finally {
            try { it.hidden = itemHidden; } catch (eHide3) {}
            try { it.locked = itemLocked; } catch (eLock3) {}
            for (k = layers.length - 1; k >= 0; k--) { try { layers[k].visible = states[k].visible; } catch (eVis4) {} try { layers[k].locked = states[k].locked; } catch (eLock4) {} }
        }
    }
    return copied;
}

function ANP_vdpAppendRecordCombinedV73(sourceDoc, ctx, recordIndex) {
    var sh = ANP_vdpAddCombinedArtboardsV73(ctx, recordIndex);
    if (!ctx.doc) { throw new Error("Không tạo được document PDF gộp."); }
    ANP_vdpCopyArtworkShiftV73(sourceDoc, ctx.doc, sh.dx, sh.dy, ctx.metrics);
    return ctx.pageCount;
}

function ANP_vdpFinishCombinedV73(ctx, combinedFile) {
    if (!ctx || !ctx.doc) { throw new Error("Không có dữ liệu để tạo PDF gộp."); }
    try {
        ctx.doc.activate();
        if (ctx.doc.artboards.length > 1) { ANP_savePDFMultiArtboardV61(ctx.doc, combinedFile, true); }
        else { ANP_savePDFDefault(ctx.doc, combinedFile, true); }
    } finally {
        try { if (ctx.doc) { ctx.doc.close(SaveOptions.DONOTSAVECHANGES); } } catch (e0) {}
        ctx.doc = null;
    }
    return ctx.pageCount;
}

function ANP_vdpBuildV71(json) {
    var originalDoc = null, workDoc = null, cloneInfo = null, sameCtx = null, workState = [], exportIndividual = false, combinePdf = false, templateItems = [], originalArtboardCount = 0;
    try {
        if (!app.documents.length) { throw new Error("Chưa mở tài liệu Illustrator."); }
        var cfg = eval("(" + json + ")"), records = cfg.records || [], mappings = cfg.mappings || [], outPath = String(cfg.outputPath || ""), start = Math.max(1, Number(cfg.from || 1)), end, outputRoot, outputFolder, i, record, nameValue, base, file, created = [], applied, parsedData, combinedFile = null, combinedPages = 0, pageRects, combinedBase, totalRecords, fastCopied = 0, fidelityMode = false;
        exportIndividual = cfg.exportIndividual !== false; combinePdf = cfg.combinePdf === true;
        if (!records.length && cfg.dataPath) { parsedData = ANP_vdpReadDataFileV71(cfg.dataPath); records = parsedData.records; if (!cfg.sourceFolder) { try { cfg.sourceFolder = (new File(cfg.dataPath)).parent.fsName; } catch (eFolder) {} } }
        if (!records.length) { throw new Error("Dữ liệu không có record."); }
        if (!mappings.length) { throw new Error("Chưa có kênh biến đổi."); }
        if (!outPath) { throw new Error("Chưa chọn thư mục xuất PDF."); }
        if (!exportIndividual && !combinePdf) { throw new Error("Hãy chọn ít nhất một kiểu xuất PDF."); }
        end = Math.min(records.length, Math.max(start, Number(cfg.to || records.length))); totalRecords = end - start + 1;
        outputRoot = new Folder(outPath); if (!outputRoot.exists) { throw new Error("Thư mục xuất không tồn tại."); }
        outputFolder = new Folder(outputRoot.fsName + "/VARIABLE_DATA"); if (!outputFolder.exists && !outputFolder.create()) { throw new Error("Không tạo được thư mục VARIABLE_DATA."); }
        originalDoc = app.activeDocument;
        pageRects = ANP_vdpArtboardRectsV72(originalDoc); originalArtboardCount = pageRects.length;
        try { ANP_vdpRestoreDocV71(originalDoc); } catch (eRestoreBase) {}

        cloneInfo = ANP_vdpCloneFidelityV78(originalDoc, outputFolder);
        workDoc = cloneInfo.doc; fidelityMode = cloneInfo.fidelity === true; workDoc.activate();
        workState = ANP_vdpCaptureStateV73(workDoc, mappings);
        if (!workState.length) {
            if (fidelityMode) { throw new Error("Không tìm thấy UUID Variable Data trong bản copy AI. Hãy đóng VDP, chọn lại đối tượng rồi bấm 'Lấy đối tượng đang chọn trong AI'."); }
            throw new Error("Không tìm thấy các đối tượng Variable Data trong bản làm việc.");
        }
        templateItems = ANP_vdpTemplateTopItemsV76(workDoc);
        if (!templateItems.length) { throw new Error("File nguồn không có artwork top-level để xuất."); }
        if (combinePdf) { sameCtx = ANP_vdpBeginSameDocCombinedV76(workDoc, pageRects, totalRecords, templateItems); }

        for (i = start - 1; i < end; i++) {
            workDoc.activate();
            ANP_vdpRestoreStateV73(workDoc, workState);
            record = records[i];
            applied = ANP_vdpApplyRecordV71(workDoc, mappings, record, String(cfg.sourceFolder || ""), true);
            if (applied < 1) { throw new Error("Record " + String(i + 1) + " không áp dụng được kênh biến đổi nào."); }

            if (exportIndividual) {
                nameValue = cfg.fileNameField && record[cfg.fileNameField] !== undefined ? record[cfg.fileNameField] : String(i + 1);
                base = ANP_vdpSafeNameV71(String(cfg.filePrefix || "VDP") + "_" + String(nameValue));
                file = ANP_vdpUniquePdfV71(outputFolder, base);
                /* Chỉ xuất đúng artboard GỐC. Artboard snapshot của các record trước
                   không được lọt vào PDF riêng. */
                ANP_savePDFRangeV76(workDoc, file, "1-" + String(originalArtboardCount), true);
                created.push(file.fsName);
            }

            if (combinePdf) {
                fastCopied += ANP_vdpSnapshotRecordV76(sameCtx, i - (start - 1));
            }
        }

        if (combinePdf) {
            combinedPages = ANP_vdpFinalizeSameDocV76(sameCtx);
            combinedBase = ANP_vdpSafeNameV71(String(cfg.combinedName || (String(cfg.filePrefix || "VDP") + "_ALL")));
            combinedFile = ANP_vdpUniquePdfV71(outputFolder, combinedBase);
            ANP_savePDFRangeV76(workDoc, combinedFile, "1-" + String(workDoc.artboards.length), true);
        }

        try { workDoc.close(SaveOptions.DONOTSAVECHANGES); } catch (eCloseWork) {}
        workDoc = null;
        try { if (cloneInfo && cloneInfo.tempFile && cloneInfo.tempFile.exists) { cloneInfo.tempFile.remove(); } } catch (eTempDel) {}
        try { originalDoc.activate(); } catch (eFinalActivate) {}
        return ANP_ok({ count:totalRecords, mappingCount:mappings.length, individualCount:created.length, from:start, to:end, outputFolder:outputFolder.fsName, created:created, combinedFile:combinedFile ? combinedFile.fsName : "", combinedPages:combinedPages, fastCombined:combinePdf, fastMode:"SAME_DOCUMENT_SNAPSHOT_V78", fastCopied:fastCopied, fidelityClone:fidelityMode, autoSaved:(cloneInfo && cloneInfo.autoSaved === true), units:"legacy" });
    } catch (e) {
        try { if (workDoc) { workDoc.close(SaveOptions.DONOTSAVECHANGES); } } catch (e0) {}
        try { if (cloneInfo && cloneInfo.tempFile && cloneInfo.tempFile.exists) { cloneInfo.tempFile.remove(); } } catch (eTempDel2) {}
        try { if (originalDoc) { originalDoc.activate(); } } catch (e1) {}
        return ANP_fail(e);
    }
}




/* ===== V114 VDP SHEET IMPOSITION =====
   Tối ưu ổn định: render từng record thành PDF nhẹ bằng pipeline V80, sau đó Place PDF
   vào đúng Layout Cache V101 trên khổ in. Không clone artwork nặng N lần trong RAM. */
function ANP_vdpSheetCloneItemsV114(items) {
    var out=[],i,a;
    for(i=0;i<(items?items.length:0);i++){
        a=items[i]||{};out.push({x:Number(a.x||0),y:Number(a.y||0),w:Number(a.w||0),h:Number(a.h||0),
            angle:a.angle!==undefined?Number(a.angle):(a.rotated?90:0),angleExplicit:a.angleExplicit===true||a.angle!==undefined,
            rotated:a.rotated===true,offsetX:Number(a.offsetX||0),offsetY:Number(a.offsetY||0),copyIndex:Number(a.copyIndex==null?i:a.copyIndex)});
    }
    return out;
}

function ANP_vdpSheetRowsV114(items) {
    var sorted=ANP_vdpSheetCloneItemsV114(items),rows=[],row=[],i,lastY=null,tol=0.8,it;
    sorted.sort(function(a,b){var dy=Number(a.y)-Number(b.y);if(Math.abs(dy)>tol){return dy;}return Number(a.x)-Number(b.x);});
    for(i=0;i<sorted.length;i++){
        it=sorted[i];
        if(lastY===null||Math.abs(Number(it.y)-Number(lastY))<=tol){row.push(it);if(lastY===null){lastY=Number(it.y);}}
        else{row.sort(function(a,b){return Number(a.x)-Number(b.x);});rows.push(row);row=[it];lastY=Number(it.y);}
    }
    if(row.length){row.sort(function(a,b){return Number(a.x)-Number(b.x);});rows.push(row);}
    return rows;
}

function ANP_vdpSheetOrderedItemsV114(items,order) {
    var rows,i,j,out=[],r,sorted;
    order=String(order||"row");
    if(order==="column"){
        sorted=ANP_vdpSheetCloneItemsV114(items);
        sorted.sort(function(a,b){var dx=Number(a.x)-Number(b.x);if(Math.abs(dx)>0.8){return dx;}return Number(a.y)-Number(b.y);});
        return sorted;
    }
    rows=ANP_vdpSheetRowsV114(items);
    for(i=0;i<rows.length;i++){
        r=rows[i];
        if(order==="snake"&&i%2===1){for(j=r.length-1;j>=0;j--){out.push(r[j]);}}
        else{for(j=0;j<r.length;j++){out.push(r[j]);}}
    }
    return out;
}

function ANP_vdpSheetChooseItemsV114(items,count,order,lastMode,binW,binH) {
    var ordered=ANP_vdpSheetOrderedItemsV114(items,order),selected=[],i,cx,cy,a,rank=[];
    count=Math.max(0,Math.min(Number(count||0),ordered.length));
    if(count>=ordered.length){return ordered;}
    if(String(lastMode||"blank")==="center"&&count>0){
        cx=Number(binW||0)/2;cy=Number(binH||0)/2;
        for(i=0;i<ordered.length;i++){a=ordered[i];rank.push({a:a,d:Math.pow(Number(a.x)+Number(a.w)/2-cx,2)+Math.pow(Number(a.y)+Number(a.h)/2-cy,2)});}
        rank.sort(function(p,q){return p.d-q.d;});
        for(i=0;i<count;i++){selected.push(rank[i].a);}
        // sau khi chọn vùng trung tâm, sắp lại theo thứ tự record mong muốn
        return ANP_vdpSheetOrderedItemsV114(selected,order);
    }
    for(i=0;i<count;i++){selected.push(ordered[i]);}
    return selected;
}

function ANP_vdpSheetSafePdfV114(folder,prefix,no) {
    var n=String(no),pad=n.length<2?"00":n.length<3?"0":"",base=ANP_vdpSafeNameV71(String(prefix||"VDP_SHEET")+"_"+pad+n);
    return ANP_vdpUniquePdfV71(folder,base);
}

function ANP_vdpSheetPlacePdfV114(doc,file,placement,cfg,opts,pageNo) {
    var pi,a,ang,bleed,sourceW,sourceH,xy;
    if(opts){
        try{opts.pageToOpen=Math.max(1,Number(pageNo||1));}catch(e0){}
        /* V125: RECORD PDF phải dùng MEDIA BOX để phần artboard đã mở rộng theo
           Bleed không bị cắt trở lại về Trim/ArtBox khi Place vào sheet. */
        try{opts.pDFCropToBox=PDFBoxType.PDFMEDIABOX;}catch(e1){try{opts.pDFCropToBox=PDFBoxType.PDFARTBOX;}catch(e2){}}
    }
    pi=doc.placedItems.add();pi.file=file;
    bleed=Math.max(0,Number(cfg.linkBleed)||0);
    sourceW=Math.max(0,Number(cfg.sourceW)||0);sourceH=Math.max(0,Number(cfg.sourceH)||0);
    /* Khóa kích thước page record về đúng Trim + 2*Bleed trước khi xoay.
       Việc này loại sai số PDF crop box khác nhau giữa Illustrator/PDF preset. */
    if(sourceW>0&&sourceH>0){
        try{pi.width=ANP_mm(sourceW+bleed*2);pi.height=ANP_mm(sourceH+bleed*2);}catch(eSize){}
    }
    ang=placement.angle!==undefined?Number(placement.angle):(placement.rotated?90:0);
    if(Math.abs(ang)>0.0001){pi.rotate(placement.angle!==undefined?-ang:ang,true,true,true,true,Transformation.CENTER);}
    a=ANP_activeArtboardRectV61(doc);
    /* Dùng CHÍNH công thức padding của engine Dàn file V4.9/V101. Đặc biệt
       với góc khác 0/90, padAxis = bleed*(|cos|+|sin|), không trừ bleed thô. */
    xy=ANP_v49EffectiveXY(placement,cfg,bleed);
    try{pi.position=[a[0]+ANP_mm(xy.x),a[1]-ANP_mm(xy.y)];}
    catch(ePos){try{pi.left=a[0]+ANP_mm(xy.x);pi.top=a[1]-ANP_mm(xy.y);}catch(ePos2){}}
    return pi;
}

function ANP_vdpSaveRecordPdfV124(doc,file,bleedMm,preserveColor,duplexMode) {
    var oldRects=[],b=Math.max(0,Number(bleedMm)||0),bp=ANP_mm(b),count=1,i,ab,oldRect;
    try {
        if(!doc||!doc.artboards||doc.artboards.length<1){throw new Error("VDP Sheet: file record khong co artboard.");}
        count=(duplexMode===true&&doc.artboards.length>=2)?2:1;
        for(i=0;i<count;i++){
            ab=doc.artboards[i];oldRect=ab.artboardRect;oldRects.push([oldRect[0],oldRect[1],oldRect[2],oldRect[3]]);
            if(b>0.0001){ab.artboardRect=[Number(oldRect[0])-bp,Number(oldRect[1])+bp,Number(oldRect[2])+bp,Number(oldRect[3])-bp];}
        }
        ANP_savePDFRangeV76(doc,file,count>1?"1-2":"1",preserveColor!==false);
        return file;
    } finally {
        for(i=0;i<oldRects.length;i++){try{doc.artboards[i].artboardRect=oldRects[i];}catch(eRestore){}}
    }
}

function ANP_vdpBuildSheetV114(s,buffer,isLast) {
    var cfg=s.sheetConfig||{},layout=s.sheetLayout||{},items=layout.items||[],chosen,doc=null,i,entry,opts=null,oldPage=1,oldCrop=null,
        sheetNo=s.sheetFiles.length+1,file,paperW=Number(cfg.paperW||0),paperH=Number(cfg.paperH||0),colorSpace=DocumentColorSpace.CMYK,
        side=0,sideCount=(cfg.duplexMode===true?2:1),sideLayout=null,layer=null,centerFix={dx:0,dy:0},ponLayer=null,cropLayer=null,titleLayer=null,markCount=0,title="";
    if(!(paperW>0)||!(paperH>0)){throw new Error("VDP Sheet: khổ in không hợp lệ.");}
    if(!items.length){throw new Error("VDP Sheet: Layout Cache V101 không có vị trí dàn.");}
    if(sideCount===2&&s.originalArtboardCount<2){throw new Error("VDP Sheet A/B: file nguồn cần ít nhất 2 artboard.");}
    chosen=ANP_vdpSheetChooseItemsV114(items,buffer.length,String(s.cfg.sheetOrder||"row"),isLast?String(s.cfg.lastSheetMode||"blank"):"blank",Number(layout.binW||0),Number(layout.binH||0));
    if(chosen.length<buffer.length){throw new Error("VDP Sheet: số vị trí dàn nhỏ hơn số record của tờ.");}
    try{
        try{colorSpace=s.originalDoc.documentColorSpace;}catch(eC){}
        doc=app.documents.add(colorSpace,ANP_mm(paperW),ANP_mm(paperH));
        try{doc.artboards[0].artboardRect=[0,ANP_mm(paperH),ANP_mm(paperW),0];doc.artboards[0].name=sideCount===2?"MAT_A":"VDP_SHEET";}catch(eA){}
        if(sideCount===2){ANP_addDuplexArtboardV61(doc,"MAT_B");}
        try{opts=app.preferences.PDFFileOptions;}catch(eO){opts=null;}
        if(opts){try{oldPage=opts.pageToOpen;}catch(eP){}try{oldCrop=opts.pDFCropToBox;}catch(eCr){}}
        title="VDP SHEET "+String(sheetNo)+" · RECORD "+String(buffer[0].recordNo)+"-"+String(buffer[buffer.length-1].recordNo);

        for(side=0;side<sideCount;side++){
            try{doc.artboards.setActiveArtboardIndex(side);}catch(eActive){}
            layer=(side===0?doc.layers[0]:doc.layers.add());
            layer.name=sideCount===2?(side===0?"FILE_IN_MAT_A_VDP":"FILE_IN_MAT_B_VDP"):"VDP_RECORDS";
            ANP_prepareTargetLayerV28(doc,layer);
            if(side===0){sideLayout={items:chosen,binW:Number(layout.binW||0),binH:Number(layout.binH||0),method:String(layout.method||"V101")};}
            else{sideLayout=ANP_duplexLayoutV60({items:chosen,binW:Number(layout.binW||0),binH:Number(layout.binH||0),method:String(layout.method||"V101")},cfg,true);}
            for(i=0;i<buffer.length;i++){
                entry=buffer[i];if(!entry||!entry.file||!entry.file.exists){throw new Error("VDP Sheet: thiếu PDF record "+String(i+1)+".");}
                ANP_vdpSheetPlacePdfV114(doc,entry.file,sideLayout.items[i],cfg,opts,side+1);
            }
            try{centerFix=ANP_exactCenterSingleV36(doc,layer);}catch(eCenter){centerFix={dx:0,dy:0};}

            if(sideCount===2){
                /* Đồng bộ đúng main engine ANP_buildDuplexPrintSheetV61:
                   2 mặt CATTP chỉ có dấu cắt thành phẩm, KHÔNG chèn PON góc/file PON. */
                if(cfg.finishCropMarks!==true){throw new Error("VDP Sheet 2 mặt chỉ dùng khi Dàn file bật PON cắt theo thành phẩm (CATTP).");}
                cropLayer=doc.layers.add();cropLayer.name=side===0?"PON_CATTP_MAT_A":"PON_CATTP_MAT_B";
                markCount=ANP_addFinishCropMarksV56(doc,cropLayer,sideLayout,cfg,centerFix);
                if(markCount<1){throw new Error("Không tạo được PON CATTP cho mặt "+(side===0?"A":"B")+".");}
                if(side===0&&cfg.addTitle&&Number(cfg.header)>=5){titleLayer=doc.layers.add();titleLayer.name="TIEU_DE_MAT_A";ANP_addCenteredTitle(titleLayer,doc,cfg,title);}
            }else{
                if(s.sheetPonCache&&s.sheetPonCache.exists){ponLayer=ANP_addPonCacheV50(doc,cfg,s.sheetPonCache,title,false);}
                else{ponLayer=ANP_addPonV12(doc,cfg,title,false);}
                if(cfg.finishCropMarks===true){
                    markCount=ANP_addFinishCropMarksV56(doc,ponLayer,sideLayout,cfg,centerFix);
                    if(markCount<1){throw new Error("Không tạo được PON cắt thành phẩm cho tờ VDP.");}
                }
            }
        }

        file=ANP_vdpSheetSafePdfV114(s.sheetFolder,String(s.cfg.sheetPrefix||"VDP_SHEET"),sheetNo);
        if(sideCount===2){ANP_savePDFMultiArtboardV61(doc,file,cfg.preservePrintColor!==false);}
        else{ANP_savePDFRangeV76(doc,file,"1",cfg.preservePrintColor!==false);}
        s.sheetFiles.push(file.fsName);s.sheetCountDone++;
        if(s.combineSheets&&s.sheetMergeCtx){ANP_vdpMergeAddPdfV79(s.sheetMergeCtx,file);s.sheetCombinedPages=s.sheetMergeCtx.pageNo;}
        return file;
    }finally{
        try{if(opts){opts.pageToOpen=oldPage;if(oldCrop!==null&&oldCrop!==undefined){opts.pDFCropToBox=oldCrop;}}}catch(eR){}
        try{if(doc){doc.close(SaveOptions.DONOTSAVECHANGES);}}catch(eD){}
    }
}

/* ===== V80 PINNED SOURCE + STREAM / LOW-RAM VDP =====
   - Không duplicate toàn bộ artwork cho mỗi record như V78.
   - Mỗi record được render trực tiếp từ work-copy fidelity sang PDF.
   - Nếu cần PDF gộp, chỉ đặt LINK từng trang PDF vào document merge rất nhẹ.
   - Mỗi record được xử lý bằng một DoJavaScript riêng từ C# để Illustrator có
     cơ hội trả event loop giữa các record, giảm tình trạng trắng/Not Responding. */
var ANP_VDP_BATCH_V79 = ANP_VDP_BATCH_V79 || null;

function ANP_vdpJsonOkV79(payload) {
    try { return payload && payload.ok === true; } catch (e) {}
    return false;
}

function ANP_vdpMergeBeginV79(pageRects, totalRecords, colorSpace) {
    var i, r, pw, ph, maxW = 1, maxH = 1, totalPages = pageRects.length * totalRecords, cols;
    if (!pageRects.length || totalRecords < 1) { throw new Error("Không có trang để gộp PDF."); }
    if (totalPages > 950) { throw new Error("PDF gộp có " + totalPages + " trang, vượt giới hạn an toàn 950 artboard. Hãy chia record thành nhiều nhóm."); }
    for (i = 0; i < pageRects.length; i++) {
        r = pageRects[i]; pw = Math.abs(Number(r[2]) - Number(r[0])); ph = Math.abs(Number(r[1]) - Number(r[3]));
        if (pw > maxW) { maxW = pw; } if (ph > maxH) { maxH = ph; }
    }
    cols = Math.ceil(Math.sqrt(totalPages * (maxH / maxW)));
    if (cols < 1) { cols = 1; } if (cols > totalPages) { cols = totalPages; }
    return { doc:null, pageRects:pageRects, maxW:maxW, maxH:maxH, cols:cols, gap:24,
        pageNo:0, colorSpace:colorSpace || DocumentColorSpace.CMYK, opts:null, oldPage:1, oldCrop:null };
}

function ANP_vdpMergeAddPdfV79(ctx, pdfFile) {
    var j, r, pw, ph, row, col, left, top, pi, ab, w, h;
    if (!ctx || !pdfFile || !pdfFile.exists) { throw new Error("Không đọc được PDF record để gộp."); }
    if (!ctx.opts) {
        try { ctx.opts = app.preferences.PDFFileOptions; } catch (e0) { ctx.opts = null; }
        if (ctx.opts) {
            try { ctx.oldPage = ctx.opts.pageToOpen; } catch (e1) {}
            try { ctx.oldCrop = ctx.opts.pDFCropToBox; ctx.opts.pDFCropToBox = PDFBoxType.PDFMEDIABOX; } catch (e2) {}
        }
    }
    for (j = 0; j < ctx.pageRects.length; j++) {
        r = ctx.pageRects[j]; pw = Math.abs(Number(r[2]) - Number(r[0])); ph = Math.abs(Number(r[1]) - Number(r[3]));
        row = Math.floor(ctx.pageNo / ctx.cols); col = ctx.pageNo % ctx.cols;
        left = col * (ctx.maxW + ctx.gap); top = -row * (ctx.maxH + ctx.gap);
        if (!ctx.doc) {
            w = pw > 0 ? pw : 100; h = ph > 0 ? ph : 100;
            ctx.doc = app.documents.add(ctx.colorSpace, w, h);
            try { ctx.doc.artboards[0].artboardRect = [left, top, left + pw, top - ph]; } catch (e3) {}
        } else {
            ab = ctx.doc.artboards.add([left, top, left + pw, top - ph]);
        }
        try { if (ctx.opts) { ctx.opts.pageToOpen = j + 1; } } catch (e4) {}
        pi = ctx.doc.placedItems.add(); pi.file = pdfFile;
        /* PDF nguồn vừa được xuất đúng artboard nên không resize artwork. Chỉ neo
           top-left của trang vào top-left artboard đích để giữ 100% kích thước. */
        try { pi.position = [left, top]; } catch (e5) { try { pi.left = left; pi.top = top; } catch (e6) {} }
        ctx.pageNo++;
    }
    return ctx.pageNo;
}

function ANP_vdpMergeClosePrefsV79(ctx) {
    if (!ctx || !ctx.opts) { return; }
    try { ctx.opts.pageToOpen = ctx.oldPage; } catch (e0) {}
    try { if (ctx.oldCrop !== null && ctx.oldCrop !== undefined) { ctx.opts.pDFCropToBox = ctx.oldCrop; } } catch (e1) {}
}


/* ===== V127 AI STAY-OPEN / SOURCE GUARD =====
   VDP tạo và đóng nhiều document tạm. Trên một số bản Illustrator Windows,
   nếu document nguồn không còn active/open đúng lúc COM release, Illustrator
   có thể tự đóng sau batch. V127 luôn giữ/reopen file .AI nguồn trước khi đóng
   work-copy/merge docs và kích hoạt lại file nguồn sau cleanup. */
function ANP_vdpFindOpenDocByPathV127(path) {
    var i, d, p = String(path || "").toLowerCase();
    if (!p) { return null; }
    for (i = 0; i < app.documents.length; i++) {
        d = app.documents[i];
        try { if (ANP_vdpPathV80(d).toLowerCase() === p) { return d; } } catch (e0) {}
    }
    return null;
}

function ANP_vdpEnsurePinnedSourceOpenV127() {
    try {
        var p = String(ANP_VDP_SOURCE_V80 && ANP_VDP_SOURCE_V80.path || ""), d = null, f = null;
        if (p) { d = ANP_vdpFindOpenDocByPathV127(p); }
        if (!d && p && /\.ai$/i.test(p)) {
            f = new File(p);
            if (f.exists) { d = app.open(f); }
        }
        if (d) {
            try { d.activate(); } catch (e1) {}
            try { ANP_vdpRememberSourceV80(d); } catch (e2) {}
            return ANP_ok({ sourceOpen:true, sourcePath:p, documentName:String(d.name || "") });
        }
        if (app.documents.length) {
            try { app.activeDocument.activate(); } catch (e3) {}
            return ANP_ok({ sourceOpen:false, fallbackDocument:true, documentName:String(app.activeDocument.name || "") });
        }
        return ANP_ok({ sourceOpen:false, noDocument:true });
    } catch (e) { return ANP_fail(e); }
}

function ANP_vdpEnsureBatchSourceOpenV127(s) {
    var p = "", d = null, f = null;
    if (!s) { return null; }
    try { p = String(s.originalPath || ""); } catch (e0) { p = ""; }
    if (!p) { try { p = ANP_vdpPathV80(s.originalDoc); } catch (e1) { p = ""; } }
    if (!p) { try { p = String(ANP_VDP_SOURCE_V80.path || ""); } catch (e2) { p = ""; } }
    if (p) { d = ANP_vdpFindOpenDocByPathV127(p); }
    if (!d && p && /\.ai$/i.test(p)) {
        try { f = new File(p); if (f.exists) { d = app.open(f); } } catch (e3) { d = null; }
    }
    if (d) {
        s.originalDoc = d;
        s.originalPath = p;
        try { ANP_vdpRememberSourceV80(d); } catch (e4) {}
        try { d.activate(); } catch (e5) {}
    }
    return d;
}

function ANP_vdpBatchCleanupV79(deleteOutputTemp) {
    var s = ANP_VDP_BATCH_V79, i;
    if (!s) { return; }
    /* V127: đảm bảo luôn có file nguồn mở TRƯỚC khi đóng các document tạm. */
    try { ANP_vdpEnsureBatchSourceOpenV127(s); } catch (eKeep0) {}
    try { ANP_vdpMergeClosePrefsV79(s.mergeCtx); } catch (e0) {}
    try { ANP_vdpMergeClosePrefsV79(s.sheetMergeCtx); } catch (eSheet0) {}
    try { if (s.mergeCtx && s.mergeCtx.doc) { s.mergeCtx.doc.close(SaveOptions.DONOTSAVECHANGES); s.mergeCtx.doc = null; } } catch (e1) {}
    try { if (s.sheetMergeCtx && s.sheetMergeCtx.doc) { s.sheetMergeCtx.doc.close(SaveOptions.DONOTSAVECHANGES); s.sheetMergeCtx.doc = null; } } catch (eSheet1) {}
    try { if (s.workDoc) { s.workDoc.close(SaveOptions.DONOTSAVECHANGES); s.workDoc = null; } } catch (e2) {}
    if (deleteOutputTemp === true) {
        try {
            for (i = 0; i < s.tempPdfs.length; i++) { if (s.tempPdfs[i] && s.tempPdfs[i].exists) { s.tempPdfs[i].remove(); } }
        } catch (e3) {}
        try { if (s.tempFolder && s.tempFolder.exists) { s.tempFolder.remove(); } } catch (e4) {}
    }
    try { if (s.cloneInfo && s.cloneInfo.tempFile && s.cloneInfo.tempFile.exists) { s.cloneInfo.tempFile.remove(); } } catch (e5) {}
    try { if (s.sheetPonCache && s.sheetPonCache.exists) { s.sheetPonCache.remove(); } } catch (ePonCache) {}
    /* V127: sau khi đóng work/merge doc, kích hoạt lại đúng file AI nguồn. */
    try { ANP_vdpEnsureBatchSourceOpenV127(s); } catch (eKeep1) {}
    try { if (s.originalDoc) { s.originalDoc.activate(); } } catch (e6) {}
    ANP_VDP_BATCH_V79 = null;
}

function ANP_vdpBatchStartV79(json) {
    try {
        if (ANP_VDP_BATCH_V79) { try { ANP_vdpBatchCleanupV79(true); } catch (eOld) {} }
        if (!app.documents.length) { throw new Error("Chưa mở tài liệu Illustrator."); }
        var cfg = eval("(" + json + ")"), records = cfg.records || [], mappings = cfg.mappings || [], outPath = String(cfg.outputPath || ""),
            start = Math.max(1, Number(cfg.from || 1)), end, outputRoot, outputFolder, originalDoc, pageRects, originalArtboardCount,
            parsedData, cloneInfo, workDoc, workState, exportIndividual, combinePdf, tempFolder = null, colorSpace = DocumentColorSpace.CMYK,
            totalRecords, mergeCtx = null, combinedBase = "", combinedFile = null, sheetMode = cfg.sheetMode === true, sheetLayout = cfg.sheetLayout || null,
            sheetConfig = cfg.sheetConfig || null, sheetFolder = null, sheetSlots = 0, sheetTotal = 0, sheetMergeCtx = null, sheetCombinedFile = null, sheetPonCache = null;
        exportIndividual = cfg.exportIndividual !== false; combinePdf = cfg.combinePdf === true;
        if (!records.length && cfg.dataPath) {
            parsedData = ANP_vdpReadDataFileV71(cfg.dataPath); records = parsedData.records;
            if (!cfg.sourceFolder) { try { cfg.sourceFolder = (new File(cfg.dataPath)).parent.fsName; } catch (eFolder) {} }
        }
        if (!records.length) { throw new Error("Dữ liệu không có record."); }
        if (!mappings.length) { throw new Error("Chưa có kênh biến đổi."); }
        if (!outPath) { throw new Error("Chưa chọn thư mục xuất PDF."); }
        if (!exportIndividual && !combinePdf && !sheetMode) { throw new Error("Hãy chọn ít nhất một kiểu xuất PDF."); }
        end = Math.min(records.length, Math.max(start, Number(cfg.to || records.length))); totalRecords = end - start + 1;
        outputRoot = new Folder(outPath); if (!outputRoot.exists) { throw new Error("Thư mục xuất không tồn tại."); }
        outputFolder = new Folder(outputRoot.fsName + "/VARIABLE_DATA"); if (!outputFolder.exists && !outputFolder.create()) { throw new Error("Không tạo được thư mục VARIABLE_DATA."); }
        originalDoc = ANP_vdpResolveSourceDocV80(mappings);
        if (!originalDoc) {
            var activeName = ""; try { activeName = app.activeDocument ? String(app.activeDocument.name || "") : ""; } catch (eActiveName) {}
            throw new Error("Không xác định được file .AI nguồn của các kênh VDP. Tab đang active: " + activeName + ". Hãy mở file AI gốc, chọn lại 1 đối tượng VDP và bấm '+ Thêm vị trí đang chọn trong AI' rồi chạy lại.");
        }
        ANP_vdpRememberSourceV80(originalDoc);
        try { originalDoc.activate(); } catch (eSourceActivate) {}
        try { colorSpace = originalDoc.documentColorSpace; } catch (eColorEarly) {}
        pageRects = ANP_vdpArtboardRectsV72(originalDoc); originalArtboardCount = pageRects.length;
        if (sheetMode) {
            if (!sheetLayout || Number(sheetLayout.version||0) !== 101 || !sheetLayout.items || !sheetLayout.items.length) { throw new Error("VDP Sheet cần Layout Cache V101. Hãy quay lại Dàn file → Tính nhanh rồi mở VDP lại."); }
            if (!sheetConfig || !(Number(sheetConfig.paperW)>0) || !(Number(sheetConfig.paperH)>0)) { throw new Error("VDP Sheet chưa nhận được thông số khổ in V101."); }
            if (originalArtboardCount < 1) { throw new Error("VDP Sheet: file AI nguồn không có artboard."); }
            var r0=pageRects[0], aw=ANP_toMm(Math.abs(Number(r0[2])-Number(r0[0]))), ah=ANP_toMm(Math.abs(Number(r0[1])-Number(r0[3])));
            if (Number(sheetLayout.sourceW||0)>0 && Math.abs(Number(sheetLayout.sourceW)-aw)>0.8) { throw new Error("VDP Sheet: chiều rộng file VDP không khớp file đã Tính nhanh ("+ANP_round(aw,2)+"mm / "+ANP_round(Number(sheetLayout.sourceW),2)+"mm)."); }
            if (Number(sheetLayout.sourceH||0)>0 && Math.abs(Number(sheetLayout.sourceH)-ah)>0.8) { throw new Error("VDP Sheet: chiều cao file VDP không khớp file đã Tính nhanh ("+ANP_round(ah,2)+"mm / "+ANP_round(Number(sheetLayout.sourceH),2)+"mm)."); }
            if(sheetConfig.duplexMode===true&&originalArtboardCount<2){throw new Error("VDP Sheet A/B: cấu hình Dàn file là 2 mặt nhưng file VDP không có đủ 2 artboard.");}
            sheetSlots=sheetLayout.items.length;sheetTotal=Math.ceil(totalRecords/sheetSlots);
            sheetFolder=new Folder(outputRoot.fsName+"/VARIABLE_DATA_SHEETS");if(!sheetFolder.exists&&!sheetFolder.create()){throw new Error("Không tạo được thư mục VARIABLE_DATA_SHEETS.");}
            if(sheetConfig.ponPath&&sheetConfig.duplexMode!==true){sheetPonCache=ANP_makePonCacheV50(sheetConfig,sheetFolder);}
            if (cfg.combineSheets === true) {
                var sheetRects=[[0,ANP_mm(Number(sheetConfig.paperH)),ANP_mm(Number(sheetConfig.paperW)),0]];
                if(sheetConfig.duplexMode===true){sheetRects.push([0,ANP_mm(Number(sheetConfig.paperH)),ANP_mm(Number(sheetConfig.paperW)),0]);}
                sheetMergeCtx=ANP_vdpMergeBeginV79(sheetRects,sheetTotal,colorSpace);
                sheetCombinedFile=ANP_vdpUniquePdfV71(sheetFolder,ANP_vdpSafeNameV71(String(cfg.sheetCombinedName||"VDP_ALL_SHEETS")));
            }
        }
        try { colorSpace = originalDoc.documentColorSpace; } catch (eColor) {}
        try { ANP_vdpRestoreDocV71(originalDoc); } catch (eRestore) {}
        cloneInfo = ANP_vdpCloneFidelityV78(originalDoc, outputFolder); workDoc = cloneInfo.doc; workDoc.activate();
        /* V140.1: UUID của PageItem có thể đổi khi mở bản work-copy trong lúc source AI vẫn đang mở.
           Rebind mapping sang đúng item tương ứng trong work-copy trước khi capture/apply record. */
        var rebindInfoV140 = ANP_vdpRebindMappingsV140(originalDoc, workDoc, mappings);
        workState = ANP_vdpCaptureStateV73(workDoc, mappings);
        var requiredTargetsV140 = ANP_vdpUniqueTargetCountV140(mappings);
        if (!workState.length || workState.length < requiredTargetsV140) {
            throw new Error("Không map đủ Variable Data trong work-copy AI (" + String(workState.length) + "/" + String(requiredTargetsV140) + " target). Hãy giữ file AI nguồn đang mở và thử lại; nếu vẫn lỗi hãy chọn lại đối tượng VDP.");
        }
        if ((combinePdf || sheetMode) && !exportIndividual) {
            tempFolder = new Folder(outputFolder.fsName + "/.__DPV_V114_TEMP_" + String((new Date()).getTime()));
            if (!tempFolder.exists && !tempFolder.create()) { throw new Error("Không tạo được thư mục PDF tạm."); }
        }
        if (combinePdf) {
            mergeCtx = ANP_vdpMergeBeginV79(pageRects, totalRecords, colorSpace);
            combinedBase = ANP_vdpSafeNameV71(String(cfg.combinedName || (String(cfg.filePrefix || "VDP") + "_ALL")));
            combinedFile = ANP_vdpUniquePdfV71(outputFolder, combinedBase);
        }
        ANP_VDP_BATCH_V79 = {
            cfg:cfg, records:records, mappings:mappings, start:start, end:end, current:start - 1, total:totalRecords,
            outputFolder:outputFolder, originalDoc:originalDoc, originalPath:ANP_vdpPathV80(originalDoc), pageRects:pageRects, originalArtboardCount:originalArtboardCount,
            cloneInfo:cloneInfo, workDoc:workDoc, workState:workState, exportIndividual:exportIndividual, combinePdf:combinePdf,
            tempFolder:tempFolder, tempPdfs:[], created:[], mergeCtx:mergeCtx, combinedFile:combinedFile, combinedPages:0,
            sheetMode:sheetMode, sheetLayout:sheetLayout, sheetConfig:sheetConfig, sheetFolder:sheetFolder, sheetSlots:sheetSlots, sheetTotal:sheetTotal,
            sheetBuffer:[], sheetFiles:[], sheetCountDone:0, combineSheets:cfg.combineSheets===true, sheetMergeCtx:sheetMergeCtx,
            sheetCombinedFile:sheetCombinedFile, sheetCombinedPages:0, keepRecordPdfs:cfg.keepRecordPdfs===true, sheetPonCache:sheetPonCache,
            fidelity:true, autoSaved:(cloneInfo && cloneInfo.autoSaved === true), vdpReboundTargets:(rebindInfoV140 ? Number(rebindInfoV140.rebound || 0) : 0)
        };
        return ANP_ok({ total:totalRecords, from:start, to:end, mappingCount:mappings.length, mode:sheetMode?"VDP_SHEET_STREAM_V114":"PINNED_SOURCE_STREAM_V80", autoSaved:ANP_VDP_BATCH_V79.autoSaved, sheetMode:sheetMode, slotsPerSheet:sheetSlots, sheetTotal:sheetTotal, vdpReboundTargets:ANP_VDP_BATCH_V79.vdpReboundTargets });
    } catch (e) {
        /* Nếu lỗi xảy ra trước khi ANP_VDP_BATCH_V79 được gán (ví dụ rebind/capture),
           tự đóng work-copy và xóa file tạm để không để lại tab/file rác. */
        try { if (!ANP_VDP_BATCH_V79 && workDoc) { workDoc.close(SaveOptions.DONOTSAVECHANGES); workDoc = null; } } catch (eLocalClose) {}
        try { if (!ANP_VDP_BATCH_V79 && cloneInfo && cloneInfo.tempFile && cloneInfo.tempFile.exists) { cloneInfo.tempFile.remove(); } } catch (eLocalDel) {}
        try { ANP_vdpBatchCleanupV79(true); } catch (eClean) {}
        try { if (originalDoc) { originalDoc.activate(); } } catch (eReactivate) {}
        return ANP_fail(e);
    }
}

function ANP_vdpBatchStepV79() {
    var s = ANP_VDP_BATCH_V79, i, record, applied, nameValue, base, file, folder, sheetFile=null, isLast=false;
    try {
        if (!s) { throw new Error("Batch VDP chưa được khởi tạo."); }
        if (s.current >= s.end) { return ANP_ok({ done:true, current:s.total, total:s.total }); }
        i = s.current; s.workDoc.activate();
        ANP_vdpRestoreStateV73(s.workDoc, s.workState);
        record = s.records[i];
        applied = ANP_vdpApplyRecordV71(s.workDoc, s.mappings, record, String(s.cfg.sourceFolder || ""), true);
        if (applied < 1) { throw new Error("Record " + String(i + 1) + " không áp dụng được kênh biến đổi nào."); }
        nameValue = s.cfg.fileNameField && record[s.cfg.fileNameField] !== undefined ? record[s.cfg.fileNameField] : String(i + 1);
        base = ANP_vdpSafeNameV71(String(s.cfg.filePrefix || "VDP") + "_" + String(nameValue));
        folder = s.exportIndividual ? s.outputFolder : s.tempFolder;
        file = ANP_vdpUniquePdfV71(folder, base);
        if (s.sheetMode) {
            ANP_vdpSaveRecordPdfV124(s.workDoc,file,Number(s.sheetConfig&&s.sheetConfig.linkBleed||0),!(s.sheetConfig&&s.sheetConfig.preservePrintColor===false),s.sheetConfig&&s.sheetConfig.duplexMode===true);
        } else {
            ANP_savePDFRangeV76(s.workDoc,file,"1-" + String(s.originalArtboardCount),true);
        }
        if (s.exportIndividual) { s.created.push(file.fsName); }
        else { s.tempPdfs.push(file); }
        if (s.sheetMode) {
            s.sheetBuffer.push({file:file,recordNo:i+1});
            isLast = (i + 1 >= s.end);
            if (s.sheetBuffer.length >= s.sheetSlots || isLast) {
                sheetFile=ANP_vdpBuildSheetV114(s,s.sheetBuffer,isLast);
                if (!s.keepRecordPdfs) {
                    var di;for(di=0;di<s.sheetBuffer.length;di++){try{if(s.sheetBuffer[di].file&&s.sheetBuffer[di].file.exists){s.sheetBuffer[di].file.remove();}}catch(eDel){}}
                }
                s.sheetBuffer=[];
            }
        }
        if (s.combinePdf) {
            ANP_vdpMergeAddPdfV79(s.mergeCtx, file);
            s.combinedPages = s.mergeCtx.pageNo;
        }
        s.current++;
        try { s.workDoc.activate(); } catch (eAct) {}
        return ANP_ok({ current:(s.current - s.start + 1), total:s.total, recordNumber:i + 1, applied:applied,
            individualFile:s.exportIndividual ? file.fsName : "", combinedPages:s.combinedPages, mode:s.sheetMode?"VDP_SHEET_STREAM_V114":"PINNED_SOURCE_STREAM_V80",
            sheetMode:s.sheetMode===true, sheetCreated:sheetFile?sheetFile.fsName:"", sheetDone:s.sheetCountDone||0, sheetTotal:s.sheetTotal||0, slotsPerSheet:s.sheetSlots||0 });
    } catch (e) {
        return ANP_fail(e);
    }
}

function ANP_vdpBatchFinishV79() {
    var s = ANP_VDP_BATCH_V79, result;
    try {
        if (!s) { throw new Error("Batch VDP chưa được khởi tạo."); }
        if (s.current < s.end) { throw new Error("Batch chưa xử lý đủ record."); }
        if (s.combinePdf) {
            if (!s.mergeCtx || !s.mergeCtx.doc) { throw new Error("Không có trang để tạo PDF gộp."); }
            ANP_vdpMergeClosePrefsV79(s.mergeCtx);
            s.mergeCtx.doc.activate();
            if (Number(s.mergeCtx.doc.artboards.length) !== Number(s.combinedPages)) {
                throw new Error("Lỗi dựng PDF gộp: có " + String(s.mergeCtx.doc.artboards.length) + " artboard nhưng dự kiến " + String(s.combinedPages) + " trang.");
            }
            ANP_savePDFRangeV76(s.mergeCtx.doc, s.combinedFile, "1-" + String(s.combinedPages), true);
            try { s.mergeCtx.doc.close(SaveOptions.DONOTSAVECHANGES); } catch (eCloseMerge) {}
            s.mergeCtx.doc = null;
        }
        if (s.sheetMode && s.combineSheets) {
            if (!s.sheetMergeCtx || !s.sheetMergeCtx.doc) { throw new Error("VDP Sheet: không có tờ để Combine."); }
            ANP_vdpMergeClosePrefsV79(s.sheetMergeCtx);s.sheetMergeCtx.doc.activate();
            ANP_vdpNormalizeSheetArtboardsV125(s.sheetMergeCtx,s.sheetCombinedPages);
            ANP_vdpAssertSheetPageSizeV125(s.sheetMergeCtx.doc,s.sheetCombinedPages,Number(s.sheetConfig.paperW),Number(s.sheetConfig.paperH));
            ANP_savePDFRangeV76(s.sheetMergeCtx.doc,s.sheetCombinedFile,"1-"+String(s.sheetCombinedPages),true);
            try{s.sheetMergeCtx.doc.close(SaveOptions.DONOTSAVECHANGES);}catch(eSheetClose){}s.sheetMergeCtx.doc=null;
        }
        result = {
            count:s.total, mappingCount:s.mappings.length, individualCount:s.created.length, from:s.start, to:s.end,
            outputFolder:s.outputFolder.fsName, created:s.created, combinedFile:s.combinedFile ? s.combinedFile.fsName : "",
            combinedPages:s.combinedPages, fastCombined:s.combinePdf, fastMode:"TRUE_MULTIPAGE_STREAM_V84", fidelityClone:true,
            autoSaved:s.autoSaved === true, units:"legacy", lowRam:true, pagesPerRecord:s.originalArtboardCount, pageRects:s.pageRects,
            sheetMode:s.sheetMode===true, sheetFiles:s.sheetFiles||[], sheetCount:s.sheetCountDone||0, slotsPerSheet:s.sheetSlots||0,
            sheetOutputFolder:s.sheetFolder?s.sheetFolder.fsName:"", sheetCombinedFile:s.sheetCombinedFile?s.sheetCombinedFile.fsName:"",
            sheetCombinedPages:s.sheetCombinedPages||0, keepRecordPdfs:s.keepRecordPdfs===true, sheetEngine:"RECORD_MEDIA_BOX_TO_V101_PRODUCTION_V125"
        };
        /* Xóa PDF tạm chỉ sau khi PDF gộp đã save xong. */
        ANP_vdpBatchCleanupV79(true);
        return ANP_ok(result);
    } catch (e) {
        try { ANP_vdpBatchCleanupV79(true); } catch (eClean) {}
        return ANP_fail(e);
    }
}



/* ===== V86 INTERNAL PDF COMBINE - KHÔNG CẦN ACROBAT =====
   Gộp SAU khi Illustrator đã render từng PDF record.
   Mỗi PDF/page chỉ được Place dưới dạng 1 PlacedItem nhẹ vào document tạm,
   tạo đúng 1 artboard/page rồi Save PDF nhiều trang một lần ở cuối.
   Không copy artwork gốc, không snapshot hàng trăm group, không cần Acrobat. */
var ANP_VDP_COMBINE_V86 = ANP_VDP_COMBINE_V86 || null;

function ANP_vdpCombineCleanupV86() {
    var s = ANP_VDP_COMBINE_V86;
    if (!s) { return; }
    try {
        if (s.opts) {
            try { s.opts.pageToOpen = s.oldPage; } catch (e0) {}
            try { if (s.oldCrop !== null && s.oldCrop !== undefined) { s.opts.pDFCropToBox = s.oldCrop; } } catch (e1) {}
        }
    } catch (e2) {}
    try { if (s.doc) { s.doc.close(SaveOptions.DONOTSAVECHANGES); s.doc = null; } } catch (e3) {}
    ANP_VDP_COMBINE_V86 = null;
}

function ANP_vdpCombineMetricsV86(pageRects) {
    var i, r, w, h, maxW = 1, maxH = 1;
    if (!pageRects) { pageRects = []; }
    for (i = 0; i < pageRects.length; i++) {
        r = pageRects[i];
        if (!r || r.length < 4) { continue; }
        w = Math.abs(Number(r[2]) - Number(r[0]));
        h = Math.abs(Number(r[1]) - Number(r[3]));
        if (w > maxW) { maxW = w; }
        if (h > maxH) { maxH = h; }
    }
    return { maxW:maxW, maxH:maxH };
}

function ANP_vdpCombineStartV86(json) {
    try {
        if (ANP_VDP_COMBINE_V86) { ANP_vdpCombineCleanupV86(); }
        var cfg = eval("(" + String(json || "{}") + ")"), outPath = String(cfg.outputPath || ""),
            pagesPerFile = Math.max(1, Number(cfg.pagesPerFile || 1)), totalFiles = Math.max(1, Number(cfg.totalFiles || 1)),
            pageRects = cfg.pageRects || [], totalPages = pagesPerFile * totalFiles, metrics, cols, opts = null,
            oldPage = 1, oldCrop = null, colorSpace = DocumentColorSpace.CMYK;
        if (!outPath) { throw new Error("Chưa có đường dẫn PDF Combine."); }
        if (totalPages > 950) { throw new Error("PDF Combine có " + totalPages + " trang, vượt giới hạn an toàn 950 artboard. Hãy chia thành nhiều nhóm."); }
        metrics = ANP_vdpCombineMetricsV86(pageRects);
        if (metrics.maxW <= 1) { metrics.maxW = 1000; }
        if (metrics.maxH <= 1) { metrics.maxH = 1000; }
        cols = Math.ceil(Math.sqrt(totalPages * (metrics.maxH / metrics.maxW)));
        if (cols < 1) { cols = 1; }
        if (cols > totalPages) { cols = totalPages; }
        try { opts = app.preferences.PDFFileOptions; } catch (e0) { opts = null; }
        if (opts) {
            try { oldPage = opts.pageToOpen; } catch (e1) {}
            try { oldCrop = opts.pDFCropToBox; } catch (e2) {}
            /* V125: khi caller đã truyền pageRects chính xác (VDP Sheet), Place
               bằng MEDIA BOX để giữ toàn bộ khổ giấy/PON/bleed. Generic Combine
               không có pageRects vẫn ưu tiên ARTBOX như trước. */
            if(pageRects && pageRects.length >= pagesPerFile){
                try { opts.pDFCropToBox = PDFBoxType.PDFMEDIABOX; } catch (e3a) { try { opts.pDFCropToBox = PDFBoxType.PDFARTBOX; } catch (e4a) {} }
            }else{
                try { opts.pDFCropToBox = PDFBoxType.PDFARTBOX; } catch (e3) { try { opts.pDFCropToBox = PDFBoxType.PDFMEDIABOX; } catch (e4) {} }
            }
        }
        ANP_VDP_COMBINE_V86 = {
            doc:null, outputFile:new File(outPath), pagesPerFile:pagesPerFile, totalFiles:totalFiles, totalPages:totalPages,
            pageRects:pageRects, maxW:metrics.maxW, maxH:metrics.maxH, cols:cols, gap:24,
            pageNo:0, fileNo:0, opts:opts, oldPage:oldPage, oldCrop:oldCrop, colorSpace:colorSpace,
            dynamicSize:pageRects.length < pagesPerFile
        };
        return ANP_ok({ mode:"DPV_INTERNAL_PDF_COMBINE_V86", totalFiles:totalFiles, pagesPerFile:pagesPerFile, totalPages:totalPages });
    } catch (e) {
        try { ANP_vdpCombineCleanupV86(); } catch (eClean) {}
        return ANP_fail(e);
    }
}

function ANP_vdpCombineAddV86(filePath) {
    var s = ANP_VDP_COMBINE_V86, f, j, r, pw, ph, row, col, left, top, pi, gb, w, h;
    try {
        if (!s) { throw new Error("Combine V86 chưa được khởi tạo."); }
        f = new File(String(filePath || ""));
        if (!f.exists) { throw new Error("Không tìm thấy PDF record: " + String(filePath || "")); }
        for (j = 0; j < s.pagesPerFile; j++) {
            if (s.opts) { try { s.opts.pageToOpen = j + 1; } catch (e0) {} }
            if (!s.doc) {
                s.doc = app.documents.add(s.colorSpace, 100, 100);
            }
            pi = s.doc.placedItems.add();
            pi.file = f;
            if (s.pageRects && s.pageRects.length > j && s.pageRects[j] && s.pageRects[j].length >= 4) {
                r = s.pageRects[j];
                pw = Math.abs(Number(r[2]) - Number(r[0]));
                ph = Math.abs(Number(r[1]) - Number(r[3]));
            } else {
                try {
                    gb = pi.geometricBounds;
                    pw = Math.abs(Number(gb[2]) - Number(gb[0]));
                    ph = Math.abs(Number(gb[1]) - Number(gb[3]));
                } catch (e1) { pw = Number(pi.width || 100); ph = Number(pi.height || 100); }
                if (!(pw > 0)) { pw = 100; }
                if (!(ph > 0)) { ph = 100; }
                if (s.pageNo === 0) {
                    s.maxW = pw; s.maxH = ph;
                    s.cols = Math.ceil(Math.sqrt(s.totalPages * (s.maxH / s.maxW)));
                    if (s.cols < 1) { s.cols = 1; }
                    if (s.cols > s.totalPages) { s.cols = s.totalPages; }
                }
            }
            row = Math.floor(s.pageNo / s.cols); col = s.pageNo % s.cols;
            left = col * (s.maxW + s.gap); top = -row * (s.maxH + s.gap);
            if (s.pageNo === 0) {
                try { s.doc.artboards[0].artboardRect = [left, top, left + pw, top - ph]; } catch (e2) {}
            } else {
                s.doc.artboards.add([left, top, left + pw, top - ph]);
            }
            /* Neo chính xác top-left của PDF page vào top-left artboard. Không scale. */
            try { pi.position = [left, top]; } catch (e3) { try { pi.left = left; pi.top = top; } catch (e4) {} }
            s.pageNo++;
        }
        s.fileNo++;
        return ANP_ok({ mode:"DPV_INTERNAL_PDF_COMBINE_V86", current:s.fileNo, total:s.totalFiles, pages:s.pageNo, file:f.fsName });
    } catch (e) {
        return ANP_fail(e);
    }
}


/* V125 - Sheet Combine phải giữ KHỔ GIẤY, không được rebuild theo
   geometricBounds của Placed PDF vì bounds đó chỉ là artwork/clip và có thể nhỏ
   hơn MediaBox vài mm. Rebuild artboard từ pageRects cố định của khổ in. */
function ANP_vdpNormalizeSheetArtboardsV125(ctx,expected) {
    var doc=ctx&&ctx.doc,n=Number(expected||0),i,r,pw,ph,row,col,left,top,rect;
    if(!doc){throw new Error("VDP Sheet Combine V125: thiếu document merge.");}
    if(n<1){n=Number(ctx.pageNo||0);}
    if(n<1){throw new Error("VDP Sheet Combine V125: không có trang.");}
    try{while(doc.artboards.length>1){doc.artboards[doc.artboards.length-1].remove();}}catch(e0){}
    for(i=0;i<n;i++){
        r=ctx.pageRects[i%ctx.pageRects.length];
        pw=Math.abs(Number(r[2])-Number(r[0]));ph=Math.abs(Number(r[1])-Number(r[3]));
        row=Math.floor(i/ctx.cols);col=i%ctx.cols;left=col*(ctx.maxW+ctx.gap);top=-row*(ctx.maxH+ctx.gap);
        rect=[left,top,left+pw,top-ph];
        if(i===0){doc.artboards[0].artboardRect=rect;}
        else{doc.artboards.add(rect);}
    }
    return Number(doc.artboards.length);
}

function ANP_vdpAssertSheetPageSizeV125(doc,expected,paperW,paperH) {
    var i,r,w,h,tol=ANP_mm(0.02),tw=ANP_mm(Number(paperW)),th=ANP_mm(Number(paperH));
    if(!doc||Number(doc.artboards.length)!==Number(expected)){throw new Error("VDP Sheet Combine V125: số artboard không khớp số trang.");}
    for(i=0;i<doc.artboards.length;i++){
        r=doc.artboards[i].artboardRect;w=Math.abs(Number(r[2])-Number(r[0]));h=Math.abs(Number(r[1])-Number(r[3]));
        if(Math.abs(w-tw)>tol||Math.abs(h-th)>tol){throw new Error("VDP Sheet Combine V125: trang "+String(i+1)+" sai khổ giấy.");}
    }
    return true;
}

/* V123 - Normalize merge artboards from the placed PDF pages themselves.
   IE/COM batch can leave Illustrator artboard collection out of sync when
   many temporary documents are created/closed. Rebuilding the artboards at
   finish guarantees exactly one artboard for each placed PDF page. */
function ANP_vdpNormalizeMergeArtboardsV123(doc, expected) {
    var n=Number(expected||0), pis=[], i, gb, rects=[];
    if(!doc){throw new Error("Combine V123: thiếu document merge.");}
    try{for(i=0;i<doc.placedItems.length;i++){pis.push(doc.placedItems[i]);}}catch(e0){}
    if(n<1){n=pis.length;}
    if(pis.length<n){throw new Error("Combine V123: thiếu PDF page đã Place ("+pis.length+"/"+n+").");}
    for(i=0;i<n;i++){
        try{gb=pis[i].geometricBounds;rects.push([Number(gb[0]),Number(gb[1]),Number(gb[2]),Number(gb[3])]);}
        catch(e1){throw new Error("Combine V123: không đọc được bounds PDF page "+String(i+1)+".");}
    }
    try{while(doc.artboards.length>1){doc.artboards[doc.artboards.length-1].remove();}}catch(e2){}
    if(!rects.length){throw new Error("Combine V123: không có trang để dựng artboard.");}
    try{doc.artboards[0].artboardRect=rects[0];}catch(e3){throw new Error("Combine V123: không đặt được artboard trang 1.");}
    for(i=1;i<rects.length;i++){doc.artboards.add(rects[i]);}
    return Number(doc.artboards.length);
}

function ANP_vdpCombineFinishV86() {
    var s = ANP_VDP_COMBINE_V86, outPath = "", pages = 0, count = 0;
    try {
        if (!s || !s.doc) { throw new Error("Không có PDF nào để Combine."); }
        if (s.fileNo !== s.totalFiles) { throw new Error("Combine chưa đủ file: " + s.fileNo + "/" + s.totalFiles + "."); }
        if (s.pageNo !== s.totalPages) { throw new Error("Số trang Combine không đúng: " + s.pageNo + "/" + s.totalPages + "."); }
        if(s.pageRects && s.pageRects.length >= s.pagesPerFile){
            ANP_vdpNormalizeSheetArtboardsV125(s,s.pageNo);
        }else{
            ANP_vdpNormalizeMergeArtboardsV123(s.doc,s.pageNo);
        }
        if (Number(s.doc.artboards.length) !== Number(s.pageNo)) { throw new Error("Combine V125: số artboard vẫn không khớp số trang ("+String(s.doc.artboards.length)+"/"+String(s.pageNo)+")."); }
        try {
            if (s.opts) {
                try { s.opts.pageToOpen = s.oldPage; } catch (e0) {}
                try { if (s.oldCrop !== null && s.oldCrop !== undefined) { s.opts.pDFCropToBox = s.oldCrop; } } catch (e1) {}
            }
        } catch (e2) {}
        s.doc.activate();
        ANP_savePDFRangeV76(s.doc, s.outputFile, "1-" + String(s.pageNo), true);
        outPath = s.outputFile.fsName; pages = s.pageNo; count = s.fileNo;
        try { s.doc.close(SaveOptions.DONOTSAVECHANGES); } catch (e3) {}
        s.doc = null; ANP_VDP_COMBINE_V86 = null;
        return ANP_ok({ combinedFile:outPath, combinedPages:pages, combinedCount:count, combineEngine:"DPV Internal Combine · Illustrator PDF Link", fastMode:"RECORD_PDF_THEN_DPV_COMBINE_V86" });
    } catch (e) {
        try { ANP_vdpCombineCleanupV86(); } catch (eClean) {}
        return ANP_fail(e);
    }
}

function ANP_vdpCombineAbortV86() {
    try { ANP_vdpCombineCleanupV86(); return ANP_ok({ aborted:true }); }
    catch (e) { return ANP_fail(e); }
}

function ANP_vdpBatchAbortV79() {
    try { ANP_vdpBatchCleanupV79(true); return ANP_ok({ aborted:true }); }
    catch (e) { ANP_VDP_BATCH_V79 = null; return ANP_fail(e); }
}

/* ========================================================================== */
/* V142.5 LAST-SHEET BASE-FILL SAFE ADD-ON                                    */
/* APPEND-ONLY: existing V141.2/V142.x sheet engine is left untouched.        */
/* New mode: lastSheetMode = "basefill"                                       */
/* - Real records keep the normal V101 slot order from the start of the sheet. */
/* - Missing slots are filled with the ORIGINAL work-copy artwork, after       */
/*   restoring captured VDP state, so no variable transformation is applied.  */
/* - This is especially safe for CUT & STACK because no last-sheet centering. */
/* ========================================================================== */
var ANP_vdpBuildSheetV114_V1425_ORIGINAL = ANP_vdpBuildSheetV114;

function ANP_vdpBaseFillTempPdfV1425(s) {
    var folder = s && s.sheetFolder ? s.sheetFolder : null, f = null, stamp = String((new Date()).getTime()), n = 1,
        cfg = s && s.sheetConfig ? s.sheetConfig : {};
    if (!folder || !folder.exists) { throw new Error("V142.5 Base Fill: thiếu thư mục VDP Sheet."); }
    if (!s.workDoc) { throw new Error("V142.5 Base Fill: thiếu work-copy Illustrator."); }
    do {
        f = new File(folder.fsName + "/.__DPV_V1425_BASE_FILL_" + stamp + "_" + String(n) + ".pdf");
        n++;
    } while (f.exists && n < 9999);
    /* Restore the captured ORIGINAL mapping state. This removes the current
       record's text/image/visibility/fill changes without touching source AI. */
    try { s.workDoc.activate(); } catch (eAct) {}
    ANP_vdpRestoreStateV73(s.workDoc, s.workState);
    ANP_vdpSaveRecordPdfV124(
        s.workDoc,
        f,
        Number(cfg.linkBleed || 0),
        !(cfg.preservePrintColor === false),
        cfg.duplexMode === true
    );
    if (!f.exists) { throw new Error("V142.5 Base Fill: không tạo được PDF file gốc."); }
    return f;
}

ANP_vdpBuildSheetV114 = function (s, buffer, isLast) {
    var mode = String(s && s.cfg ? (s.cfg.lastSheetMode || "blank") : "blank"),
        slots = s && s.sheetLayout && s.sheetLayout.items ? Number(s.sheetLayout.items.length || 0) : 0,
        realCount = buffer ? Number(buffer.length || 0) : 0, padded = [], i, filler = null, lastNo = 0, out;
    if (!isLast || mode !== "basefill" || !(slots > 0) || realCount >= slots || realCount < 1) {
        return ANP_vdpBuildSheetV114_V1425_ORIGINAL(s, buffer, isLast);
    }
    for (i = 0; i < realCount; i++) { padded.push(buffer[i]); }
    try { lastNo = Number(buffer[realCount - 1].recordNo || realCount); } catch (eNo) { lastNo = realCount; }
    try {
        filler = ANP_vdpBaseFillTempPdfV1425(s);
        while (padded.length < slots) {
            padded.push({ file:filler, recordNo:lastNo, v1425BaseFill:true });
        }
        out = ANP_vdpBuildSheetV114_V1425_ORIGINAL(s, padded, isLast);
        return out;
    } finally {
        try { if (filler && filler.exists) { filler.remove(); } } catch (eDel) {}
        try { if (s && s.workDoc) { s.workDoc.activate(); } } catch (eBack) {}
    }
};

/* ===== DPV V146 QR & BARCODE VECTOR SAFE ADD-ON =====
   APPEND-ONLY wrapper. Old VDP actions delegate to original ANP_vdpApplyOneV71 unchanged. */
(function(){
    if (typeof ANP_vdpApplyOneV71 !== "function" || typeof ANP_V146_OLD_APPLY_ONE !== "undefined") { return; }
    ANP_V146_OLD_APPLY_ONE = ANP_vdpApplyOneV71;

    function ANP_v146Utf8Bytes(s) {
        s = String(s == null ? "" : s); var out=[],i,c,c2;
        for(i=0;i<s.length;i++){
            c=s.charCodeAt(i);
            if(c<0x80){out.push(c);}
            else if(c<0x800){out.push(0xC0|(c>>6),0x80|(c&63));}
            else if(c>=0xD800&&c<=0xDBFF&&i+1<s.length){
                c2=s.charCodeAt(++i); c=0x10000+((c-0xD800)<<10)+(c2-0xDC00);
                out.push(0xF0|(c>>18),0x80|((c>>12)&63),0x80|((c>>6)&63),0x80|(c&63));
            } else {out.push(0xE0|(c>>12),0x80|((c>>6)&63),0x80|(c&63));}
        }
        return out;
    }
    function ANP_v146GfMul(x,y){var r=0;while(y>0){if(y&1)r^=x;y>>=1;x<<=1;if(x&0x100)x^=0x11d;}return r;}
    function ANP_v146RsGenerator(deg){var g=[1],i,j,n;
        for(i=0;i<deg;i++){n=[];for(j=0;j<g.length+1;j++)n[j]=0;for(j=0;j<g.length;j++){n[j]^=g[j];n[j+1]^=ANP_v146GfMul(g[j],ANP_v146GfPow2(i));}g=n;}return g;}
    function ANP_v146GfPow2(p){var x=1,i;for(i=0;i<p;i++){x<<=1;if(x&0x100)x^=0x11d;}return x;}
    function ANP_v146RsRemainder(data,degree){var gen=ANP_v146RsGenerator(degree),res=[],i,j,f;for(i=0;i<degree;i++)res[i]=0;
        for(i=0;i<data.length;i++){f=data[i]^res[0];for(j=0;j<degree-1;j++)res[j]=res[j+1];res[degree-1]=0;for(j=0;j<degree;j++)res[j]^=ANP_v146GfMul(gen[j+1],f);}return res;}
    function ANP_v146AppendBits(arr,val,len){var i;for(i=len-1;i>=0;i--)arr.push((val>>>i)&1);}
    function ANP_v146BitsToBytes(bits){var out=[],i,b;for(i=0;i<bits.length;i+=8){b=0;for(var j=0;j<8;j++)b=(b<<1)|(bits[i+j]||0);out.push(b);}return out;}
    function ANP_v146QrSpec(ver){
        var t={1:[26,19,1],2:[44,34,1],3:[70,55,1],4:[100,80,1],5:[134,108,1],6:[172,136,2]}; return t[ver];
    }
    function ANP_v146QrCapBytes(ver){var s=ANP_v146QrSpec(ver); return s[1]-2-(ver<10?2:3);}
    function ANP_v146QrBlocks(ver,data){
        var spec=ANP_v146QrSpec(ver), total=spec[0], dataTotal=spec[1], blocks=spec[2], eccTotal=total-dataTotal,
            baseData=Math.floor(dataTotal/blocks), extraData=dataTotal%blocks, eccPer=Math.floor(eccTotal/blocks), db=[],eb=[],i,off=0,len;
        for(i=0;i<blocks;i++){len=baseData+(i>=blocks-extraData?1:0);db[i]=data.slice(off,off+len);off+=len;eb[i]=ANP_v146RsRemainder(db[i],eccPer);}
        var out=[],max=0,j;for(i=0;i<blocks;i++)if(db[i].length>max)max=db[i].length;
        for(j=0;j<max;j++)for(i=0;i<blocks;i++)if(j<db[i].length)out.push(db[i][j]);
        for(j=0;j<eccPer;j++)for(i=0;i<blocks;i++)out.push(eb[i][j]); return out;
    }
    function ANP_v146QrData(ver,bytes){var spec=ANP_v146QrSpec(ver),bits=[],cap=spec[1]*8,i,pads=[0xEC,0x11],p=0;
        ANP_v146AppendBits(bits,4,4); ANP_v146AppendBits(bits,bytes.length,ver<10?8:16); for(i=0;i<bytes.length;i++)ANP_v146AppendBits(bits,bytes[i],8);
        if(bits.length+4<=cap)ANP_v146AppendBits(bits,0,4); while(bits.length%8)bits.push(0); var data=ANP_v146BitsToBytes(bits); while(data.length<spec[1])data.push(pads[(p++)&1]); return ANP_v146QrBlocks(ver,data);}
    function ANP_v146BchTypeInfo(data){var d=data<<10,g=0x537;while((ANP_v146BchDigit(d)-ANP_v146BchDigit(g))>=0)d^=(g<<(ANP_v146BchDigit(d)-ANP_v146BchDigit(g)));return ((data<<10)|d)^0x5412;}
    function ANP_v146BchDigit(d){var n=0;while(d){n++;d>>>=1;}return n;}
    function ANP_v146Mask(mask,i,j){switch(mask){case 0:return (i+j)%2===0;case 1:return i%2===0;case 2:return j%3===0;case 3:return (i+j)%3===0;case 4:return (Math.floor(i/2)+Math.floor(j/3))%2===0;case 5:return (i*j)%2+(i*j)%3===0;case 6:return ((i*j)%2+(i*j)%3)%2===0;case 7:return ((i*j)%3+(i+j)%2)%2===0;}return false;}
    function ANP_v146Blank(n){var a=[],r,c;for(r=0;r<n;r++){a[r]=[];for(c=0;c<n;c++)a[r][c]=null;}return a;}
    function ANP_v146Finder(m,row,col){var r,c,n=m.length;for(r=-1;r<=7;r++)for(c=-1;c<=7;c++){if(row+r<0||row+r>=n||col+c<0||col+c>=n)continue;m[row+r][col+c]=(r>=0&&r<=6&&c>=0&&c<=6&&(r===0||r===6||c===0||c===6||(r>=2&&r<=4&&c>=2&&c<=4)));}}
    function ANP_v146AlignPositions(ver){var a={1:[],2:[6,18],3:[6,22],4:[6,26],5:[6,30],6:[6,34]};return a[ver];}
    function ANP_v146SetupBase(ver){var n=17+4*ver,m=ANP_v146Blank(n),pos=ANP_v146AlignPositions(ver),i,j,r,c;
        ANP_v146Finder(m,0,0);ANP_v146Finder(m,n-7,0);ANP_v146Finder(m,0,n-7);
        for(i=8;i<n-8;i++){if(m[i][6]===null)m[i][6]=(i%2===0);if(m[6][i]===null)m[6][i]=(i%2===0);}
        for(i=0;i<pos.length;i++)for(j=0;j<pos.length;j++){r=pos[i];c=pos[j];if(m[r][c]!==null)continue;for(var dr=-2;dr<=2;dr++)for(var dc=-2;dc<=2;dc++)m[r+dr][c+dc]=(Math.max(Math.abs(dr),Math.abs(dc))!==1);}
        m[n-8][8]=true; return m;}
    function ANP_v146PlaceType(m,mask){var n=m.length,bits=ANP_v146BchTypeInfo((1<<3)|mask),i,bit;
        for(i=0;i<15;i++){bit=((bits>>i)&1)!==0;if(i<6)m[i][8]=bit;else if(i<8)m[i+1][8]=bit;else m[n-15+i][8]=bit;}
        for(i=0;i<15;i++){bit=((bits>>i)&1)!==0;if(i<8)m[8][n-i-1]=bit;else if(i<9)m[8][15-i]=bit;else m[8][15-i-1]=bit;}
        m[n-8][8]=true;
    }
    function ANP_v146MapData(m,bytes,mask){var n=m.length,row=n-1,inc=-1,bitIndex=0,byteIndex=0,col,r,c,dark;
        for(col=n-1;col>0;col-=2){if(col===6)col--;while(true){for(c=0;c<2;c++){var cc=col-c;if(m[row][cc]===null){dark=false;if(byteIndex<bytes.length)dark=((bytes[byteIndex]>>>(7-bitIndex))&1)!==0;if(ANP_v146Mask(mask,row,cc))dark=!dark;m[row][cc]=dark;bitIndex++;if(bitIndex===8){byteIndex++;bitIndex=0;}}}row+=inc;if(row<0||row>=n){row-=inc;inc=-inc;break;}}}
    }
    function ANP_v146Lost(m){var n=m.length,l=0,r,c,k,same,dark;
        for(r=0;r<n;r++)for(c=0;c<n;c++){same=0;dark=m[r][c];for(var dr=-1;dr<=1;dr++)for(var dc=-1;dc<=1;dc++){if(dr===0&&dc===0)continue;if(r+dr<0||r+dr>=n||c+dc<0||c+dc>=n)continue;if(Math.abs(dr)+Math.abs(dc)===2)continue;if(m[r+dr][c+dc]===dark)same++;}if(same>5)l+=3+same-5;}
        for(r=0;r<n-1;r++)for(c=0;c<n-1;c++){k=(m[r][c]?1:0)+(m[r+1][c]?1:0)+(m[r][c+1]?1:0)+(m[r+1][c+1]?1:0);if(k===0||k===4)l+=3;}
        for(r=0;r<n;r++)for(c=0;c<n-6;c++)if(m[r][c]&&!m[r][c+1]&&m[r][c+2]&&m[r][c+3]&&m[r][c+4]&&!m[r][c+5]&&m[r][c+6])l+=40;
        for(c=0;c<n;c++)for(r=0;r<n-6;r++)if(m[r][c]&&!m[r+1][c]&&m[r+2][c]&&m[r+3][c]&&m[r+4][c]&&!m[r+5][c]&&m[r+6][c])l+=40;
        var cnt=0;for(r=0;r<n;r++)for(c=0;c<n;c++)if(m[r][c])cnt++;l+=Math.floor(Math.abs(100*cnt/n/n-50)/5)*10;return l;}
    function ANP_v146QrMatrix(text){var bytes=ANP_v146Utf8Bytes(text),ver=1,cap,m,best=null,bestLoss=1e99,mask,base,data;
        while(ver<=6&&bytes.length>ANP_v146QrCapBytes(ver))ver++; if(ver>6)throw new Error("QR V146 quá dài: "+bytes.length+" byte. Giới hạn an toàn hiện tại khoảng 134 byte.");
        data=ANP_v146QrData(ver,bytes);
        for(mask=0;mask<8;mask++){m=ANP_v146SetupBase(ver);ANP_v146PlaceType(m,mask);ANP_v146MapData(m,data,mask);var loss=ANP_v146Lost(m);if(loss<bestLoss){bestLoss=loss;best=m;}}
        return best;
    }
    function ANP_v146Black(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=100;return c;}
    function ANP_v146White(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=0;return c;}
    function ANP_v146Bounds(item){var b=item.geometricBounds;return [Number(b[0]),Number(b[1]),Number(b[2]),Number(b[3])];}
    function ANP_v146RemoveOld(layer,name){var i,it;try{for(i=layer.pageItems.length-1;i>=0;i--){it=layer.pageItems[i];if(String(it.name||"")===name){try{it.remove();}catch(e){}}}}catch(e0){}}
    function ANP_v146DrawQR(doc,item,text,token){var m=ANP_v146QrMatrix(text),n=m.length,b=ANP_v146Bounds(item),w=b[2]-b[0],h=b[1]-b[3],size=Math.min(w,h),quiet=4,mod=size/(n+quiet*2),left=b[0]+(w-size)/2,top=b[1]-(h-size)/2,g,name="DPV_V146_QR_"+String(token),r,c,rect;
        ANP_v146RemoveOld(item.layer,name);g=item.layer.groupItems.add();g.name=name;
        rect=g.pathItems.rectangle(top,left,size,size);rect.filled=true;rect.fillColor=ANP_v146White();rect.stroked=false;
        for(r=0;r<n;r++)for(c=0;c<n;c++)if(m[r][c]){rect=g.pathItems.rectangle(top-(quiet+r)*mod,left+(quiet+c)*mod,mod,mod);rect.filled=true;rect.fillColor=ANP_v146Black();rect.stroked=false;}
        try{item.hidden=true;}catch(e1){} return true;
    }
    function ANP_v146Code128Values(text){text=String(text==null?"":text);if(!text.length)throw new Error("Code 128 rỗng.");var vals=[104],i,c,sum=104;for(i=0;i<text.length;i++){c=text.charCodeAt(i);if(c<32||c>126)throw new Error("Code 128 V146 chỉ hỗ trợ ASCII 32–126. Ký tự lỗi ở vị trí "+(i+1)+".");vals.push(c-32);sum+=(c-32)*(i+1);}vals.push(sum%103);vals.push(106);return vals;}
    var ANP_V146_C128=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
    function ANP_v146DrawCode128(doc,item,text,token){var vals=ANP_v146Code128Values(text),seq=[],i,j,p,total=0,b=ANP_v146Bounds(item),w=b[2]-b[0],h=b[1]-b[3],quiet=10,name="DPV_V146_C128_"+String(token),g,x,unit,rect,bar=true;
        for(i=0;i<vals.length;i++){p=ANP_V146_C128[vals[i]];for(j=0;j<p.length;j++){seq.push(Number(p.charAt(j)));total+=Number(p.charAt(j));}}
        total+=quiet*2;unit=w/total;x=b[0]+quiet*unit;ANP_v146RemoveOld(item.layer,name);g=item.layer.groupItems.add();g.name=name;bar=true;
        for(i=0;i<seq.length;i++){if(bar){rect=g.pathItems.rectangle(b[1],x,seq[i]*unit,h);rect.filled=true;rect.fillColor=ANP_v146Black();rect.stroked=false;}x+=seq[i]*unit;bar=!bar;}
        try{item.hidden=true;}catch(e1){} return true;
    }
    ANP_vdpApplyOneV71 = function(doc,mapping,record,sourceFolder){
        var action=String(mapping&&mapping.action||"text"),field=String(mapping&&mapping.field||""),item,value,text;
        if(action!=="qrVector"&&action!=="code128Vector")return ANP_V146_OLD_APPLY_ONE(doc,mapping,record,sourceFolder);
        item=ANP_vdpFindByTokenV71(doc,String(mapping.targetId||"")); if(!item||!field)return false;
        value=record&&record[field]!==undefined?record[field]:""; text=String(mapping.prefix||"")+String(value==null?"":value)+String(mapping.suffix||"");
        if(action==="qrVector")return ANP_v146DrawQR(doc,item,text,String(mapping.targetId||""));
        return ANP_v146DrawCode128(doc,item,text,String(mapping.targetId||""));
    };
})();
/* ===== END DPV V146 QR & BARCODE VECTOR SAFE ===== */



/* ===== DPV V146.1 EAN-13 VECTOR SAFE - APPEND ONLY ===== */
(function(){
    if (typeof ANP_vdpApplyOneV71 !== "function" || typeof ANP_V1461_OLD_APPLY_ONE !== "undefined") { return; }
    ANP_V1461_OLD_APPLY_ONE = ANP_vdpApplyOneV71;

    var ANP_V1461_EAN_L=["0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"];
    var ANP_V1461_EAN_G=["0100111","0110011","0011011","0100001","0011101","0111001","0000101","0010001","0001001","0010111"];
    var ANP_V1461_EAN_R=["1110010","1100110","1101100","1000010","1011100","1001110","1010000","1000100","1001000","1110100"];
    var ANP_V1461_EAN_PAR=["LLLLLL","LLGLGG","LLGGLG","LLGGGL","LGLLGG","LGGLLG","LGGGLL","LGLGLG","LGLGGL","LGGLGL"];

    function ANP_v1461Black(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=100;return c;}
    function ANP_v1461White(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=0;return c;}
    function ANP_v1461Bounds(item){var b=item.geometricBounds;return [Number(b[0]),Number(b[1]),Number(b[2]),Number(b[3])];}
    function ANP_v1461RemoveOld(layer,name){var i,it;try{for(i=layer.pageItems.length-1;i>=0;i--){it=layer.pageItems[i];if(String(it.name||"")===name){try{it.remove();}catch(e){}}}}catch(e0){}}
    function ANP_v1461CheckDigit(s12){
        var i,sum=0,n;
        if(!/^\d{12}$/.test(String(s12||""))) throw new Error("EAN-13 cần đúng 12 hoặc 13 chữ số.");
        for(i=0;i<12;i++){n=Number(s12.charAt(i));sum+=(i%2===0)?n:(n*3);} return String((10-(sum%10))%10);
    }
    function ANP_v1461NormalizeEAN(value){
        var s=String(value==null?"":value).replace(/^\s+|\s+$/g,"");
        if(!/^\d{12,13}$/.test(s)) throw new Error("EAN-13 chỉ nhận 12 hoặc 13 chữ số. Giá trị: "+s);
        if(s.length===12) return s+ANP_v1461CheckDigit(s);
        var cd=ANP_v1461CheckDigit(s.substr(0,12));
        if(s.charAt(12)!==cd) throw new Error("EAN-13 sai checksum. Mã "+s+" phải có số kiểm tra cuối là "+cd+".");
        return s;
    }
    function ANP_v1461Bits(ean){
        var first=Number(ean.charAt(0)), parity=ANP_V1461_EAN_PAR[first], bits="101",i,d;
        for(i=1;i<=6;i++){d=Number(ean.charAt(i));bits+=(parity.charAt(i-1)==="L"?ANP_V1461_EAN_L[d]:ANP_V1461_EAN_G[d]);}
        bits+="01010";
        for(i=7;i<=12;i++){d=Number(ean.charAt(i));bits+=ANP_V1461_EAN_R[d];}
        bits+="101";
        if(bits.length!==95) throw new Error("EAN-13 internal encoding error.");
        return bits;
    }
    function ANP_v1461IsGuard(i){return (i>=0&&i<=2)||(i>=45&&i<=49)||(i>=92&&i<=94);}
    function ANP_v1461AddOutlinedText(doc,g,text,centerX,bottomY,size){
        try{
            var tf=doc.textFrames.pointText([0,0]),o,gb,dx,dy;
            tf.contents=String(text);
            try{tf.textRange.characterAttributes.size=size;}catch(e0){}
            try{tf.textRange.characterAttributes.fillColor=ANP_v1461Black();}catch(e1){}
            try{tf.paragraphs[0].paragraphAttributes.justification=Justification.CENTER;}catch(e2){}
            o=tf.createOutline();
            gb=o.geometricBounds;
            dx=centerX-((Number(gb[0])+Number(gb[2]))/2);
            dy=bottomY-Number(gb[3]);
            try{o.translate(dx,dy);}catch(e3){try{o.left=Number(o.left)+dx;o.top=Number(o.top)+dy;}catch(e4){}}
            try{o.move(g,ElementPlacement.PLACEATEND);}catch(e5){}
            return true;
        }catch(e){return false;}
    }
    function ANP_v1461DrawEAN13(doc,item,raw,token){
        var ean=ANP_v1461NormalizeEAN(raw),bits=ANP_v1461Bits(ean),b=ANP_v1461Bounds(item),w=b[2]-b[0],h=b[1]-b[3],
            quietL=11,quietR=7,total=95+quietL+quietR,unit=w/total,startX=b[0]+quietL*unit,
            textZone=Math.min(h*0.25,unit*10.0),barH=h-textZone,guardH=Math.min(h,barH+textZone*0.38),
            name="DPV_V1461_EAN13_"+String(token),g,bg,i,x,run,runStart,rect,fontSize,textBottom;
        if(!(w>0&&h>0)) throw new Error("EAN-13: khung giữ chỗ không hợp lệ.");
        if(!(barH>0)) throw new Error("EAN-13: khung giữ chỗ quá thấp.");
        ANP_v1461RemoveOld(item.layer,name);
        g=item.layer.groupItems.add();g.name=name;
        bg=g.pathItems.rectangle(b[1],b[0],w,h);bg.filled=true;bg.fillColor=ANP_v1461White();bg.stroked=false;
        i=0;
        while(i<95){
            if(bits.charAt(i)!=="1"){i++;continue;}
            runStart=i;run=1;
            while(i+run<95&&bits.charAt(i+run)==="1"&&ANP_v1461IsGuard(i+run)===ANP_v1461IsGuard(runStart))run++;
            x=startX+runStart*unit;
            rect=g.pathItems.rectangle(b[1],x,run*unit,ANP_v1461IsGuard(runStart)?guardH:barH);
            rect.filled=true;rect.fillColor=ANP_v1461Black();rect.stroked=false;
            i+=run;
        }
        fontSize=Math.max(5,Math.min(12,unit*7.5));
        textBottom=b[3]+Math.max(unit*0.55,textZone*0.05);
        ANP_v1461AddOutlinedText(doc,g,ean.charAt(0),startX-unit*5.2,textBottom,fontSize);
        ANP_v1461AddOutlinedText(doc,g,ean.substr(1,6),startX+24*unit,textBottom,fontSize);
        ANP_v1461AddOutlinedText(doc,g,ean.substr(7,6),startX+71*unit,textBottom,fontSize);
        try{item.hidden=true;}catch(e6){}
        return true;
    }

    ANP_vdpApplyOneV71 = function(doc,mapping,record,sourceFolder){
        var action=String(mapping&&mapping.action||"text"),field=String(mapping&&mapping.field||""),item,value,text;
        if(action!=="ean13Vector") return ANP_V1461_OLD_APPLY_ONE(doc,mapping,record,sourceFolder);
        item=ANP_vdpFindByTokenV71(doc,String(mapping.targetId||""));
        if(!item||!field) return false;
        value=record&&record[field]!==undefined?record[field]:"";
        text=String(mapping.prefix||"")+String(value==null?"":value)+String(mapping.suffix||"");
        return ANP_v1461DrawEAN13(doc,item,text,String(mapping.targetId||""));
    };
})();
/* ===== END DPV V146.1 EAN-13 VECTOR SAFE ===== */

/* ===== DPV V146.2 QR PIPELINE HOTFIX - APPEND ONLY =====
   - Extends QR byte capacity safely to QR Version 20-L (~858 UTF-8 bytes).
   - Keeps Code128/EAN13 and all older actions delegated unchanged.
   - Cleans generated vector code groups on Restore.
*/
(function(){
    if (typeof ANP_vdpApplyOneV71 !== "function" || typeof ANP_V1462_OLD_APPLY_ONE !== "undefined") { return; }
    ANP_V1462_OLD_APPLY_ONE = ANP_vdpApplyOneV71;

    var ANP_V1462_PATTERN = [
        [],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],
        [6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],
        [6,30,56,82],[6,30,58,86],[6,34,62,90]
    ];
    /* Level L RS blocks: count,total,data triplets for versions 1..20. */
    var ANP_V1462_RS_L = [
        [1,26,19],
        [1,44,34],
        [1,70,55],
        [1,100,80],
        [1,134,108],
        [2,86,68],
        [2,98,78],
        [2,121,97],
        [2,146,116],
        [2,86,68,2,87,69],
        [4,101,81],
        [2,116,92,2,117,93],
        [4,133,107],
        [3,145,115,1,146,116],
        [5,109,87,1,110,88],
        [5,122,98,1,123,99],
        [1,135,107,5,136,108],
        [5,150,120,1,151,121],
        [3,141,113,4,142,114],
        [3,135,107,5,136,108]
    ];

    function ANP_v1462Utf8Bytes(s){
        s=String(s==null?"":s);var out=[],i,c,c2;
        for(i=0;i<s.length;i++){
            c=s.charCodeAt(i);
            if(c<0x80)out.push(c);
            else if(c<0x800)out.push(0xC0|(c>>6),0x80|(c&63));
            else if(c>=0xD800&&c<=0xDBFF&&i+1<s.length){
                c2=s.charCodeAt(++i);c=0x10000+((c-0xD800)<<10)+(c2-0xDC00);
                out.push(0xF0|(c>>18),0x80|((c>>12)&63),0x80|((c>>6)&63),0x80|(c&63));
            }else out.push(0xE0|(c>>12),0x80|((c>>6)&63),0x80|(c&63));
        }
        return out;
    }
    function ANP_v1462GfMul(x,y){var r=0;while(y>0){if(y&1)r^=x;y>>=1;x<<=1;if(x&0x100)x^=0x11d;}return r;}
    function ANP_v1462GfPow2(p){var x=1,i;for(i=0;i<p;i++){x<<=1;if(x&0x100)x^=0x11d;}return x;}
    function ANP_v1462RsGenerator(deg){var g=[1],i,j,n;for(i=0;i<deg;i++){n=[];for(j=0;j<g.length+1;j++)n[j]=0;for(j=0;j<g.length;j++){n[j]^=g[j];n[j+1]^=ANP_v1462GfMul(g[j],ANP_v1462GfPow2(i));}g=n;}return g;}
    function ANP_v1462RsRemainder(data,degree){var gen=ANP_v1462RsGenerator(degree),res=[],i,j,f;for(i=0;i<degree;i++)res[i]=0;for(i=0;i<data.length;i++){f=data[i]^res[0];for(j=0;j<degree-1;j++)res[j]=res[j+1];res[degree-1]=0;for(j=0;j<degree;j++)res[j]^=ANP_v1462GfMul(gen[j+1],f);}return res;}
    function ANP_v1462AppendBits(a,v,len){var i;for(i=len-1;i>=0;i--)a.push((v>>>i)&1);}
    function ANP_v1462BitsToBytes(bits){var out=[],i,j,b;for(i=0;i<bits.length;i+=8){b=0;for(j=0;j<8;j++)b=(b<<1)|(bits[i+j]||0);out.push(b);}return out;}
    function ANP_v1462RsDesc(ver){return ANP_V1462_RS_L[ver-1];}
    function ANP_v1462DataCodewords(ver){var d=ANP_v1462RsDesc(ver),i,sum=0;for(i=0;i<d.length;i+=3)sum+=d[i]*d[i+2];return sum;}
    function ANP_v1462CapBytes(ver){var bits=ANP_v1462DataCodewords(ver)*8-4-(ver<10?8:16);return Math.floor(bits/8);}
    function ANP_v1462Blocks(ver,data){
        var d=ANP_v1462RsDesc(ver),db=[],eb=[],i,j,k,count,total,dc,off=0,maxD=0,maxE=0,out=[];
        for(i=0;i<d.length;i+=3){count=d[i];total=d[i+1];dc=d[i+2];for(j=0;j<count;j++){var part=data.slice(off,off+dc);off+=dc;db.push(part);eb.push(ANP_v1462RsRemainder(part,total-dc));if(dc>maxD)maxD=dc;if(total-dc>maxE)maxE=total-dc;}}
        for(i=0;i<maxD;i++)for(j=0;j<db.length;j++)if(i<db[j].length)out.push(db[j][i]);
        for(i=0;i<maxE;i++)for(j=0;j<eb.length;j++)if(i<eb[j].length)out.push(eb[j][i]);
        return out;
    }
    function ANP_v1462Data(ver,bytes){
        var cap=ANP_v1462DataCodewords(ver)*8,bits=[],i,pads=[0xEC,0x11],p=0,data;
        ANP_v1462AppendBits(bits,4,4);ANP_v1462AppendBits(bits,bytes.length,ver<10?8:16);
        for(i=0;i<bytes.length;i++)ANP_v1462AppendBits(bits,bytes[i],8);
        if(bits.length>cap)throw new Error("QR data overflow V"+ver+".");
        if(bits.length+4<=cap)ANP_v1462AppendBits(bits,0,4);else while(bits.length<cap)bits.push(0);
        while(bits.length%8)bits.push(0);
        data=ANP_v1462BitsToBytes(bits);while(data.length<ANP_v1462DataCodewords(ver))data.push(pads[(p++)&1]);
        return ANP_v1462Blocks(ver,data);
    }
    function ANP_v1462BchDigit(d){var n=0;while(d){n++;d>>>=1;}return n;}
    function ANP_v1462BchTypeInfo(data){var d=data<<10,g=0x537;while(ANP_v1462BchDigit(d)-ANP_v1462BchDigit(g)>=0)d^=g<<(ANP_v1462BchDigit(d)-ANP_v1462BchDigit(g));return ((data<<10)|d)^0x5412;}
    function ANP_v1462BchTypeNumber(data){var d=data<<12,g=0x1f25;while(ANP_v1462BchDigit(d)-ANP_v1462BchDigit(g)>=0)d^=g<<(ANP_v1462BchDigit(d)-ANP_v1462BchDigit(g));return (data<<12)|d;}
    function ANP_v1462Mask(mask,i,j){switch(mask){case 0:return(i+j)%2===0;case 1:return i%2===0;case 2:return j%3===0;case 3:return(i+j)%3===0;case 4:return(Math.floor(i/2)+Math.floor(j/3))%2===0;case 5:return(i*j)%2+(i*j)%3===0;case 6:return((i*j)%2+(i*j)%3)%2===0;case 7:return((i*j)%3+(i+j)%2)%2===0;}return false;}
    function ANP_v1462Blank(n){var a=[],r,c;for(r=0;r<n;r++){a[r]=[];for(c=0;c<n;c++)a[r][c]=null;}return a;}
    function ANP_v1462Finder(m,row,col){var r,c,n=m.length;for(r=-1;r<=7;r++)for(c=-1;c<=7;c++){if(row+r<0||row+r>=n||col+c<0||col+c>=n)continue;m[row+r][col+c]=(r>=0&&r<=6&&c>=0&&c<=6&&(r===0||r===6||c===0||c===6||(r>=2&&r<=4&&c>=2&&c<=4)));}}
    function ANP_v1462PlaceVersion(m,ver){var bits,i,bit,n=m.length;if(ver<7)return;bits=ANP_v1462BchTypeNumber(ver);for(i=0;i<18;i++){bit=((bits>>i)&1)!==0;m[Math.floor(i/3)][i%3+n-11]=bit;m[i%3+n-11][Math.floor(i/3)]=bit;}}
    function ANP_v1462SetupBase(ver){
        var n=17+4*ver,m=ANP_v1462Blank(n),pos=ANP_V1462_PATTERN[ver-1],i,j,r,c,dr,dc;
        ANP_v1462Finder(m,0,0);ANP_v1462Finder(m,n-7,0);ANP_v1462Finder(m,0,n-7);
        /* Alignment must be placed before timing. This matters from Version 7 upward. */
        for(i=0;i<pos.length;i++)for(j=0;j<pos.length;j++){r=pos[i];c=pos[j];if(m[r][c]!==null)continue;for(dr=-2;dr<=2;dr++)for(dc=-2;dc<=2;dc++)m[r+dr][c+dc]=(Math.max(Math.abs(dr),Math.abs(dc))!==1);}
        for(i=8;i<n-8;i++){if(m[i][6]===null)m[i][6]=(i%2===0);if(m[6][i]===null)m[6][i]=(i%2===0);}
        ANP_v1462PlaceVersion(m,ver);m[n-8][8]=true;return m;
    }
    function ANP_v1462PlaceType(m,mask){var n=m.length,bits=ANP_v1462BchTypeInfo((1<<3)|mask),i,bit;for(i=0;i<15;i++){bit=((bits>>i)&1)!==0;if(i<6)m[i][8]=bit;else if(i<8)m[i+1][8]=bit;else m[n-15+i][8]=bit;}for(i=0;i<15;i++){bit=((bits>>i)&1)!==0;if(i<8)m[8][n-i-1]=bit;else if(i<9)m[8][15-i]=bit;else m[8][15-i-1]=bit;}m[n-8][8]=true;}
    function ANP_v1462MapData(m,bytes,mask){var n=m.length,row=n-1,inc=-1,bitIndex=0,byteIndex=0,col,c,cc,dark;for(col=n-1;col>0;col-=2){if(col===6)col--;while(true){for(c=0;c<2;c++){cc=col-c;if(m[row][cc]===null){dark=false;if(byteIndex<bytes.length)dark=((bytes[byteIndex]>>>(7-bitIndex))&1)!==0;if(ANP_v1462Mask(mask,row,cc))dark=!dark;m[row][cc]=dark;bitIndex++;if(bitIndex===8){byteIndex++;bitIndex=0;}}}row+=inc;if(row<0||row>=n){row-=inc;inc=-inc;break;}}}}
    function ANP_v1462Lost(m){var n=m.length,l=0,r,c,k,same,dark,dr,dc,cnt=0;for(r=0;r<n;r++)for(c=0;c<n;c++){same=0;dark=m[r][c];for(dr=-1;dr<=1;dr++)for(dc=-1;dc<=1;dc++){if(dr===0&&dc===0)continue;if(r+dr<0||r+dr>=n||c+dc<0||c+dc>=n)continue;if(Math.abs(dr)+Math.abs(dc)===2)continue;if(m[r+dr][c+dc]===dark)same++;}if(same>5)l+=3+same-5;}for(r=0;r<n-1;r++)for(c=0;c<n-1;c++){k=(m[r][c]?1:0)+(m[r+1][c]?1:0)+(m[r][c+1]?1:0)+(m[r+1][c+1]?1:0);if(k===0||k===4)l+=3;}for(r=0;r<n;r++)for(c=0;c<n-6;c++)if(m[r][c]&&!m[r][c+1]&&m[r][c+2]&&m[r][c+3]&&m[r][c+4]&&!m[r][c+5]&&m[r][c+6])l+=40;for(c=0;c<n;c++)for(r=0;r<n-6;r++)if(m[r][c]&&!m[r+1][c]&&m[r+2][c]&&m[r+3][c]&&m[r+4][c]&&!m[r+5][c]&&m[r+6][c])l+=40;for(r=0;r<n;r++)for(c=0;c<n;c++)if(m[r][c])cnt++;l+=Math.floor(Math.abs(100*cnt/n/n-50)/5)*10;return l;}
    function ANP_v1462QrMatrix(text){var bytes=ANP_v1462Utf8Bytes(text),ver=1,m,best=null,bestLoss=1e99,mask,data,loss;while(ver<=20&&bytes.length>ANP_v1462CapBytes(ver))ver++;if(ver>20)throw new Error("QR quá dài: "+bytes.length+" byte. V146.2 hỗ trợ tối đa khoảng 858 byte UTF-8.");data=ANP_v1462Data(ver,bytes);for(mask=0;mask<8;mask++){m=ANP_v1462SetupBase(ver);ANP_v1462PlaceType(m,mask);ANP_v1462MapData(m,data,mask);loss=ANP_v1462Lost(m);if(loss<bestLoss){bestLoss=loss;best=m;}}return best;}
    function ANP_v1462Black(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=100;return c;}
    function ANP_v1462White(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=0;return c;}
    function ANP_v1462Bounds(item){var b=item.geometricBounds;return[Number(b[0]),Number(b[1]),Number(b[2]),Number(b[3])];}
    function ANP_v1462RemoveNamed(doc,token){var i,g,names=["DPV_V146_QR_"+token,"DPV_V1462_QR_"+token];try{for(i=doc.groupItems.length-1;i>=0;i--){g=doc.groupItems[i];if(String(g.name||"")===names[0]||String(g.name||"")===names[1]){try{g.remove();}catch(e0){}}}}catch(e1){}}
    function ANP_v1462DrawQR(doc,item,text,token){
        var m=ANP_v1462QrMatrix(text),n=m.length,b=ANP_v1462Bounds(item),w=b[2]-b[0],h=b[1]-b[3],size=Math.min(w,h),quiet=4,mod=size/(n+quiet*2),left=b[0]+(w-size)/2,top=b[1]-(h-size)/2,g,r,c,start,rect,name="DPV_V1462_QR_"+String(token);
        if(!(w>0&&h>0))throw new Error("QR: khung giữ chỗ không hợp lệ.");
        ANP_v1462RemoveNamed(doc,String(token));g=item.layer.groupItems.add();g.name=name;
        rect=g.pathItems.rectangle(top,left,size,size);rect.filled=true;rect.fillColor=ANP_v1462White();rect.stroked=false;
        /* Merge horizontal dark runs to reduce Illustrator objects. */
        for(r=0;r<n;r++){c=0;while(c<n){while(c<n&&!m[r][c])c++;if(c>=n)break;start=c;while(c<n&&m[r][c])c++;rect=g.pathItems.rectangle(top-(quiet+r)*mod,left+(quiet+start)*mod,(c-start)*mod,mod);rect.filled=true;rect.fillColor=ANP_v1462Black();rect.stroked=false;}}
        try{item.hidden=true;}catch(e2){}
        return true;
    }
    function ANP_v1462CleanupGenerated(doc){var i,g,n;try{for(i=doc.groupItems.length-1;i>=0;i--){g=doc.groupItems[i];n=String(g.name||"");if(n.indexOf("DPV_V146_QR_")===0||n.indexOf("DPV_V1462_QR_")===0||n.indexOf("DPV_V146_C128_")===0||n.indexOf("DPV_V1461_EAN13_")===0){try{g.remove();}catch(e0){}}}}catch(e1){}}

    ANP_vdpApplyOneV71=function(doc,mapping,record,sourceFolder){
        var action=String(mapping&&mapping.action||"text"),field=String(mapping&&mapping.field||""),item,value,text;
        if(action!=="qrVector")return ANP_V1462_OLD_APPLY_ONE(doc,mapping,record,sourceFolder);
        item=ANP_vdpFindByTokenV71(doc,String(mapping.targetId||""));if(!item||!field)return false;
        value=record&&record[field]!==undefined?record[field]:"";text=String(mapping.prefix||"")+String(value==null?"":value)+String(mapping.suffix||"");
        if(!text)throw new Error("QR Code rỗng ở cột “"+field+"”.");
        return ANP_v1462DrawQR(doc,item,text,String(mapping.targetId||""));
    };

    if(typeof ANP_vdpRestoreDocV71==="function"&&typeof ANP_V1462_OLD_RESTORE_DOC==="undefined"){
        ANP_V1462_OLD_RESTORE_DOC=ANP_vdpRestoreDocV71;
        ANP_vdpRestoreDocV71=function(doc){var n=ANP_V1462_OLD_RESTORE_DOC(doc);ANP_v1462CleanupGenerated(doc);return n;};
    }
})();
/* ===== END DPV V146.2 QR PIPELINE HOTFIX ===== */

/* ===== DPV V146.3.2 QR/BARCODE BATCH DISPATCH + TYPOGRAPHY - APPEND ONLY =====
   Purpose:
   - Guarantee qrVector/code128Vector/ean13Vector are applied by record/batch dispatch.
   - Leave every non-code mapping on the frozen stable path.
   - Add optional Barcode Studio-like human-readable text styling for Code128/EAN-13.
*/
(function(){
    if (typeof ANP_vdpApplyRecordV71 !== "function" || typeof ANP_V14632_OLD_APPLY_RECORD !== "undefined") { return; }
    ANP_V14632_OLD_APPLY_RECORD = ANP_vdpApplyRecordV71;

    function ANP_v14632IsCode(action){
        action=String(action||"");
        return action==="qrVector"||action==="code128Vector"||action==="ean13Vector";
    }
    function ANP_v14632Mm(v){return Number(v||0)*2.834645669291339;}
    function ANP_v14632Black(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=100;return c;}
    function ANP_v14632White(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=0;return c;}
    function ANP_v14632Bounds(item){var b=item.geometricBounds;return [Number(b[0]),Number(b[1]),Number(b[2]),Number(b[3])];}
    function ANP_v14632Remove(doc,prefix,token){
        var i,g,n=prefix+String(token||"");
        try{for(i=doc.groupItems.length-1;i>=0;i--){g=doc.groupItems[i];if(String(g.name||"")===n){try{g.remove();}catch(e0){}}}}catch(e1){}
    }
    function ANP_v14632Style(mapping){
        var s=mapping&&mapping.barcodeStyle?mapping.barcodeStyle:{};
        return {
            showText: !(Number(s.showText)===0 || s.showText===false),
            fontName:String(s.fontName||"Arial"),
            fontSize:Math.max(4,Number(s.fontSize)||9),
            tracking:Number(s.tracking)||0,
            textGapMm:Math.max(0,Number(s.textGapMm)||1.2),
            barHeightPercent:Math.max(40,Math.min(200,Number(s.barHeightPercent)||100)),
            barWidthPercent:Math.max(60,Math.min(140,Number(s.barWidthPercent)||100)),
            quietZone:Math.max(2,Math.min(20,Math.round(Number(s.quietZone)||10))),
            fontWeight:String(s.fontWeight||"regular"),
            textMode:String(s.textMode||"outline")
        };
    }
    function ANP_v14632FindFont(name,weight){
        var i,f,n=String(name||""),wantBold=String(weight||"")==="bold",fn,ff;
        if(!n){return null;}
        try{return app.textFonts.getByName(n);}catch(e0){}
        try{
            for(i=0;i<app.textFonts.length;i++){
                f=app.textFonts[i];fn=String(f.name||"");ff=String(f.family||"");
                if(fn===n || ff===n || fn.toLowerCase()===n.toLowerCase() || ff.toLowerCase()===n.toLowerCase()){
                    if(!wantBold || /bold|semibold|demi/i.test(fn)){return f;}
                }
            }
            if(wantBold){
                for(i=0;i<app.textFonts.length;i++){
                    f=app.textFonts[i];fn=String(f.name||"");ff=String(f.family||"");
                    if((ff===n || ff.toLowerCase()===n.toLowerCase()) && /bold|semibold|demi/i.test(fn)){return f;}
                }
            }
        }catch(e1){}
        return null;
    }
    function ANP_v14632AddText(doc,g,text,centerX,bottomY,style){
        var tf=null,o=null,gb,dx,dy,font;
        if(!style.showText){return true;}
        try{
            tf=doc.textFrames.pointText([0,0]);tf.contents=String(text==null?"":text);
            try{tf.textRange.characterAttributes.size=style.fontSize;}catch(e0){}
            try{tf.textRange.characterAttributes.tracking=style.tracking;}catch(e1){}
            try{tf.textRange.characterAttributes.fillColor=ANP_v14632Black();}catch(e2){}
            font=ANP_v14632FindFont(style.fontName,style.fontWeight);if(font){try{tf.textRange.characterAttributes.textFont=font;}catch(e3){}}
            try{tf.paragraphs[0].paragraphAttributes.justification=Justification.CENTER;}catch(e4){}
            if(style.textMode==="live"){
                try{tf.position=[centerX,bottomY+style.fontSize];}catch(e5){}
                try{tf.move(g,ElementPlacement.PLACEATEND);}catch(e6){}
                return true;
            }
            o=tf.createOutline();gb=o.geometricBounds;dx=centerX-((Number(gb[0])+Number(gb[2]))/2);dy=bottomY-Number(gb[3]);
            try{o.translate(dx,dy);}catch(e7){try{o.left=Number(o.left)+dx;o.top=Number(o.top)+dy;}catch(e8){}}
            try{o.move(g,ElementPlacement.PLACEATEND);}catch(e9){}
            return true;
        }catch(e){try{if(tf)tf.remove();}catch(e10){}return false;}
    }

    var ANP_V14632_C128=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
    function ANP_v14632Code128Values(text){
        text=String(text==null?"":text);if(!text.length)throw new Error("Code 128 rỗng.");
        var vals=[104],i,c,sum=104;for(i=0;i<text.length;i++){c=text.charCodeAt(i);if(c<32||c>126)throw new Error("Code 128 chỉ hỗ trợ ASCII 32–126. Ký tự lỗi ở vị trí "+String(i+1)+".");vals.push(c-32);sum+=(c-32)*(i+1);}vals.push(sum%103);vals.push(106);return vals;
    }
    function ANP_v14632DrawCode128(doc,item,text,token,mapping){
        var st=ANP_v14632Style(mapping),vals=ANP_v14632Code128Values(text),seq=[],i,j,p,total=0,b=ANP_v14632Bounds(item),w=b[2]-b[0],h=b[1]-b[3],quiet=st.quietZone,
            name="DPV_V14632_C128_"+String(token),g,x,unit,rect,bar=true,codeW,textZone=0,gap=ANP_v14632Mm(st.textGapMm),barH,top;
        if(!(w>0&&h>0))throw new Error("Code 128: khung giữ chỗ không hợp lệ.");
        for(i=0;i<vals.length;i++){p=ANP_V14632_C128[vals[i]];for(j=0;j<p.length;j++){seq.push(Number(p.charAt(j)));total+=Number(p.charAt(j));}}
        if(st.showText){textZone=Math.min(h*0.35,Math.max(st.fontSize*1.55,gap+st.fontSize*1.2));}
        barH=(h-textZone)*st.barHeightPercent/100;if(barH>h-textZone)barH=h-textZone;if(!(barH>0))throw new Error("Code 128: chiều cao khung quá thấp.");
        total+=quiet*2;codeW=w*st.barWidthPercent/100;if(codeW>w)codeW=w;unit=codeW/total;x=b[0]+(w-codeW)/2+quiet*unit;top=b[1];
        ANP_v14632Remove(doc,"DPV_V14632_C128_",token);ANP_v14632Remove(doc,"DPV_V146_C128_",token);
        g=item.layer.groupItems.add();g.name=name;
        rect=g.pathItems.rectangle(b[1],b[0],w,h);rect.filled=true;rect.fillColor=ANP_v14632White();rect.stroked=false;
        for(i=0;i<seq.length;i++){if(bar){rect=g.pathItems.rectangle(top,x,seq[i]*unit,barH);rect.filled=true;rect.fillColor=ANP_v14632Black();rect.stroked=false;}x+=seq[i]*unit;bar=!bar;}
        if(st.showText){ANP_v14632AddText(doc,g,text,(b[0]+b[2])/2,b[3]+Math.max(0,gap*0.2),st);}
        try{item.hidden=true;}catch(e0){}return true;
    }

    var ANP_V14632_EAN_L=["0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"];
    var ANP_V14632_EAN_G=["0100111","0110011","0011011","0100001","0011101","0111001","0000101","0010001","0001001","0010111"];
    var ANP_V14632_EAN_R=["1110010","1100110","1101100","1000010","1011100","1001110","1010000","1000100","1001000","1110100"];
    var ANP_V14632_EAN_PAR=["LLLLLL","LLGLGG","LLGGLG","LLGGGL","LGLLGG","LGGLLG","LGGGLL","LGLGLG","LGLGGL","LGGLGL"];
    function ANP_v14632EANCheck(s12){var i,sum=0,n;if(!/^\d{12}$/.test(String(s12||"")))throw new Error("EAN-13 cần đúng 12 hoặc 13 chữ số.");for(i=0;i<12;i++){n=Number(s12.charAt(i));sum+=(i%2===0)?n:n*3;}return String((10-(sum%10))%10);}
    function ANP_v14632EAN(raw){var s=String(raw==null?"":raw).replace(/^\s+|\s+$/g,"");if(!/^\d{12,13}$/.test(s))throw new Error("EAN-13 chỉ nhận 12 hoặc 13 chữ số. Giá trị: "+s);if(s.length===12)return s+ANP_v14632EANCheck(s);var cd=ANP_v14632EANCheck(s.substr(0,12));if(s.charAt(12)!==cd)throw new Error("EAN-13 sai checksum. Mã "+s+" phải có số kiểm tra cuối là "+cd+".");return s;}
    function ANP_v14632EANBits(ean){var parity=ANP_V14632_EAN_PAR[Number(ean.charAt(0))],bits="101",i,d;for(i=1;i<=6;i++){d=Number(ean.charAt(i));bits+=(parity.charAt(i-1)==="L"?ANP_V14632_EAN_L[d]:ANP_V14632_EAN_G[d]);}bits+="01010";for(i=7;i<=12;i++){d=Number(ean.charAt(i));bits+=ANP_V14632_EAN_R[d];}bits+="101";return bits;}
    function ANP_v14632Guard(i){return (i<=2)||(i>=45&&i<=49)||(i>=92);}
    function ANP_v14632DrawEAN13(doc,item,raw,token,mapping){
        var st=ANP_v14632Style(mapping),ean=ANP_v14632EAN(raw),bits=ANP_v14632EANBits(ean),b=ANP_v14632Bounds(item),w=b[2]-b[0],h=b[1]-b[3],quietL=Math.max(7,st.quietZone+1),quietR=Math.max(5,st.quietZone-3),total=95+quietL+quietR,
            codeW=w*st.barWidthPercent/100,unit,startX,textZone=0,gap=ANP_v14632Mm(st.textGapMm),barH,guardH,name="DPV_V14632_EAN13_"+String(token),g,bg,i,x,run,runStart,rect,textBottom;
        if(!(w>0&&h>0))throw new Error("EAN-13: khung giữ chỗ không hợp lệ.");if(codeW>w)codeW=w;unit=codeW/total;startX=b[0]+(w-codeW)/2+quietL*unit;
        if(st.showText){textZone=Math.min(h*0.34,Math.max(st.fontSize*1.65,gap+st.fontSize*1.25));}
        barH=(h-textZone)*st.barHeightPercent/100;if(barH>h-textZone)barH=h-textZone;if(!(barH>0))throw new Error("EAN-13: chiều cao khung quá thấp.");guardH=Math.min(h-textZone*0.4,barH+Math.max(unit*5,textZone*0.25));
        ANP_v14632Remove(doc,"DPV_V14632_EAN13_",token);ANP_v14632Remove(doc,"DPV_V1461_EAN13_",token);
        g=item.layer.groupItems.add();g.name=name;bg=g.pathItems.rectangle(b[1],b[0],w,h);bg.filled=true;bg.fillColor=ANP_v14632White();bg.stroked=false;
        i=0;while(i<95){if(bits.charAt(i)!=="1"){i++;continue;}runStart=i;run=1;while(i+run<95&&bits.charAt(i+run)==="1"&&ANP_v14632Guard(i+run)===ANP_v14632Guard(runStart))run++;x=startX+runStart*unit;rect=g.pathItems.rectangle(b[1],x,run*unit,ANP_v14632Guard(runStart)?guardH:barH);rect.filled=true;rect.fillColor=ANP_v14632Black();rect.stroked=false;i+=run;}
        if(st.showText){textBottom=b[3]+Math.max(0,gap*0.15);ANP_v14632AddText(doc,g,ean.charAt(0),startX-unit*5.2,textBottom,st);ANP_v14632AddText(doc,g,ean.substr(1,6),startX+24*unit,textBottom,st);ANP_v14632AddText(doc,g,ean.substr(7,6),startX+71*unit,textBottom,st);}
        try{item.hidden=true;}catch(e0){}return true;
    }

    function ANP_v14632ApplyCode(doc,mapping,record,sourceFolder){
        var action=String(mapping&&mapping.action||""),field=String(mapping&&mapping.field||""),item,value,text;
        if(!ANP_v14632IsCode(action)){return false;}
        item=ANP_vdpFindByTokenV71(doc,String(mapping.targetId||""));
        if(!item){throw new Error("Không tìm thấy target mã trong work-copy: "+String(mapping.label||mapping.targetId||"Barcode"));}
        if(!field){throw new Error("Mapping mã chưa chọn cột dữ liệu: "+String(mapping.label||mapping.targetId||"Barcode"));}
        value=record&&record[field]!==undefined?record[field]:"";text=String(mapping.prefix||"")+String(value==null?"":value)+String(mapping.suffix||"");
        if(action==="qrVector"){
            /* Reuse the V146.2 QR Version 1-20 implementation directly through the final apply-one wrapper. */
            return ANP_vdpApplyOneV71(doc,mapping,record,sourceFolder)===true;
        }
        if(action==="code128Vector" && mapping.barcodeStyle){return ANP_v14632DrawCode128(doc,item,text,String(mapping.targetId||""),mapping);}
        if(action==="ean13Vector" && mapping.barcodeStyle){return ANP_v14632DrawEAN13(doc,item,text,String(mapping.targetId||""),mapping);}
        return ANP_vdpApplyOneV71(doc,mapping,record,sourceFolder)===true;
    }

    ANP_vdpApplyRecordV71=function(doc,mappings,record,sourceFolder,skipRedraw){
        var i,m,normal=[],codes=[],applied=0,n;
        mappings=mappings||[];
        for(i=0;i<mappings.length;i++){m=mappings[i]||{};if(ANP_v14632IsCode(m.action)){codes.push(m);}else{normal.push(m);}}
        /* Absolute zero-impact path for old jobs. */
        if(!codes.length){return ANP_V14632_OLD_APPLY_RECORD(doc,mappings,record,sourceFolder,skipRedraw);}
        if(normal.length){applied+=Number(ANP_V14632_OLD_APPLY_RECORD(doc,normal,record,sourceFolder,true))||0;}
        for(i=0;i<codes.length;i++){
            try{if(ANP_v14632ApplyCode(doc,codes[i],record,sourceFolder)){applied++;}}
            catch(eCode){throw new Error("Kênh mã "+String(codes[i].label||codes[i].field||String(i+1))+": "+String(eCode&&eCode.message?eCode.message:eCode));}
        }
        if(!skipRedraw){try{app.redraw();}catch(eRedraw){}}
        return applied;
    };
})();
/* ===== END DPV V146.3.2 QR/BARCODE BATCH DISPATCH + TYPOGRAPHY ===== */

/* ===== DPV V146.3.3 PERSISTENT ENGINE SAFE CODE DISPATCH - APPEND ONLY =====
   Root fix: Illustrator #targetengine persists globals between bridge evaluations.
   Older guards could skip QR/Barcode wrappers on later calls, resetting ApplyOne/ApplyRecord
   to the stable pre-code implementation. This final wrapper is intentionally UNGUARDED
   and self-contained, so every host evaluation reinstalls code actions.
*/
(function(){
    if (typeof ANP_vdpApplyOneV71 !== "function" || typeof ANP_vdpApplyRecordV71 !== "function") { return; }
    var ANP_V14633_PREV_APPLY_ONE = ANP_vdpApplyOneV71;
    var ANP_V14633_PREV_APPLY_RECORD = ANP_vdpApplyRecordV71;
    function ANP_v14633IsCode(a){a=String(a||"");return a==="qrVector"||a==="code128Vector"||a==="ean13Vector";}
    var ANP_V14633Q_PATTERN = [
        [],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],
        [6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],
        [6,30,56,82],[6,30,58,86],[6,34,62,90]
    ];
    /* Level L RS blocks: count,total,data triplets for versions 1..20. */
    var ANP_V14633Q_RS_L = [
        [1,26,19],
        [1,44,34],
        [1,70,55],
        [1,100,80],
        [1,134,108],
        [2,86,68],
        [2,98,78],
        [2,121,97],
        [2,146,116],
        [2,86,68,2,87,69],
        [4,101,81],
        [2,116,92,2,117,93],
        [4,133,107],
        [3,145,115,1,146,116],
        [5,109,87,1,110,88],
        [5,122,98,1,123,99],
        [1,135,107,5,136,108],
        [5,150,120,1,151,121],
        [3,141,113,4,142,114],
        [3,135,107,5,136,108]
    ];

    function ANP_v14633QUtf8Bytes(s){
        s=String(s==null?"":s);var out=[],i,c,c2;
        for(i=0;i<s.length;i++){
            c=s.charCodeAt(i);
            if(c<0x80)out.push(c);
            else if(c<0x800)out.push(0xC0|(c>>6),0x80|(c&63));
            else if(c>=0xD800&&c<=0xDBFF&&i+1<s.length){
                c2=s.charCodeAt(++i);c=0x10000+((c-0xD800)<<10)+(c2-0xDC00);
                out.push(0xF0|(c>>18),0x80|((c>>12)&63),0x80|((c>>6)&63),0x80|(c&63));
            }else out.push(0xE0|(c>>12),0x80|((c>>6)&63),0x80|(c&63));
        }
        return out;
    }
    function ANP_v14633QGfMul(x,y){var r=0;while(y>0){if(y&1)r^=x;y>>=1;x<<=1;if(x&0x100)x^=0x11d;}return r;}
    function ANP_v14633QGfPow2(p){var x=1,i;for(i=0;i<p;i++){x<<=1;if(x&0x100)x^=0x11d;}return x;}
    function ANP_v14633QRsGenerator(deg){var g=[1],i,j,n;for(i=0;i<deg;i++){n=[];for(j=0;j<g.length+1;j++)n[j]=0;for(j=0;j<g.length;j++){n[j]^=g[j];n[j+1]^=ANP_v14633QGfMul(g[j],ANP_v14633QGfPow2(i));}g=n;}return g;}
    function ANP_v14633QRsRemainder(data,degree){var gen=ANP_v14633QRsGenerator(degree),res=[],i,j,f;for(i=0;i<degree;i++)res[i]=0;for(i=0;i<data.length;i++){f=data[i]^res[0];for(j=0;j<degree-1;j++)res[j]=res[j+1];res[degree-1]=0;for(j=0;j<degree;j++)res[j]^=ANP_v14633QGfMul(gen[j+1],f);}return res;}
    function ANP_v14633QAppendBits(a,v,len){var i;for(i=len-1;i>=0;i--)a.push((v>>>i)&1);}
    function ANP_v14633QBitsToBytes(bits){var out=[],i,j,b;for(i=0;i<bits.length;i+=8){b=0;for(j=0;j<8;j++)b=(b<<1)|(bits[i+j]||0);out.push(b);}return out;}
    function ANP_v14633QRsDesc(ver){return ANP_V14633Q_RS_L[ver-1];}
    function ANP_v14633QDataCodewords(ver){var d=ANP_v14633QRsDesc(ver),i,sum=0;for(i=0;i<d.length;i+=3)sum+=d[i]*d[i+2];return sum;}
    function ANP_v14633QCapBytes(ver){var bits=ANP_v14633QDataCodewords(ver)*8-4-(ver<10?8:16);return Math.floor(bits/8);}
    function ANP_v14633QBlocks(ver,data){
        var d=ANP_v14633QRsDesc(ver),db=[],eb=[],i,j,k,count,total,dc,off=0,maxD=0,maxE=0,out=[];
        for(i=0;i<d.length;i+=3){count=d[i];total=d[i+1];dc=d[i+2];for(j=0;j<count;j++){var part=data.slice(off,off+dc);off+=dc;db.push(part);eb.push(ANP_v14633QRsRemainder(part,total-dc));if(dc>maxD)maxD=dc;if(total-dc>maxE)maxE=total-dc;}}
        for(i=0;i<maxD;i++)for(j=0;j<db.length;j++)if(i<db[j].length)out.push(db[j][i]);
        for(i=0;i<maxE;i++)for(j=0;j<eb.length;j++)if(i<eb[j].length)out.push(eb[j][i]);
        return out;
    }
    function ANP_v14633QData(ver,bytes){
        var cap=ANP_v14633QDataCodewords(ver)*8,bits=[],i,pads=[0xEC,0x11],p=0,data;
        ANP_v14633QAppendBits(bits,4,4);ANP_v14633QAppendBits(bits,bytes.length,ver<10?8:16);
        for(i=0;i<bytes.length;i++)ANP_v14633QAppendBits(bits,bytes[i],8);
        if(bits.length>cap)throw new Error("QR data overflow V"+ver+".");
        if(bits.length+4<=cap)ANP_v14633QAppendBits(bits,0,4);else while(bits.length<cap)bits.push(0);
        while(bits.length%8)bits.push(0);
        data=ANP_v14633QBitsToBytes(bits);while(data.length<ANP_v14633QDataCodewords(ver))data.push(pads[(p++)&1]);
        return ANP_v14633QBlocks(ver,data);
    }
    function ANP_v14633QBchDigit(d){var n=0;while(d){n++;d>>>=1;}return n;}
    function ANP_v14633QBchTypeInfo(data){var d=data<<10,g=0x537;while(ANP_v14633QBchDigit(d)-ANP_v14633QBchDigit(g)>=0)d^=g<<(ANP_v14633QBchDigit(d)-ANP_v14633QBchDigit(g));return ((data<<10)|d)^0x5412;}
    function ANP_v14633QBchTypeNumber(data){var d=data<<12,g=0x1f25;while(ANP_v14633QBchDigit(d)-ANP_v14633QBchDigit(g)>=0)d^=g<<(ANP_v14633QBchDigit(d)-ANP_v14633QBchDigit(g));return (data<<12)|d;}
    function ANP_v14633QMask(mask,i,j){switch(mask){case 0:return(i+j)%2===0;case 1:return i%2===0;case 2:return j%3===0;case 3:return(i+j)%3===0;case 4:return(Math.floor(i/2)+Math.floor(j/3))%2===0;case 5:return(i*j)%2+(i*j)%3===0;case 6:return((i*j)%2+(i*j)%3)%2===0;case 7:return((i*j)%3+(i+j)%2)%2===0;}return false;}
    function ANP_v14633QBlank(n){var a=[],r,c;for(r=0;r<n;r++){a[r]=[];for(c=0;c<n;c++)a[r][c]=null;}return a;}
    function ANP_v14633QFinder(m,row,col){var r,c,n=m.length;for(r=-1;r<=7;r++)for(c=-1;c<=7;c++){if(row+r<0||row+r>=n||col+c<0||col+c>=n)continue;m[row+r][col+c]=(r>=0&&r<=6&&c>=0&&c<=6&&(r===0||r===6||c===0||c===6||(r>=2&&r<=4&&c>=2&&c<=4)));}}
    function ANP_v14633QPlaceVersion(m,ver){var bits,i,bit,n=m.length;if(ver<7)return;bits=ANP_v14633QBchTypeNumber(ver);for(i=0;i<18;i++){bit=((bits>>i)&1)!==0;m[Math.floor(i/3)][i%3+n-11]=bit;m[i%3+n-11][Math.floor(i/3)]=bit;}}
    function ANP_v14633QSetupBase(ver){
        var n=17+4*ver,m=ANP_v14633QBlank(n),pos=ANP_V14633Q_PATTERN[ver-1],i,j,r,c,dr,dc;
        ANP_v14633QFinder(m,0,0);ANP_v14633QFinder(m,n-7,0);ANP_v14633QFinder(m,0,n-7);
        /* Alignment must be placed before timing. This matters from Version 7 upward. */
        for(i=0;i<pos.length;i++)for(j=0;j<pos.length;j++){r=pos[i];c=pos[j];if(m[r][c]!==null)continue;for(dr=-2;dr<=2;dr++)for(dc=-2;dc<=2;dc++)m[r+dr][c+dc]=(Math.max(Math.abs(dr),Math.abs(dc))!==1);}
        for(i=8;i<n-8;i++){if(m[i][6]===null)m[i][6]=(i%2===0);if(m[6][i]===null)m[6][i]=(i%2===0);}
        ANP_v14633QPlaceVersion(m,ver);m[n-8][8]=true;return m;
    }
    function ANP_v14633QPlaceType(m,mask){var n=m.length,bits=ANP_v14633QBchTypeInfo((1<<3)|mask),i,bit;for(i=0;i<15;i++){bit=((bits>>i)&1)!==0;if(i<6)m[i][8]=bit;else if(i<8)m[i+1][8]=bit;else m[n-15+i][8]=bit;}for(i=0;i<15;i++){bit=((bits>>i)&1)!==0;if(i<8)m[8][n-i-1]=bit;else if(i<9)m[8][15-i]=bit;else m[8][15-i-1]=bit;}m[n-8][8]=true;}
    function ANP_v14633QMapData(m,bytes,mask){var n=m.length,row=n-1,inc=-1,bitIndex=0,byteIndex=0,col,c,cc,dark;for(col=n-1;col>0;col-=2){if(col===6)col--;while(true){for(c=0;c<2;c++){cc=col-c;if(m[row][cc]===null){dark=false;if(byteIndex<bytes.length)dark=((bytes[byteIndex]>>>(7-bitIndex))&1)!==0;if(ANP_v14633QMask(mask,row,cc))dark=!dark;m[row][cc]=dark;bitIndex++;if(bitIndex===8){byteIndex++;bitIndex=0;}}}row+=inc;if(row<0||row>=n){row-=inc;inc=-inc;break;}}}}
    function ANP_v14633QLost(m){var n=m.length,l=0,r,c,k,same,dark,dr,dc,cnt=0;for(r=0;r<n;r++)for(c=0;c<n;c++){same=0;dark=m[r][c];for(dr=-1;dr<=1;dr++)for(dc=-1;dc<=1;dc++){if(dr===0&&dc===0)continue;if(r+dr<0||r+dr>=n||c+dc<0||c+dc>=n)continue;if(Math.abs(dr)+Math.abs(dc)===2)continue;if(m[r+dr][c+dc]===dark)same++;}if(same>5)l+=3+same-5;}for(r=0;r<n-1;r++)for(c=0;c<n-1;c++){k=(m[r][c]?1:0)+(m[r+1][c]?1:0)+(m[r][c+1]?1:0)+(m[r+1][c+1]?1:0);if(k===0||k===4)l+=3;}for(r=0;r<n;r++)for(c=0;c<n-6;c++)if(m[r][c]&&!m[r][c+1]&&m[r][c+2]&&m[r][c+3]&&m[r][c+4]&&!m[r][c+5]&&m[r][c+6])l+=40;for(c=0;c<n;c++)for(r=0;r<n-6;r++)if(m[r][c]&&!m[r+1][c]&&m[r+2][c]&&m[r+3][c]&&m[r+4][c]&&!m[r+5][c]&&m[r+6][c])l+=40;for(r=0;r<n;r++)for(c=0;c<n;c++)if(m[r][c])cnt++;l+=Math.floor(Math.abs(100*cnt/n/n-50)/5)*10;return l;}
    function ANP_v14633QQrMatrix(text){var bytes=ANP_v14633QUtf8Bytes(text),ver=1,m,best=null,bestLoss=1e99,mask,data,loss;while(ver<=20&&bytes.length>ANP_v14633QCapBytes(ver))ver++;if(ver>20)throw new Error("QR quá dài: "+bytes.length+" byte. V146.2 hỗ trợ tối đa khoảng 858 byte UTF-8.");data=ANP_v14633QData(ver,bytes);for(mask=0;mask<8;mask++){m=ANP_v14633QSetupBase(ver);ANP_v14633QPlaceType(m,mask);ANP_v14633QMapData(m,data,mask);loss=ANP_v14633QLost(m);if(loss<bestLoss){bestLoss=loss;best=m;}}return best;}
    function ANP_v14633QBlack(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=100;return c;}
    function ANP_v14633QWhite(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=0;return c;}
    function ANP_v14633QBounds(item){var b=item.geometricBounds;return[Number(b[0]),Number(b[1]),Number(b[2]),Number(b[3])];}
    function ANP_v14633QRemoveNamed(doc,token){var i,g,names=["DPV_V146_QR_"+token,"DPV_V1462_QR_"+token];try{for(i=doc.groupItems.length-1;i>=0;i--){g=doc.groupItems[i];if(String(g.name||"")===names[0]||String(g.name||"")===names[1]){try{g.remove();}catch(e0){}}}}catch(e1){}}
    function ANP_v14633QDrawQR(doc,item,text,token){
        var m=ANP_v14633QQrMatrix(text),n=m.length,b=ANP_v14633QBounds(item),w=b[2]-b[0],h=b[1]-b[3],size=Math.min(w,h),quiet=4,mod=size/(n+quiet*2),left=b[0]+(w-size)/2,top=b[1]-(h-size)/2,g,r,c,start,rect,name="DPV_V1462_QR_"+String(token);
        if(!(w>0&&h>0))throw new Error("QR: khung giữ chỗ không hợp lệ.");
        ANP_v14633QRemoveNamed(doc,String(token));g=item.layer.groupItems.add();g.name=name;
        rect=g.pathItems.rectangle(top,left,size,size);rect.filled=true;rect.fillColor=ANP_v14633QWhite();rect.stroked=false;
        /* Merge horizontal dark runs to reduce Illustrator objects. */
        for(r=0;r<n;r++){c=0;while(c<n){while(c<n&&!m[r][c])c++;if(c>=n)break;start=c;while(c<n&&m[r][c])c++;rect=g.pathItems.rectangle(top-(quiet+r)*mod,left+(quiet+start)*mod,(c-start)*mod,mod);rect.filled=true;rect.fillColor=ANP_v14633QBlack();rect.stroked=false;}}
        try{item.hidden=true;}catch(e2){}
        return true;
    }

    function ANP_v14633BMm(v){return Number(v||0)*2.834645669291339;}
    function ANP_v14633BBlack(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=100;return c;}
    function ANP_v14633BWhite(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=0;return c;}
    function ANP_v14633BBounds(item){var b=item.geometricBounds;return [Number(b[0]),Number(b[1]),Number(b[2]),Number(b[3])];}
    function ANP_v14633BRemove(doc,prefix,token){
        var i,g,n=prefix+String(token||"");
        try{for(i=doc.groupItems.length-1;i>=0;i--){g=doc.groupItems[i];if(String(g.name||"")===n){try{g.remove();}catch(e0){}}}}catch(e1){}
    }
    function ANP_v14633BStyle(mapping){
        var s=mapping&&mapping.barcodeStyle?mapping.barcodeStyle:{};
        return {
            showText: !(Number(s.showText)===0 || s.showText===false),
            fontName:String(s.fontName||"Arial"),
            fontSize:Math.max(4,Number(s.fontSize)||9),
            tracking:Number(s.tracking)||0,
            textGapMm:Math.max(0,Number(s.textGapMm)||1.2),
            barHeightPercent:Math.max(40,Math.min(200,Number(s.barHeightPercent)||100)),
            barWidthPercent:Math.max(60,Math.min(140,Number(s.barWidthPercent)||100)),
            quietZone:Math.max(2,Math.min(20,Math.round(Number(s.quietZone)||10))),
            fontWeight:String(s.fontWeight||"regular"),
            textMode:String(s.textMode||"outline")
        };
    }
    function ANP_v14633BFindFont(name,weight){
        var i,f,n=String(name||""),wantBold=String(weight||"")==="bold",fn,ff;
        if(!n){return null;}
        try{return app.textFonts.getByName(n);}catch(e0){}
        try{
            for(i=0;i<app.textFonts.length;i++){
                f=app.textFonts[i];fn=String(f.name||"");ff=String(f.family||"");
                if(fn===n || ff===n || fn.toLowerCase()===n.toLowerCase() || ff.toLowerCase()===n.toLowerCase()){
                    if(!wantBold || /bold|semibold|demi/i.test(fn)){return f;}
                }
            }
            if(wantBold){
                for(i=0;i<app.textFonts.length;i++){
                    f=app.textFonts[i];fn=String(f.name||"");ff=String(f.family||"");
                    if((ff===n || ff.toLowerCase()===n.toLowerCase()) && /bold|semibold|demi/i.test(fn)){return f;}
                }
            }
        }catch(e1){}
        return null;
    }
    function ANP_v14633BAddText(doc,g,text,centerX,bottomY,style){
        var tf=null,o=null,gb,dx,dy,font;
        if(!style.showText){return true;}
        try{
            tf=doc.textFrames.pointText([0,0]);tf.contents=String(text==null?"":text);
            try{tf.textRange.characterAttributes.size=style.fontSize;}catch(e0){}
            try{tf.textRange.characterAttributes.tracking=style.tracking;}catch(e1){}
            try{tf.textRange.characterAttributes.fillColor=ANP_v14633BBlack();}catch(e2){}
            font=ANP_v14633BFindFont(style.fontName,style.fontWeight);if(font){try{tf.textRange.characterAttributes.textFont=font;}catch(e3){}}
            try{tf.paragraphs[0].paragraphAttributes.justification=Justification.CENTER;}catch(e4){}
            if(style.textMode==="live"){
                try{tf.position=[centerX,bottomY+style.fontSize];}catch(e5){}
                try{tf.move(g,ElementPlacement.PLACEATEND);}catch(e6){}
                return true;
            }
            o=tf.createOutline();gb=o.geometricBounds;dx=centerX-((Number(gb[0])+Number(gb[2]))/2);dy=bottomY-Number(gb[3]);
            try{o.translate(dx,dy);}catch(e7){try{o.left=Number(o.left)+dx;o.top=Number(o.top)+dy;}catch(e8){}}
            try{o.move(g,ElementPlacement.PLACEATEND);}catch(e9){}
            return true;
        }catch(e){try{if(tf)tf.remove();}catch(e10){}return false;}
    }

    var ANP_V14633B_C128=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
    function ANP_v14633BCode128Values(text){
        text=String(text==null?"":text);if(!text.length)throw new Error("Code 128 rỗng.");
        var vals=[104],i,c,sum=104;for(i=0;i<text.length;i++){c=text.charCodeAt(i);if(c<32||c>126)throw new Error("Code 128 chỉ hỗ trợ ASCII 32–126. Ký tự lỗi ở vị trí "+String(i+1)+".");vals.push(c-32);sum+=(c-32)*(i+1);}vals.push(sum%103);vals.push(106);return vals;
    }
    function ANP_v14633BDrawCode128(doc,item,text,token,mapping){
        var st=ANP_v14633BStyle(mapping),vals=ANP_v14633BCode128Values(text),seq=[],i,j,p,total=0,b=ANP_v14633BBounds(item),w=b[2]-b[0],h=b[1]-b[3],quiet=st.quietZone,
            name="DPV_V14633_C128_"+String(token),g,x,unit,rect,bar=true,codeW,textZone=0,gap=ANP_v14633BMm(st.textGapMm),barH,top;
        if(!(w>0&&h>0))throw new Error("Code 128: khung giữ chỗ không hợp lệ.");
        for(i=0;i<vals.length;i++){p=ANP_V14633B_C128[vals[i]];for(j=0;j<p.length;j++){seq.push(Number(p.charAt(j)));total+=Number(p.charAt(j));}}
        if(st.showText){textZone=Math.min(h*0.35,Math.max(st.fontSize*1.55,gap+st.fontSize*1.2));}
        barH=(h-textZone)*st.barHeightPercent/100;if(barH>h-textZone)barH=h-textZone;if(!(barH>0))throw new Error("Code 128: chiều cao khung quá thấp.");
        total+=quiet*2;codeW=w*st.barWidthPercent/100;if(codeW>w)codeW=w;unit=codeW/total;x=b[0]+(w-codeW)/2+quiet*unit;top=b[1];
        ANP_v14633BRemove(doc,"DPV_V14633_C128_",token);ANP_v14633BRemove(doc,"DPV_V146_C128_",token);
        g=item.layer.groupItems.add();g.name=name;
        rect=g.pathItems.rectangle(b[1],b[0],w,h);rect.filled=true;rect.fillColor=ANP_v14633BWhite();rect.stroked=false;
        for(i=0;i<seq.length;i++){if(bar){rect=g.pathItems.rectangle(top,x,seq[i]*unit,barH);rect.filled=true;rect.fillColor=ANP_v14633BBlack();rect.stroked=false;}x+=seq[i]*unit;bar=!bar;}
        if(st.showText){ANP_v14633BAddText(doc,g,text,(b[0]+b[2])/2,b[3]+Math.max(0,gap*0.2),st);}
        try{item.hidden=true;}catch(e0){}return true;
    }

    var ANP_V14633B_EAN_L=["0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"];
    var ANP_V14633B_EAN_G=["0100111","0110011","0011011","0100001","0011101","0111001","0000101","0010001","0001001","0010111"];
    var ANP_V14633B_EAN_R=["1110010","1100110","1101100","1000010","1011100","1001110","1010000","1000100","1001000","1110100"];
    var ANP_V14633B_EAN_PAR=["LLLLLL","LLGLGG","LLGGLG","LLGGGL","LGLLGG","LGGLLG","LGGGLL","LGLGLG","LGLGGL","LGGLGL"];
    function ANP_v14633BEANCheck(s12){var i,sum=0,n;if(!/^\d{12}$/.test(String(s12||"")))throw new Error("EAN-13 cần đúng 12 hoặc 13 chữ số.");for(i=0;i<12;i++){n=Number(s12.charAt(i));sum+=(i%2===0)?n:n*3;}return String((10-(sum%10))%10);}
    function ANP_v14633BEAN(raw){var s=String(raw==null?"":raw).replace(/^\s+|\s+$/g,"");if(!/^\d{12,13}$/.test(s))throw new Error("EAN-13 chỉ nhận 12 hoặc 13 chữ số. Giá trị: "+s);if(s.length===12)return s+ANP_v14633BEANCheck(s);var cd=ANP_v14633BEANCheck(s.substr(0,12));if(s.charAt(12)!==cd)throw new Error("EAN-13 sai checksum. Mã "+s+" phải có số kiểm tra cuối là "+cd+".");return s;}
    function ANP_v14633BEANBits(ean){var parity=ANP_V14633B_EAN_PAR[Number(ean.charAt(0))],bits="101",i,d;for(i=1;i<=6;i++){d=Number(ean.charAt(i));bits+=(parity.charAt(i-1)==="L"?ANP_V14633B_EAN_L[d]:ANP_V14633B_EAN_G[d]);}bits+="01010";for(i=7;i<=12;i++){d=Number(ean.charAt(i));bits+=ANP_V14633B_EAN_R[d];}bits+="101";return bits;}
    function ANP_v14633BGuard(i){return (i<=2)||(i>=45&&i<=49)||(i>=92);}
    function ANP_v14633BDrawEAN13(doc,item,raw,token,mapping){
        var st=ANP_v14633BStyle(mapping),ean=ANP_v14633BEAN(raw),bits=ANP_v14633BEANBits(ean),b=ANP_v14633BBounds(item),w=b[2]-b[0],h=b[1]-b[3],quietL=Math.max(7,st.quietZone+1),quietR=Math.max(5,st.quietZone-3),total=95+quietL+quietR,
            codeW=w*st.barWidthPercent/100,unit,startX,textZone=0,gap=ANP_v14633BMm(st.textGapMm),barH,guardH,name="DPV_V14633_EAN13_"+String(token),g,bg,i,x,run,runStart,rect,textBottom;
        if(!(w>0&&h>0))throw new Error("EAN-13: khung giữ chỗ không hợp lệ.");if(codeW>w)codeW=w;unit=codeW/total;startX=b[0]+(w-codeW)/2+quietL*unit;
        if(st.showText){textZone=Math.min(h*0.34,Math.max(st.fontSize*1.65,gap+st.fontSize*1.25));}
        barH=(h-textZone)*st.barHeightPercent/100;if(barH>h-textZone)barH=h-textZone;if(!(barH>0))throw new Error("EAN-13: chiều cao khung quá thấp.");guardH=Math.min(h-textZone*0.4,barH+Math.max(unit*5,textZone*0.25));
        ANP_v14633BRemove(doc,"DPV_V14633_EAN13_",token);ANP_v14633BRemove(doc,"DPV_V1461_EAN13_",token);
        g=item.layer.groupItems.add();g.name=name;bg=g.pathItems.rectangle(b[1],b[0],w,h);bg.filled=true;bg.fillColor=ANP_v14633BWhite();bg.stroked=false;
        i=0;while(i<95){if(bits.charAt(i)!=="1"){i++;continue;}runStart=i;run=1;while(i+run<95&&bits.charAt(i+run)==="1"&&ANP_v14633BGuard(i+run)===ANP_v14633BGuard(runStart))run++;x=startX+runStart*unit;rect=g.pathItems.rectangle(b[1],x,run*unit,ANP_v14633BGuard(runStart)?guardH:barH);rect.filled=true;rect.fillColor=ANP_v14633BBlack();rect.stroked=false;i+=run;}
        if(st.showText){textBottom=b[3]+Math.max(0,gap*0.15);ANP_v14633BAddText(doc,g,ean.charAt(0),startX-unit*5.2,textBottom,st);ANP_v14633BAddText(doc,g,ean.substr(1,6),startX+24*unit,textBottom,st);ANP_v14633BAddText(doc,g,ean.substr(7,6),startX+71*unit,textBottom,st);}
        try{item.hidden=true;}catch(e0){}return true;
    }


    function ANP_v14633Cleanup(doc,token){
        var i,g,n,t=String(token||"");
        try{for(i=doc.groupItems.length-1;i>=0;i--){g=doc.groupItems[i];n=String(g.name||"");
            if(n==="DPV_V14633_QR_"+t||n==="DPV_V1462_QR_"+t||n==="DPV_V146_QR_"+t||
               n==="DPV_V14633_C128_"+t||n==="DPV_V14633_C128_"+t||n==="DPV_V146_C128_"+t||
               n==="DPV_V14633_EAN13_"+t||n==="DPV_V14633_EAN13_"+t||n==="DPV_V1461_EAN13_"+t){try{g.remove();}catch(e0){}}
        }}catch(e1){}
    }
    function ANP_v14633ApplyCode(doc,mapping,record,sourceFolder){
        var action=String(mapping&&mapping.action||""),field=String(mapping&&mapping.field||""),item,value,text,token;
        if(!ANP_v14633IsCode(action)){return false;}
        token=String(mapping.targetId||"");
        item=ANP_vdpFindByTokenV71(doc,token);
        if(!item){throw new Error("Không tìm thấy target mã trong work-copy: "+String(mapping.label||token||"Barcode"));}
        if(!field){throw new Error("Mapping mã chưa chọn cột dữ liệu: "+String(mapping.label||token||"Barcode"));}
        value=record&&record[field]!==undefined?record[field]:"";
        text=String(mapping.prefix||"")+String(value==null?"":value)+String(mapping.suffix||"");
        if(action==="qrVector"){
            if(!text){throw new Error("QR Code rỗng ở cột “"+field+"”.");}
            ANP_v14633Cleanup(doc,token);
            return ANP_v14633QDrawQR(doc,item,text,token)===true;
        }
        if(action==="code128Vector"){
            ANP_v14633Cleanup(doc,token);
            return ANP_v14633BDrawCode128(doc,item,text,token,mapping)===true;
        }
        if(action==="ean13Vector"){
            ANP_v14633Cleanup(doc,token);
            return ANP_v14633BDrawEAN13(doc,item,text,token,mapping)===true;
        }
        return false;
    }
    ANP_vdpApplyOneV71 = function(doc,mapping,record,sourceFolder){
        if(ANP_v14633IsCode(mapping&&mapping.action)){return ANP_v14633ApplyCode(doc,mapping,record,sourceFolder);}
        return ANP_V14633_PREV_APPLY_ONE(doc,mapping,record,sourceFolder);
    };
    ANP_vdpApplyRecordV71 = function(doc,mappings,record,sourceFolder,skipRedraw){
        var i,m,hasCode=false,applied=0; mappings=mappings||[];
        for(i=0;i<mappings.length;i++){if(ANP_v14633IsCode(mappings[i]&&mappings[i].action)){hasCode=true;break;}}
        if(!hasCode){return ANP_V14633_PREV_APPLY_RECORD(doc,mappings,record,sourceFolder,skipRedraw);}
        for(i=0;i<mappings.length;i++){m=mappings[i]||{};
            try{if(ANP_vdpApplyOneV71(doc,m,record,sourceFolder)){applied++;}}
            catch(eMap){throw new Error("Kênh "+String(m.label||m.field||String(i+1))+": "+String(eMap&&eMap.message?eMap.message:eMap));}
        }
        if(!skipRedraw){try{app.redraw();}catch(eRedraw){}}
        return applied;
    };
    /* Marker only; wrapper is still reinstalled on every evaluation by design. */
    try{ANP_vdpApplyOneV71.__dpv14633PersistentSafe=true;ANP_vdpApplyRecordV71.__dpv14633PersistentSafe=true;}catch(eMark){}
})();
/* ===== END DPV V146.3.3 PERSISTENT ENGINE SAFE CODE DISPATCH ===== */



/* ===== DPV V146.4 CODE128 AUTO A/B/C SAFE - APPEND ONLY =====
   Purpose:
   - make code128Vector behave closer to Barcode Studio AUTO mode
   - auto choose Subset C for numeric runs, Subset B for general text
   - preserve existing QR / EAN-13 / old jobs untouched
*/
(function(){
    if (typeof ANP_vdpApplyOneV71 !== 'function' || typeof ANP_vdpApplyRecordV71 !== 'function') { return; }
    var ANP_V1464_PREV_ONE = ANP_vdpApplyOneV71;
    var ANP_V1464_PREV_RECORD = ANP_vdpApplyRecordV71;
    function ANP_v1464IsCode(a){ a=String(a||''); return a==='qrVector' || a==='code128Vector' || a==='ean13Vector'; }
    function ANP_v1464Black(){ var c=new CMYKColor(); c.black=100; c.cyan=0; c.magenta=0; c.yellow=0; return c; }
    function ANP_v1464White(){ var c=new GrayColor(); c.gray=0; return c; }
    function ANP_v1464Mm(mm){ return Number(mm||0) * 2.834645669291339; }
    function ANP_v1464Bounds(item){ var b=item.visibleBounds || item.geometricBounds; return [Number(b[0]),Number(b[1]),Number(b[2]),Number(b[3])]; }
    function ANP_v1464Remove(doc,prefix,token){
        var i,g,n=String(prefix||'')+String(token||'');
        try{ for(i=doc.groupItems.length-1;i>=0;i--){ g=doc.groupItems[i]; if(String(g.name||'')===n){ try{ g.remove(); }catch(e0){} } } }catch(e1){}
    }
    function ANP_v1464Cleanup(doc,token){
        ANP_v1464Remove(doc,'DPV_V1464_C128_',token);
        ANP_v1464Remove(doc,'DPV_V14633_C128_',token);
        ANP_v1464Remove(doc,'DPV_V14632_C128_',token);
        ANP_v1464Remove(doc,'DPV_V146_C128_',token);
    }
    function ANP_v1464Style(mapping){
        var s=mapping&&mapping.barcodeStyle?mapping.barcodeStyle:{};
        return {
            showText: !(Number(s.showText)===0 || s.showText===false),
            fontName:String(s.fontName||'Arial'),
            fontSize:Math.max(4, Number(s.fontSize)||9),
            tracking:Number(s.tracking)||0,
            textGapMm:Math.max(0, Number(s.textGapMm)||1.2),
            barHeightPercent:Math.max(40, Math.min(200, Number(s.barHeightPercent)||100)),
            barWidthPercent:Math.max(60, Math.min(140, Number(s.barWidthPercent)||100)),
            quietZone:Math.max(2, Math.min(20, Math.round(Number(s.quietZone)||10))),
            fontWeight:String(s.fontWeight||'regular'),
            textMode:String(s.textMode||'outline')
        };
    }
    function ANP_v1464FindFont(name,weight){
        var i,f,n=String(name||''),wantBold=String(weight||'')==='bold',fn,ff;
        if(!n){ return null; }
        try{ return app.textFonts.getByName(n); }catch(e0){}
        try{
            for(i=0;i<app.textFonts.length;i++){
                f=app.textFonts[i]; fn=String(f.name||''); ff=String(f.family||'');
                if(fn===n || ff===n || fn.toLowerCase()===n.toLowerCase() || ff.toLowerCase()===n.toLowerCase()){
                    if(!wantBold || /bold|semibold|demi/i.test(fn)) return f;
                }
            }
            if(wantBold){
                for(i=0;i<app.textFonts.length;i++){
                    f=app.textFonts[i]; fn=String(f.name||''); ff=String(f.family||'');
                    if((ff===n || ff.toLowerCase()===n.toLowerCase()) && /bold|semibold|demi/i.test(fn)) return f;
                }
            }
        }catch(e1){}
        return null;
    }
    function ANP_v1464AddText(doc,g,text,centerX,bottomY,style){
        var tf=null,o=null,gb,dx,dy,font;
        if(!style.showText) return true;
        try{
            tf=doc.textFrames.pointText([0,0]);
            tf.contents=String(text==null?'':text);
            try{ tf.textRange.characterAttributes.size = style.fontSize; }catch(e0){}
            try{ tf.textRange.characterAttributes.tracking = style.tracking; }catch(e1){}
            try{ tf.textRange.characterAttributes.fillColor = ANP_v1464Black(); }catch(e2){}
            font=ANP_v1464FindFont(style.fontName, style.fontWeight); if(font){ try{ tf.textRange.characterAttributes.textFont = font; }catch(e3){} }
            try{ tf.paragraphs[0].paragraphAttributes.justification = Justification.CENTER; }catch(e4){}
            if(style.textMode==='live'){
                try{ tf.position=[centerX, bottomY + style.fontSize]; }catch(e5){}
                try{ tf.move(g, ElementPlacement.PLACEATEND); }catch(e6){}
                return true;
            }
            o=tf.createOutline(); gb=o.geometricBounds; dx=centerX-((Number(gb[0])+Number(gb[2]))/2); dy=bottomY-Number(gb[3]);
            try{ o.translate(dx,dy); }catch(e7){ try{ o.left=Number(o.left)+dx; o.top=Number(o.top)+dy; }catch(e8){} }
            try{ o.move(g, ElementPlacement.PLACEATEND); }catch(e9){}
            return true;
        }catch(e){ try{ if(tf) tf.remove(); }catch(e10){} return false; }
    }
    var ANP_V1464_C128=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
    function ANP_v1464DigitRun(s,i){ var n=0; while(i+n<s.length && /\d/.test(s.charAt(i+n))) n++; return n; }
    function ANP_v1464AssertAscii(text){ var i,c; for(i=0;i<text.length;i++){ c=text.charCodeAt(i); if(c<32||c>126) throw new Error('Code 128 AUTO chỉ hỗ trợ ASCII 32–126. Ký tự lỗi ở vị trí '+String(i+1)+'.'); } }
    function ANP_v1464Code128AutoValues(text){
        text=String(text==null?'':text); if(!text.length) throw new Error('Code 128 rỗng.');
        ANP_v1464AssertAscii(text);
        var vals=[], current, i=0, run, ch, sum, p;
        run = ANP_v1464DigitRun(text,0);
        if(run>=4 && run%2===0){ vals.push(105); current='C'; }
        else { vals.push(104); current='B'; }
        while(i<text.length){
            if(current==='C'){
                run = ANP_v1464DigitRun(text,i);
                if(run>=2){
                    vals.push(Number(text.substr(i,2)));
                    i += 2;
                    continue;
                }
                vals.push(100); current='B';
                continue;
            }
            run = ANP_v1464DigitRun(text,i);
            if(run>=4){
                if(run%2===1){
                    ch=text.charCodeAt(i); vals.push(ch-32); i += 1; continue;
                }
                vals.push(99); current='C';
                continue;
            }
            ch=text.charCodeAt(i); vals.push(ch-32); i += 1;
        }
        sum = vals[0];
        for(p=1;p<vals.length;p++) sum += vals[p]*p;
        vals.push(sum%103); vals.push(106);
        return vals;
    }
    function ANP_v1464DetectEncoding(text){
        text=String(text==null?'':text);
        if(/^\d+$/.test(text) && text.length>=2 && text.length%2===0) return 'Code128-C';
        if(/\d{4,}/.test(text)) return 'Code128 AUTO (B/C)';
        return 'Code128-B';
    }
    function ANP_v1464DrawCode128Auto(doc,item,text,token,mapping){
        var st=ANP_v1464Style(mapping), vals=ANP_v1464Code128AutoValues(text), seq=[], i,j,p,total=0,
            b=ANP_v1464Bounds(item), w=b[2]-b[0], h=b[1]-b[3], quiet=st.quietZone,
            name='DPV_V1464_C128_'+String(token), g, x, unit, rect, bar=true, codeW, textZone=0, gap=ANP_v1464Mm(st.textGapMm), barH, top;
        if(!(w>0&&h>0)) throw new Error('Code 128: khung giữ chỗ không hợp lệ.');
        for(i=0;i<vals.length;i++){ p=ANP_V1464_C128[vals[i]]; for(j=0;j<p.length;j++){ seq.push(Number(p.charAt(j))); total += Number(p.charAt(j)); } }
        if(st.showText) textZone=Math.min(h*0.35, Math.max(st.fontSize*1.55, gap + st.fontSize*1.2));
        barH=(h-textZone)*st.barHeightPercent/100; if(barH>h-textZone) barH=h-textZone; if(!(barH>0)) throw new Error('Code 128: chiều cao khung quá thấp.');
        total += quiet*2; codeW = w*st.barWidthPercent/100; if(codeW>w) codeW=w; unit = codeW/total; x = b[0] + (w-codeW)/2 + quiet*unit; top = b[1];
        ANP_v1464Cleanup(doc,token);
        g=item.layer.groupItems.add(); g.name=name;
        rect=g.pathItems.rectangle(b[1],b[0],w,h); rect.filled=true; rect.fillColor=ANP_v1464White(); rect.stroked=false;
        for(i=0;i<seq.length;i++){ if(bar){ rect=g.pathItems.rectangle(top,x,seq[i]*unit,barH); rect.filled=true; rect.fillColor=ANP_v1464Black(); rect.stroked=false; } x+=seq[i]*unit; bar=!bar; }
        if(st.showText){ ANP_v1464AddText(doc,g,text,(b[0]+b[2])/2,b[3]+Math.max(0,gap*0.2),st); }
        try{ g.note='DPV V146.4 '+ANP_v1464DetectEncoding(text); }catch(eNote){}
        try{ item.hidden=true; }catch(e0){}
        return true;
    }
    ANP_vdpApplyOneV71 = function(doc,mapping,record,sourceFolder){
        var action=String(mapping&&mapping.action||''), field=String(mapping&&mapping.field||''), item, value, text, token;
        if(action!=='code128Vector') return ANP_V1464_PREV_ONE(doc,mapping,record,sourceFolder);
        token=String(mapping.targetId||'');
        item=ANP_vdpFindByTokenV71(doc, token);
        if(!item) throw new Error('Không tìm thấy target barcode trong work-copy: '+String(mapping.label||token||'Barcode'));
        if(!field) throw new Error('Mapping barcode chưa chọn cột dữ liệu: '+String(mapping.label||token||'Barcode'));
        value = record&&record[field]!==undefined ? record[field] : '';
        text = String(mapping.prefix||'') + String(value==null?'':value) + String(mapping.suffix||'');
        return ANP_v1464DrawCode128Auto(doc,item,text,token,mapping)===true;
    };
    ANP_vdpApplyRecordV71 = function(doc,mappings,record,sourceFolder,skipRedraw){
        var i,m,hasCode=false,applied=0;
        mappings=mappings||[];
        for(i=0;i<mappings.length;i++){ if(ANP_v1464IsCode(mappings[i]&&mappings[i].action)){ hasCode=true; break; } }
        if(!hasCode) return ANP_V1464_PREV_RECORD(doc,mappings,record,sourceFolder,skipRedraw);
        for(i=0;i<mappings.length;i++){
            m=mappings[i]||{};
            try{ if(ANP_vdpApplyOneV71(doc,m,record,sourceFolder)) applied++; }
            catch(eMap){ throw new Error('Kênh '+String(m.label||m.field||String(i+1))+': '+String(eMap&&eMap.message?eMap.message:eMap)); }
        }
        if(!skipRedraw){ try{ app.redraw(); }catch(eRedraw){} }
        return applied;
    };
})();
/* ===== END DPV V146.4 CODE128 AUTO A/B/C SAFE ===== */


/* ===== DPV V146.4.1 BARCODE TEXT VISIBILITY + FONT SAFE - APPEND ONLY =====
   Fixes:
   - outlined human-readable text under barcode is forced visible above white background
   - fontName/fontSize/tracking are honored more reliably
   - Code128 keeps AUTO A/B/C behavior from V146.4
   - EAN-13 human-readable text also uses the safer text painter
*/
(function(){
    if (typeof ANP_vdpApplyOneV71 !== 'function' || typeof ANP_vdpApplyRecordV71 !== 'function') { return; }
    var ANP_V14641_PREV_ONE = ANP_vdpApplyOneV71;
    var ANP_V14641_PREV_RECORD = ANP_vdpApplyRecordV71;
    function ANP_v14641IsCode(a){ a=String(a||''); return a==='code128Vector' || a==='ean13Vector'; }
    function ANP_v14641Black(){ var c=new CMYKColor(); c.cyan=0;c.magenta=0;c.yellow=0;c.black=100; return c; }
    function ANP_v14641White(){ var c=new GrayColor(); c.gray=0; return c; }
    function ANP_v14641Mm(mm){ return Number(mm||0)*2.834645669291339; }
    function ANP_v14641Bounds(item){ var b=item.visibleBounds||item.geometricBounds; return [Number(b[0]),Number(b[1]),Number(b[2]),Number(b[3])]; }
    function ANP_v14641Remove(doc,prefix,token){ var i,g,n=String(prefix||'')+String(token||''); try{ for(i=doc.groupItems.length-1;i>=0;i--){ g=doc.groupItems[i]; if(String(g.name||'')===n){ try{ g.remove(); }catch(e0){} } } }catch(e1){} }
    function ANP_v14641Style(mapping){
        var s=mapping&&mapping.barcodeStyle?mapping.barcodeStyle:{};
        return {
            showText: !(Number(s.showText)===0 || s.showText===false),
            fontName:String(s.fontName||'Arial'),
            fontSize:Math.max(4, Number(s.fontSize)||9),
            tracking:Number(s.tracking)||0,
            textGapMm:Math.max(0, Number(s.textGapMm)||1.2),
            barHeightPercent:Math.max(40, Math.min(200, Number(s.barHeightPercent)||100)),
            barWidthPercent:Math.max(60, Math.min(140, Number(s.barWidthPercent)||100)),
            quietZone:Math.max(2, Math.min(20, Math.round(Number(s.quietZone)||10))),
            fontWeight:String(s.fontWeight||'regular'),
            textMode:String(s.textMode||'outline')
        };
    }
    function ANP_v14641FindFont(name,weight){
        var i,f,n=String(name||''), wantBold=String(weight||'')==='bold', fn,ff;
        if(!n) return null;
        try{ return app.textFonts.getByName(n); }catch(e0){}
        try{
            for(i=0;i<app.textFonts.length;i++){
                f=app.textFonts[i]; fn=String(f.name||''); ff=String(f.family||'');
                if(fn===n || ff===n || fn.toLowerCase()===n.toLowerCase() || ff.toLowerCase()===n.toLowerCase()){
                    if(!wantBold || /bold|semibold|demi/i.test(fn)) return f;
                }
            }
            if(wantBold){
                for(i=0;i<app.textFonts.length;i++){
                    f=app.textFonts[i]; fn=String(f.name||''); ff=String(f.family||'');
                    if((ff===n || ff.toLowerCase()===n.toLowerCase()) && /bold|semibold|demi/i.test(fn)) return f;
                }
            }
        }catch(e1){}
        return null;
    }
    function ANP_v14641PaintBlack(item){
        var i;
        try{ item.filled=true; item.fillColor=ANP_v14641Black(); }catch(e0){}
        try{ item.stroked=false; }catch(e1){}
        try{ if(item.pathItems){ for(i=0;i<item.pathItems.length;i++) ANP_v14641PaintBlack(item.pathItems[i]); } }catch(e2){}
        try{ if(item.compoundPathItems){ for(i=0;i<item.compoundPathItems.length;i++) ANP_v14641PaintBlack(item.compoundPathItems[i]); } }catch(e3){}
        try{ if(item.groupItems){ for(i=0;i<item.groupItems.length;i++) ANP_v14641PaintBlack(item.groupItems[i]); } }catch(e4){}
        return true;
    }
    function ANP_v14641BringFront(item){ try{ item.zOrder(ZOrderMethod.BRINGTOFRONT); }catch(e0){} return true; }
    function ANP_v14641AddText(doc,g,text,centerX,targetTop,style){
        var tf=null,o=null,gb,dx,dy,font;
        if(!style.showText) return true;
        try{
            tf=doc.textFrames.pointText([0,0]);
            tf.contents=String(text==null?'':text);
            try{ tf.textRange.characterAttributes.size = style.fontSize; }catch(e0){}
            try{ tf.textRange.characterAttributes.tracking = style.tracking; }catch(e1){}
            try{ tf.textRange.characterAttributes.fillColor = ANP_v14641Black(); }catch(e2){}
            font=ANP_v14641FindFont(style.fontName, style.fontWeight); if(font){ try{ tf.textRange.characterAttributes.textFont = font; }catch(e3){} }
            try{ tf.paragraphs[0].paragraphAttributes.justification = Justification.CENTER; }catch(e4){}
            if(style.textMode==='live'){
                try{ tf.move(g, ElementPlacement.PLACEATEND); }catch(e6){}
                try{ gb=tf.geometricBounds; dx=centerX-((Number(gb[0])+Number(gb[2]))/2); dy=targetTop-Number(gb[1]); tf.translate(dx,dy); }catch(e5){}
                ANP_v14641PaintBlack(tf); ANP_v14641BringFront(tf);
                return true;
            }
            o=tf.createOutline();
            ANP_v14641PaintBlack(o);
            gb=o.geometricBounds;
            dx=centerX-((Number(gb[0])+Number(gb[2]))/2); dy=targetTop-Number(gb[1]);
            try{ o.translate(dx,dy); }catch(e7){ try{ o.left=Number(o.left)+dx; o.top=Number(o.top)+dy; }catch(e8){} }
            try{ o.move(g, ElementPlacement.PLACEATEND); }catch(e9){}
            ANP_v14641BringFront(o);
            return true;
        }catch(e){ try{ if(tf) tf.remove(); }catch(e10){} return false; }
    }
    var ANP_V14641_C128=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
    function ANP_v14641DigitRun(s,i){ var n=0; while(i+n<s.length && /\d/.test(s.charAt(i+n))) n++; return n; }
    function ANP_v14641AssertAscii(text){ var i,c; for(i=0;i<text.length;i++){ c=text.charCodeAt(i); if(c<32||c>126) throw new Error('Code 128 AUTO chỉ hỗ trợ ASCII 32–126. Ký tự lỗi ở vị trí '+String(i+1)+'.'); } }
    function ANP_v14641Code128AutoValues(text){
        text=String(text==null?'':text); if(!text.length) throw new Error('Code 128 rỗng.'); ANP_v14641AssertAscii(text);
        var vals=[], current, i=0, run, ch, sum, p;
        run=ANP_v14641DigitRun(text,0);
        if(run>=4 && run%2===0){ vals.push(105); current='C'; } else { vals.push(104); current='B'; }
        while(i<text.length){
            if(current==='C'){
                run=ANP_v14641DigitRun(text,i);
                if(run>=2){ vals.push(Number(text.substr(i,2))); i+=2; continue; }
                vals.push(100); current='B'; continue;
            }
            run=ANP_v14641DigitRun(text,i);
            if(run>=4){ if(run%2===1){ ch=text.charCodeAt(i); vals.push(ch-32); i+=1; continue; } vals.push(99); current='C'; continue; }
            ch=text.charCodeAt(i); vals.push(ch-32); i+=1;
        }
        sum=vals[0]; for(p=1;p<vals.length;p++) sum+=vals[p]*p; vals.push(sum%103); vals.push(106); return vals;
    }
    function ANP_v14641DetectEncoding(text){ text=String(text==null?'':text); if(/^\d+$/.test(text)&&text.length>=2&&text.length%2===0) return 'Code128-C'; if(/\d{4,}/.test(text)) return 'Code128 AUTO (B/C)'; return 'Code128-B'; }
    function ANP_v14641DrawCode128(doc,item,text,token,mapping){
        var st=ANP_v14641Style(mapping), vals=ANP_v14641Code128AutoValues(text), seq=[], i,j,p,total=0,
            b=ANP_v14641Bounds(item), w=b[2]-b[0], h=b[1]-b[3], quiet=st.quietZone,
            name='DPV_V14641_C128_'+String(token), g, x, unit, rect, bar=true, codeW, textZone=0, gap=ANP_v14641Mm(st.textGapMm), barH, top;
        if(!(w>0&&h>0)) throw new Error('Code 128: khung giữ chỗ không hợp lệ.');
        for(i=0;i<vals.length;i++){ p=ANP_V14641_C128[vals[i]]; for(j=0;j<p.length;j++){ seq.push(Number(p.charAt(j))); total+=Number(p.charAt(j)); } }
        if(st.showText) textZone=Math.min(h*0.35, Math.max(st.fontSize*1.55, gap+st.fontSize*1.2));
        barH=(h-textZone)*st.barHeightPercent/100; if(barH>h-textZone) barH=h-textZone; if(!(barH>0)) throw new Error('Code 128: chiều cao khung quá thấp.');
        total+=quiet*2; codeW=w*st.barWidthPercent/100; if(codeW>w) codeW=w; unit=codeW/total; x=b[0]+(w-codeW)/2+quiet*unit; top=b[1];
        ANP_v14641Remove(doc,'DPV_V14641_C128_',token); ANP_v14641Remove(doc,'DPV_V1464_C128_',token); ANP_v14641Remove(doc,'DPV_V14633_C128_',token); ANP_v14641Remove(doc,'DPV_V14632_C128_',token); ANP_v14641Remove(doc,'DPV_V146_C128_',token);
        g=item.layer.groupItems.add(); g.name=name;
        rect=g.pathItems.rectangle(b[1],b[0],w,h); rect.filled=true; rect.fillColor=ANP_v14641White(); rect.stroked=false;
        for(i=0;i<seq.length;i++){ if(bar){ rect=g.pathItems.rectangle(top,x,seq[i]*unit,barH); rect.filled=true; rect.fillColor=ANP_v14641Black(); rect.stroked=false; } x+=seq[i]*unit; bar=!bar; }
        if(st.showText){ ANP_v14641AddText(doc,g,text,(b[0]+b[2])/2,b[3]+Math.max(0,gap*0.2),st); }
        try{ g.note='DPV V146.4.1 '+ANP_v14641DetectEncoding(text); }catch(eN){}
        try{ item.hidden=true; }catch(eH){}
        return true;
    }
    var ANP_V14641_EAN_L=["0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"];
    var ANP_V14641_EAN_G=["0100111","0110011","0011011","0100001","0011101","0111001","0000101","0010001","0001001","0010111"];
    var ANP_V14641_EAN_R=["1110010","1100110","1101100","1000010","1011100","1001110","1010000","1000100","1001000","1110100"];
    var ANP_V14641_EAN_PAR=["LLLLLL","LLGLGG","LLGGLG","LLGGGL","LGLLGG","LGGLLG","LGGGLL","LGLGLG","LGLGGL","LGGLGL"];
    function ANP_v14641EANCheck(s12){ var i,sum=0,n; if(!/^\d{12}$/.test(String(s12||''))) throw new Error('EAN-13 cần đúng 12 hoặc 13 chữ số.'); for(i=0;i<12;i++){ n=Number(s12.charAt(i)); sum += (i%2===0)?n:n*3; } return String((10-(sum%10))%10); }
    function ANP_v14641EAN(raw){ var s=String(raw==null?'':raw).replace(/^\s+|\s+$/g,''); if(!/^\d{12,13}$/.test(s)) throw new Error('EAN-13 chỉ nhận 12 hoặc 13 chữ số. Giá trị: '+s); if(s.length===12) return s+ANP_v14641EANCheck(s); var cd=ANP_v14641EANCheck(s.substr(0,12)); if(s.charAt(12)!==cd) throw new Error('EAN-13 sai checksum. Mã '+s+' phải có số kiểm tra cuối là '+cd+'.'); return s; }
    function ANP_v14641EANBits(ean){ var parity=ANP_V14641_EAN_PAR[Number(ean.charAt(0))], bits='101', i,d; for(i=1;i<=6;i++){ d=Number(ean.charAt(i)); bits += (parity.charAt(i-1)==='L' ? ANP_V14641_EAN_L[d] : ANP_V14641_EAN_G[d]); } bits+='01010'; for(i=7;i<=12;i++){ d=Number(ean.charAt(i)); bits += ANP_V14641_EAN_R[d]; } bits+='101'; return bits; }
    function ANP_v14641Guard(i){ return (i<=2)||(i>=45&&i<=49)||(i>=92); }
    function ANP_v14641DrawEAN13(doc,item,raw,token,mapping){
        var st=ANP_v14641Style(mapping), ean=ANP_v14641EAN(raw), bits=ANP_v14641EANBits(ean), b=ANP_v14641Bounds(item), w=b[2]-b[0], h=b[1]-b[3], quietL=Math.max(7,st.quietZone+1), quietR=Math.max(5,st.quietZone-3), total=95+quietL+quietR,
            codeW=w*st.barWidthPercent/100, unit, startX, textZone=0, gap=ANP_v14641Mm(st.textGapMm), barH, guardH, name='DPV_V14641_EAN13_'+String(token), g,bg,i,x,run,runStart,rect,textBottom;
        if(!(w>0&&h>0)) throw new Error('EAN-13: khung giữ chỗ không hợp lệ.'); if(codeW>w) codeW=w; unit=codeW/total; startX=b[0]+(w-codeW)/2+quietL*unit;
        if(st.showText) textZone=Math.min(h*0.34, Math.max(st.fontSize*1.65, gap+st.fontSize*1.25));
        barH=(h-textZone)*st.barHeightPercent/100; if(barH>h-textZone) barH=h-textZone; if(!(barH>0)) throw new Error('EAN-13: chiều cao khung quá thấp.'); guardH=Math.min(h-textZone*0.4, barH+Math.max(unit*5, textZone*0.25));
        ANP_v14641Remove(doc,'DPV_V14641_EAN13_',token); ANP_v14641Remove(doc,'DPV_V14633_EAN13_',token); ANP_v14641Remove(doc,'DPV_V14632_EAN13_',token); ANP_v14641Remove(doc,'DPV_V1461_EAN13_',token);
        g=item.layer.groupItems.add(); g.name=name; bg=g.pathItems.rectangle(b[1],b[0],w,h); bg.filled=true; bg.fillColor=ANP_v14641White(); bg.stroked=false;
        i=0; while(i<95){ if(bits.charAt(i)!=='1'){ i++; continue; } runStart=i; run=1; while(i+run<95 && bits.charAt(i+run)==='1' && ANP_v14641Guard(i+run)===ANP_v14641Guard(runStart)) run++; x=startX+runStart*unit; rect=g.pathItems.rectangle(b[1],x,run*unit,ANP_v14641Guard(runStart)?guardH:barH); rect.filled=true; rect.fillColor=ANP_v14641Black(); rect.stroked=false; i+=run; }
        if(st.showText){ textBottom=b[1]-barH-gap; ANP_v14641AddText(doc,g,ean.charAt(0),startX-unit*5.2,textBottom,st); ANP_v14641AddText(doc,g,ean.substr(1,6),startX+24*unit,textBottom,st); ANP_v14641AddText(doc,g,ean.substr(7,6),startX+71*unit,textBottom,st); }
        try{ item.hidden=true; }catch(e0){}
        return true;
    }
    ANP_vdpApplyOneV71 = function(doc,mapping,record,sourceFolder){
        var action=String(mapping&&mapping.action||''), field=String(mapping&&mapping.field||''), item, value, text, token;
        if(!ANP_v14641IsCode(action)) return ANP_V14641_PREV_ONE(doc,mapping,record,sourceFolder);
        token=String(mapping.targetId||''); item=ANP_vdpFindByTokenV71(doc,token);
        if(!item) throw new Error('Không tìm thấy target barcode trong work-copy: '+String(mapping.label||token||'Barcode'));
        if(!field) throw new Error('Mapping barcode chưa chọn cột dữ liệu: '+String(mapping.label||token||'Barcode'));
        value=record&&record[field]!==undefined?record[field]:''; text=String(mapping.prefix||'')+String(value==null?'':value)+String(mapping.suffix||'');
        if(action==='code128Vector') return ANP_v14641DrawCode128(doc,item,text,token,mapping)===true;
        if(action==='ean13Vector') return ANP_v14641DrawEAN13(doc,item,text,token,mapping)===true;
        return ANP_V14641_PREV_ONE(doc,mapping,record,sourceFolder);
    };
    ANP_vdpApplyRecordV71 = function(doc,mappings,record,sourceFolder,skipRedraw){
        var i,m,has=false,applied=0; mappings=mappings||[];
        for(i=0;i<mappings.length;i++){ if(ANP_v14641IsCode(mappings[i]&&mappings[i].action)){ has=true; break; } }
        if(!has) return ANP_V14641_PREV_RECORD(doc,mappings,record,sourceFolder,skipRedraw);
        for(i=0;i<mappings.length;i++){ m=mappings[i]||{}; try{ if(ANP_vdpApplyOneV71(doc,m,record,sourceFolder)) applied++; } catch(eMap){ throw new Error('Kênh '+String(m.label||m.field||String(i+1))+': '+String(eMap&&eMap.message?eMap.message:eMap)); } }
        if(!skipRedraw){ try{ app.redraw(); }catch(eR){} }
        return applied;
    };
})();
/* ===== END DPV V146.4.1 BARCODE TEXT VISIBILITY + FONT SAFE ===== */

/* ===== DPV V146.4.2 BARCODE FONT PICKER + ALIGN SAFE - APPEND ONLY =====
   Adds Code128 human-readable text alignment (left/center/right).
   Font name, pt size, tracking, live/outline continue through barcodeStyle.
   This wrapper is intentionally unguarded for Illustrator persistent targetengine safety.
*/
(function(){
    if (typeof ANP_vdpApplyOneV71 !== "function" || typeof ANP_vdpApplyRecordV71 !== "function") { return; }
    var ANP_V14642_PREV_ONE = ANP_vdpApplyOneV71;
    var ANP_V14642_PREV_RECORD = ANP_vdpApplyRecordV71;
    function ANP_v14642Black(){var c=new CMYKColor();c.cyan=0;c.magenta=0;c.yellow=0;c.black=100;return c;}
    function ANP_v14642White(){var c=new GrayColor();c.gray=0;return c;}
    function ANP_v14642Mm(mm){return Number(mm||0)*2.834645669291339;}
    function ANP_v14642Bounds(item){var b=item.visibleBounds||item.geometricBounds;return [Number(b[0]),Number(b[1]),Number(b[2]),Number(b[3])];}
    function ANP_v14642Remove(doc,prefix,token){var i,g,n=String(prefix||"")+String(token||"");try{for(i=doc.groupItems.length-1;i>=0;i--){g=doc.groupItems[i];if(String(g.name||"")===n){try{g.remove();}catch(e0){}}}}catch(e1){}}
    function ANP_v14642Style(mapping){
        var s=mapping&&mapping.barcodeStyle?mapping.barcodeStyle:{};
        return {
            showText:!(Number(s.showText)===0||s.showText===false),fontName:String(s.fontName||"Arial"),fontSize:Math.max(4,Number(s.fontSize)||9),tracking:Number(s.tracking)||0,
            textGapMm:(isNaN(Number(s.textGapMm))?1.2:Math.max(0,Number(s.textGapMm))),barHeightPercent:Math.max(40,Math.min(200,Number(s.barHeightPercent)||100)),barWidthPercent:Math.max(60,Math.min(140,Number(s.barWidthPercent)||100)),quietZone:Math.max(2,Math.min(20,Math.round(Number(s.quietZone)||10))),
            fontWeight:String(s.fontWeight||"regular"),textMode:String(s.textMode||"outline"),textAlign:String(s.textAlign||"center")
        };
    }
    function ANP_v14642FindFont(name,weight){var i,f,n=String(name||""),wantBold=String(weight||"")==="bold",fn,ff;if(!n)return null;try{return app.textFonts.getByName(n);}catch(e0){}try{for(i=0;i<app.textFonts.length;i++){f=app.textFonts[i];fn=String(f.name||"");ff=String(f.family||"");if(fn===n||ff===n||fn.toLowerCase()===n.toLowerCase()||ff.toLowerCase()===n.toLowerCase()){if(!wantBold||/bold|semibold|demi/i.test(fn))return f;}}if(wantBold){for(i=0;i<app.textFonts.length;i++){f=app.textFonts[i];fn=String(f.name||"");ff=String(f.family||"");if((ff===n||ff.toLowerCase()===n.toLowerCase())&&/bold|semibold|demi/i.test(fn))return f;}}}catch(e1){}return null;}
    function ANP_v14642PaintBlack(item){var i;try{item.filled=true;item.fillColor=ANP_v14642Black();}catch(e0){}try{item.stroked=false;}catch(e1){}try{if(item.pathItems){for(i=0;i<item.pathItems.length;i++)ANP_v14642PaintBlack(item.pathItems[i]);}}catch(e2){}try{if(item.compoundPathItems){for(i=0;i<item.compoundPathItems.length;i++)ANP_v14642PaintBlack(item.compoundPathItems[i]);}}catch(e3){}try{if(item.groupItems){for(i=0;i<item.groupItems.length;i++)ANP_v14642PaintBlack(item.groupItems[i]);}}catch(e4){}return true;}
    function ANP_v14642AddText(doc,g,text,leftX,centerX,rightX,targetTop,style){
        var tf=null,o=null,gb,dx,dy,font,anchor=String(style.textAlign||"center"),x=centerX,just=Justification.CENTER;
        if(!style.showText)return true;
        if(anchor==="left"){x=leftX;just=Justification.LEFT;}else if(anchor==="right"){x=rightX;just=Justification.RIGHT;}
        try{
            tf=doc.textFrames.pointText([0,0]);tf.contents=String(text==null?"":text);
            try{tf.textRange.characterAttributes.size=style.fontSize;}catch(e0){}
            try{tf.textRange.characterAttributes.tracking=style.tracking;}catch(e1){}
            try{tf.textRange.characterAttributes.fillColor=ANP_v14642Black();}catch(e2){}
            font=ANP_v14642FindFont(style.fontName,style.fontWeight);if(font){try{tf.textRange.characterAttributes.textFont=font;}catch(e3){}}
            try{tf.paragraphs[0].paragraphAttributes.justification=just;}catch(e4){}
            if(style.textMode==="live"){
                try{tf.move(g,ElementPlacement.PLACEATEND);}catch(e6){}
                try{gb=tf.geometricBounds;if(anchor==="left")dx=leftX-Number(gb[0]);else if(anchor==="right")dx=rightX-Number(gb[2]);else dx=centerX-((Number(gb[0])+Number(gb[2]))/2);dy=targetTop-Number(gb[1]);tf.translate(dx,dy);}catch(e5){}
                ANP_v14642PaintBlack(tf);try{tf.zOrder(ZOrderMethod.BRINGTOFRONT);}catch(e7){}return true;
            }
            o=tf.createOutline();ANP_v14642PaintBlack(o);gb=o.geometricBounds;
            if(anchor==="left")dx=leftX-Number(gb[0]);else if(anchor==="right")dx=rightX-Number(gb[2]);else dx=centerX-((Number(gb[0])+Number(gb[2]))/2);
            dy=targetTop-Number(gb[1]);try{o.translate(dx,dy);}catch(e8){try{o.left=Number(o.left)+dx;o.top=Number(o.top)+dy;}catch(e9){}}
            try{o.move(g,ElementPlacement.PLACEATEND);}catch(e10){}try{o.zOrder(ZOrderMethod.BRINGTOFRONT);}catch(e11){}return true;
        }catch(e){try{if(tf)tf.remove();}catch(e12){}return false;}
    }
    var ANP_V14642_C128=["212222","222122","222221","121223","121322","131222","122213","122312","132212","221213","221312","231212","112232","122132","122231","113222","123122","123221","223211","221132","221231","213212","223112","312131","311222","321122","321221","312212","322112","322211","212123","212321","232121","111323","131123","131321","112313","132113","132311","211313","231113","231311","112133","112331","132131","113123","113321","133121","313121","211331","231131","213113","213311","213131","311123","311321","331121","312113","312311","332111","314111","221411","431111","111224","111422","121124","121421","141122","141221","112214","112412","122114","122411","142112","142211","241211","221114","413111","241112","134111","111242","121142","121241","114212","124112","124211","411212","421112","421211","212141","214121","412121","111143","111341","131141","114113","114311","411113","411311","113141","114131","311141","411131","211412","211214","211232","2331112"];
    function ANP_v14642DigitRun(s,i){var n=0;while(i+n<s.length&&/\d/.test(s.charAt(i+n)))n++;return n;}
    function ANP_v14642AssertAscii(text){var i,c;for(i=0;i<text.length;i++){c=text.charCodeAt(i);if(c<32||c>126)throw new Error("Code 128 AUTO chỉ hỗ trợ ASCII 32–126. Ký tự lỗi ở vị trí "+String(i+1)+".");}}
    function ANP_v14642Values(text){
        text=String(text==null?"":text);if(!text.length)throw new Error("Code 128 rỗng.");ANP_v14642AssertAscii(text);
        var vals=[],current,i=0,run,ch,sum,p;run=ANP_v14642DigitRun(text,0);if(run>=4&&run%2===0){vals.push(105);current="C";}else{vals.push(104);current="B";}
        while(i<text.length){if(current==="C"){run=ANP_v14642DigitRun(text,i);if(run>=2){vals.push(Number(text.substr(i,2)));i+=2;continue;}vals.push(100);current="B";continue;}run=ANP_v14642DigitRun(text,i);if(run>=4){if(run%2===1){ch=text.charCodeAt(i);vals.push(ch-32);i++;continue;}vals.push(99);current="C";continue;}ch=text.charCodeAt(i);vals.push(ch-32);i++;}
        sum=vals[0];for(p=1;p<vals.length;p++)sum+=vals[p]*p;vals.push(sum%103);vals.push(106);return vals;
    }
    function ANP_v14642Encoding(text){text=String(text==null?"":text);if(/^\d+$/.test(text)&&text.length>=2&&text.length%2===0)return "Code128-C";if(/\d{4,}/.test(text))return "Code128 AUTO (B/C)";return "Code128-B";}
    function ANP_v14642Draw(doc,item,text,token,mapping){
        var st=ANP_v14642Style(mapping),vals=ANP_v14642Values(text),seq=[],i,j,p,total=0,b=ANP_v14642Bounds(item),w=b[2]-b[0],h=b[1]-b[3],quiet=st.quietZone,
            name="DPV_V14642_C128_"+String(token),g,x,unit,rect,bar=true,codeW,textZone=0,gap=ANP_v14642Mm(st.textGapMm),barH,top,codeLeft,codeRight;
        if(!(w>0&&h>0))throw new Error("Code 128: khung giữ chỗ không hợp lệ.");for(i=0;i<vals.length;i++){p=ANP_V14642_C128[vals[i]];for(j=0;j<p.length;j++){seq.push(Number(p.charAt(j)));total+=Number(p.charAt(j));}}
        if(st.showText)textZone=Math.min(h*0.35,Math.max(st.fontSize*1.55,gap+st.fontSize*1.2));barH=(h-textZone)*st.barHeightPercent/100;if(barH>h-textZone)barH=h-textZone;if(!(barH>0))throw new Error("Code 128: chiều cao khung quá thấp.");
        total+=quiet*2;codeW=w*st.barWidthPercent/100;if(codeW>w)codeW=w;unit=codeW/total;codeLeft=b[0]+(w-codeW)/2;codeRight=codeLeft+codeW;x=codeLeft+quiet*unit;top=b[1];
        ANP_v14642Remove(doc,"DPV_V14642_C128_",token);ANP_v14642Remove(doc,"DPV_V14641_C128_",token);ANP_v14642Remove(doc,"DPV_V1464_C128_",token);ANP_v14642Remove(doc,"DPV_V14633_C128_",token);ANP_v14642Remove(doc,"DPV_V14632_C128_",token);ANP_v14642Remove(doc,"DPV_V146_C128_",token);
        g=item.layer.groupItems.add();g.name=name;rect=g.pathItems.rectangle(b[1],b[0],w,h);rect.filled=true;rect.fillColor=ANP_v14642White();rect.stroked=false;
        for(i=0;i<seq.length;i++){if(bar){rect=g.pathItems.rectangle(top,x,seq[i]*unit,barH);rect.filled=true;rect.fillColor=ANP_v14642Black();rect.stroked=false;}x+=seq[i]*unit;bar=!bar;}
        if(st.showText)ANP_v14642AddText(doc,g,text,codeLeft,(codeLeft+codeRight)/2,codeRight,b[1]-barH-gap,st);
        try{g.note="DPV V146.4.2 "+ANP_v14642Encoding(text)+" · "+st.fontName+" · "+st.fontSize+"pt · align="+st.textAlign;}catch(eN){}try{item.hidden=true;}catch(eH){}return true;
    }
    ANP_vdpApplyOneV71=function(doc,mapping,record,sourceFolder){
        var action=String(mapping&&mapping.action||""),field=String(mapping&&mapping.field||""),item,value,text,token;
        if(action!=="code128Vector")return ANP_V14642_PREV_ONE(doc,mapping,record,sourceFolder);
        token=String(mapping.targetId||"");item=ANP_vdpFindByTokenV71(doc,token);if(!item)throw new Error("Không tìm thấy target barcode trong work-copy: "+String(mapping.label||token||"Barcode"));if(!field)throw new Error("Mapping barcode chưa chọn cột dữ liệu.");
        value=record&&record[field]!==undefined?record[field]:"";text=String(mapping.prefix||"")+String(value==null?"":value)+String(mapping.suffix||"");return ANP_v14642Draw(doc,item,text,token,mapping)===true;
    };
    ANP_vdpApplyRecordV71=function(doc,mappings,record,sourceFolder,skipRedraw){var i,m,has=false,applied=0;mappings=mappings||[];for(i=0;i<mappings.length;i++){if(String(mappings[i]&&mappings[i].action||"")==="code128Vector"){has=true;break;}}if(!has)return ANP_V14642_PREV_RECORD(doc,mappings,record,sourceFolder,skipRedraw);for(i=0;i<mappings.length;i++){m=mappings[i]||{};try{if(ANP_vdpApplyOneV71(doc,m,record,sourceFolder))applied++;}catch(eMap){throw new Error("Kênh "+String(m.label||m.field||String(i+1))+": "+String(eMap&&eMap.message?eMap.message:eMap));}}if(!skipRedraw){try{app.redraw();}catch(eR){}}return applied;};
})();
/* ===== END DPV V146.4.2 BARCODE FONT PICKER + ALIGN SAFE ===== */


/* ===== DPV V147.2 MULTI ARTBOARD DIE RECOGNITION SAFE - APPEND ONLY =====
   Root fix:
   V146.4.3 incorrectly treated a detected dieline as fallback whenever its bounds
   did not match the artboard rectangle. A real KHUON_BE can be inset/rounded and
   therefore SHOULD NOT match the artboard bounds. That stale dieFallback flag made
   ANP_v12Build forceArtboardDie=true, so the real red dieline was not removed from
   PRINT artwork.

   V147.2 separates two concepts:
   - source width/height still always come from artboardRect (stable behavior)
   - dieFallback is true ONLY when no KHUON_BE/die was actually detected
*/
function ANP_listArtboardsV12(hint) {
    try {
        if (!app.documents.length) { throw new Error("Chưa mở file nhiều artboard trong Illustrator."); }
        var doc = app.activeDocument, list = [], i, die, b, a, fallback, shape, artboardRect, hasDie;
        for (i = 0; i < doc.artboards.length; i++) {
            a = doc.artboards[i]; artboardRect = a.artboardRect;
            die = ANP_dieForArtboard(doc, i, hint || "");
            b = ANP_bounds(die);
            hasDie = !!(die && die.length && b);
            fallback = !hasDie;

            /* V147.2 CRITICAL:
               Width/height are artboard dimensions, but shape/die identity is independent.
               A rounded/inset KHUON_BE must still be considered a valid die. */
            shape = hasDie ? ANP_shapeFromDieV20(die, b) : ANP_shapeFromDieV20([], artboardRect);
            list.push({
                artboardIndex: i,
                displayIndex: i + 1,
                name: a.name || ("Artboard " + (i + 1)),
                width: ANP_round(ANP_toMm(artboardRect[2] - artboardRect[0]), 2),
                height: ANP_round(ANP_toMm(artboardRect[1] - artboardRect[3]), 2),
                dieFallback: fallback,
                dieDetected: hasDie,
                dieCount: die ? die.length : 0,
                useArtboardBounds: true,
                selected: true,
                shape: shape
            });
        }
        return ANP_ok({ documentName: doc.name, artboards: list, multiArtboardDieFix:"V147.2" });
    } catch (e) { return ANP_fail(e); }
}
/* ===== END DPV V147.2 MULTI ARTBOARD DIE RECOGNITION SAFE ===== */


/* ===== DPV V147.3 MULTI ARTBOARD TEXT FIDELITY SAFE - APPEND ONLY =====
   Root issue:
   Multi-artboard simple vector/text files could enter V97 simple-source fast path.
   Cross-document duplicate + resize may corrupt AreaText/text matrices in some AI files,
   producing oversized/repeated glyphs in PRINT-LINK.
   Fix: for multi-artboard sources, force the existing V5.3 Fidelity AI-copy path.
   Old single-source jobs remain untouched.
*/
(function(){
    if (typeof ANP_createLinkPair !== "function") { return; }
    var ANP_V1473_PREV_CREATE_LINK_PAIR = ANP_createLinkPair;
    function ANP_v1473CloneCfg(cfg){
        var out={},k; cfg=cfg||{};
        for(k in cfg){ try{ if(cfg.hasOwnProperty(k)) out[k]=cfg[k]; }catch(e0){} }
        return out;
    }
    function ANP_v1473HasTextOnArtboard(doc,idx){
        var i,t,b,a;
        try{ a=doc.artboards[idx].artboardRect; }catch(e0){ return false; }
        try{
            for(i=0;i<doc.textFrames.length;i++){
                t=doc.textFrames[i];
                try{ if(t.hidden===true) continue; }catch(eH){}
                try{ b=t.geometricBounds; if(ANP_intersects(b,a)) return true; }catch(eB){}
            }
        }catch(e1){}
        return false;
    }
    ANP_createLinkPair = function(sourceDoc,meta,cfg,linkFolder){
        var isMulti=false, idx=-1, hasText=false, c2;
        try{
            isMulti = !!(meta && meta.artboardIndex !== undefined && meta.useArtboardBounds === true && sourceDoc && sourceDoc.artboards && sourceDoc.artboards.length > 1);
            idx = isMulti ? Number(meta.artboardIndex) : -1;
            if(isMulti && (idx<0 || idx>=sourceDoc.artboards.length)) idx=sourceDoc.artboards.getActiveArtboardIndex();
            hasText = isMulti ? ANP_v1473HasTextOnArtboard(sourceDoc,idx) : false;
        }catch(e0){ isMulti=false; }
        if(!isMulti){ return ANP_V1473_PREV_CREATE_LINK_PAIR(sourceDoc,meta,cfg,linkFolder); }

        /* Always force fidelity for multi-artboard. Text files are the critical case,
           but this also protects clipping/live appearance and avoids artboard cross-talk. */
        c2 = ANP_v1473CloneCfg(cfg);
        c2.fastMode = false;
        try{ meta._multiArtboardFidelityV1473 = true; meta._multiArtboardHasTextV1473 = hasText; }catch(eM){}

        /* V148.9.2 PDF + AI TEXT FIDELITY:
           - AI: giữ Fidelity copy nguyên file như trước; nếu có thay đổi chưa Save thì DPV tự Save.
           - PDF: KHÔNG bắt Save As .AI. DPV render riêng artboard đang dàn thành một PDF fidelity
             tạm từ trạng thái đang mở, bỏ KHUON_BE/PON khỏi bản in rồi dùng PDF đó làm PRINT-LINK.
           Nhờ vậy cùng một workflow Multi Artboard chạy được cả file .AI và .PDF có TextFrame. */
        try{
            var sourceFileV1492 = null, sourceNameV1492 = "", sourceExtV1492 = "", autoSavedV1492 = false;
            try{ sourceFileV1492 = sourceDoc.fullName; }catch(eFullV1492){ sourceFileV1492 = null; }
            try{ sourceNameV1492 = sourceFileV1492 ? String(sourceFileV1492.name||"") : ""; }catch(eNameV1492){ sourceNameV1492 = ""; }
            try{ sourceExtV1492 = sourceNameV1492.toLowerCase(); }catch(eExtV1492){ sourceExtV1492 = ""; }

            if(/\.pdf$/i.test(sourceExtV1492)){
                c2._pdfFidelityV1492 = true;
                try{ meta._multiArtboardPdfFidelityV1492 = true; }catch(eMetaPdf1492){}
            }else if(hasText){
                if(!sourceFileV1492 || !sourceFileV1492.exists || !/\.ai$/i.test(sourceNameV1492)){
                    throw new Error("Multi Artboard có TextFrame: DPV hỗ trợ trực tiếp file .AI và .PDF. File hiện tại chưa có đường dẫn AI/PDF hợp lệ. Hãy Save As .AI hoặc mở trực tiếp file PDF rồi chạy lại.");
                }
                if(sourceDoc.saved !== true){
                    try{
                        sourceDoc.save();
                        autoSavedV1492 = true;
                    }catch(eSaveV1492){
                        throw new Error("DPV không thể tự Save file AI trước khi dàn: " + String(eSaveV1492) + ". Hãy kiểm tra quyền ghi file rồi thử lại.");
                    }
                }
                try{ meta._multiArtboardAutoSavedV1492 = autoSavedV1492; }catch(eMetaV1492){}
            }
        }catch(eCheck){
            if(hasText) throw eCheck;
        }
        return ANP_V1473_PREV_CREATE_LINK_PAIR(sourceDoc,meta,c2,linkFolder);
    };
})();
/* ===== END DPV V147.3 MULTI ARTBOARD TEXT FIDELITY SAFE ===== */

/* ===== DPV V148.9.2 MULTI ARTBOARD PDF + AI FIDELITY =====
   PDF mở trong Illustrator có thể sinh TextFrame nhưng không có đường dẫn .AI.
   Thay vì bắt người dùng Save As AI, DPV clone trạng thái document đang mở,
   bỏ dieline/PON, crop đúng artboard + bleed rồi xuất một PDF 1 trang làm PRINT-LINK.
   File AI vẫn đi Fidelity AI-copy cũ để giữ appearance tối đa. */
(function(){
    if (typeof ANP_makeFidelityPrintSourceV52 !== "function") { return; }
    var ANP_V1492_PREV_FIDELITY = ANP_makeFidelityPrintSourceV52;

    function ANP_makePdfFidelityPrintSourceV1492(sourceDoc, meta, cfg, dieBounds, dieItems, linkFolder, base){
        var workDoc=null,target=null,activeIndex=0,bleedPt=0,artboardBounds=null,cropRect=null,signatures=null;
        try{
            if(!sourceDoc || !cfg || cfg._pdfFidelityV1492 !== true){ return null; }
            activeIndex=(meta&&meta.artboardIndex!==undefined)?Number(meta.artboardIndex):sourceDoc.artboards.getActiveArtboardIndex();
            if(activeIndex<0 || activeIndex>=sourceDoc.artboards.length){ activeIndex=sourceDoc.artboards.getActiveArtboardIndex(); }
            bleedPt=ANP_mm(Math.max(0,Number(cfg.linkBleed)||0));
            artboardBounds=sourceDoc.artboards[activeIndex].artboardRect;
            cropRect=ANP_printCropBoundsV64(meta,artboardBounds,dieBounds,bleedPt);
            signatures=ANP_makeDieSignaturesV52(dieItems||[]);

            /* Clone 1:1 từ document đang mở để lấy luôn các chỉnh sửa hiện tại của PDF,
               không thay path/tên document của người dùng. */
            workDoc=ANP_vdpCloneDocumentV72(sourceDoc);
            if(!workDoc){ return null; }
            try{ workDoc.artboards.setActiveArtboardIndex(Math.min(activeIndex,workDoc.artboards.length-1)); }catch(eA){}
            ANP_removeGeneratedPonLayersV52(workDoc);
            ANP_removeDieOnlyFromFidelityCopyV53(workDoc,cfg.dieHint||"",signatures);
            ANP_keepOnlyFidelityArtboardV52(workDoc,Math.min(activeIndex,workDoc.artboards.length-1),cropRect);

            target=new File(linkFolder.fsName+"/"+base+"_PRINT-FIDELITY.pdf");
            if(target.exists){ try{ target.remove(); }catch(eRm){} }
            ANP_savePDFRangeV76(workDoc,target,"1",cfg.preservePrintColor!==false);
            try{ workDoc.close(SaveOptions.DONOTSAVECHANGES); }catch(eC){}
            workDoc=null;
            if(!target.exists){ return null; }
            return {file:target,padding:Number(cfg.linkBleed)||0,fidelity:true,pdfFidelity:true};
        }catch(e){
            try{ if(workDoc){ workDoc.close(SaveOptions.DONOTSAVECHANGES); } }catch(e0){}
            try{ if(target&&target.exists){ target.remove(); } }catch(e1){}
            return null;
        }
    }

    ANP_makeFidelityPrintSourceV52=function(sourceDoc,meta,cfg,dieBounds,dieItems,linkFolder,base){
        var r=null;
        try{ r=ANP_V1492_PREV_FIDELITY(sourceDoc,meta,cfg,dieBounds,dieItems,linkFolder,base); }catch(e0){ r=null; }
        if(r){ return r; }
        if(cfg&&cfg._pdfFidelityV1492===true){
            r=ANP_makePdfFidelityPrintSourceV1492(sourceDoc,meta,cfg,dieBounds,dieItems,linkFolder,base);
            if(!r){ throw new Error("DPV không tạo được PDF Fidelity cho artboard PDF. Hãy kiểm tra file PDF có mở bình thường trong Illustrator và thử lại."); }
            return r;
        }
        return null;
    };
})();
/* ===== END DPV V148.9.2 MULTI ARTBOARD PDF + AI FIDELITY ===== */



/* ===== DPV V147.4 STANDALONE QR/BARCODE CREATE TO ILLUSTRATOR - APPEND ONLY =====
   Uses the already-stable PreviewVariableData bridge method.
   Does NOT require VDP data/mapping UI.
*/
(function(){
    if (typeof ANP_vdpPreviewV71 !== "function" || typeof ANP_vdpApplyOneV71 !== "function") { return; }
    var ANP_V1474_PREV_PREVIEW = ANP_vdpPreviewV71;
    function ANP_v1474Mm(v){ return Number(v||0)*2.834645669291339; }
    function ANP_v1474Token(item){
        var token="";
        try{ if(item&&item.uuid){ token="UUID:"+String(item.uuid); } }catch(e0){ token=""; }
        if(!token){ try{ token=ANP_vdpGetTokenV71(item); }catch(e1){ token=""; } }
        return token;
    }
    function ANP_v1474Action(t){
        t=String(t||"qr");
        if(t==="code128") return "code128Vector";
        if(t==="ean13") return "ean13Vector";
        return "qrVector";
    }
    function ANP_v1474Style(cfg){
        return {
            showText: !(Number(cfg.showText)===0 || cfg.showText===false),
            fontName:String(cfg.fontName||"Arial"),
            fontSize:Math.max(4,Number(cfg.fontSize)||9),
            tracking:Number(cfg.tracking)||0,
            textGapMm:(isNaN(Number(cfg.textGapMm))?1.2:Math.max(0,Number(cfg.textGapMm))),
            barHeightPercent:Math.max(40,Math.min(200,Number(cfg.barHeightPercent)||100)),
            barWidthPercent:Math.max(60,Math.min(140,Number(cfg.barWidthPercent)||100)),
            quietZone:Math.max(2,Math.min(20,Math.round(Number(cfg.quietZone)||10))),
            fontWeight:String(cfg.fontWeight||"regular"),
            textMode:String(cfg.textMode||"outline"),
            textAlign:String(cfg.textAlign||"center")
        };
    }
    function ANP_v1474MapFor(item,cfg){
        var token=ANP_v1474Token(item);
        if(!token) throw new Error("Không lấy được ID đối tượng giữ chỗ.");
        return { targetId:token, label:"Standalone Code", action:ANP_v1474Action(cfg.codeType), field:"VALUE", prefix:"", suffix:"", barcodeStyle:ANP_v1474Style(cfg) };
    }
    function ANP_v1474CreateOnItem(doc,item,value,cfg){
        var mapping=ANP_v1474MapFor(item,cfg), rec={VALUE:String(value==null?"":value)};
        if(!rec.VALUE) throw new Error("Nội dung mã đang trống.");
        if(ANP_vdpApplyOneV71(doc,mapping,rec,"")!==true) throw new Error("Engine không tạo được mã trên đối tượng đã chọn.");
        return true;
    }
    function ANP_v1474TempRect(doc,left,top,w,h){
        var layer=doc.activeLayer, r=layer.pathItems.rectangle(top,left,w,h);
        r.filled=false; r.stroked=false;
        return r;
    }
    function ANP_v1474ArtRect(doc){
        var idx=0, ab, r;
        try{ idx=doc.artboards.getActiveArtboardIndex(); }catch(e0){ idx=0; }
        ab=doc.artboards[idx]; r=ab.artboardRect;
        return [Number(r[0]),Number(r[1]),Number(r[2]),Number(r[3])];
    }
    function ANP_v1474CreateArtboard(doc,values,cfg){
        var ar=ANP_v1474ArtRect(doc), aw=ar[2]-ar[0], ah=ar[1]-ar[3],
            w=ANP_v1474Mm(Number(cfg.widthMm)||((cfg.codeType==="qr")?30:50)),
            h=ANP_v1474Mm(Number(cfg.heightMm)||((cfg.codeType==="qr")?30:20)),
            gap=ANP_v1474Mm(Number(cfg.gapMm)||5), margin=ANP_v1474Mm(5), cols=Math.max(1,Math.floor(Number(cfg.columns)||0)),
            autoCols=Math.max(1,Math.floor((aw-margin*2+gap)/(w+gap))), maxRows, maxCount, i,row,col,left,top,tmp,count=0;
        if(!(w>0&&h>0)) throw new Error("Kích thước mã không hợp lệ.");
        if(!cols) cols=autoCols; if(cols>autoCols) cols=autoCols;
        maxRows=Math.max(1,Math.floor((ah-margin*2+gap)/(h+gap))); maxCount=cols*maxRows;
        if(values.length>maxCount) throw new Error("Artboard chỉ đủ khoảng "+maxCount+" mã với kích thước hiện tại. Hãy giảm kích thước/gap hoặc tạo ít mã hơn.");
        for(i=0;i<values.length;i++){
            row=Math.floor(i/cols); col=i%cols;
            if(values.length===1){ left=ar[0]+(aw-w)/2; top=ar[1]-(ah-h)/2; }
            else { left=ar[0]+margin+col*(w+gap); top=ar[1]-margin-row*(h+gap); }
            tmp=ANP_v1474TempRect(doc,left,top,w,h);
            try{ ANP_v1474CreateOnItem(doc,tmp,values[i],cfg); count++; }
            finally{ try{ tmp.remove(); }catch(eR){} }
        }
        return count;
    }
    function ANP_v1474Standalone(cfg){
        if(!app.documents.length) throw new Error("Chưa mở tài liệu Illustrator.");
        var doc=app.activeDocument, vals=cfg.values||[], mode=String(cfg.targetMode||"selection"), sel=doc.selection||[], i,count=0;
        if(!vals.length && cfg.value!==undefined) vals=[cfg.value];
        if(!vals.length) throw new Error("Chưa nhập nội dung QR/Barcode.");
        if(mode==="selection"){
            if(!sel || !sel.length) throw new Error("Hãy chọn một shape/khung giữ chỗ trong Illustrator trước, hoặc đổi sang ‘Tạo ra giữa artboard’. ");
            if(vals.length>1 && sel.length<vals.length) throw new Error("Tạo batch vào selection cần ít nhất "+vals.length+" đối tượng đang chọn. Hoặc dùng chế độ ‘Tạo ra giữa artboard’. ");
            for(i=0;i<vals.length;i++){ ANP_v1474CreateOnItem(doc,sel[Math.min(i,sel.length-1)],vals[i],cfg); count++; }
        } else {
            count=ANP_v1474CreateArtboard(doc,vals,cfg);
        }
        try{ app.redraw(); }catch(eDraw){}
        return ANP_ok({standaloneV1474:true,created:count,codeType:String(cfg.codeType||"qr"),targetMode:mode,documentName:doc.name});
    }
    ANP_vdpPreviewV71=function(json){
        try{
            var cfg=eval("("+json+")");
            if(cfg && (cfg.standaloneV1474===true || String(cfg.standaloneV1474)==="true")) return ANP_v1474Standalone(cfg);
        }catch(eParse){ if(String(json||"").indexOf("standaloneV1474")>=0) return ANP_fail(eParse); }
        return ANP_V1474_PREV_PREVIEW(json);
    };
})();
/* ===== END DPV V147.4 STANDALONE CREATE TO ILLUSTRATOR ===== */

/* DPV V147.7.7 FULL FONT LIBRARY SAFE: ANP_v1475FontList now iterates ALL app.textFonts; no 2000-item truncation. */
/* ===== DPV V147.5 ILLUSTRATOR FONT LIST SAFE - APPEND ONLY =====
   Uses PreviewVariableData so no native bridge changes are required.
*/
(function(){
    if (typeof ANP_vdpPreviewV71 !== "function") { return; }
    var ANP_V1475_PREV_PREVIEW = ANP_vdpPreviewV71;
    function ANP_v1475FontList(){
        var arr=[],seen={},i,f,name,family,style,key;
        try{
            for(i=0;i<app.textFonts.length;i++){
                f=app.textFonts[i];
                name=String(f.name||"");family=String(f.family||name);style=String(f.style||"");
                if(!name) continue;
                key=name.toLowerCase(); if(seen[key]) continue; seen[key]=true;
                arr.push({name:name,family:family,style:style});
            }
        }catch(e){}
        arr.sort(function(a,b){var aa=String(a.family||a.name).toLowerCase(),bb=String(b.family||b.name).toLowerCase();if(aa<bb)return -1;if(aa>bb)return 1;return String(a.style||"").toLowerCase()<String(b.style||"").toLowerCase()?-1:1;});
        return arr;
    }
    ANP_vdpPreviewV71=function(json){
        try{
            var cfg=eval("("+json+")");
            if(cfg && (cfg.standaloneFontListV1475===true || String(cfg.standaloneFontListV1475)==="true")){
                return ANP_ok({standaloneFontListV1475:true,fonts:ANP_v1475FontList(),illustratorVersion:String(app.version||"")});
            }
        }catch(eParse){ if(String(json||"").indexOf("standaloneFontListV1475")>=0) return ANP_fail(eParse); }
        return ANP_V1475_PREV_PREVIEW(json);
    };
})();
/* ===== END DPV V147.5 ILLUSTRATOR FONT LIST SAFE ===== */


/* ===== DPV V147.6 TRUE DIE PREVIEW SAFE - APPEND ONLY =====
   Preview-only hotfix.
   Export/Build is intentionally untouched.
   Root cause: ANP_v14DiePreview could choose Fast Vector Preview from cached/group shape
   before using the real serialized KHUON_BE geometry. If the cached shape was polluted by
   artwork/text outlines, preview could show glyph contours although exported DIE was correct.
   V147.6 disables that fast-shape branch only while OpenDiePreview is executing, so the
   existing function falls through to dieGeometry (true KHUON_BE Bezier geometry) first.
*/
(function(){
    if (typeof ANP_v14DiePreview !== 'function' || typeof ANP_canFastVectorDieV22 !== 'function') { return; }
    var ANP_V1476_OLD_DIE_PREVIEW = ANP_v14DiePreview;
    var ANP_V1476_OLD_CAN_FAST_DIE = ANP_canFastVectorDieV22;
    var ANP_V1476_PREVIEW_ACTIVE = false;

    ANP_canFastVectorDieV22 = function(cfg, layout, shape){
        if (ANP_V1476_PREVIEW_ACTIVE === true) {
            /* Force OpenDiePreview to prefer real dieGeometry/template, never cached shape. */
            return false;
        }
        return ANP_V1476_OLD_CAN_FAST_DIE(cfg, layout, shape);
    };

    ANP_v14DiePreview = function(json){
        var result;
        ANP_V1476_PREVIEW_ACTIVE = true;
        try {
            result = ANP_V1476_OLD_DIE_PREVIEW(json);
        } finally {
            ANP_V1476_PREVIEW_ACTIVE = false;
        }
        return result;
    };
})();
/* ===== END DPV V147.6 TRUE DIE PREVIEW SAFE ===== */


/* ===== DPV V147.7.8 REMOTE FONT SEARCH SAFE - APPEND ONLY =====
   Search Illustrator app.textFonts on demand and return only small matching subsets.
   This avoids native bridge response-size limits that previously made a "FULL 2000" list incomplete.
*/
(function(){
    if(typeof ANP_vdpPreviewV71!=="function")return;
    var ANP_V14778_PREV=ANP_vdpPreviewV71;
    function ANP_v14778Norm(v){return String(v==null?"":v).toLowerCase().replace(/[\s_\-\.]+/g,"");}
    if(typeof ANP_V14779_FONT_INDEX==="undefined") ANP_V14779_FONT_INDEX=null;
    function ANP_v14779BuildIndex(force){
        var arr=[],i,f,name,family,style,total=0;
        if(!force && ANP_V14779_FONT_INDEX && ANP_V14779_FONT_INDEX.length) return ANP_V14779_FONT_INDEX;
        try{total=app.textFonts.length;}catch(e0){total=0;}
        for(i=0;i<total;i++){
            try{f=app.textFonts[i];name=String(f.name||"");family=String(f.family||name);style=String(f.style||"");}catch(e1){continue;}
            arr.push({name:name,family:family,style:style,hay:ANP_v14778Norm(family+" "+style+" "+name)});
        }
        ANP_V14779_FONT_INDEX=arr;
        return arr;
    }
    function ANP_v14778Search(q,limit,force){
        var out=[],i,it,nq=ANP_v14778Norm(q),matches=0,max=Math.max(1,Math.min(120,Number(limit)||80)),idx=ANP_v14779BuildIndex(force===true);
        for(i=0;i<idx.length;i++){
            it=idx[i];
            if(nq && it.hay.indexOf(nq)<0)continue;
            matches++;
            if(out.length<max)out.push({name:it.name,family:it.family,style:it.style});
        }
        return {fonts:out,total:idx.length,matches:matches,indexCached:true};
    }
    ANP_vdpPreviewV71=function(json){
        try{
            var cfg=eval("("+json+")");
            if(cfg&&(cfg.standaloneFontSearchV1478===true||String(cfg.standaloneFontSearchV1478)==="true")){
                var r=ANP_v14778Search(cfg.query||"",cfg.limit||80,cfg.rebuild===true||String(cfg.rebuild)==="true");
                return ANP_ok({standaloneFontSearchV1478:true,fonts:r.fonts,total:r.total,matches:r.matches,indexCached:r.indexCached===true,illustratorVersion:String(app.version||"")});
            }
        }catch(e){if(String(json||"").indexOf("standaloneFontSearchV1478")>=0)return ANP_fail(e);}
        return ANP_V14778_PREV(json);
    };
})();
/* ===== END DPV V147.7.8 REMOTE FONT SEARCH SAFE ===== */


/* ===== DPV V147.8 VDP TEXT TRACKING SAFE - APPEND ONLY =====
   Adds optional per-mapping textTracking override for VDP Text actions.
   null/blank => preserve original Illustrator tracking exactly.
   Numeric value => override tracking (Illustrator units: 1/1000 em).
   Other actions are delegated unchanged to the previous stable handler.
*/
(function(){
    if (typeof ANP_vdpApplyOneV71 !== "function") { return; }
    var ANP_V1478_PREV_APPLY_ONE = ANP_vdpApplyOneV71;
    function ANP_v1478CloneStyle(s){
        var o={},k; s=s||{};
        for(k in s){ try{ if(s.hasOwnProperty(k)) o[k]=s[k]; }catch(e0){} }
        return o;
    }
    function ANP_v1478HasTracking(mapping){
        if(!mapping) return false;
        if(mapping.textTracking===undefined || mapping.textTracking===null || String(mapping.textTracking)==="") return false;
        return !isNaN(Number(mapping.textTracking));
    }
    ANP_vdpApplyOneV71 = function(doc,mapping,record,sourceFolder){
        var action=String(mapping&&mapping.action||"text"), id, item, field, value, base, st, tracking;
        if(action!=="text" || !ANP_v1478HasTracking(mapping)){
            return ANP_V1478_PREV_APPLY_ONE(doc,mapping,record,sourceFolder);
        }
        id=String(mapping.targetId||"");
        field=String(mapping.field||"");
        item=ANP_vdpFindByTokenV71(doc,id);
        if(!item || !field) return false;
        if(String(item.typename)!=="TextFrame") throw new Error("Kênh Text không trỏ tới TextFrame: "+String(mapping.label||id));
        value=record&&record[field]!==undefined?record[field]:"";
        base=null;
        try{ base=ANP_VDP_TEXT_STYLE_CACHE_V137[id]||null; }catch(e1){ base=null; }
        if(!base){ try{ base=ANP_vdpCaptureTextStyleV137(item); }catch(e2){ base=null; } }
        st=ANP_v1478CloneStyle(base||{});
        tracking=Number(mapping.textTracking);
        if(tracking<-1000) tracking=-1000;
        if(tracking>10000) tracking=10000;
        st.tracking=tracking;
        ANP_vdpSetTextExactV137(item,String(mapping.prefix||"")+String(value==null?"":value)+String(mapping.suffix||""),st);
        return true;
    };
})();
/* ===== END DPV V147.8 VDP TEXT TRACKING SAFE ===== */

/* ===== DPV V147.8.1 DIE CONTOUR GUARD SAFE - APPEND ONLY =====
   Prevent internal red artwork/text/logo outlines from being inferred as KHUON_BE.
   Priority:
   1) directly named dieline contour
   2) clean closed stroke-only dieline contour (prefer outer/enclosing path)
   3) inherited named contour
   4) legacy fallback only if no safe contour exists
*/
(function(){
    if (typeof ANP_inferDieV33 !== "function") { return; }
    var ANP_V14781_LEGACY_INFER = ANP_inferDieV33;

    function ANP_v14781Bounds(item){
        try { return item.geometricBounds; } catch(e) { return null; }
    }

    function ANP_v14781Area(b){
        if (!b) { return 0; }
        return Math.max(0, Number(b[2])-Number(b[0])) * Math.max(0, Number(b[1])-Number(b[3]));
    }

    function ANP_v14781CleanStroke(item, hint){
        var i,p,seen=false;
        if (!item) { return false; }
        try {
            if (item.typename === "PathItem") {
                if (item.clipping === true || item.closed !== true || item.stroked !== true || item.filled === true) { return false; }
                return ANP_colorLooksDie(item.strokeColor, hint || "");
            }
            if (item.typename === "CompoundPathItem") {
                if (!item.pathItems || !item.pathItems.length) { return false; }
                for (i=0;i<item.pathItems.length;i++) {
                    p=item.pathItems[i];
                    if (p.clipping === true || p.closed !== true || p.stroked !== true || p.filled === true) { return false; }
                    if (!ANP_colorLooksDie(p.strokeColor, hint || "")) { return false; }
                    seen=true;
                }
                return seen;
            }
        } catch(e0) {}
        return false;
    }

    function ANP_v14781DirectNamed(item,hint){
        try {
            if (ANP_hasDieWord(item.name, hint || "") || ANP_hasDieWord(item.note, hint || "")) { return true; }
        } catch(e0) {}
        return false;
    }

    function ANP_v14781InheritedNamed(item,hint){
        var p;
        try {
            p=item.parent;
            if (p && p.typename !== "Layer" && ANP_hasDieWord(p.name, hint || "")) { return true; }
        } catch(e0) {}
        try { if (item.layer && ANP_hasDieWord(item.layer.name, hint || "")) { return true; } } catch(e1) {}
        return false;
    }

    function ANP_v14781EdgeScore(b,a){
        var tol,score=0;
        if (!b || !a) { return 0; }
        tol=ANP_mm(2.5);
        if (Math.abs(Number(b[0])-Number(a[0])) <= tol) { score++; }
        if (Math.abs(Number(b[1])-Number(a[1])) <= tol) { score++; }
        if (Math.abs(Number(b[2])-Number(a[2])) <= tol) { score++; }
        if (Math.abs(Number(b[3])-Number(a[3])) <= tol) { score++; }
        return score;
    }

    function ANP_v14781Choose(items,artRect,hint,mode){
        var i,item,b,area,artArea,rel,edge,nameW,poly,fillRatio,score,best=null,bestScore=-1e30;
        artArea=ANP_v14781Area(artRect); if (!(artArea>0)) { artArea=1; }
        for (i=0;i<items.length;i++) {
            item=items[i]; b=ANP_v14781Bounds(item); if (!b) { continue; }
            area=ANP_v14781Area(b); if (!(area>0)) { continue; }
            rel=area/artArea;
            nameW=ANP_dieNameWeightV33(item,hint||"");
            edge=ANP_v14781EdgeScore(b,artRect);

            if (mode === 1) {
                if (!ANP_v14781DirectNamed(item,hint)) { continue; }
            } else if (mode === 2) {
                if (!ANP_v14781CleanStroke(item,hint)) { continue; }
                /* A color-only automatic die must be meaningful in relation to the artboard.
                   This rejects small internal logos/letters/crop symbols. Named dies are exempt. */
                if (nameW < 2 && rel < 0.18 && edge < 2) { continue; }
            } else if (mode === 3) {
                if (!ANP_v14781InheritedNamed(item,hint)) { continue; }
            }

            poly=ANP_largestDiePolygonV20([item]);
            fillRatio=1;
            try { if (poly && poly.length>=3) { fillRatio=Math.abs(ANP_signedAreaV20(poly))/Math.max(0.0001,area); } } catch(ePoly) {}

            score = rel*1e10 + edge*3e10 + nameW*8e10;
            /* For actual dielines, stroke-only is a very strong signal. */
            if (ANP_v14781CleanStroke(item,hint)) { score += 2e11; }
            /* Prefer outer contour over tiny detailed/internal contour. */
            if (rel >= 0.55) { score += 8e10; }
            if (edge >= 3) { score += 1e11; }
            /* Do not reward filled logo glyphs merely because they are concave. */
            if (!ANP_v14781CleanStroke(item,hint) && nameW < 4 && fillRatio < 0.995) { score -= 5e10; }
            if (score > bestScore) { bestScore=score; best=item; }
        }
        return best;
    }

    ANP_inferDieV33 = function(sourceItems, artRect, hint){
        var vectors=[],i,best;
        sourceItems=sourceItems||[];
        for(i=0;i<sourceItems.length;i++){ ANP_collectAllVectors(sourceItems[i],vectors); }

        /* Directly named path is authoritative. */
        best=ANP_v14781Choose(vectors,artRect,hint||"",1);
        if (best) { return [best]; }

        /* Critical guard: if any clean red/spot stroke-only closed contour exists,
           choose ONLY within this safe class. Filled red artwork such as QC PASS/Q
           is not eligible in this pass. */
        best=ANP_v14781Choose(vectors,artRect,hint||"",2);
        if (best) { return [best]; }

        /* If a user deliberately groups/layers the die, honor that next. */
        best=ANP_v14781Choose(vectors,artRect,hint||"",3);
        if (best) { return [best]; }

        /* Legacy behavior only when the document provides no safe die signal. */
        return ANP_V14781_LEGACY_INFER(sourceItems,artRect,hint||"");
    };

    /* Compatibility alias used by older callers. */
    ANP_inferDieV32 = function(sourceItems, artRect){ return ANP_inferDieV33(sourceItems,artRect,"KHUON_BE"); };
})();
/* ===== END DPV V147.8.1 DIE CONTOUR GUARD SAFE ===== */

/* ===== DPV V149.1 NATIVE BATCH BRIDGE + GEOMETRY CACHE =====
   Mục tiêu:
   - Một lệnh Production (Preview / Die Preview / Build) prewarm toàn bộ geometry/layout
     cho các artboard được chọn ngay trong persistent Illustrator Bridge.
   - Cache KHUON_BE theo document + artboard + hint để tránh quét artwork lặp lại.
   - Cache layout theo shape + thông số dàn để Preview -> Build không chạy solver lần nữa.
   - Cache qua nhiều job CHỈ khi document đang Saved; file có thay đổi chưa Save chỉ cache
     trong đúng một operation để tuyệt đối không dùng geometry cũ.
   - Không đổi thuật toán dàn / fidelity / output; chỉ giảm đọc/quét/tính lặp.
*/
(function(){
    if (typeof ANP_dieForArtboard !== "function" ||
        typeof ANP_artboardLayoutV12 !== "function" ||
        typeof ANP_v12Preview !== "function" ||
        typeof ANP_v12Build !== "function") { return; }

    var PREV_DIE = ANP_dieForArtboard;
    var PREV_LAYOUT = ANP_artboardLayoutV12;
    var PREV_LIST = (typeof ANP_listArtboardsV12 === "function") ? ANP_listArtboardsV12 : null;
    var PREV_PREVIEW = ANP_v12Preview;
    var PREV_BUILD = ANP_v12Build;
    var PREV_DIE_PREVIEW = (typeof ANP_v14DiePreview === "function") ? ANP_v14DiePreview : null;

    if (typeof ANP_V1491_NATIVE_CACHE === "undefined" || !ANP_V1491_NATIVE_CACHE) {
        ANP_V1491_NATIVE_CACHE = {
            docRef:null, docKey:"", active:false, operation:"", operationSeq:0,
            dies:{}, dieOrder:[], layouts:{}, layoutOrder:[],
            cumulative:{dieHits:0,dieMisses:0,layoutHits:0,layoutMisses:0,resets:0},
            op:null
        };
    }

    function nowMs(){ return (new Date()).getTime(); }
    function boolSaved(doc){ try { return doc && doc.saved === true; } catch(e) { return false; } }
    function safe(v){ try { return String(v == null ? "" : v); } catch(e) { return ""; } }
    function round(v,n){ var p=Math.pow(10,n||3); return Math.round(Number(v||0)*p)/p; }
    function own(o,k){ try { return o && o.hasOwnProperty(k); } catch(e) { return false; } }

    function fileStamp(doc){
        var p="",m=0,f=null;
        try { if(doc && doc.fullName){ p=String(doc.fullName.fsName||doc.fullName); } } catch(e0) { p=""; }
        if(p){
            try { f=new File(p); if(f.exists && f.modified){ m=Number(f.modified.getTime ? f.modified.getTime() : f.modified); } } catch(e1) { m=0; }
        }
        return {path:p,modified:m};
    }

    function docKey(doc){
        var s=fileStamp(doc),name="",ab=0,pi=0,tf=0,pa=0,saved=boolSaved(doc);
        try{name=String(doc.name||"");}catch(e0){}
        try{ab=Number(doc.artboards.length||0);}catch(e1){}
        try{pi=Number(doc.pageItems.length||0);}catch(e2){}
        try{tf=Number(doc.textFrames.length||0);}catch(e3){}
        try{pa=Number(doc.pathItems.length||0);}catch(e4){}
        return s.path+"|"+s.modified+"|"+name+"|ab="+ab+"|pi="+pi+"|tf="+tf+"|pa="+pa+"|"+(saved?"S":"U");
    }

    function reset(doc,key,reason){
        var c=ANP_V1491_NATIVE_CACHE;
        c.docRef=doc||null; c.docKey=key||""; c.dies={}; c.dieOrder=[]; c.layouts={}; c.layoutOrder=[];
        c.cumulative.resets++;
        if(c.op){ c.op.resetReason=String(reason||"cache-reset"); }
    }

    function begin(doc,operation){
        var c=ANP_V1491_NATIVE_CACHE,k=docKey(doc),saved=boolSaved(doc),must=false,reason="";
        c.operationSeq++;
        c.op={operation:String(operation||"production"),seq:c.operationSeq,started:nowMs(),prewarmMs:0,
            dieHits:0,dieMisses:0,layoutHits:0,layoutMisses:0,prewarmDies:0,prewarmLayouts:0,
            resetReason:"",persistent:saved===true,warning:""};
        if(c.docRef!==doc){ must=true; reason="document-changed"; }
        else if(saved && c.docKey!==k){ must=true; reason="saved-document-signature-changed"; }
        else if(!saved){ must=true; reason="unsaved-operation-isolation"; }
        if(must){ reset(doc,k,reason); }
        c.docRef=doc; c.docKey=k; c.active=true; c.operation=String(operation||"");
        return c.op;
    }

    function end(doc){
        var c=ANP_V1491_NATIVE_CACHE;
        c.active=false; c.operation="";
        try { if(doc && boolSaved(doc)){ c.docKey=docKey(doc); c.docRef=doc; } } catch(e) {}
    }

    function ensureDirect(doc){
        var c=ANP_V1491_NATIVE_CACHE,k;
        if(c.active && c.docRef===doc){ return; }
        k=docKey(doc);
        if(c.docRef!==doc || !boolSaved(doc) || c.docKey!==k){ reset(doc,k,"direct-access-refresh"); }
        c.docRef=doc; c.docKey=k;
    }

    function artRectSig(doc,index){
        var a=null;
        try{a=doc.artboards[Number(index)].artboardRect;}catch(e){return "";}
        if(!a||a.length<4)return "";
        return [round(a[0],3),round(a[1],3),round(a[2],3),round(a[3],3)].join(",");
    }

    function dieKey(doc,index,hint){ return String(Number(index))+"|"+safe(hint).toLowerCase()+"|"+artRectSig(doc,index); }

    function validDieItems(items){
        var i,it,b;
        if(!items || typeof items.length==="undefined")return false;
        for(i=0;i<items.length;i++){
            try{it=items[i]; if(!it || !it.typename)return false; b=it.geometricBounds; if(!b || b.length<4)return false;}catch(e){return false;}
        }
        return true;
    }

    function shallowItems(items){ var out=[],i; if(!items)return out; for(i=0;i<items.length;i++)out.push(items[i]); return out; }

    function trimDieCache(){
        var c=ANP_V1491_NATIVE_CACHE,k;
        while(c.dieOrder.length>256){ k=c.dieOrder.shift(); try{delete c.dies[k];}catch(e){c.dies[k]=null;} }
    }

    ANP_dieForArtboard=function(doc,artboardIndex,hint){
        var c=ANP_V1491_NATIVE_CACHE,key,entry,r;
        ensureDirect(doc); key=dieKey(doc,artboardIndex,hint||""); entry=c.dies[key];
        if(entry && entry.items && validDieItems(entry.items)){
            c.cumulative.dieHits++; if(c.op)c.op.dieHits++;
            return shallowItems(entry.items);
        }
        if(entry){ try{delete c.dies[key];}catch(e0){c.dies[key]=null;} }
        c.cumulative.dieMisses++; if(c.op)c.op.dieMisses++;
        r=PREV_DIE(doc,artboardIndex,hint||"");
        c.dies[key]={items:shallowItems(r||[]),at:nowMs(),empty:!(r&&r.length)}; c.dieOrder.push(key); trimDieCache();
        return shallowItems(r||[]);
    };

    function clonePlain(v,depth){
        var i,k,o;
        if(depth>8)return v;
        if(v===null || v===undefined)return v;
        if(typeof v!=="object")return v;
        if(v instanceof Array){o=[];for(i=0;i<v.length;i++)o.push(clonePlain(v[i],depth+1));return o;}
        o={};
        for(k in v){ if(own(v,k)){ try{o[k]=clonePlain(v[k],depth+1);}catch(e){} } }
        return o;
    }

    function cfgValue(cfg,k){ var v; try{v=cfg[k];}catch(e){v="";} if(typeof v==="object")return ""; return safe(v); }
    function layoutKey(cfg,w,h,shape){
        var keys=["paperW","paperH","margin","header","gapX","gapY","maxQty","allowRotate","angleStep","fastMode","demiMode","uniformGap","trueShape","cornerClear","edgeRelax","lockGap","finishCropMarks"],
            a=[round(w,3),round(h,3),safe(shape&&shape.signature),safe(shape&&shape.isCircle),safe(shape&&shape.isRectangle)],i;
        for(i=0;i<keys.length;i++)a.push(keys[i]+"="+cfgValue(cfg||{},keys[i]));
        return a.join("|");
    }

    function validLayout(l){
        var i,it;
        if(!l || !l.items || typeof l.items.length==="undefined" || l.items.length<1)return false;
        for(i=0;i<l.items.length;i++){it=l.items[i];if(!it || !isFinite(Number(it.x)) || !isFinite(Number(it.y)) || !isFinite(Number(it.w)) || !isFinite(Number(it.h)))return false;}
        return true;
    }

    function trimLayoutCache(){
        var c=ANP_V1491_NATIVE_CACHE,k;
        while(c.layoutOrder.length>96){ k=c.layoutOrder.shift(); try{delete c.layouts[k];}catch(e){c.layouts[k]=null;} }
    }

    ANP_artboardLayoutV12=function(cfg,w,h,shape){
        var c=ANP_V1491_NATIVE_CACHE,key=layoutKey(cfg,w,h,shape),entry=c.layouts[key],r;
        if(entry && entry.layout && validLayout(entry.layout)){
            c.cumulative.layoutHits++; if(c.op)c.op.layoutHits++;
            r=clonePlain(entry.layout,0); r.geometryCacheV1491=true; r.layoutCacheHitV1491=true; return r;
        }
        if(entry){try{delete c.layouts[key];}catch(e0){c.layouts[key]=null;}}
        c.cumulative.layoutMisses++; if(c.op)c.op.layoutMisses++;
        r=PREV_LAYOUT(cfg,w,h,shape);
        if(validLayout(r)){
            c.layouts[key]={layout:clonePlain(r,0),at:nowMs()}; c.layoutOrder.push(key); trimLayoutCache();
            try{r.geometryCacheV1491=true;r.layoutCacheHitV1491=false;}catch(e1){}
        }
        return r;
    };

    function selectedIndices(cfg,doc){
        var out=[],seen={},a=cfg&&cfg.artboards?cfg.artboards:[],i,idx;
        for(i=0;i<a.length;i++){
            idx=Number(a[i]&&a[i].artboardIndex);
            if(!isFinite(idx)||idx<0)continue;
            try{if(idx>=doc.artboards.length)continue;}catch(e0){continue;}
            if(!seen[String(idx)]){seen[String(idx)]=1;out.push(idx);}
        }
        return out;
    }

    function prewarm(doc,cfg){
        var c=ANP_V1491_NATIVE_CACHE,started=nowMs(),ids=selectedIndices(cfg,doc),i,groups,g;
        for(i=0;i<ids.length;i++){
            try{ANP_dieForArtboard(doc,ids[i],cfg&&cfg.dieHint||""); if(c.op)c.op.prewarmDies++;}
            catch(eD){if(c.op)c.op.warning+=(c.op.warning?" | ":"")+"die AB"+(ids[i]+1)+": "+safe(eD&&eD.message?eD.message:eD);}
        }
        try{
            groups=ANP_groupArtboardsV12(cfg&&cfg.artboards?cfg.artboards:[]);
            for(i=0;i<groups.length;i++){
                g=groups[i];
                try{ANP_artboardLayoutV12(cfg,g.width,g.height,g.shape);if(c.op)c.op.prewarmLayouts++;}
                catch(eL){if(c.op)c.op.warning+=(c.op.warning?" | ":"")+"layout "+safe(g.width)+"x"+safe(g.height)+": "+safe(eL&&eL.message?eL.message:eL);}
            }
        }catch(eG){if(c.op)c.op.warning+=(c.op.warning?" | ":"")+"group: "+safe(eG&&eG.message?eG.message:eG);}
        if(c.op)c.op.prewarmMs=Math.max(0,nowMs()-started);
    }

    function stats(){
        var c=ANP_V1491_NATIVE_CACHE,o=c.op||{},dieCount=0,layoutCount=0,k;
        for(k in c.dies)if(own(c.dies,k)&&c.dies[k])dieCount++;
        for(k in c.layouts)if(own(c.layouts,k)&&c.layouts[k])layoutCount++;
        return {enabled:true,version:"V149.1",operation:safe(o.operation),operationSeq:Number(o.seq||0),
            persistent:o.persistent===true,prewarmMs:Number(o.prewarmMs||0),prewarmDies:Number(o.prewarmDies||0),prewarmLayouts:Number(o.prewarmLayouts||0),
            dieHits:Number(o.dieHits||0),dieMisses:Number(o.dieMisses||0),layoutHits:Number(o.layoutHits||0),layoutMisses:Number(o.layoutMisses||0),
            cachedDieEntries:dieCount,cachedLayoutEntries:layoutCount,resetReason:safe(o.resetReason),warning:safe(o.warning),
            cumulative:{dieHits:c.cumulative.dieHits,dieMisses:c.cumulative.dieMisses,layoutHits:c.cumulative.layoutHits,layoutMisses:c.cumulative.layoutMisses,resets:c.cumulative.resets}};
    }

    function annotate(raw){
        var obj=null;
        try{obj=eval("("+String(raw||"{}")+")");}catch(e0){obj=null;}
        if(!obj || typeof obj!=="object")return raw;
        try{obj.nativeBatchV1491=stats();}catch(e1){}
        try{return ANP_stringify(obj);}catch(e2){return raw;}
    }

    function activeDoc(){ try{return app.documents.length?app.activeDocument:null;}catch(e){return null;} }

    if(PREV_LIST){
        ANP_listArtboardsV12=function(hint){
            var doc=activeDoc(),raw;
            if(!doc)return PREV_LIST(hint);
            begin(doc,"list-artboards");
            try{raw=PREV_LIST(hint);return annotate(raw);}finally{end(doc);}
        };
    }

    ANP_v12Preview=function(json){
        var doc=activeDoc(),cfg,raw;
        if(!doc)return PREV_PREVIEW(json);
        begin(doc,"preview");
        try{cfg=ANP_parse(json);prewarm(doc,cfg);raw=PREV_PREVIEW(json);return annotate(raw);}finally{end(doc);}
    };

    ANP_v12Build=function(json){
        var doc=activeDoc(),cfg,raw;
        if(!doc)return PREV_BUILD(json);
        begin(doc,"build");
        try{cfg=ANP_parse(json);prewarm(doc,cfg);raw=PREV_BUILD(json);return annotate(raw);}finally{end(doc);}
    };

    if(PREV_DIE_PREVIEW){
        ANP_v14DiePreview=function(json){
            var doc=activeDoc(),cfg=null,raw;
            if(!doc)return PREV_DIE_PREVIEW(json);
            begin(doc,"die-preview");
            try{try{cfg=ANP_parse(json);}catch(eP){cfg=null;}if(cfg&&String(cfg.mode||"")==="artboards")prewarm(doc,cfg);raw=PREV_DIE_PREVIEW(json);return annotate(raw);}finally{end(doc);}
        };
    }

    ANP_v1491GeometryCacheInfo=function(){ return ANP_ok({nativeBatchV1491:stats()}); };
    ANP_v1491GeometryCacheClear=function(){
        var doc=activeDoc();reset(doc,doc?docKey(doc):"","manual-clear");return ANP_ok({cleared:true,nativeBatchV1491:stats()});
    };
})();
/* ===== END DPV V149.1 NATIVE BATCH BRIDGE + GEOMETRY CACHE ===== */
