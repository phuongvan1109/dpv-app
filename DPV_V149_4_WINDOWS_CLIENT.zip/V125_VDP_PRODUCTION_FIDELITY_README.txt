DPV V125 — VDP PRODUCTION FIDELITY

FIX CHÍNH
1. PDF gộp VDP Sheet giữ CHÍNH XÁC khổ Dàn file (vd 330x390 mm). Không còn dựng artboard theo geometricBounds của artwork/PDF link.
2. Bleed record dùng PDF MediaBox, khóa kích thước Trim + 2*Bleed và dùng cùng công thức padAxis của engine Dàn file V101.
3. PON file dùng cùng PON Cache K100 của engine Dàn file. Auto PON / tiêu đề / CATTP lấy trực tiếp từ Production Config.
4. Nếu Dàn file đang bật In 2 mặt AB + CATTP, VDP Sheet xuất mỗi tờ thành PDF 2 trang A/B và Combine giữ đủ 2 trang/tờ.
5. Trước khi Save PDF gộp, V125 assert từng artboard đúng paperW x paperH với dung sai 0.02 mm.

Core V101 layout/Exact Gap/True-Shape không thay đổi.
