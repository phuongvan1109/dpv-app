DPV V149.4 — FRIENDLY CUTE UX

Mục tiêu: app vui vẻ, dễ thương nhưng không che mất thông tin kỹ thuật.
Mặc định: Dễ thương. Người dùng có thể đổi Mood thành Thân thiện hoặc Chuyên nghiệp.

Cute ở lớp ngoài — rõ ràng ở lớp trong:
- Mascot/lời nhắc dùng câu thân thiện.
- Status/log kỹ thuật gốc vẫn giữ nguyên để chẩn đoán lỗi.

Các trạng thái: kết nối Illustrator, đọc nguồn, preview, dàn file, VDP, tác vụ chậm, hoàn tất, lỗi.
