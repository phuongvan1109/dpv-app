DPV V103 LIVE PREVIEW — CORE V101 STABLE

MỚI Ở V103
- Sơ đồ dàn nhanh có Zoom 25%–800%.
- Lăn chuột để zoom, kéo chuột để pan, double-click để Fit.
- Nút Full Screen để xem bố cục lớn trực tiếp trong DPV.
- Chế độ “Khuôn thật” vẽ contour KHUON_BE trực tiếp theo shape/rotation của layout, thay vì chỉ vẽ ô bounding-box.
- Dark/Light hoạt động đầy đủ với viewer mới.
- Không thay đổi Core/solver/Bridge V101: đây là nâng cấp UI Preview, tránh ảnh hưởng độ ổn định dàn file.
