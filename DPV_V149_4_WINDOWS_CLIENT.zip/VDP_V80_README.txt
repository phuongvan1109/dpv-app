DPV V80 — PINNED SOURCE + STREAM LOW-RAM

Nếu trước đó app báo "VDP Fidelity cần file nguồn .AI" dù AI gốc đã Save:
1. Mở đúng file AI gốc.
2. Chọn ít nhất 1 đối tượng Variable Data.
3. Bấm "+ Thêm vị trí đang chọn trong AI" để V80 khóa path + UUID file nguồn.
4. Chạy batch. Sau đó dù tab PDF khác đang active, V80 vẫn tìm đúng file AI nguồn.

V80 vẫn xử lý từng record riêng để giảm RAM.
