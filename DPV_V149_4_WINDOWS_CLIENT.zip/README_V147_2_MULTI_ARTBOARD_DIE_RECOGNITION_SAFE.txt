DPV V147.2 – MULTI ARTBOARD DIE RECOGNITION SAFE

Root fix:
V146.4.3 marked a detected KHUON_BE as dieFallback whenever dieline bounds did not exactly match the artboard rectangle. Rounded/inset dielines were therefore treated as artboard-only and could remain visible in FILE IN.

V147.2:
- artboard width/height stay based on artboardRect
- dieFallback is true only when no dieline is detected
- detected KHUON_BE remains the die shape and is removed from print artwork
- no changes to Core V101 / VDP / QR-Barcode / Cut&Stack / Duplex
