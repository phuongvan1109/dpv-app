DPV V114 — VDP SHEET IMPOSITION (CORE V101 STABLE)

MỚI:
- Từ 1 file AI + CSV/TXT, chạy dữ liệu từng record rồi dàn nhiều record trực tiếp lên khổ in.
- Bố cục dùng chính Layout Cache V101 đã Tính nhanh: Exact Gap, lề cứng, xoay, True-Shape, khuôn đặc biệt.
- Low-RAM pipeline: render từng record PDF nhẹ → Place vào đúng tọa độ V101 → xuất từng tờ. Không clone toàn bộ artwork N lần trong RAM.
- Thứ tự record: hàng, cột, ziczac.
- Tờ cuối: để trống hoặc dồn record vào giữa.
- Có thể giữ/xóa PDF record trung gian.
- Có thể Combine toàn bộ tờ thành một PDF nhiều trang.
- PON/Auto PON/tiêu đề có thể lấy trực tiếp từ cấu hình Dàn file.
- Không thay thuật toán dàn V101 STABLE.

CÁCH DÙNG:
1) Dàn file chính: lấy file nguồn và bấm Tính nhanh để khóa bố cục V101.
2) Mở Biến đổi dữ liệu VDP, chọn CSV/TXT và map các vị trí.
3) Chọn “Dàn record trực tiếp lên khổ in”.
4) Đồng bộ bố cục, chọn thư mục xuất, record range và bấm xuất.
