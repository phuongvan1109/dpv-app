DPV V83 — KHUÔN ĐẶC BIỆT XOAY + KHOẢNG CÁCH ĐỀU

Cách dùng:
1. Bật Cho phép xoay 90°/nhiều góc.
2. Bật Khoảng cách đều chính xác – kể cả khuôn đặc biệt xoay.
3. Bật True-Shape theo KHUON_BE.
4. Bật Khuôn đặc biệt – dàn so le nhanh.
5. Nhập Gap ngang/dọc. Với khuôn xoay, V83 dùng giá trị lớn hơn làm khoảng cách an toàn chung trên contour.

Khác V82:
- V82 buộc tắt Khuôn đặc biệt khi bật Khoảng cách đều.
- V83 cho phép hai chế độ chạy cùng lúc. Khuôn vẫn xoay đầu–đuôi/90°/270° nhưng khoảng cách contour được giữ theo gap.
- Lưới một hướng chỉ áp dụng khi không bật Khuôn đặc biệt hoặc không có shape KHUON_BE thật.
