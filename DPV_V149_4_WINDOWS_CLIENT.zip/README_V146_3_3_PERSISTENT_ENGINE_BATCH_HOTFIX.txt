DPV V146.3.3 — PERSISTENT ENGINE BATCH HOTFIX SAFE

ROOT CAUSE FIXED
Illustrator uses #targetengine "VDPROBridge". Variables in that engine persist between bridge calls.
Older V146/V146.1/V146.2/V146.3.2 wrappers used persistent guard variables, so after the first host evaluation a later evaluation could reset ANP_vdpApplyOneV71 / ANP_vdpApplyRecordV71 to the old implementation while the guard skipped reinstalling QR/Barcode wrappers. The visible result was exactly: Record 1 không áp dụng được kênh biến đổi nào.

V146.3.3 appends one final self-contained UNGUARDED dispatcher to host.jsx and host_bundle.jsx. It is reinstalled on every host evaluation and directly implements QR Version 1-20-L, Code128-B, EAN-13 and barcode typography. Old non-code jobs delegate to the previous stable path.

Recommended first test: 3 records, one qrVector mapping, VDP Sheet.
