DPV V136 FONT FIDELITY

FIX VDP TEXT / NUMBER SEQUENCE:
- Giữ nguyên Font Family + Font Style của TextFrame layout (ví dụ UTM Avo Bold).
- Giữ nguyên font size, leading, tracking, horizontal/vertical scale, baseline shift.
- Giữ Fill/Stroke text và Paragraph Justification.
- Áp dụng cho CSV/TXT, Dãy số tự động, CSV + Dãy số.
- Áp dụng Preview, PDF từng record và VDP Sheet.
- Không thay Core V101 / Mixed Rotation / PON / CATTP / Duplex.
