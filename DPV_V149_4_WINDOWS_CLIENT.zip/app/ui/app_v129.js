(function(){
  "use strict";
  function byId(id){ return document.getElementById(id); }
  function add(el,c){ if(!el)return; if((' '+el.className+' ').indexOf(' '+c+' ')<0) el.className += (el.className?' ':'')+c; }
  function rem(el,c){ if(!el)return; el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,''); }

  function makeQrUi(){
    if(byId('dpvQrCard')) return true;
    var sidebar=byId('dpvSidebar');
    if(!sidebar) return false;
    var core=sidebar.querySelector ? sidebar.querySelector('.dpv-side-card') : null;
    var card=document.createElement('section');
    card.id='dpvQrCard';
    card.className='dpv-qr-card';
    card.innerHTML=''
      +'<div class="dpv-qr-head">'
      +'<span class="dpv-qr-scan-icon">QR</span>'
      +'<strong class="dpv-qr-title">Quét QR</strong>'
      +'<span class="dpv-qr-subtitle">Quét để biết thêm thông tin</span>'
      +'</div>'
      +'<div id="dpvQrImageWrap" class="dpv-qr-image-wrap" title="Bấm để phóng to mã QR">'
      +'<img class="dpv-qr-image" src="../../assets/qr/DPV_Zalo_QR.png" alt="QR Zalo DPV">'
      +'</div>'
      +'<button id="dpvQrOpen" class="dpv-qr-action" type="button">Phóng to mã QR</button>'
      +'<div class="dpv-qr-caption">Zalo hỗ trợ · Thông tin nhanh</div>';
    if(core) sidebar.insertBefore(card,core); else sidebar.appendChild(card);

    var modal=document.createElement('div');
    modal.id='dpvQrModal';
    modal.className='dpv-qr-modal';
    modal.innerHTML=''
      +'<div class="dpv-qr-modal-card">'
      +'<h3 class="dpv-qr-modal-title">Quét QR để biết thêm thông tin</h3>'
      +'<div class="dpv-qr-modal-sub">Mở camera điện thoại hoặc Zalo để quét mã</div>'
      +'<img class="dpv-qr-modal-image" src="../../assets/qr/DPV_Zalo_QR.png" alt="QR Zalo DPV phóng to">'
      +'<br><button id="dpvQrClose" class="dpv-qr-modal-close" type="button">Đóng</button>'
      +'</div>';
    document.body.appendChild(modal);

    function openQr(){ add(modal,'open'); }
    function closeQr(){ rem(modal,'open'); }
    var openBtn=byId('dpvQrOpen'), imgBtn=byId('dpvQrImageWrap'), closeBtn=byId('dpvQrClose');
    if(openBtn) openBtn.onclick=openQr;
    if(imgBtn) imgBtn.onclick=openQr;
    if(closeBtn) closeBtn.onclick=closeQr;
    modal.onclick=function(e){ e=e||window.event; if((e.target||e.srcElement)===modal) closeQr(); };
    if(document.addEventListener){
      document.addEventListener('keydown',function(e){ if((e||window.event).keyCode===27) closeQr(); },false);
    }else if(document.attachEvent){
      document.attachEvent('onkeydown',function(){ if(window.event && window.event.keyCode===27) closeQr(); });
    }
    return true;
  }

  function markVersion(){
    var v=document.querySelector ? document.querySelector('.version-badge') : null;
    if(v) v.innerHTML='V129 QR INFO · CORE V101 STABLE';
    var beta=document.querySelector ? document.querySelector('.beta-note') : null;
    if(beta) beta.innerHTML='<strong>DPV® V129 QR Info · Core V101 Stable</strong><br>Thêm QR Zalo hỗ trợ ở sidebar + chế độ phóng to để quét dễ hơn · không thay engine dàn, PON, VDP, Duplex hay Bridge Illustrator.';
    var core=document.querySelector ? document.querySelector('.dpv-side-card') : null;
    if(core) core.innerHTML='<strong><span class="dpv-side-dot"></span>Core V101 STABLE</strong>Engine dàn được khóa ổn định.<br>V129 chỉ thêm giao diện QR hỗ trợ.';
  }

  function start(){
    var tries=0;
    function boot(){
      tries++;
      if(makeQrUi()){ markVersion(); return; }
      if(tries<30) setTimeout(boot,80);
    }
    boot();
  }
  if(document.readyState==='loading'){
    if(document.addEventListener) document.addEventListener('DOMContentLoaded',start,false);
    else window.attachEvent('onload',start);
  }else start();
})();
