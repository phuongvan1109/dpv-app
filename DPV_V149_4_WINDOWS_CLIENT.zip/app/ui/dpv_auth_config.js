/* DPV V148.9.2 LICENSE EXPIRY DISPLAY + REGISTER + AUTO UPDATE AUTH CONFIG
   Sau khi deploy, SETUP sẽ tự đổi serverUrl thành URL *.workers.dev. */
window.DPV_AUTH_CONFIG = {
  serverUrl: "https://dpv-auth-free.dpvphuongvan.workers.dev",
  appVersion: "V149.4",
  requireOnline: true,
  validateEveryMinutes: 10,
  googlePollSeconds: 2
};
