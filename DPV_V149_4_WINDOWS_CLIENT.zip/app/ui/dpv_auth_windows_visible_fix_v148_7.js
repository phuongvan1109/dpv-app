(function(){
  function rescue(){try{
    if(window.DPVAuth && !window.DPVAuth.isAuthorized()){
      var o=document.getElementById('dpvAuthOverlay');
      if(o){o.className='';o.style.position='fixed';o.style.top='0';o.style.right='0';o.style.bottom='0';o.style.left='0';o.style.width='100%';o.style.height='100%';o.style.display='flex';o.style.zIndex='2147483647';}
      else if(window.DPVAuth.showLogin){window.DPVAuth.showLogin();}
    }
  }catch(e){}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(rescue,50);setTimeout(rescue,700);});
  else {setTimeout(rescue,50);setTimeout(rescue,700);}
})();
