(function(){
  "use strict";
  var VERSION="V149.4";
  var TONE_KEY="dpv.v1494.friendTone";
  var BUDDY_KEY="dpv.v1494.buddyCollapsed";
  var GREET_KEY="dpv.v1494.lastGreeting";
  var busy=null, busyTimers=[], observer=null;

  function byId(id){return document.getElementById(id);}
  function qs(s,r){return (r||document).querySelector?(r||document).querySelector(s):null;}
  function qsa(s,r){return (r||document).querySelectorAll?(r||document).querySelectorAll(s):[];}
  function add(el,c){if(!el)return;if((" "+el.className+" ").indexOf(" "+c+" ")<0)el.className+=(el.className?" ":"")+c;}
  function rem(el,c){if(!el)return;el.className=(" "+el.className+" ").replace(" "+c+" "," ").replace(/^\s+|\s+$/g,"");}
  function has(el,c){return !!el&&(" "+el.className+" ").indexOf(" "+c+" ")>=0;}
  function text(el,v){if(!el)return;if("textContent" in el)el.textContent=v;else el.innerText=v;}
  function getStored(k,d){try{var v=localStorage.getItem(k);return v===null?d:v;}catch(e){return d;}}
  function setStored(k,v){try{localStorage.setItem(k,v);}catch(e){}}
  function now(){return new Date().getTime();}
  function trim(s){return String(s||"").replace(/^\s+|\s+$/g,"");}
  function lower(s){return String(s||"").toLowerCase();}
  function containsAny(s,arr){s=lower(s);for(var i=0;i<arr.length;i++){if(s.indexOf(arr[i])>=0)return true;}return false;}

  var MSG={
    pro:{
      hello:"DPV đã sẵn sàng.",
      connect:"Đang kết nối Illustrator…",
      source:"Đang đọc dữ liệu nguồn…",
      preview:"Đang tính bố cục…",
      build:"Đang dàn và xuất file…",
      vdp:"Đang xử lý dữ liệu biến đổi…",
      slow1:"Tác vụ đang mất nhiều thời gian hơn dự kiến.",
      slow2:"DPV vẫn đang xử lý. Vui lòng giữ ứng dụng mở.",
      done:"Hoàn tất.",
      error:"Có lỗi xảy ra. Mở chi tiết để kiểm tra.",
      idle:"Sẵn sàng."
    },
    friendly:{
      hello:"Chào bạn 👋 DPV sẵn sàng làm file rồi nha!",
      connect:"Đang kết nối Illustrator, chờ mình một chút nha.",
      source:"Đang đọc artboard và khuôn nè…",
      preview:"Đang xem bố cục cho bạn nha ✨",
      build:"DPV đang dàn file, chờ mình một chút nha.",
      vdp:"Đang chạy dữ liệu VDP nè, sắp xong rồi nha.",
      slow1:"Hơi nhiều việc xíu, DPV vẫn đang xử lý nha 🐾",
      slow2:"Job này hơi nặng á, đừng đóng app nha — mình vẫn đang chạy.",
      done:"Xong rồi nha ✨",
      error:"Ui, chỗ này hơi trục trặc rồi. Mở chi tiết để mình kiểm tra nha.",
      idle:"Mình sẵn sàng rồi nha."
    },
    cute:{
      hello:"Chào tình iu 💛 Hôm nay mình làm file mượt mượt nha!",
      connect:"Đang bắt tay với Illustrator nè, chờ mình xíu nha 💛",
      source:"Đang đọc artboard nè… tí xíu thôi nha 🐾",
      preview:"Đang ngó thử bố cục cho đẹp nè ✨",
      build:"Đợi tí nha tình iu, DPV đang dàn file cho bạn nè…",
      vdp:"Đợi mình xíu nha, đang chạy dữ liệu siêng năng đây 🐶",
      slow1:"Máy hơi bận xíu á, đợi mình tí nha tình iu 🐾",
      slow2:"Job này hơi nặng nè 😵 DPV vẫn làm chăm chỉ, đừng đóng app nha 💛",
      done:"Xong rồi nè tình iu ✨",
      error:"Ui, chỗ này hơi trục trặc rồi 😵 Mở chi tiết để mình sửa nhanh nha.",
      idle:"Mình ngồi đây chờ bạn làm file nè 🐶"
    }
  };

  function tone(){var t=getStored(TONE_KEY,"cute");return (t==="pro"||t==="friendly"||t==="cute")?t:"cute";}
  function msg(k){var t=tone(),m=MSG[t]||MSG.cute;return m[k]||m.idle;}
  function setTone(t){if(t!=="pro"&&t!=="friendly"&&t!=="cute")t="cute";setStored(TONE_KEY,t);applyToneUi();say(msg("idle"),"idle",false);}
  function toneLabel(t){return t==="pro"?"Chuyên nghiệp":(t==="friendly"?"Thân thiện":"Dễ thương");}

  function makeTonePicker(){
    if(byId("dpvV1494ToneWrap"))return;
    var bar=byId("dpvV1493ModeBar")||qs(".topbar");if(!bar)return;
    var w=document.createElement("div");w.id="dpvV1494ToneWrap";w.className="dpv-v1494-tone-wrap";
    w.innerHTML='<span class="dpv-v1494-tone-label">Mood</span><select id="dpvV1494Tone" title="Mức độ trò chuyện của DPV"><option value="pro">Chuyên nghiệp</option><option value="friendly">Thân thiện</option><option value="cute">💛 Dễ thương</option></select>';
    bar.appendChild(w);
    var s=byId("dpvV1494Tone");if(s){s.value=tone();s.onchange=function(){setTone(this.value);};}
  }

  function makeBuddy(){
    if(byId("dpvV1494Buddy"))return;
    var d=document.createElement("div");d.id="dpvV1494Buddy";d.className="dpv-v1494-buddy";
    d.innerHTML='<button id="dpvV1494BuddyMini" class="dpv-v1494-buddy-mini" type="button" title="Mở trợ lý DPV"><img src="../../assets/icon/DPV-mascot-friendly-v1494.png" alt="DPV"></button>'+
      '<div class="dpv-v1494-buddy-card"><button id="dpvV1494BuddyClose" class="dpv-v1494-buddy-close" type="button" title="Thu gọn">×</button>'+
      '<img class="dpv-v1494-buddy-avatar" src="../../assets/icon/DPV-mascot-friendly-v1494.png" alt="DPV Mascot">'+
      '<div class="dpv-v1494-buddy-copy"><strong id="dpvV1494BuddyTitle">DPV đang ở đây nè</strong><span id="dpvV1494BuddyText"></span><div id="dpvV1494BuddyDots" class="dpv-v1494-buddy-dots"><i></i><i></i><i></i></div></div></div>';
    document.body.appendChild(d);
    var mini=byId("dpvV1494BuddyMini"),close=byId("dpvV1494BuddyClose");
    if(mini)mini.onclick=function(){expandBuddy(true);};
    if(close)close.onclick=function(){collapseBuddy(true);};
    if(getStored(BUDDY_KEY,"0")==="1")collapseBuddy(false);else expandBuddy(false);
  }

  function collapseBuddy(store){var d=byId("dpvV1494Buddy");if(!d)return;add(d,"collapsed");if(store)setStored(BUDDY_KEY,"1");}
  function expandBuddy(store){var d=byId("dpvV1494Buddy");if(!d)return;rem(d,"collapsed");if(store)setStored(BUDDY_KEY,"0");}
  function buddyTitle(kind){if(kind==="error")return "Ui, mình gặp chút trục trặc";if(kind==="busy")return "DPV đang làm việc nè";if(kind==="done")return "Hoàn tất rồi nè";return "DPV đang ở đây nè";}
  function say(message,kind,forceOpen){
    makeBuddy();var d=byId("dpvV1494Buddy"),t=byId("dpvV1494BuddyText"),h=byId("dpvV1494BuddyTitle");if(!d)return;
    rem(d,"is-busy");rem(d,"is-error");rem(d,"is-done");
    if(kind==="busy")add(d,"is-busy");else if(kind==="error")add(d,"is-error");else if(kind==="done")add(d,"is-done");
    text(h,buddyTitle(kind));text(t,message||msg("idle"));
    if(forceOpen)expandBuddy(false);
  }

  function toast(message,kind){
    var host=byId("dpvV1494ToastHost");if(!host){host=document.createElement("div");host.id="dpvV1494ToastHost";host.className="dpv-v1494-toast-host";document.body.appendChild(host);}
    var n=document.createElement("div");n.className="dpv-v1494-toast "+(kind||"");n.innerHTML='<span class="dpv-v1494-toast-icon">'+(kind==="error"?"!":(kind==="done"?"✓":"•"))+'</span><span></span>';
    text(n.lastChild,message);host.appendChild(n);setTimeout(function(){add(n,"show");},10);setTimeout(function(){rem(n,"show");setTimeout(function(){if(n.parentNode)n.parentNode.removeChild(n);},260);},3400);
  }

  function clearBusyTimers(){for(var i=0;i<busyTimers.length;i++)clearTimeout(busyTimers[i]);busyTimers=[];}
  function actionKey(id){
    if(id==="connectBtn")return"connect";
    if(id==="activeBtn"||id==="multiBtn"||id==="artboardsBtn"||id==="manualBtn"||id==="manualSizeBtn"||id==="useArtboards")return"source";
    if(id==="localPreviewBtn"||id==="hostPreviewBtn"||id==="diePreviewBtn")return"preview";
    if(id==="buildBtn")return"build";
    if(id==="vdpBuildBtn"||id==="vdpPreviewBtn"||id==="vdpChooseDataBtn")return"vdp";
    return"";
  }
  function beginBusy(k){
    if(!k)return;clearBusyTimers();busy={key:k,started:now()};say(msg(k),"busy",true);
    busyTimers.push(setTimeout(function(){if(busy)say(msg("slow1"),"busy",true);},2200));
    busyTimers.push(setTimeout(function(){if(busy)say(msg("slow2"),"busy",true);},7000));
  }
  function endBusy(ok,detail){
    if(!busy)return;var elapsed=now()-busy.started;clearBusyTimers();busy=null;
    if(ok){say(msg("done"),"done",true);toast(msg("done"),"done");if(elapsed<900)setTimeout(function(){collapseBuddy(false);},2200);}
    else{say(detail||msg("error"),"error",true);toast(msg("error"),"error");}
  }

  function statusText(){var a=byId("status"),b=byId("vdpStatus"),c=byId("connectionText");return trim((a?a.innerText||a.textContent:"")+" "+(b?b.innerText||b.textContent:"")+" "+(c?c.innerText||c.textContent:""));}
  function inspectStatus(){
    updateHealth();if(!busy)return;var s=statusText();
    if(containsAny(s,["undefined is not an object"," lỗi","lỗi:","error","failed","thất bại","không thể","chưa đăng nhập","hết hiệu lực"]))endBusy(false,msg("error"));
    else if(containsAny(s,["hoàn tất","thành công","đã xuất","xong","sẵn sàng sản xuất","đã kết nối","ready"]))endBusy(true,s);
  }

  function sourceCount(){var list=byId("sourceList");if(!list)return 0;var cards=qsa(".source-card,.source-item,.source-row",list);if(cards&&cards.length)return cards.length;var textv=trim(list.innerText||list.textContent||"");if(!textv||containsAny(textv,["chưa có","mở file trong illustrator"]))return 0;return 1;}
  function isConnected(){var d=byId("connectionDot"),t=byId("connectionText");return (d&&!has(d,"offline"))||containsAny(t?t.innerText||t.textContent:"",["đã kết nối","connected"]);}
  function hasOutput(){var n=byId("outputPath");return !!(n&&trim(n.value));}
  function licenseOk(){var s=statusText();return !containsAny(s,["chưa đăng nhập","bản quyền máy chủ đã hết","hết hiệu lực"]);}

  function makeHealth(){
    if(byId("dpvV1494Health"))return;var mode=byId("dpvV1493ModeBar"),ws=qs(".workspace");if(!ws)return;
    var h=document.createElement("div");h.id="dpvV1494Health";h.className="dpv-v1494-health";
    h.innerHTML='<div class="dpv-v1494-health-copy"><strong>🐾 DPV Health</strong><span id="dpvV1494HealthText">Đang kiểm tra xíu nha…</span></div><div class="dpv-v1494-health-chips"><span id="dpvHConn"></span><span id="dpvHSrc"></span><span id="dpvHOut"></span><span id="dpvHLic"></span></div>';
    if(mode&&mode.parentNode){if(mode.nextSibling)mode.parentNode.insertBefore(h,mode.nextSibling);else mode.parentNode.appendChild(h);}else ws.insertBefore(h,ws.firstChild);
  }
  function setChip(id,ok,label){var n=byId(id);if(!n)return;n.className=ok?"ok":"wait";text(n,(ok?"✓ ":"○ ")+label);}
  function updateHealth(){
    makeHealth();var conn=isConnected(),sc=sourceCount(),out=hasOutput(),lic=licenseOk();
    setChip("dpvHConn",conn,"Illustrator");setChip("dpvHSrc",sc>0,"Nguồn"+(sc>1?" "+sc:""));setChip("dpvHOut",out,"Output");setChip("dpvHLic",lic,"License");
    var n=byId("dpvV1494HealthText");if(n)text(n,(conn&&sc>0&&out&&lic)?"Sẵn sàng rồi nè ✨":"Còn vài bước nhỏ là chạy ngon nha");
    var h=byId("dpvV1494Health");if(h){if(conn&&sc>0&&out&&lic)add(h,"ready");else rem(h,"ready");}
  }

  function applyToneUi(){
    var b=document.body;if(!b)return;rem(b,"dpv-tone-pro");rem(b,"dpv-tone-friendly");rem(b,"dpv-tone-cute");add(b,"dpv-tone-"+tone());
    var s=byId("dpvV1494Tone");if(s)s.value=tone();
    var t=qs("#dpvV1494ToneWrap .dpv-v1494-tone-label");if(t)text(t,toneLabel(tone()));
  }

  function bindClicks(){
    var handler=function(ev){var target=ev.target||ev.srcElement;while(target&&target!==document.body&&(!target.id)){target=target.parentNode;}if(!target)return;var k=actionKey(target.id);if(k)beginBusy(k);};
    if(document.addEventListener)document.addEventListener("click",handler,true);else if(document.attachEvent)document.attachEvent("onclick",handler);
  }

  function watchStatus(){
    if(window.MutationObserver){observer=new MutationObserver(function(){setTimeout(inspectStatus,30);});var ids=["status","vdpStatus","connectionText","sourceList","outputPath","log"],i,n;for(i=0;i<ids.length;i++){n=byId(ids[i]);if(n)observer.observe(n,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:["value","class","style"]});}}
    else setInterval(inspectStatus,1200);
  }

  function dailyGreeting(){
    var d=new Date(),key=d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate();if(getStored(GREET_KEY,"")===key){say(msg("idle"),"idle",false);return;}setStored(GREET_KEY,key);say(msg("hello"),"idle",true);toast(msg("hello"),"");setTimeout(function(){if(!busy)collapseBuddy(false);},5200);
  }

  function tuneSplash(){
    var sub=qs(".dpv-splash-sub");if(sub)text(sub,tone()==="cute"?"DPV đang chuẩn bị xíu nha… 🐾":"PRINT WORKFLOW · FRIENDLY UX");
  }

  function forceVersion(){
    try{document.title="DPV® V149.4 — Friendly Cute UX · Quick/Advanced";}catch(e){}
    var v=qs(".version-badge");if(v)v.innerHTML="V149.4 · FRIENDLY CUTE UX · CORE V101";
    var beta=qs(".beta-note");if(beta)beta.innerHTML='<strong>DPV® V149.4 FRIENDLY CUTE UX</strong><br>Mascot DPV · trạng thái vui vẻ · cảnh báo lag thân thiện · Mood Chuyên nghiệp / Thân thiện / Dễ thương · Quick / Advanced giữ nguyên.';
  }

  function start(){
    makeTonePicker();makeBuddy();makeHealth();applyToneUi();tuneSplash();bindClicks();watchStatus();updateHealth();forceVersion();dailyGreeting();
    setInterval(updateHealth,2500);
    setTimeout(function(){makeTonePicker();makeBuddy();makeHealth();applyToneUi();updateHealth();forceVersion();},900);
    setTimeout(forceVersion,2800);setTimeout(forceVersion,5600);
  }

  window.DPVV1494={version:VERSION,setTone:setTone,say:say,toast:toast,updateHealth:updateHealth};
  if(document.readyState==="loading"){if(document.addEventListener)document.addEventListener("DOMContentLoaded",function(){setTimeout(start,180);},false);else window.attachEvent("onload",function(){setTimeout(start,180);});}else setTimeout(start,180);
})();
