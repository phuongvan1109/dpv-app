
/* DPV V147.2 Multi-Artboard Die Recognition SAFE — UI diagnostic only. */
(function(){
  'use strict';
  function $(id){return document.getElementById(id);} 
  function addNote(){
    var old=$('v14643MultiAbNote'); if(!old||$('v1472DieFixNote')) return !!old;
    var n=document.createElement('div'); n.id='v1472DieFixNote'; n.className='v14643-note';
    n.style.marginTop='8px'; n.style.borderColor='#bfe7d4'; n.style.background='#f4fff9';
    n.innerHTML='<b>MULTI ARTBOARD KHUON_BE · V147.2 FIX</b><br>'+ 
      'DPV tách riêng <b>kích thước artboard</b> và <b>nhận diện khuôn bế</b>. KHUON_BE bo góc/nằm lọt trong artboard vẫn được nhận đúng và sẽ bị loại khỏi <b>FILE IN</b>. Trong danh sách artboard, hãy kiểm tra badge <b>“Có KHUON_BE”</b> trước khi Build.';
    old.parentNode.insertBefore(n,old.nextSibling); return true;
  }
  function watchChooser(){
    var list=$('artboardList'); if(!list) return;
    var rows=list.querySelectorAll('.artboard-option'),i,small;
    for(i=0;i<rows.length;i++){
      small=rows[i].querySelector('small');
      if(!small) continue;
      if(/Có KHUON_BE/i.test(small.textContent||'')){
        small.style.color='#078b60'; small.style.fontWeight='800';
      } else if(/Dùng artboard/i.test(small.textContent||'')){
        small.style.color='#b87800'; small.style.fontWeight='800';
      }
    }
  }
  function run(){addNote();watchChooser();}
  var n=0,t=setInterval(function(){n++;run();if(n>100)clearInterval(t);},400);
  document.addEventListener('click',function(){setTimeout(run,80);},false);
})();
