/* DPV V146.3 QR/BARCODE BATCH + TYPOGRAPHY SAFE ADD-ON
   SAFE ADDITIVE MODULE ONLY.
   - marks qrVector/code128Vector/ean13Vector as batch-capable in UI layer
   - adds barcode typography panel for Code128 / EAN-13
   - stores typography settings separately without overriding stable handlers
*/
(function(){
  'use strict';
  var VERSION='V146.3';
  var STORE='dpv_v1463_barcode_style';
  function $(id){return document.getElementById(id);} 
  function load(){ try{return JSON.parse(localStorage.getItem(STORE)||'{}')||{};}catch(e){return {};}}
  function save(v){ try{localStorage.setItem(STORE,JSON.stringify(v||{}));}catch(e){} }
  function state(){ try{return window.DPVVDP101&&window.DPVVDP101.getState?window.DPVVDP101.getState():null;}catch(e){return null;} }
  function mappings(){ var st=state()||{}; return st.mappings||[]; }
  function isBarcode(a){ return a==='code128Vector'||a==='ean13Vector'; }
  function isCode(a){ return a==='qrVector'||a==='code128Vector'||a==='ean13Vector'; }
  function keyOf(m,i){ return (m && (m.id||m.uuid||m.label||m.field)) ? String(m.id||m.uuid||m.label||m.field) : ('map_'+i); }
  function ensureCard(){
    var root=$('vdpMappings'); if(!root||!root.parentNode) return null;
    var card=$('v1463BarcodeTypographyCard');
    if(card) return card;
    card=document.createElement('div'); card.id='v1463BarcodeTypographyCard'; card.className='v1463-card';
    card.innerHTML=''
      +'<div class="v1463-head"><strong>QR / BARCODE BATCH + TYPOGRAPHY</strong><span>'+VERSION+' SAFE</span></div>'
      +'<div class="v1463-note">Batch VDP/VDP Sheet công nhận QR · Code128 · EAN-13 là action mã hợp lệ. Với barcode, bạn có thể chỉnh font, cỡ chữ và kiểu hiển thị số dưới mã.</div>'
      +'<div id="v1463BatchStatus" class="v1463-batch-status"></div>'
      +'<div id="v1463TypographyBox" class="v1463-typography-box"></div>';
    root.parentNode.insertBefore(card, root.nextSibling);
    return card;
  }
  function selectedBarcodeMapping(){
    var root=$('vdpMappings'); if(!root) return null;
    var rows=root.querySelectorAll('.vdp-map-item,.vdp-mapping,.vdp-row,[data-map-index]');
    var maps=mappings(), i, actSel, row, mi;
    for(i=0;i<rows.length;i++){
      row=rows[i]; actSel=row.querySelector('select.vdp-action');
      if(actSel && isBarcode(actSel.value)){
        mi = Number(row.getAttribute('data-map-index')); if(isNaN(mi)) mi=i;
        return { row:row, map:maps[mi]||{}, idx:mi, action:actSel.value };
      }
    }
    for(i=0;i<maps.length;i++) if(isBarcode(maps[i].action)) return { row:null, map:maps[i], idx:i, action:maps[i].action };
    return null;
  }
  function renderBatchStatus(){
    ensureCard();
    var box=$('v1463BatchStatus'); if(!box) return;
    var maps=mappings(), code=0, bars=0, ean=0, qr=0, i, parts=[];
    for(i=0;i<maps.length;i++){
      if(maps[i].action==='qrVector'){code++; qr++;}
      else if(maps[i].action==='code128Vector'){code++; bars++;}
      else if(maps[i].action==='ean13Vector'){code++; ean++;}
    }
    parts.push('<span><b>'+code+'</b> mapping mã hợp lệ cho batch</span>');
    parts.push('<span>QR '+qr+'</span>'); parts.push('<span>Code128 '+bars+'</span>'); parts.push('<span>EAN-13 '+ean+'</span>');
    box.innerHTML = parts.map(function(s){return '<i>'+s+'</i>';}).join('');
  }
  function renderTypography(){
    ensureCard();
    var box=$('v1463TypographyBox'); if(!box) return;
    var pick=selectedBarcodeMapping(), db=load(), cfg, k;
    if(!pick){ box.innerHTML='<div class="v1463-empty">Chọn một mapping <b>Barcode Code 128 · Vector</b> hoặc <b>Barcode EAN-13 · Vector</b> để chỉnh typography.</div>'; return; }
    k=keyOf(pick.map,pick.idx); cfg=db[k]||{};
    function val(n,d){ return cfg[n]==null?d:cfg[n]; }
    box.innerHTML=''
      +'<div class="v1463-sub">BARCODE TEXT STYLE · '+(pick.action==='ean13Vector'?'EAN‑13':'CODE 128')+'</div>'
      +'<div class="v1463-grid">'
      +'<label><span>Hiện chữ dưới mã</span><select id="v1463ShowText"><option value="1">Bật</option><option value="0">Tắt</option></select></label>'
      +'<label><span>Font chữ</span><input id="v1463FontName" type="text" placeholder="Arial" value="'+String(val('fontName','Arial')).replace(/"/g,'&quot;')+'"></label>'
      +'<label><span>Cỡ chữ (pt)</span><input id="v1463FontSize" type="number" min="4" step="0.1" value="'+String(val('fontSize',9))+'"></label>'
      +'<label><span>Tracking</span><input id="v1463Tracking" type="number" step="1" value="'+String(val('tracking',0))+'"></label>'
      +'<label><span>Khoảng cách chữ–mã (mm)</span><input id="v1463TextGap" type="number" min="0" step="0.1" value="'+String(val('textGapMm',1.2))+'"></label>'
      +'<label><span>Chiều cao vạch (%)</span><input id="v1463BarHeight" type="number" min="40" max="200" step="1" value="'+String(val('barHeightPercent',100))+'"></label>'
      +'<label><span>Giãn bề ngang (%)</span><input id="v1463BarWidth" type="number" min="60" max="140" step="1" value="'+String(val('barWidthPercent',100))+'"></label>'
      +'<label><span>Quiet zone (module)</span><input id="v1463Quiet" type="number" min="2" max="20" step="1" value="'+String(val('quietZone',10))+'"></label>'
      +'<label><span>Kiểu chữ</span><select id="v1463FontWeight"><option value="regular">Regular</option><option value="bold">Bold</option></select></label>'
      +'<label><span>Text output</span><select id="v1463TextMode"><option value="outline">Outline</option><option value="live">Text sống</option></select></label>'
      +'</div>'
      +'<div class="v1463-actions"><button id="v1463SaveTypography" class="button accent">Lưu style barcode</button><button id="v1463ResetTypography" class="button ghost">Khôi phục mặc định</button></div>'
      +'<div class="v1463-help">Kiểu này tương tự workflow Barcode Studio: có thể chỉnh <b>font</b>, <b>size</b>, <b>text dưới mã</b>, <b>khoảng cách</b>, <b>bar height</b> và <b>outline/live text</b>. Cấu hình được lưu tách riêng, không đụng mapping cũ.</div>';
    $('v1463ShowText').value=String(val('showText',1));
    $('v1463FontWeight').value=String(val('fontWeight','regular'));
    $('v1463TextMode').value=String(val('textMode','outline'));
    $('v1463SaveTypography').onclick=function(){
      db[k]={
        showText:Number($('v1463ShowText').value||1),
        fontName:$('v1463FontName').value||'Arial',
        fontSize:Number($('v1463FontSize').value||9),
        tracking:Number($('v1463Tracking').value||0),
        textGapMm:Number($('v1463TextGap').value||1.2),
        barHeightPercent:Number($('v1463BarHeight').value||100),
        barWidthPercent:Number($('v1463BarWidth').value||100),
        quietZone:Number($('v1463Quiet').value||10),
        fontWeight:$('v1463FontWeight').value||'regular',
        textMode:$('v1463TextMode').value||'outline'
      }; save(db);
      try{ if(window.DPVVDP101){ window.DPVVDP101.__v1463BarcodeStyle = db; } }catch(e){}
      if(window.DPVVDP101&&window.DPVVDP101.status) window.DPVVDP101.status('Đã lưu Barcode Text Style · '+VERSION,'ok');
    };
    $('v1463ResetTypography').onclick=function(){ delete db[k]; save(db); renderTypography(); };
  }
  function hook(){ ensureCard(); renderBatchStatus(); renderTypography(); return !!$('vdpMappings'); }
  var tries=0, timer=setInterval(function(){ tries++; if(hook()||tries>80) clearInterval(timer); }, 500);
  document.addEventListener('click', function(){ setTimeout(hook,60); }, false);
  window.DPV_V1463_BARCODE_STYLE = { load:load, save:save, render:hook };
})();
