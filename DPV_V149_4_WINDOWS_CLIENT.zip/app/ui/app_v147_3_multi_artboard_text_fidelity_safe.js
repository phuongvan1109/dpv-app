
(function(){
  function inject(){
    var old=document.getElementById('v1472MultiArtboardDieCard') || document.querySelector('[data-v1472-multi-die]');
    var host=old || document.querySelector('.source-column') || document.querySelector('.column.source-column');
    if(!host || document.getElementById('v1473TextFidelityBadge')) return !!host;
    var box=document.createElement('div'); box.id='v1473TextFidelityBadge';
    box.style.marginTop='10px';box.style.padding='10px 12px';box.style.border='1px solid #cfe7db';box.style.borderRadius='12px';box.style.background='#f6fffa';box.style.fontSize='12px';box.style.lineHeight='1.45';box.style.color='#315d50';
    box.innerHTML='<b>MULTI ARTBOARD TEXT FIDELITY · V147.3 SAFE</b><br>Multi Artboard có TextFrame dùng Fidelity an toàn. <b>File AI</b>: DPV tự Save thay đổi trước khi Build. <b>File PDF</b>: DPV tự render đúng artboard thành PDF Fidelity tạm, không bắt Save As AI. Giữ đúng bố cục chữ/Area Text và không đưa KHUON_BE vào FILE IN.';
    host.appendChild(box); return true;
  }
  var n=0,t=setInterval(function(){n++;if(inject()||n>50)clearInterval(t);},500);
})();
