(function(){
  "use strict";
  function add(el,c){if(!el)return;if((" "+(el.className||"")+" ").indexOf(" "+c+" ")<0)el.className+=(el.className?" ":"")+c;}
  function rem(el,c){if(!el)return;el.className=(" "+(el.className||"")+" ").replace(" "+c+" "," ").replace(/^\s+|\s+$/g,"");}
  function qs(s){return document.querySelector?document.querySelector(s):null;}
  function vp(){var d=document.documentElement||{},b=document.body||{};return {w:d.clientWidth||b.clientWidth||window.innerWidth||1400,h:d.clientHeight||b.clientHeight||window.innerHeight||850};}
  var old=['dpv-layout-medium','dpv-layout-two','dpv-layout-stack','dpv-short-window','dpv-compact-sidebar','dpv-v117-wide','dpv-v117-stack','dpv-v117-compact','dpv-v117-tight','dpv-v117-mini','dpv-v117-tiny','dpv-v117-short','dpv-v118-wide','dpv-v118-stack','dpv-v118-compact','dpv-v118-tight','dpv-v118-mini','dpv-v118-tiny','dpv-v118-narrow','dpv-v118-short'];
  var timer=0,lastW=-1,lastH=-1;

  function clearLayout(b){for(var i=0;i<old.length;i++)rem(b,old[i]);}
  function isWindows(){var u=String(navigator.userAgent||'').toLowerCase();return u.indexOf('windows')>=0||u.indexOf('trident')>=0;}

  function apply(){
    var b=document.body, s=vp();
    clearLayout(b);
    if(isWindows()){add(b,'dpv-windows');add(b,'dpv-win-fast');}else{add(b,'dpv-mac');return;}

    /* Sidebar first. Re-read width only after its class has been applied. */
    if(s.w<1580)add(b,'dpv-v118-compact');
    var side=qs('.dpv-sidebar');
    var sideW=side?(side.offsetWidth||0):0;
    var usable=s.w-sideW-32;

    /* IE table mode only when there is genuinely enough CSS-pixel width. */
    if(usable>=1320)add(b,'dpv-v118-wide');
    else add(b,'dpv-v118-stack');

    if(s.w<1650)add(b,'dpv-v118-tight');
    if(s.w<1280)add(b,'dpv-v118-mini');
    if(s.w<980)add(b,'dpv-v118-tiny');
    if(usable<680)add(b,'dpv-v118-narrow');
    if(s.h<790)add(b,'dpv-v118-short');

    /* Measure actual topbar after wrap and size the scrollable workspace. */
    var top=qs('.topbar'), work=qs('.workspace');
    if(top&&work){
      var rect=top.getBoundingClientRect?top.getBoundingClientRect():null;
      var bottom=rect?rect.bottom:(top.offsetHeight||68);
      var available=s.h-bottom;
      if(available<260)available=260;
      work.style.height=available+'px';
    }
  }

  function mark(){
    var v=qs('.version-badge');if(v)v.innerHTML='V118 IE TABLE FIX · CORE V101 STABLE';
    var n=qs('.beta-note');if(n)n.innerHTML='<strong>DPV® V118 IE Table Fix · Core V101 Stable</strong><br>Windows bỏ flex 3 cột gây co sập khi maximize/restore; màn hình rộng dùng table-layout ổn định, màn hình hẹp tự xếp dọc và cuộn. Không thay engine dàn, PON, VDP hay Bridge Illustrator.';
  }

  function run(force){var s=vp();if(force||s.w!==lastW||s.h!==lastH){lastW=s.w;lastH=s.h;apply();mark();setTimeout(apply,80);setTimeout(apply,260);}}
  function resize(){if(timer)clearTimeout(timer);timer=setTimeout(function(){run(true);},45);}
  function start(){run(true);if(window.addEventListener){window.addEventListener('resize',resize,false);window.addEventListener('load',function(){run(true);},false);}else if(window.attachEvent){window.attachEvent('onresize',resize);window.attachEvent('onload',function(){run(true);});}setTimeout(function(){run(true);},400);setTimeout(function(){run(true);},1100);setInterval(function(){run(false);},1200);}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();
