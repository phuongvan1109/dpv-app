/* DPV V146.1 EAN-13 VECTOR SAFE ADD-ON
   Additive UI only. V146 QR/Code128 and all older VDP handlers remain untouched. */
(function(){
  'use strict';
  var VERSION='V146.1';
  function $(id){return document.getElementById(id);}
  function addOption(sel){
    if(!sel||sel.querySelector('option[value="ean13Vector"]')) return;
    var o=document.createElement('option');
    o.value='ean13Vector'; o.textContent='Barcode EAN-13 · Vector'; sel.appendChild(o);
  }
  function enhance(){
    var root=$('vdpMappings'), sels, i;
    if(!root) return false;
    sels=root.querySelectorAll('select.vdp-action');
    for(i=0;i<sels.length;i++) addOption(sels[i]);
    insertCard(); updateCard();
    if(!root.__v1461EanObserver){
      var mo=new MutationObserver(function(){
        var ss=root.querySelectorAll('select.vdp-action'),j;
        for(j=0;j<ss.length;j++) addOption(ss[j]);
        updateCard();
      });
      mo.observe(root,{childList:true,subtree:true});
      root.__v1461EanObserver=mo;
      root.addEventListener('change',function(e){
        if(e.target&&e.target.classList&&e.target.classList.contains('vdp-action')) updateCard();
      },false);
    }
    return true;
  }
  function insertCard(){
    if($('v1461EanCard')) return;
    var anchor=$('v146QrBarcodeCard'), root=$('vdpMappings');
    if(!root||!root.parentNode) return;
    var c=document.createElement('div');
    c.id='v1461EanCard';
    c.style.cssText='margin:8px 0;padding:10px 11px;border:1px solid rgba(255,255,255,.11);border-radius:10px;background:rgba(255,255,255,.035);font-size:11px;line-height:1.45';
    c.innerHTML='<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px"><strong>EAN-13 VECTOR</strong><span id="v1461EanBadge" style="opacity:.72">'+VERSION+' SAFE</span></div>'+
      '<div><b>12 số</b> → tự tính check digit. <b>13 số</b> → kiểm tra checksum trước khi vẽ.</div>'+
      '<div style="opacity:.72;margin-top:4px">Khuyến nghị khung rộng ≥ 30 mm. Mã được tạo bằng vector 100K, có quiet zone và số đọc bên dưới.</div>';
    if(anchor&&anchor.parentNode===root.parentNode){ root.parentNode.insertBefore(c,anchor.nextSibling); }
    else{ root.parentNode.insertBefore(c,root.nextSibling); }
  }
  function updateCard(){
    var root=$('vdpMappings'), badge=$('v1461EanBadge'), a, i, n=0;
    if(!root||!badge) return;
    a=root.querySelectorAll('select.vdp-action');
    for(i=0;i<a.length;i++) if(a[i].value==='ean13Vector') n++;
    badge.textContent=VERSION+' SAFE · EAN '+n;
  }
  var tries=0,t=setInterval(function(){tries++;if(enhance()||tries>60)clearInterval(t);},500);
  document.addEventListener('click',function(){setTimeout(enhance,30);},false);
})();
