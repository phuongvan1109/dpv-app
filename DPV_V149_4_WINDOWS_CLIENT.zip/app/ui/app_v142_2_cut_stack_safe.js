(function(){
  'use strict';
  var running=false,statusObserver=null;
  function $(id){return document.getElementById(id);}
  function q(s,r){return (r||document).querySelector?(r||document).querySelector(s):null;}
  function txt(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function status(m,k){try{if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}catch(e){}}
  function getState(){if(!window.DPVVDP101||typeof window.DPVVDP101.getState!=='function')throw new Error('VDP Core V141.2 chưa sẵn sàng.');return window.DPVVDP101.getState();}
  function getRecords(){if(!window.DPVVDP101||typeof window.DPVVDP101.getRecords!=='function')return [];return window.DPVVDP101.getRecords();}
  function getCore(){
    if(!window.DPVCoreV101||typeof window.DPVCoreV101.getConfig!=='function')throw new Error('Core V101 chưa sẵn sàng.');
    var c=window.DPVCoreV101.getConfig(),l=c&&(c.precomputedLayoutV101||c.precomputedLayoutV99);
    if(!l||!l.items||!l.items.length)throw new Error('Chưa có bố cục V101. Đóng VDP → Tính nhanh → mở VDP lại.');
    return {config:c,layout:l};
  }
  function rangeInfo(){
    var st=getState(),total=Math.max(0,Number(st.recordCount||0)),from=Math.max(1,Math.floor(Number($('vdpFrom')&&$('vdpFrom').value)||1)),to=Math.min(total,Math.max(from,Math.floor(Number($('vdpTo')&&$('vdpTo').value)||total)));
    return {total:total,from:from,to:to,count:total?Math.max(0,to-from+1):0};
  }
  function makePlan(n,slots){
    n=Math.max(0,Math.floor(Number(n)||0));slots=Math.max(1,Math.floor(Number(slots)||1));
    var base=Math.floor(n/slots),rem=n%slots,sheets=Math.ceil(n/slots),sizes=[],starts=[],p,j,c=0,order=[],matrix=[],row,idx;
    for(p=0;p<slots;p++){sizes[p]=base+(p<rem?1:0);starts[p]=c;c+=sizes[p];}
    for(j=0;j<sheets;j++){
      row=[];
      for(p=0;p<slots;p++){
        if(j<sizes[p]){idx=starts[p]+j;order.push(idx);row[p]=idx;}else row[p]=-1;
      }
      matrix.push(row);
    }
    return {count:n,slots:slots,sheets:sheets,sizes:sizes,starts:starts,order:order,matrix:matrix};
  }
  function reorder(records,plan){var out=[],i;for(i=0;i<plan.order.length;i++)out.push(records[plan.order[i]]);return out;}
  function cloneRecord(o){var n={},k;o=o||{};for(k in o){if(Object.prototype.hasOwnProperty.call(o,k))n[k]=o[k];}return n;}
  function orderLabel(){var e=$('vdpSheetOrder'),v=e?String(e.value||'row'):'row';if(v==='column')return 'Trên → dưới, trái → phải';if(v==='snake')return 'Ziczac theo hàng';return 'Trái → phải, trên → dưới';}
  function preview(){
    var box=$('v1422PlanPreview');if(!box)return;
    try{
      var x=getCore(),r=rangeInfo(),slots=x.layout.items.length,plan=makePlan(r.count,slots),maxS=Math.min(slots,8),maxRows=Math.min(plan.sheets,8),html='',p,j,a,b;
      if(!r.count){box.innerHTML='Chưa có record trong phạm vi đang chọn.';return;}
      html+='<div class="v1422-summary"><b>'+r.count+' record</b> · <b>'+slots+' vị trí/tờ</b> · <b>'+plan.sheets+' tờ</b><br><span>VT1…VT'+slots+' được hiểu theo: '+esc(orderLabel())+'.</span></div>';
      html+='<div class="v1422-stacks">';
      for(p=0;p<Math.min(slots,10);p++){if(!plan.sizes[p])continue;a=r.from+plan.starts[p];b=a+plan.sizes[p]-1;html+='<span><b>VT'+(p+1)+'</b> '+a+'→'+b+'</span>';}
      if(slots>10)html+='<span>… +'+(slots-10)+' vị trí</span>';html+='</div>';
      html+='<div class="v1422-table-wrap"><table class="v1422-table"><thead><tr><th>Tờ</th>';
      for(p=0;p<maxS;p++)html+='<th>VT'+(p+1)+'</th>';if(slots>maxS)html+='<th>…</th>';html+='</tr></thead><tbody>';
      for(j=0;j<maxRows;j++){html+='<tr><th>'+(j+1)+'</th>';for(p=0;p<maxS;p++){html+='<td>'+(plan.matrix[j][p]>=0?(r.from+plan.matrix[j][p]):'—')+'</td>';}if(slots>maxS)html+='<td>…</td>';html+='</tr>';}
      if(plan.sheets>maxRows)html+='<tr><th>…</th><td colspan="'+(maxS+(slots>maxS?1:0))+'">… '+(plan.sheets-maxRows)+' tờ còn lại</td></tr>';
      html+='</tbody></table></div>';
      html+='<div class="v1422-result"><b>Sau khi cắt:</b> chồng xấp <b>VT1 → VT2 → VT3 → …</b> sẽ ra đúng <b>'+r.from+' → '+r.to+'</b>.</div>';
      box.innerHTML=html;
    }catch(e){box.innerHTML='<span class="v1422-error">'+esc(String(e&&e.message?e.message:e))+'</span>';}
  }
  function buildSheetConfig(x){
    var c=x.config,sourceW=Number(x.layout.sourceW||((c.sources&&c.sources.length)?c.sources[0].width:0)||0),sourceH=Number(x.layout.sourceH||((c.sources&&c.sources.length)?c.sources[0].height:0)||0),sc={
      paperW:Number(c.paperW),paperH:Number(c.paperH),margin:Number(c.margin),header:Number(c.header),gapX:Number(c.gapX),gapY:Number(c.gapY),
      sourceW:sourceW,sourceH:sourceH,linkBleed:Math.max(0,Number(c.linkBleed||0)),addTitle:c.addTitle===true,
      ponPath:String(c.ponPath||''),fitPon:c.fitPon===true,autoPon:c.autoPon===true,ponProcessBlack:c.ponProcessBlack===true,cornerPonRed:c.cornerPonRed===true,
      finishCropMarks:c.finishCropMarks===true,finishMarkLength:Math.max(.1,Number(c.finishMarkLength||6)),finishMarkGap:Math.max(0,Number(c.finishMarkGap||0)),
      cornerSafe:c.cornerSafe===true,cornerZone:Math.max(0,Number(c.cornerZone||0)),preservePrintColor:c.preservePrintColor!==false,
      duplexMode:c.duplexMode===true,duplexFlip:String(c.duplexFlip||'tumble180')
    };
    if($('vdpSheetUsePon')&&!$('vdpSheetUsePon').checked){sc.ponPath='';sc.autoPon=false;sc.addTitle=false;}
    return sc;
  }
  function build(){
    var btn=$('v1422Build');
    try{
      if(running)throw new Error('CUT & STACK đang chạy. Hãy chờ job hiện tại hoàn tất.');
      var st=getState(),all=getRecords(),r=rangeInfo(),out=$('vdpOutputPath')?String($('vdpOutputPath').value||''):'',x=getCore(),slots=x.layout.items.length,selected,plan,recs,sc,cfg;
      if(!r.count||!all.length)throw new Error('Chưa có dữ liệu CSV/TXT hoặc Dãy số tự động.');
      if(!st.mappings||!st.mappings.length)throw new Error('Chưa map dữ liệu vào đối tượng Illustrator.');
      if(!out)throw new Error('Chưa chọn thư mục xuất PDF.');
      selected=[];var si,sr;for(si=r.from-1;si<r.to;si++){sr=cloneRecord(all[si]||{});sr.__DPV1422_ORIGINAL_RECORD__=String(si+1);selected.push(sr);}plan=makePlan(selected.length,slots);recs=reorder(selected,plan);sc=buildSheetConfig(x);
      cfg={
        dataPath:'',records:recs,mappings:st.mappings,sourceFolder:st.sourceFolder||'',outputPath:out,from:1,to:recs.length,
        fileNameField:$('vdpFileNameField')?String($('vdpFileNameField').value||''):'',filePrefix:$('vdpFilePrefix')?String($('vdpFilePrefix').value||'VDP'):'VDP',
        exportIndividual:$('vdpSheetKeepRecords')&&$('vdpSheetKeepRecords').checked===true,combinePdf:false,
        sheetMode:true,sheetLayout:x.layout,sheetConfig:sc,sheetOrder:$('vdpSheetOrder')?String($('vdpSheetOrder').value||'row'):'row',lastSheetMode:'blank',
        keepRecordPdfs:$('vdpSheetKeepRecords')&&$('vdpSheetKeepRecords').checked===true,combineSheets:!$('vdpSheetCombine')||$('vdpSheetCombine').checked===true,
        sheetPrefix:$('vdpSheetPrefix')?String($('vdpSheetPrefix').value||'VDP_SHEET'):'VDP_SHEET',sheetCombinedName:$('vdpSheetCombinedName')?String($('vdpSheetCombinedName').value||'VDP_ALL_SHEETS'):'VDP_ALL_SHEETS'
      };
      if(cfg.keepRecordPdfs===true&&!cfg.fileNameField){cfg.fileNameField='__DPV1422_ORIGINAL_RECORD__';}
      running=true;if(btn){btn.setAttribute('data-running','1');txt(btn,'Đang chạy CUT & STACK…');}
      status('V142.2 CUT & STACK SAFE: '+r.count+' record · '+slots+' vị trí/tờ · '+plan.sheets+' tờ · VT1→VT2→… sau cắt sẽ đúng '+r.from+'→'+r.to+'.','work');
      window.DPVVDP101.bridgeCall('BuildVariableData',[JSON.stringify(cfg)]);
    }catch(e){running=false;if(btn){btn.removeAttribute('data-running');txt(btn,'Dàn CUT & STACK & xuất PDF tờ');}status('V142.2 CUT & STACK: '+String(e&&e.message?e.message:e),'error');}
    return false;
  }
  function monitorStatus(){
    var s=$('vdpStatus');if(!s||statusObserver||!window.MutationObserver)return;
    statusObserver=new MutationObserver(function(){var t=String(s.textContent||s.innerText||'');if(!running)return;if(/Hoàn tất VDP Sheet|VDP Sheet lỗi|Không chạy được VDP Sheet|Batch VDP.*lỗi|lỗi:/i.test(t)){running=false;var b=$('v1422Build');if(b){b.removeAttribute('data-running');txt(b,'Dàn CUT & STACK & xuất PDF tờ');}}});
    statusObserver.observe(s,{childList:true,subtree:true,characterData:true});
  }
  function insertUI(){
    var panel=$('vdpSheetPanel'),anchor;if(!panel)return false;if($('v1422CutStackPanel'))return true;
    anchor=q('.form-grid.compact',panel);if(!anchor)return false;
    var d=document.createElement('div');d.id='v1422CutStackPanel';d.className='v1422-cutstack';d.innerHTML=''
      +'<div class="v1422-head"><div><b>CẮT XẢ TUẦN TỰ · CUT & STACK</b><span>SAFE ADD-ON · không thay nút dàn thường</span></div><span class="v1422-badge">V142.2</span></div>'
      +'<div class="v1422-explain">DPV chia record thành từng xấp theo <b>Vị trí 1, Vị trí 2, Vị trí 3…</b>. Sau khi in → gom tờ → cắt → chồng <b>VT1 → VT2 → VT3 → …</b>, thành phẩm sẽ chạy đúng thứ tự liên tục.</div>'
      +'<div id="v1422PlanPreview" class="v1422-preview">Đang tính sơ đồ cắt xả…</div>'
      +'<div class="v1422-actions"><button type="button" id="v1422Refresh">Cập nhật sơ đồ</button><button type="button" id="v1422Build" class="primary">Dàn CUT & STACK & xuất PDF tờ</button></div>'
      +'<div class="v1422-note"><b>An toàn:</b> nút <b>Dàn dữ liệu lên khổ in & xuất PDF tờ</b> cũ vẫn chạy nguyên V141.2/V142.1. CUT & STACK dùng nút riêng, chỉ reorder một bản sao record trong RAM. <b>Tờ cuối luôn để trống vị trí dư</b>; không dồn giữa vì sẽ phá thứ tự xấp.</div>';
    anchor.parentNode.insertBefore(d,anchor.nextSibling);
    $('v1422Refresh').onclick=preview;$('v1422Build').onclick=build;
    var ids=['vdpFrom','vdpTo','vdpSheetOrder','vdpSheetRefresh'],i,e;for(i=0;i<ids.length;i++){e=$(ids[i]);if(e&&e.addEventListener)e.addEventListener('change',function(){window.setTimeout(preview,40);},false);}
    if($('vdpSheetRefresh')&&$('vdpSheetRefresh').addEventListener)$('vdpSheetRefresh').addEventListener('click',function(){window.setTimeout(preview,100);},false);
    preview();monitorStatus();
    var kicker=q('.vdp-kicker');if(kicker&&!$('v1422HeaderBadge')){var b=document.createElement('span');b.id='v1422HeaderBadge';b.className='v1422-header-badge';b.innerHTML='CUT & STACK';kicker.appendChild(b);}
    window.DPVCutStackV1422={makePlan:makePlan,reorder:reorder,preview:preview,build:build};
    return true;
  }
  function start(){var n=0,t=setInterval(function(){n++;if(insertUI()||n>40)clearInterval(t);},150);}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();
