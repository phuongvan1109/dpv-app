/* DPV V147.5.2 WINDOWS FONT PICKER HOTFIX
   Fixes IE/WebBrowser <option style=display:none> incompatibility.
   Rebuilds the select with matching Illustrator fonts instead of hiding options.
   UI-only: no Bridge/Core/Barcode engine changes.
*/
(function(){
  'use strict';
  var master=null, searchTimer=null, lastQuery='';
  function $(id){return document.getElementById(id);} 
  function norm(s){return String(s==null?'':s).toLowerCase();}
  function snapshot(){
    var sel=$('v1475FontSelect'), i,o,a=[];
    if(!sel || sel.options.length<5) return false;
    /* Only snapshot the full Illustrator list, not a previously filtered subset. */
    if(master && master.length>=sel.options.length-1) return true;
    for(i=1;i<sel.options.length;i++){
      o=sel.options[i];
      a.push({
        value:String(o.value||''),
        text:String(o.text||o.textContent||o.innerText||o.value||''),
        family:String(o.getAttribute('data-family')||''),
        style:String(o.getAttribute('data-style')||''),
        search:String(o.getAttribute('data-search')||((o.text||'')+' '+(o.value||''))).toLowerCase()
      });
    }
    if(a.length){master=a;return true;}
    return false;
  }
  function optionFrom(f){
    var o=document.createElement('option');
    o.value=f.value;o.text=f.text;
    o.setAttribute('data-family',f.family);o.setAttribute('data-style',f.style);o.setAttribute('data-search',f.search);
    return o;
  }
  function dispatchChange(sel){
    try{var ev=document.createEvent('HTMLEvents');ev.initEvent('change',true,false);sel.dispatchEvent(ev);}
    catch(e){try{if(sel.fireEvent)sel.fireEvent('onchange');}catch(x){}}
  }
  function rebuild(q){
    var sel=$('v1475FontSelect'),st=$('v1475FontStatus'),i,f,matches=[],cur;
    if(!sel || !snapshot()) return;
    q=norm(q).replace(/^\s+|\s+$/g,''); lastQuery=q; cur=String(sel.value||'');
    for(i=0;i<master.length;i++){
      f=master[i];
      if(!q || f.search.indexOf(q)>=0) matches.push(f);
    }
    /* Keep Windows WebBrowser responsive when searching 2000+ fonts. */
    if(q && matches.length>300) matches=matches.slice(0,300);
    while(sel.options.length) sel.remove(0);
    var head=document.createElement('option'); head.value=''; head.text=q?'— '+matches.length+' font phù hợp —':'— Chọn font Illustrator —'; sel.add(head);
    for(i=0;i<matches.length;i++) sel.add(optionFrom(matches[i]));
    var selected=-1;
    if(cur){for(i=1;i<sel.options.length;i++){if(sel.options[i].value===cur){selected=i;break;}}}
    if(selected<0 && matches.length) selected=1;
    if(selected>0){sel.selectedIndex=selected;dispatchChange(sel);}
    if(st){
      if(!matches.length) st.textContent='Không tìm thấy font khớp “'+q+'”. Hãy thử tên Family hoặc PostScript khác.';
      else if(q) st.textContent='Tìm thấy '+matches.length+' font · đang chọn: '+String(sel.options[sel.selectedIndex].text||sel.value);
      else st.textContent='Đã đồng bộ '+master.length+' font từ Illustrator · chọn font trong danh sách.';
    }
  }
  function onSearch(){
    if(searchTimer) clearTimeout(searchTimer);
    searchTimer=setTimeout(function(){rebuild(($('v1475FontSearch')||{}).value||'');},120);
  }
  function bind(){
    var inp=$('v1475FontSearch'),sel=$('v1475FontSelect'),reload=$('v1475ReloadFonts');
    if(!inp||!sel) return false;
    snapshot();
    if(!inp.__v14752){
      inp.__v14752=true;
      if(inp.addEventListener){inp.addEventListener('input',onSearch,false);inp.addEventListener('keyup',function(e){e=e||window.event;if(e.keyCode===13)rebuild(inp.value);},false);}
      else if(inp.attachEvent){inp.attachEvent('onkeyup',onSearch);}
    }
    if(reload&&!reload.__v14752){
      reload.__v14752=true;
      if(reload.addEventListener) reload.addEventListener('click',function(){master=null;setTimeout(function(){snapshot();rebuild(inp.value||'');},900);},false);
    }
    /* If user already typed before this patch bound, apply it immediately. */
    if(inp.value && norm(inp.value)!==lastQuery) rebuild(inp.value);
    return true;
  }
  var tries=0,t=setInterval(function(){tries++;bind();if(tries>240)clearInterval(t);},350);
  if(document.addEventListener)document.addEventListener('click',function(){setTimeout(bind,30);},false);
})();
