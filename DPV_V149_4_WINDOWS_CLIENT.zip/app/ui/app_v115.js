(function(){
  "use strict";
  function add(el,c){if(!el)return;if((' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(!el)return;el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function setMode(){
    var w=(document.documentElement&&document.documentElement.clientWidth)||window.innerWidth||1400;
    var h=(document.documentElement&&document.documentElement.clientHeight)||window.innerHeight||850;
    var b=document.body;
    rem(b,'dpv-compact-sidebar');rem(b,'dpv-layout-medium');rem(b,'dpv-layout-two');rem(b,'dpv-layout-stack');rem(b,'dpv-short-window');
    if(w<1370)add(b,'dpv-compact-sidebar');
    if(w>=1120&&w<1370)add(b,'dpv-layout-medium');
    else if(w>=930&&w<1120)add(b,'dpv-layout-two');
    else if(w<930)add(b,'dpv-layout-stack');
    if(h<760)add(b,'dpv-short-window');
  }
  function platform(){
    var ua=String(navigator.userAgent||'').toLowerCase();
    if(ua.indexOf('windows')>=0 || ua.indexOf('trident')>=0){add(document.body,'dpv-windows');add(document.body,'dpv-win-fast');}
    else add(document.body,'dpv-mac');
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;
    if(v)v.innerHTML='V115 RESPONSIVE FAST · CORE V101 STABLE';
    var b=document.querySelector?document.querySelector('.beta-note'):null;
    if(b)b.innerHTML='<strong>DPV® V115 Responsive Fast · Core V101 Stable</strong><br>Giao diện tự co/stack khi thu nhỏ cửa sổ · Windows Fast UI giảm animation/shadow nặng · không thay engine dàn, PON, VDP hay Bridge Illustrator.';
  }
  var timer=0;
  function resized(){if(timer)clearTimeout(timer);timer=setTimeout(setMode,80);}
  function start(){platform();setMode();mark();if(window.addEventListener)window.addEventListener('resize',resized,false);else window.attachEvent('onresize',resized);}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();
