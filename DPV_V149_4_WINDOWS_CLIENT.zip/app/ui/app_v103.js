(function () {
  var lastResult=null, lastConfig=null, exactView=true;
  var mainState={zoom:1,panX:0,panY:0,drag:false,lastX:0,lastY:0};
  var fullState={zoom:1,panX:0,panY:0,drag:false,lastX:0,lastY:0};
  function $(id){return document.getElementById(id);}
  function txt(el,s){if(!el)return; if('textContent' in el)el.textContent=s; else el.innerText=s;}
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function isDark(){return (' '+document.body.className+' ').indexOf(' dpv-dark ')>=0;}
  function ensureShell(){
    var canvas=$('layoutCanvas'); if(!canvas||$('layoutZoomMinus'))return;
    var parent=canvas.parentNode, vp=document.createElement('div'); vp.id='layoutViewport'; vp.className='layout-viewport';
    parent.insertBefore(vp,canvas); vp.appendChild(canvas);
    var sh=parent.querySelector?parent.querySelector('.subhead'):null;
    if(sh){
      var tb=document.createElement('div'); tb.className='layout-view-tools';
      tb.innerHTML='<button id="layoutZoomMinus" class="layout-tool" title="Thu nhỏ">−</button>'+
        '<span id="layoutZoomLabel" class="layout-zoom-label">100%</span>'+
        '<button id="layoutZoomPlus" class="layout-tool" title="Phóng to">+</button>'+
        '<button id="layoutZoomFit" class="layout-tool text">Vừa khổ</button>'+
        '<button id="layoutExactView" class="layout-tool text active" title="Vẽ trực tiếp contour KHUON_BE thật">Khuôn thật</button>'+
        '<button id="layoutFullscreen" class="layout-tool" title="Xem toàn màn hình">⛶</button>';
      sh.appendChild(tb);
    }
    var overlay=document.createElement('div'); overlay.id='layoutFullscreenOverlay'; overlay.className='layout-fullscreen hidden';
    overlay.innerHTML='<div class="layout-fullscreen-panel"><div class="layout-fullscreen-head"><div><strong>Xem trực tiếp sơ đồ dàn</strong><span id="layoutFullCaption"></span></div><div class="layout-view-tools"><button id="layoutFullMinus" class="layout-tool">−</button><span id="layoutFullZoomLabel" class="layout-zoom-label">100%</span><button id="layoutFullPlus" class="layout-tool">+</button><button id="layoutFullFit" class="layout-tool text">Vừa khổ</button><button id="layoutFullClose" class="layout-tool danger">×</button></div></div><div id="layoutFullViewport" class="layout-viewport fullscreen"><canvas id="layoutFullCanvas" width="1280" height="760"></canvas></div><div class="layout-hint">Cuộn chuột để zoom · Kéo chuột để di chuyển · Double-click để vừa khổ · Khuôn thật = contour KHUON_BE trực tiếp</div></div>';
    document.body.appendChild(overlay);
    bindView(vp,canvas,mainState,'layoutZoomLabel');
    bindView($('layoutFullViewport'),$('layoutFullCanvas'),fullState,'layoutFullZoomLabel');
    $('layoutZoomMinus').onclick=function(){zoomBy(mainState,canvas,-.2,'layoutZoomLabel');};
    $('layoutZoomPlus').onclick=function(){zoomBy(mainState,canvas,.2,'layoutZoomLabel');};
    $('layoutZoomFit').onclick=function(){fitView(mainState,canvas,'layoutZoomLabel');};
    $('layoutExactView').onclick=function(){exactView=!exactView; this.className='layout-tool text'+(exactView?' active':''); txt(this,exactView?'Khuôn thật':'Khung nhanh'); if(lastResult&&lastConfig)renderEnhanced(canvas,lastResult,lastConfig); if(!overlay.className.match(/hidden/)&&lastResult&&lastConfig)renderEnhanced($('layoutFullCanvas'),lastResult,lastConfig);};
    $('layoutFullscreen').onclick=function(){openFull();};
    $('layoutFullClose').onclick=function(){overlay.className='layout-fullscreen hidden';};
    $('layoutFullMinus').onclick=function(){zoomBy(fullState,$('layoutFullCanvas'),-.2,'layoutFullZoomLabel');};
    $('layoutFullPlus').onclick=function(){zoomBy(fullState,$('layoutFullCanvas'),.2,'layoutFullZoomLabel');};
    $('layoutFullFit').onclick=function(){fitView(fullState,$('layoutFullCanvas'),'layoutFullZoomLabel');};
  }
  function setTransform(st,canvas,labelId){
    canvas.style.transformOrigin='0 0';
    canvas.style.transform='translate('+st.panX+'px,'+st.panY+'px) scale('+st.zoom+')';
    txt($(labelId),Math.round(st.zoom*100)+'%');
  }
  function fitView(st,canvas,labelId){st.zoom=1;st.panX=0;st.panY=0;setTransform(st,canvas,labelId);}
  function zoomBy(st,canvas,delta,labelId,cx,cy){
    var old=st.zoom, nz=clamp(old+delta,.25,8); if(nz===old)return;
    if(cx===undefined){cx=canvas.clientWidth/2;cy=canvas.clientHeight/2;}
    st.panX=cx-(cx-st.panX)*(nz/old); st.panY=cy-(cy-st.panY)*(nz/old); st.zoom=nz; setTransform(st,canvas,labelId);
  }
  function bindView(vp,canvas,st,labelId){
    if(!vp||!canvas)return;
    function wheel(e){e=e||window.event; var d=0; if(e.deltaY!==undefined)d=e.deltaY; else if(e.wheelDelta!==undefined)d=-e.wheelDelta; var r=vp.getBoundingClientRect?vp.getBoundingClientRect():{left:0,top:0}; var cx=(e.clientX||0)-r.left,cy=(e.clientY||0)-r.top; zoomBy(st,canvas,d<0?.18:-.18,labelId,cx,cy); try{e.preventDefault();}catch(x){} return false;}
    if(vp.addEventListener){vp.addEventListener('wheel',wheel,{passive:false});vp.addEventListener('mousewheel',wheel,false);}else vp.onmousewheel=wheel;
    vp.onmousedown=function(e){e=e||window.event;st.drag=true;st.lastX=e.clientX;st.lastY=e.clientY;vp.className+=' dragging';return false;};
    document.addEventListener&&document.addEventListener('mousemove',function(e){if(!st.drag)return; st.panX+=e.clientX-st.lastX;st.panY+=e.clientY-st.lastY;st.lastX=e.clientX;st.lastY=e.clientY;setTransform(st,canvas,labelId);});
    document.addEventListener&&document.addEventListener('mouseup',function(){if(st.drag){st.drag=false;vp.className=vp.className.replace(/\sdragging/g,'');}});
    vp.ondblclick=function(){fitView(st,canvas,labelId);};
  }
  function openFull(){
    var o=$('layoutFullscreenOverlay'),c=$('layoutFullCanvas'); if(!o||!c)return; o.className='layout-fullscreen';
    var w=Math.max(900,(window.innerWidth||1400)-110),h=Math.max(560,(window.innerHeight||900)-150); c.width=w;c.height=h;
    fitView(fullState,c,'layoutFullZoomLabel'); if(lastResult&&lastConfig)renderEnhanced(c,lastResult,lastConfig); else copyCanvas($('layoutCanvas'),c);
    txt($('layoutFullCaption'),$('layoutCaption')?(' · '+($('layoutCaption').textContent||$('layoutCaption').innerText||'')):'');
  }
  function copyCanvas(src,dst){if(!src||!dst)return;var ctx=dst.getContext('2d');ctx.clearRect(0,0,dst.width,dst.height);ctx.drawImage(src,0,0,dst.width,dst.height);}
  function getVariant(shape,item){
    if(!shape||!shape.points||shape.points.length<3)return null;
    var a=item.angle!==undefined?Number(item.angle):(item.rotated===true?90:0);
    try{if(window.ANPTrueShape&&ANPTrueShape.rotateVariant)return ANPTrueShape.rotateVariant(shape.points,Number(shape.w||item.w),Number(shape.h||item.h),a);}catch(e){}
    return null;
  }
  function renderEnhanced(canvas,result,c){
    if(!canvas||!result||!c)return; var layout=result.layout;if(!layout||!layout.items||!layout.items.length)return;
    var ctx=canvas.getContext('2d'), pad=canvas=== $('layoutFullCanvas')?34:12, paperW=Number(c.paperW),paperH=Number(c.paperH); if(!(paperW>0&&paperH>0))return;
    var scale=Math.min((canvas.width-pad*2)/paperW,(canvas.height-pad*2)/paperH), sw=paperW*scale,sh=paperH*scale,ox=(canvas.width-sw)/2,oy=(canvas.height-sh)/2;
    var dark=isDark(), bg=dark?'#0a1725':'#f5f1e4', sheet=dark?'#0d2030':'#fffefa', border=dark?'#718298':'#172033', marginC=dark?'rgba(55,211,166,.8)':'rgba(8,168,120,.78)';
    ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle=bg;ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle=sheet;ctx.fillRect(ox,oy,sw,sh);ctx.strokeStyle=border;ctx.lineWidth=1.2;ctx.strokeRect(ox+.5,oy+.5,sw-1,sh-1);
    ctx.save();ctx.strokeStyle=marginC;ctx.lineWidth=1;if(ctx.setLineDash)ctx.setLineDash([5,4]);ctx.strokeRect(ox+Number(c.margin)*scale,oy+Number(c.margin)*scale,Math.max(0,(paperW-Number(c.margin)*2)*scale),Math.max(0,(paperH-Number(c.margin)*2)*scale));ctx.restore();
    var items=layout.items, maxDraw=canvas===$('layoutFullCanvas')?5000:2600,stride=Math.max(1,Math.ceil(items.length/maxDraw));
    var colors=dark?['#f6bf22','#28c69a','#ff7b59','#48b8d4','#8bcf65','#e7a932']:['#e5a900','#08a878','#e85a32','#1399af','#6cad3c','#d68d00'];
    for(var i=0;i<items.length;i+=stride){
      var it=items[i],si=Math.max(0,Number(it.sourceIndex)||0),src=(c.sources&&c.sources[si])||(c.sources&&c.sources[0])||{},col=colors[si%colors.length];
      var bx=ox+(Number(c.margin)+Number(it.x))*scale,by=oy+(Number(c.margin)+Number(it.y))*scale,variant=exactView?getVariant(src.shape,it):null;
      ctx.beginPath();
      if(variant&&variant.points&&variant.points.length>=3){
        for(var p=0;p<variant.points.length;p++){var px=bx+Number(variant.points[p].x)*scale,py=by+Number(variant.points[p].y)*scale;if(p===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);}ctx.closePath();
      } else if(src.shape&&src.shape.isCircle===true){var ww=Number(it.w)*scale,hh=Number(it.h)*scale;ctx.arc(bx+ww/2,by+hh/2,Math.min(ww,hh)/2,0,Math.PI*2,false);
      } else {ctx.rect(bx+Number(it.offsetX||0)*scale,by+Number(it.offsetY||0)*scale,Number(it.w)*scale,Number(it.h)*scale);}
      ctx.fillStyle=col;ctx.globalAlpha=dark?.11:.12;ctx.fill();ctx.globalAlpha=1;ctx.strokeStyle=col;ctx.lineWidth=Math.max(.65,Math.min(1.5,scale*.14));ctx.stroke();
      if(canvas===$('layoutFullCanvas')&&fullState.zoom>=1.5&&items.length<250){ctx.fillStyle=dark?'#9fb1c5':'#53637a';ctx.font='10px Segoe UI, Arial';ctx.fillText(String(i+1),bx+3,by+12);}
    }
    if(canvas===$('layoutCanvas')){var cap=$('layoutCaption'); if(cap){var base=items.length+' con trên '+paperW+'×'+paperH+' mm';txt(cap,base+(exactView?' · view KHUON_BE thật':' · khung nhanh'));}}
  }
  function hookEngine(){
    if(!window.VDPROEngine||!VDPROEngine.preview||VDPROEngine.__v103Hook)return;
    var old=VDPROEngine.preview; VDPROEngine.preview=function(c){var r=old.apply(VDPROEngine,arguments); lastConfig=c;lastResult=r; setTimeout(function(){try{renderEnhanced($('layoutCanvas'),r,c);}catch(e){}},0);return r;}; VDPROEngine.__v103Hook=true;
  }
  function updateLabels(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V103 LIVE PREVIEW · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V103 LIVE PREVIEW · CORE V101 STABLE</strong><br>Zoom 25–800% · kéo để pan · full-screen · xem contour KHUON_BE trực tiếp · engine V101 không thay đổi.';
  }
  function start(){ensureShell();hookEngine();updateLabels();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();
