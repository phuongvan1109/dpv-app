/* DPV V142.5 — LAST SHEET BASE-FILL SAFE ADD-ON
   Additive rules:
   - Does not modify V141.2 handlers, V142.1 SMART, V142.2 Cut & Stack, V142.4 Duplex.
   - Adds a new last-sheet mode: BASE FILL = original artwork, no variable data.
   - Cut & Stack button is intercepted only at config-send time to force basefill.
*/
(function () {
  'use strict';
  var MODE = 'basefill', patchedCutStack = false;
  function $(id) { return document.getElementById(id); }
  function q(sel, root) { return (root || document).querySelector ? (root || document).querySelector(sel) : null; }
  function text(el, s) { if (!el) { return; } if ('textContent' in el) { el.textContent = s; } else { el.innerText = s; } }
  function fireChange(el) {
    if (!el) { return; }
    try {
      if (document.createEvent) { var ev = document.createEvent('HTMLEvents'); ev.initEvent('change', true, false); el.dispatchEvent(ev); }
      else if (el.fireEvent) { el.fireEvent('onchange'); }
    } catch (e) {}
  }
  function hasOption(sel, value) {
    var i; if (!sel || !sel.options) { return false; }
    for (i = 0; i < sel.options.length; i++) { if (String(sel.options[i].value) === value) { return true; } }
    return false;
  }
  function addMode() {
    var sel = $('vdpLastSheetMode'), opt, field, note;
    if (!sel) { return false; }
    if (!hasOption(sel, MODE)) {
      opt = document.createElement('option'); opt.value = MODE;
      text(opt, 'Lấp file gốc · không dữ liệu — KHUYẾN NGHỊ');
      try { sel.insertBefore(opt, sel.options[0] || null); } catch (e0) { sel.appendChild(opt); }
    }
    /* Requested production default, applied only once per dynamically-created selector.
       After that the user may still choose the legacy blank/center modes manually. */
    if (!sel.__dpvV1425ModeInitialized) {
      sel.value = MODE;
      sel.__dpvV1425ModeInitialized = true;
      fireChange(sel);
    }
    field = sel.parentNode;
    if (field && !$('v1425LastSheetHint')) {
      note = document.createElement('div'); note.id = 'v1425LastSheetHint'; note.className = 'v1425-last-sheet-hint';
      note.innerHTML = '<b>V142.5:</b> record thật luôn chạy từ VT1 → VT cuối theo thứ tự tờ. Ô thiếu vẫn đặt <b>FILE GỐC</b> nhưng <b>không áp dữ liệu biến đổi</b>.';
      field.appendChild(note);
    }
    return true;
  }
  function patchCutStackButton() {
    var btn = $('v1422Build'), original;
    if (!btn || btn.__dpvV1425BaseFillPatched) { return false; }
    original = btn.onclick;
    if (typeof original !== 'function') { return false; }
    btn.onclick = function (ev) {
      var api = window.DPVVDP101, oldBridge, self = this;
      if (!api || typeof api.bridgeCall !== 'function') { return original.call(self, ev); }
      oldBridge = api.bridgeCall;
      api.bridgeCall = function (name, args) {
        var a = args, cfg;
        if (String(name) === 'BuildVariableData' && a && a.length) {
          try {
            cfg = JSON.parse(String(a[0] || '{}'));
            if (cfg && cfg.sheetMode === true) {
              cfg.lastSheetMode = MODE;
              cfg.v1425LastSheetBaseFill = true;
              a[0] = JSON.stringify(cfg);
            }
          } catch (eCfg) {}
        }
        return oldBridge.apply(api, arguments);
      };
      try { return original.call(self, ev); }
      finally { api.bridgeCall = oldBridge; }
    };
    btn.__dpvV1425BaseFillPatched = true; patchedCutStack = true;
    return true;
  }
  function markCutStackPreview() {
    var box = $('v1422PlanPreview'), cells, i, s, note;
    if (!box) { return; }
    cells = box.getElementsByTagName('td');
    for (i = 0; i < cells.length; i++) {
      s = String(cells[i].textContent || cells[i].innerText || '').replace(/^\s+|\s+$/g, '');
      if (s === '—') { cells[i].innerHTML = '<span class="v1425-base-cell">FILE GỐC<br><small>NO DATA</small></span>'; }
    }
    note = q('.v1422-note');
    if (note && !note.__dpvV1425Changed) {
      note.innerHTML = '<b>V142.5 an toàn cho Cut & Stack:</b> tờ cuối <b>không dồn giữa và không bỏ trống artwork</b>. Record thật đi từ VT1 trở đi; vị trí dư tự đặt <b>file gốc không dữ liệu</b>, giữ form cắt giống các tờ trước.';
      note.__dpvV1425Changed = true;
    }
  }
  function observeCutStack() {
    var box = $('v1422PlanPreview');
    if (!box || !window.MutationObserver || box.__dpvV1425Observed) { markCutStackPreview(); return; }
    box.__dpvV1425Observed = true;
    (new MutationObserver(function () { markCutStackPreview(); })).observe(box, { childList:true, subtree:true });
    markCutStackPreview();
  }
  function version() {
    var v = q('.version-badge'), badge = 'V142.5 LAST-SHEET BASE FILL SAFE · CORE V101 STABLE', title = 'DPV® V142.5 — Last-Sheet Base Fill Safe · Core V101 Stable';
    if (v && String(v.innerHTML || '') !== badge) { v.innerHTML = badge; }
    try { if (String(document.title || '') !== title) { document.title = title; } } catch (e) {}
  }
  function initOnce() {
    addMode(); patchCutStackButton(); observeCutStack(); version();
  }
  function init() {
    initOnce();
    /* VDP Sheet/CutStack panels are created dynamically. Observe DOM creation instead
       of polling or replacing any stable V141/V142 handler. */
    if (window.MutationObserver && document.body && !document.body.__dpvV1425Observed) {
      document.body.__dpvV1425Observed = true;
      (new MutationObserver(function () { initOnce(); })).observe(document.body, { childList:true, subtree:true });
    } else if (!window.MutationObserver) {
      window.setInterval(initOnce, 1000);
    }
  }
  if (document.readyState === 'loading') {
    if (document.addEventListener) { document.addEventListener('DOMContentLoaded', init, false); }
    else { window.attachEvent('onload', init); }
  } else { window.setTimeout(init, 0); }
}());
