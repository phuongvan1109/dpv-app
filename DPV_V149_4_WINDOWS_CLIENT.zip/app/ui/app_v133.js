(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function txt(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function add(el,c){if(el&&(' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(el)el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function status(m,k){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}
  var seq={active:false,records:[],field:'SO_NHAY',start:1,end:100,step:1,pad:false,width:4,prefix:'',suffix:''};
  var MAX=50000;
  function escCsv(v){v=String(v==null?'':v);return /[",\r\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}
  function absDigits(n){var s=String(Math.abs(Math.floor(Number(n)||0)));return s.length;}
  function padNum(n,w){var neg=Number(n)<0,s=String(Math.abs(Math.floor(Number(n)||0)));while(s.length<w)s='0'+s;return (neg?'-':'')+s;}
  function formatted(n){var core=seq.pad?padNum(n,Math.max(1,seq.width)):String(n);return seq.prefix+core+seq.suffix;}
  function read(){
    seq.field=String($('v133Field').value||'SO_NHAY').replace(/^\s+|\s+$/g,'')||'SO_NHAY';
    seq.start=Math.floor(Number($('v133Start').value)||0); seq.end=Math.floor(Number($('v133End').value)||0);
    seq.step=Math.max(1,Math.floor(Math.abs(Number($('v133Step').value)||1)));
    seq.pad=$('v133Pad').checked===true; seq.width=Math.max(1,Math.min(12,Math.floor(Number($('v133Width').value)||1)));
    seq.prefix=String($('v133Prefix').value||'');seq.suffix=String($('v133Suffix').value||'');
  }
  function count(){read();return Math.floor(Math.abs(seq.end-seq.start)/seq.step)+1;}
  function updatePreview(){
    read();var n=count(),dir=seq.end>=seq.start?1:-1,a=[],i,v=seq.start,lim=Math.min(4,n);
    $('v133Width').disabled=!seq.pad;
    for(i=0;i<lim;i++){a.push(formatted(v));v+=dir*seq.step;}
    var last=formatted(seq.start+dir*seq.step*(n-1));
    $('v133Sample').innerHTML='<b>'+n.toLocaleString()+' record</b> · '+a.join(' · ')+(n>lim?' · … · '+last:'');
  }
  function generate(){
    try{
      read();var n=count();if(n<1)throw new Error('Khoảng số không hợp lệ.');if(n>MAX)throw new Error('Tối đa '+MAX.toLocaleString()+' record/lần để Illustrator chạy ổn định. Hãy chia thành nhiều batch nếu cần.');
      var dir=seq.end>=seq.start?1:-1,lines=[escCsv(seq.field)],records=[],i,v=seq.start,val;
      for(i=0;i<n;i++){val=formatted(v);lines.push(escCsv(val));records.push((function(k,x){var o={};o[k]=x;return o;})(seq.field,val));v+=dir*seq.step;}
      seq.active=true;seq.records=records;
      if(!window.DPVVDP101||typeof window.DPVVDP101.loadFileResult!=='function')throw new Error('VDP Core chưa sẵn sàng.');
      window.DPVVDP101.loadFileResult(JSON.stringify({ok:true,path:'',folder:'',name:'Dãy số tự động · '+seq.field,text:lines.join('\r\n')}));
      status('Đã tạo '+n+' record số tự động · '+formatted(seq.start)+' → '+formatted(seq.end)+'. Không cần CSV/TXT.','ok');
      setMode('seq');
    }catch(e){status('Không tạo được dãy số: '+String(e&&e.message?e.message:e),'error');}
  }
  function setMode(mode){
    var seqMode=mode==='seq';
    if(!seqMode)seq.active=false;
    var a=$('v133CsvMode'),b=$('v133SeqMode'),box=$('v133SeqBox'),toolbar=$('vdpChooseDataBtn')&&$('vdpChooseDataBtn').parentNode;
    if(a){if(seqMode)rem(a,'active');else add(a,'active');}if(b){if(seqMode)add(b,'active');else rem(b,'active');}
    if(box){if(seqMode)rem(box,'v133-hidden');else add(box,'v133-hidden');}
    if(toolbar){if(seqMode)add(toolbar,'v133-hidden');else rem(toolbar,'v133-hidden');}
  }
  function makeUI(){
    if($('v133SourceSwitch'))return;
    var card=$('vdpChooseDataBtn');card=card&&card.parentNode&&card.parentNode.parentNode;if(!card)return;
    var sw=document.createElement('div');sw.id='v133SourceSwitch';sw.className='v133-source-switch';sw.innerHTML='<button id="v133CsvMode" type="button" class="active">CSV / TXT</button><button id="v133SeqMode" type="button">Dãy số tự động</button>';
    var first=card.querySelector?card.querySelector('.toolbar'):null;if(first)card.insertBefore(sw,first);else card.insertBefore(sw,card.firstChild);
    var box=document.createElement('div');box.id='v133SeqBox';box.className='v133-seq-box v133-hidden';box.innerHTML=''
      +'<div class="v133-seq-title"><strong>NHẢY SỐ KHÔNG CẦN CSV</strong><span class="v133-seq-badge">NUMBER SEQUENCE</span></div>'
      +'<div class="v133-seq-grid">'
      +'<div class="field"><label>Bắt đầu</label><input id="v133Start" type="number" value="1" step="1"></div>'
      +'<div class="field"><label>Kết thúc</label><input id="v133End" type="number" value="100" step="1"></div>'
      +'<div class="field"><label>Bước nhảy</label><input id="v133Step" type="number" value="1" min="1" step="1"></div>'
      +'<div class="field"><label>Tên cột để map</label><input id="v133Field" type="text" value="SO_NHAY"></div>'
      +'<div class="field"><label>Tiền tố (tuỳ chọn)</label><input id="v133Prefix" type="text" placeholder="VD: A-"></div>'
      +'<div class="field"><label>Hậu tố (tuỳ chọn)</label><input id="v133Suffix" type="text" placeholder="VD: -B"></div>'
      +'<label class="v133-seq-zero"><input id="v133Pad" type="checkbox"> Thêm số 0 phía trước <span>· độ dài</span><input id="v133Width" type="number" min="1" max="12" value="4" disabled> <span>chữ số</span></label>'
      +'</div><div id="v133Sample" class="v133-seq-preview"></div>'
      +'<div class="v133-seq-actions"><button id="v133Generate" type="button" class="button accent">Tạo dãy số & dùng ngay</button></div>'
      +'<div class="v133-seq-help">Ví dụ: 1 → 500, bật số 0 trước và đặt 4 chữ số → <b>0001, 0002, …, 0500</b>. Có thể thêm tiền tố/hậu tố như <b>SP-0001-A</b>. Sau khi tạo, map cột <b>SO_NHAY</b> vào Text và Preview/Xuất như CSV bình thường.</div>';
    sw.parentNode.insertBefore(box,sw.nextSibling);
    $('v133CsvMode').onclick=function(){setMode('csv');};$('v133SeqMode').onclick=function(){setMode('seq');updatePreview();};$('v133Generate').onclick=generate;
    var ids=['v133Start','v133End','v133Step','v133Field','v133Prefix','v133Suffix','v133Pad','v133Width'],i,el;
    for(i=0;i<ids.length;i++){el=$(ids[i]);if(el){el.onchange=updatePreview;el.onkeyup=updatePreview;}}
    updatePreview();
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V133 NUMBER SEQUENCE · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V133 Number Sequence · Core V101 Stable</strong><br>VDP thêm nguồn Dãy số tự động: Start / End / Step / số 0 phía trước / tiền tố / hậu tố · không cần CSV/TXT · dùng được cả PDF record và VDP Sheet.';
  }
  function expose(){window.DPVNumberSeqV133={isActive:function(){return seq.active===true;},getRecords:function(){return seq.records.slice(0);},getConfig:function(){return seq;}};}
  function start(){makeUI();mark();expose();var c=$('vdpChooseDataBtn');if(c&&c.addEventListener)c.addEventListener('click',function(){seq.active=false;},false);}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();
