/* DPV V147.8.3 — PRODUCTION PLANNER COLLAPSE SAFE
   UI-only additive patch. Does not change Production Planner calculations/Core/Bridge.
*/
(function(){
  'use strict';
  var KEY='dpv.v14783.productionPlanner.expanded';
  var mounted=false, retry=0, obs=null;
  function $(id){return document.getElementById(id);}
  function txt(id){var e=$(id);return e?String(('textContent' in e?e.textContent:e.innerText)||'').replace(/^\s+|\s+$/g,''):'—';}
  function val(id){var e=$(id);return e?String(e.value==null?'':e.value).replace(/^\s+|\s+$/g,''):'';}
  function getSaved(){try{return window.localStorage&&localStorage.getItem(KEY)==='1';}catch(e){return false;}}
  function save(v){try{if(window.localStorage)localStorage.setItem(KEY,v?'1':'0');}catch(e){}}
  function setText(el,s){if(!el)return;if('textContent' in el)el.textContent=s;else el.innerText=s;}
  function updateSummary(){
    var s=$('v14783PlannerSummary'); if(!s)return;
    var qty=val('v144TargetQty')||'—', waste=val('v144WastePct')||'0', count=txt('v144KpiCount'), sheets=txt('v144KpiSheets');
    setText(s,'SL '+qty+' · Hao hụt '+waste+'% · '+count+' con/tờ · '+sheets+' tờ');
  }
  function apply(expanded){
    var p=$('v144Planner'), body=$('v14783PlannerBody'), b=$('v14783PlannerToggle'); if(!p||!body||!b)return;
    if(expanded){p.className=p.className.replace(/\s*v14783-collapsed\b/g,'')+' v14783-expanded'; body.style.display='block'; setText(b,'Thu gọn'); b.setAttribute('aria-expanded','true');}
    else {p.className=p.className.replace(/\s*v14783-expanded\b/g,'')+' v14783-collapsed'; body.style.display='none'; setText(b,'Mở'); b.setAttribute('aria-expanded','false');}
    save(expanded); updateSummary();
  }
  function mount(){
    if(mounted)return true;
    var p=$('v144Planner'); if(!p)return false;
    var head=null, kids=p.children, i;
    for(i=0;i<kids.length;i++){if((' '+kids[i].className+' ').indexOf(' v144-head ')>=0){head=kids[i];break;}}
    if(!head)return false;
    var body=document.createElement('div'); body.id='v14783PlannerBody'; body.className='v14783-planner-body';
    var node=head.nextSibling, next;
    while(node){next=node.nextSibling;body.appendChild(node);node=next;}
    p.appendChild(body);
    var summary=document.createElement('div'); summary.id='v14783PlannerSummary'; summary.className='v14783-planner-summary';
    head.appendChild(summary);
    var btn=document.createElement('button'); btn.type='button'; btn.id='v14783PlannerToggle'; btn.className='v14783-planner-toggle'; btn.setAttribute('aria-expanded','false'); setText(btn,'Mở');
    head.appendChild(btn);
    btn.onclick=function(ev){if(ev&&ev.stopPropagation)ev.stopPropagation();apply(btn.getAttribute('aria-expanded')!=='true');};
    head.style.cursor='pointer';
    head.onclick=function(ev){var t=ev?ev.target:null;if(t===btn)return;apply(btn.getAttribute('aria-expanded')!=='true');};
    var ids=['v144TargetQty','v144WastePct'], e;
    for(i=0;i<ids.length;i++){e=$(ids[i]);if(e&&e.addEventListener){e.addEventListener('input',updateSummary,false);e.addEventListener('change',updateSummary,false);}}
    if(window.MutationObserver){
      try{obs=new MutationObserver(updateSummary);['v144KpiCount','v144KpiSheets','v144KpiProduced','v144KpiOver'].forEach(function(id){var x=$(id);if(x)obs.observe(x,{childList:true,subtree:true,characterData:true});});}catch(x){}
    }
    mounted=true; apply(getSaved()); window.setTimeout(updateSummary,120); return true;
  }
  function boot(){if(mount())return;retry++;if(retry<80)window.setTimeout(boot,300);}
  if(document.readyState==='complete')window.setTimeout(boot,350);else if(window.addEventListener)window.addEventListener('load',function(){window.setTimeout(boot,350);},false);else window.attachEvent('onload',function(){window.setTimeout(boot,350);});
})();
