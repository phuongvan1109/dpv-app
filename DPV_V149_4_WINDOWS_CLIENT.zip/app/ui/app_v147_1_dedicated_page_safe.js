/* DPV V147.1 QR / BARCODE STUDIO DEDICATED PAGE SAFE
   ADDITIVE UI ONLY.
   Moves the existing V147 standalone card into its own full-screen workspace.
   Does not replace QR/Barcode engines, VDP handlers, Bridge, or Core.
*/
(function(){
  'use strict';
  function $(id){ return document.getElementById(id); }
  function add(el,c){ if(!el)return; if((' '+el.className+' ').indexOf(' '+c+' ')<0) el.className+=(el.className?' ':'')+c; }
  function rem(el,c){ if(!el)return; el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,''); }
  function q(sel,root){ return (root||document).querySelector ? (root||document).querySelector(sel) : null; }
  function qa(sel,root){ return (root||document).querySelectorAll ? (root||document).querySelectorAll(sel) : []; }

  function setNavActive(name){
    var btns=qa('.dpv-nav-btn'),i;
    for(i=0;i<btns.length;i++){
      if(btns[i].getAttribute('data-nav')===name) add(btns[i],'active'); else rem(btns[i],'active');
    }
  }
  function closeOtherOverlays(){
    var vdp=$('vdpPanel'),pro=$('dpvProOverlay'),settings=$('dpvSettings');
    if(vdp) add(vdp,'hidden');
    if(pro) add(pro,'hidden');
    if(settings) rem(settings,'open');
  }
  function openStudio(){
    var ov=$('v1471StudioOverlay'); if(!ov)return;
    closeOtherOverlays(); rem(ov,'v1471-hidden'); add(document.body,'v1471-studio-open'); setNavActive('qrstudio');
    try{ var first=q('textarea,input,select',ov); if(first) first.focus(); }catch(e){}
  }
  function closeStudio(){
    var ov=$('v1471StudioOverlay'); if(ov)add(ov,'v1471-hidden'); rem(document.body,'v1471-studio-open'); setNavActive('main');
  }
  function createOverlay(){
    var ov=$('v1471StudioOverlay'); if(ov)return ov;
    ov=document.createElement('div'); ov.id='v1471StudioOverlay'; ov.className='v1471-overlay v1471-hidden';
    ov.innerHTML=''
      +'<div class="v1471-window">'
      +'<header class="v1471-header">'
      +'<div class="v1471-title-wrap"><div class="v1471-kicker">DPV® STANDALONE TOOLS</div><h2>QR / Barcode Studio</h2><p>Tạo QR Code · Code128 AUTO · EAN‑13 riêng, không cần mở Biến đổi dữ liệu VDP.</p></div>'
      +'<div class="v1471-head-actions"><span class="v1471-badge">V147.1 SAFE</span><button id="v1471CloseBtn" class="v1471-close" type="button" aria-label="Đóng">×</button></div>'
      +'</header>'
      +'<div class="v1471-body"><div id="v1471StudioMount" class="v1471-mount"></div></div>'
      +'</div>';
    document.body.appendChild(ov);
    $('v1471CloseBtn').onclick=closeStudio;
    ov.onclick=function(e){ e=e||window.event; if((e.target||e.srcElement)===ov) closeStudio(); };
    return ov;
  }
  function addSidebarButton(){
    var nav=q('.dpv-nav'); if(!nav)return false;
    var old=$('v1471StudioNav'); if(old)return true;
    var btn=document.createElement('button'); btn.id='v1471StudioNav'; btn.className='dpv-nav-btn v1471-nav-btn'; btn.setAttribute('data-nav','qrstudio');
    btn.innerHTML='<span class="dpv-nav-icon">▦</span>QR / Barcode Studio';
    var vdp=q('.dpv-nav-btn[data-nav="vdp"]',nav);
    if(vdp && vdp.nextSibling) nav.insertBefore(btn,vdp.nextSibling); else if(vdp) nav.appendChild(btn); else nav.insertBefore(btn,nav.firstChild);
    btn.onclick=function(e){ if(e&&e.preventDefault)e.preventDefault(); openStudio(); return false; };
    return true;
  }
  function moveV147Card(){
    var card=$('v147QrStudioCard'),mount=$('v1471StudioMount');
    if(!card||!mount)return false;
    if(card.parentNode!==mount) mount.appendChild(card);
    add(card,'v1471-contained-card');
    return true;
  }
  function bindCloseOnOtherNavigation(){
    if(document.body.__v1471NavBound)return;
    document.body.__v1471NavBound=true;
    var nav=q('.dpv-nav');
    if(nav && nav.addEventListener){
      nav.addEventListener('click',function(e){
        var t=e.target; while(t&&t!==nav&&!t.getAttribute('data-nav'))t=t.parentNode;
        if(t&&t!==nav&&t.getAttribute('data-nav')!=='qrstudio'){
          var ov=$('v1471StudioOverlay'); if(ov&&!(' '+ov.className+' ').match(/ v1471-hidden /)){ add(ov,'v1471-hidden'); rem(document.body,'v1471-studio-open'); }
        }
      },false);
    }
    var vdp=$('vdpOpenBtn'); if(vdp&&vdp.addEventListener)vdp.addEventListener('click',function(){ var ov=$('v1471StudioOverlay');if(ov)add(ov,'v1471-hidden');rem(document.body,'v1471-studio-open'); },false);
    document.addEventListener('keydown',function(e){e=e||window.event;if(e.keyCode===27){var ov=$('v1471StudioOverlay');if(ov&&(' '+ov.className+' ').indexOf(' v1471-hidden ')<0)closeStudio();}},false);
  }
  function addTopShortcut(){
    var conn=q('.connection'); if(!conn||$('v1471TopBtn'))return;
    var b=document.createElement('button'); b.id='v1471TopBtn'; b.className='button ghost v1471-top-btn'; b.type='button'; b.textContent='QR / Barcode Studio'; b.onclick=openStudio;
    var vdp=$('vdpOpenBtn'); if(vdp&&vdp.parentNode===conn) conn.insertBefore(b,vdp); else conn.insertBefore(b,conn.firstChild);
  }
  function init(){
    createOverlay();
    var a=addSidebarButton(), b=moveV147Card();
    if(a&&b){ bindCloseOnOtherNavigation(); addTopShortcut(); return true; }
    return false;
  }
  var tries=0,t=setInterval(function(){tries++;if(init()||tries>100)clearInterval(t);},250);
})();
