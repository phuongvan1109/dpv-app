(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function txt(el,v){if(!el)return;if('textContent'in el)el.textContent=v;else el.innerText=v;}
  function add(el,c){if(el&&(' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(el)el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function show(el,on){if(!el)return;if(on)rem(el,'hidden');else add(el,'hidden');}
  var sheetSnapshot=null;
  function getCore(){
    if(!window.DPVCoreV101||typeof window.DPVCoreV101.getConfig!=='function')throw new Error('Core V101 chưa sẵn sàng.');
    var c=window.DPVCoreV101.getConfig(),l=c&&(c.precomputedLayoutV101||c.precomputedLayoutV99);
    if(!l||!l.items||!l.items.length)throw new Error('Chưa có bố cục V101. Hãy đóng VDP → bấm Tính nhanh trên DPV → mở VDP lại.');
    return {config:c,layout:l};
  }
  function state(){if(!window.DPVVDP101||!window.DPVVDP101.getState)throw new Error('VDP Core chưa sẵn sàng.');return window.DPVVDP101.getState();}
  function status(m,k){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}
  function calcSummary(){
    try{
      var x=getCore(),s=state(),from=Math.max(1,Number($('vdpFrom').value)||1),to=Math.min(Number(s.recordCount||0),Math.max(from,Number($('vdpTo').value)||Number(s.recordCount||0))),n=Math.max(0,to-from+1),slots=x.layout.items.length,sheets=slots?Math.ceil(n/slots):0;
      sheetSnapshot=x;
      txt($('vdpSheetSlots'),String(slots));txt($('vdpSheetTotal'),String(sheets));txt($('vdpSheetRecords'),String(n));
      txt($('vdpSheetLayoutName'),(x.layout.method||'V101 Layout')+' · '+x.config.paperW+'×'+x.config.paperH+' mm · lề '+x.config.margin+' mm · gap '+x.config.gapX+'/'+x.config.gapY+' mm');
      status('Đã đồng bộ bố cục V101: '+slots+' con/tờ · '+sheets+' tờ cho '+n+' record.','ok');
      return x;
    }catch(e){sheetSnapshot=null;txt($('vdpSheetSlots'),'0');txt($('vdpSheetTotal'),'0');txt($('vdpSheetRecords'),'0');txt($('vdpSheetLayoutName'),e.message);status(e.message,'error');return null;}
  }
  function setMode(sheet){
    var rec=$('vdpRecordOutputBox'),sp=$('vdpSheetPanel'),rb=$('vdpBuildBtn'),sb=$('vdpSheetBuildBtn');
    show(rec,!sheet);show(sp,sheet);show(rb,!sheet);show(sb,sheet);
    if(sheet)calcSummary();
  }
  function makeUI(){
    var anchor=document.querySelector?document.querySelector('.vdp-output-options'):null;if(!anchor||$('vdpOutputMode'))return;
    var mode=document.createElement('div');mode.id='vdpOutputMode';mode.className='v114-mode';mode.innerHTML='<div class="v114-mode-title">Chế độ sản xuất VDP</div><div class="v114-segment"><label><input type="radio" name="vdpMode114" id="vdpModeRecord" checked><span>PDF từng record</span></label><label><input type="radio" name="vdpMode114" id="vdpModeSheet"><span>Dàn record trực tiếp lên khổ in</span></label></div>';
    anchor.parentNode.insertBefore(mode,anchor);
    var wrap=document.createElement('div');wrap.id='vdpRecordOutputBox';anchor.parentNode.insertBefore(wrap,anchor);wrap.appendChild(anchor);
    var cname=$('vdpCombinedName');if(cname&&cname.parentNode)wrap.appendChild(cname.parentNode);
    var sheet=document.createElement('div');sheet.id='vdpSheetPanel';sheet.className='v114-sheet hidden';sheet.innerHTML=''
      +'<div class="v114-sheet-head"><div><strong>VDP SHEET · Core V101 STABLE</strong><small id="vdpSheetLayoutName">Chưa đồng bộ bố cục.</small></div><button id="vdpSheetRefresh" type="button" class="button tiny">Đồng bộ bố cục</button></div>'
      +'<div class="v114-kpis"><div><span>Record chạy</span><strong id="vdpSheetRecords">0</strong></div><div><span>Con / tờ</span><strong id="vdpSheetSlots">0</strong></div><div><span>Số tờ</span><strong id="vdpSheetTotal">0</strong></div></div>'
      +'<div class="form-grid compact"><div class="field"><label>Thứ tự gán record</label><select id="vdpSheetOrder"><option value="row">Trái → phải, trên → dưới</option><option value="column">Trên → dưới, trái → phải</option><option value="snake">Ziczac theo hàng</option></select></div><div class="field"><label>Tờ cuối thiếu record</label><select id="vdpLastSheetMode"><option value="blank">Để trống vị trí còn lại</option><option value="center">Dồn các record còn lại vào giữa tờ</option></select></div><div class="field"><label>Tiền tố tên tờ</label><input id="vdpSheetPrefix" value="VDP_SHEET"></div><div class="field"><label>Tên PDF gộp các tờ</label><input id="vdpSheetCombinedName" value="VDP_ALL_SHEETS"></div></div>'
      +'<div class="vdp-output-options"><label class="vdp-check"><input id="vdpSheetKeepRecords" type="checkbox"> <span>Giữ PDF record trung gian (mặc định tắt để nhẹ ổ đĩa)</span></label><label class="vdp-check"><input id="vdpSheetCombine" type="checkbox" checked> <span>Gộp tất cả tờ thành 1 PDF nhiều trang</span></label><label class="vdp-check"><input id="vdpSheetUsePon" type="checkbox" checked> <span>Giữ PON / Auto PON / tiêu đề theo cấu hình Dàn file</span></label></div>'
      +'<div class="v114-note">Pipeline tối ưu: <b>Render record → PDF nhẹ → Place theo tọa độ V101 → xuất tờ</b>. Không clone toàn bộ artwork nhiều lần trong RAM. Exact Gap, lề cứng, xoay, True-Shape và bố cục đều lấy từ Core V101 đã Tính nhanh.</div>';
    wrap.parentNode.insertBefore(sheet,wrap.nextSibling);
    var oldBtn=$('vdpBuildBtn'),newBtn=document.createElement('button');newBtn.id='vdpSheetBuildBtn';newBtn.className='button success large vdp-build hidden';txt(newBtn,'Dàn dữ liệu lên khổ in & xuất PDF tờ');oldBtn.parentNode.insertBefore(newBtn,oldBtn.nextSibling);
    $('vdpModeRecord').onclick=function(){setMode(false);};$('vdpModeSheet').onclick=function(){setMode(true);};$('vdpSheetRefresh').onclick=calcSummary;
    $('vdpFrom').addEventListener('change',function(){if($('vdpModeSheet').checked)calcSummary();});$('vdpTo').addEventListener('change',function(){if($('vdpModeSheet').checked)calcSummary();});
    /* V122: do not bind undefined buildSheet here. bindBuildFix() below owns the button. */
  }
  function bindBuildFix(){
    // buildSheet được viết lại ở đây để giữ cú pháp ES5 đơn giản cho Windows WebBrowser.
    var b=$('vdpSheetBuildBtn');if(!b)return;
    b.onclick=function(){
      var st,x,out,from,to,cfg,sc;
      try{
        st=state();if(!st.filePath&&!(window.DPVVDP101&&window.DPVVDP101.getRecords&&window.DPVVDP101.getRecords().length))throw new Error('Chưa có dữ liệu CSV/TXT hoặc Dãy số tự động.');if(!(st.recordCount>0))throw new Error('Dữ liệu không có record.');if(!st.mappings||!st.mappings.length)throw new Error('Chưa map dữ liệu vào đối tượng Illustrator.');
        out=$('vdpOutputPath').value;if(!out)throw new Error('Chưa chọn thư mục xuất PDF.');x=calcSummary();if(!x)return;
        from=Math.max(1,Math.floor(Number($('vdpFrom').value)||1));to=Math.min(st.recordCount,Math.max(from,Math.floor(Number($('vdpTo').value)||st.recordCount)));
        sc={paperW:Number(x.config.paperW),paperH:Number(x.config.paperH),margin:Number(x.config.margin),header:Number(x.config.header),addTitle:x.config.addTitle===true,
          ponPath:String(x.config.ponPath||''),fitPon:x.config.fitPon===true,autoPon:x.config.autoPon===true,ponProcessBlack:x.config.ponProcessBlack===true,cornerPonRed:x.config.cornerPonRed===true};
        if($('vdpSheetUsePon')&&!$('vdpSheetUsePon').checked){sc.ponPath='';sc.autoPon=false;sc.addTitle=false;}
        cfg={dataPath:st.filePath,records:st.filePath?[]:((window.DPVVDP101&&window.DPVVDP101.getRecords)?window.DPVVDP101.getRecords():[]),mappings:st.mappings,sourceFolder:st.sourceFolder,outputPath:out,from:from,to:to,fileNameField:$('vdpFileNameField').value,filePrefix:$('vdpFilePrefix').value||'VDP',
          exportIndividual:$('vdpSheetKeepRecords').checked===true,combinePdf:false,sheetMode:true,sheetLayout:x.layout,sheetConfig:sc,sheetOrder:$('vdpSheetOrder').value,lastSheetMode:$('vdpLastSheetMode').value,
          keepRecordPdfs:$('vdpSheetKeepRecords').checked===true,combineSheets:$('vdpSheetCombine').checked===true,sheetPrefix:$('vdpSheetPrefix').value||'VDP_SHEET',sheetCombinedName:$('vdpSheetCombinedName').value||'VDP_ALL_SHEETS'};
        status('Bắt đầu VDP Sheet: '+x.layout.items.length+' con/tờ · dùng Core V101 đã khóa layout…','work');
        window.DPVVDP101.bridgeCall('BuildVariableData',[JSON.stringify(cfg)]);
      }catch(e){status(e.message||String(e),'error');}
    };
  }
  function wrapReceive(){
    if(!window.VDPRO_receive||window.__V114ReceiveWrapped)return;window.__V114ReceiveWrapped=true;var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){old(op,payload);try{var r=JSON.parse(String(payload||'{}'));if(op==='vdpBuildProgress'&&r.sheetMode){status('VDP Sheet · record '+r.current+'/'+r.total+(r.sheetCreated?' · vừa xuất tờ '+r.sheetDone+'/'+r.sheetTotal:''),'ok');}if(op==='vdpBuild'&&r.ok&&r.sheetMode){var m='Hoàn tất VDP Sheet: '+r.count+' record → '+r.sheetCount+' tờ';if(r.sheetCombinedFile)m+=' · PDF gộp: '+r.sheetCombinedFile;status(m,'ok');}}catch(e){} };
  }
  function mark(){var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V114 VDP SHEET · CORE V101 STABLE');var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V114 VDP SHEET · Core V101 Stable</strong><br>Dàn nhiều record trực tiếp lên khổ in bằng Layout Cache V101 · pipeline PDF nhẹ, low-RAM · giữ nguyên engine dàn ổn định.';}
  function start(){makeUI();bindBuildFix();wrapReceive();mark();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();
