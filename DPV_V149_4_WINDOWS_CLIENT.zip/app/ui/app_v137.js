(function(){
  function $(id){return document.getElementById(id);}
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)v.innerHTML='V137 EXACT TEXT TEMPLATE · CORE V101 STABLE';
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V137 Exact Text Template</strong><br>VDP giữ style RIÊNG từng TextFrame/target: font, style, size, leading, tracking, paragraph. Artboard A chữ lớn và B chữ nhỏ không còn bị lẫn định dạng.';
  }
  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',mark);}else{mark();}
})();
