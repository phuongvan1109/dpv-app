(function(){
  function done(){var s=document.getElementById('dpvSplash');if(!s)return;setTimeout(function(){s.className+=' dpv-splash-hide';setTimeout(function(){if(s&&s.parentNode)s.parentNode.removeChild(s);},420);},420);}
  if(document.readyState==='complete'){done();}else if(window.addEventListener){window.addEventListener('load',done,false);}else{window.attachEvent('onload',done);}
})();
