/* DPV V146 QR & BARCODE VECTOR SAFE ADD-ON
   Additive UI only. Does not override VDP bridge/core handlers. */
(function(){
  'use strict';
  var VERSION='V146';
  function $(id){return document.getElementById(id);}
  function addOption(sel,value,label){
    if(!sel||sel.querySelector('option[value="'+value+'"]')) return;
    var o=document.createElement('option'); o.value=value; o.textContent=label; sel.appendChild(o);
  }
  function enhanceMappings(){
    var root=$('vdpMappings'); if(!root) return;
    var sels=root.querySelectorAll('select.vdp-action'),i;
    for(i=0;i<sels.length;i++){
      addOption(sels[i],'qrVector','QR Code · Vector');
      addOption(sels[i],'code128Vector','Barcode Code 128 · Vector');
    }
  }
  function insertCard(){
    if($('v146QrBarcodeCard')) return;
    var root=$('vdpMappings'); if(!root||!root.parentNode) return;
    var card=document.createElement('div');
    card.id='v146QrBarcodeCard'; card.className='v146-code-card';
    card.innerHTML='<div class="v146-code-head"><strong>QR & BARCODE VECTOR</strong><span>V146 SAFE</span></div>'+
      '<div class="v146-code-grid">'+
      '<div><b>QR Code</b><small>Dữ liệu UTF-8 · vector đen · tối đa khoảng 132 byte.</small></div>'+
      '<div><b>Code 128</b><small>ASCII 32–126 · vector bar · tự tính checksum.</small></div>'+
      '</div><div class="v146-code-note">Cách dùng: chọn một shape/khung giữ chỗ trong Illustrator → <b>+ Thêm vị trí đang chọn trong AI</b> → chọn cột dữ liệu → đổi Action thành QR Code hoặc Code 128. Kích thước mã lấy theo bounds của shape giữ chỗ.</div>';
    root.parentNode.insertBefore(card,root.nextSibling);
  }
  function updateCard(){
    var card=$('v146QrBarcodeCard'); if(!card) return;
    var root=$('vdpMappings'); if(!root) return;
    var actions=root.querySelectorAll('.vdp-action'), q=0,b=0,i;
    for(i=0;i<actions.length;i++){ if(actions[i].value==='qrVector')q++; if(actions[i].value==='code128Vector')b++; }
    var badge=card.querySelector('.v146-code-head span'); if(badge) badge.textContent=VERSION+' SAFE · QR '+q+' · BAR '+b;
  }
  function hook(){
    var root=$('vdpMappings'); if(!root) return false;
    enhanceMappings(); insertCard(); updateCard();
    if(!root.__v146Observer){
      var mo=new MutationObserver(function(){enhanceMappings();updateCard();});
      mo.observe(root,{childList:true,subtree:true}); root.__v146Observer=mo;
      root.addEventListener('change',function(e){if(e.target&&e.target.classList&&e.target.classList.contains('vdp-action'))updateCard();});
    }
    return true;
  }
  var tries=0, timer=setInterval(function(){tries++; if(hook()||tries>60)clearInterval(timer);},500);
  document.addEventListener('click',function(){setTimeout(hook,30);},false);
})();
