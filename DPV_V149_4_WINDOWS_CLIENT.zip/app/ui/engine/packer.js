/* Auto Nest Pro - equal rectangle mixed-orientation packer (ES3 compatible). */
var ANPPacker = (function () {
    function n(v, d) {
        var x = Number(v);
        return isNaN(x) ? d : x;
    }

    function fitCount(space, size, gap) {
        if (size <= 0 || space + 0.0001 < size) { return 0; }
        return Math.floor((space + gap + 0.0001) / (size + gap));
    }

    function metrics(items) {
        var i, minX = 1e20, minY = 1e20, right = -1e20, bottom = -1e20;
        if (!items.length) { return { minX: 0, minY: 0, usedW: 0, usedH: 0 }; }
        for (i = 0; i < items.length; i++) {
            minX = Math.min(minX, items[i].x); minY = Math.min(minY, items[i].y);
            right = Math.max(right, items[i].x + items[i].w);
            bottom = Math.max(bottom, items[i].y + items[i].h);
        }
        return { minX: minX, minY: minY, usedW: right - minX, usedH: bottom - minY };
    }

    function trim(items, maxQty) {
        if (maxQty > 0 && items.length > maxQty) {
            return items.slice(0, maxQty);
        }
        return items;
    }

    function center(items, binW, binH, centerY) {
        var i, m = metrics(items);
        var dx = Math.max(0, (binW - m.usedW) / 2 - m.minX);
        var dy = centerY ? Math.max(0, (binH - m.usedH) / 2 - m.minY) : 0;
        for (i = 0; i < items.length; i++) {
            items[i].x += dx;
            items[i].y += dy;
        }
        m = metrics(items);
        return { items: items, usedW: m.usedW, usedH: m.usedH };
    }

    function columnCandidate(binW, binH, w, h, gx, gy, c0, c90, maxQty, cornerClear) {
        var rows0 = fitCount(binH, h, gy);
        var rows90 = fitCount(binH, w, gy);
        var specs = [];
        var i, j, x = 0, y, items = [];

        /* Taller-yield columns first; this creates the 3 horizontal + 1 vertical
           strip seen in common label imposition layouts. */
        /* Cột ngắn được chia đều ra hai mép; cột dài nằm giữa. */
        var outer = [], inner = [], half;
        var height0 = rows0 > 0 ? rows0 * h + (rows0 - 1) * gy : 0;
        var height90 = rows90 > 0 ? rows90 * w + (rows90 - 1) * gy : 0;
        if (cornerClear > 0 ? height90 < height0 : rows90 < rows0) {
            for (i = 0; i < c90; i++) { outer.push({ w: h, h: w, rows: rows90, r: true }); }
            for (i = 0; i < c0; i++) { inner.push({ w: w, h: h, rows: rows0, r: false }); }
        } else {
            for (i = 0; i < c0; i++) { outer.push({ w: w, h: h, rows: rows0, r: false }); }
            for (i = 0; i < c90; i++) { inner.push({ w: h, h: w, rows: rows90, r: true }); }
        }
        half = Math.ceil(outer.length / 2);
        specs = outer.slice(0, half).concat(inner).concat(outer.slice(half));

        for (i = 0; i < specs.length; i++) {
            /* Hai cột ngoài cùng chỉ dùng vùng giữa tờ. Nhờ vậy tem không lấn
               vào bốn vùng PON; các cột giữa vẫn được chạy hết chiều cao. */
            if (cornerClear > 0 && (i === 0 || i === specs.length - 1)) {
                specs[i].rows = Math.min(specs[i].rows,
                    fitCount(Math.max(0, binH - cornerClear * 2), specs[i].h, gy));
            }
            y = Math.max(0, (binH - (specs[i].rows * specs[i].h + (specs[i].rows - 1) * gy)) / 2);
            for (j = 0; j < specs[i].rows; j++) {
                items.push({ x: x, y: y, w: specs[i].w, h: specs[i].h, rotated: specs[i].r, angle: specs[i].r ? 90 : 0, offsetX:0, offsetY:0 });
                y += specs[i].h + gy;
            }
            x += specs[i].w + gx;
        }
        items = trim(items, maxQty);
        return center(items, binW, binH, false);
    }

    function rowCandidate(binW, binH, w, h, gx, gy, r0, r90, maxQty, cornerClear) {
        var cols0 = fitCount(binW, w, gx);
        var cols90 = fitCount(binW, h, gx);
        var specs = [];
        var i, j, x, y = 0, items = [];

        /* Hàng ngắn được chia đều lên trên/dưới, hàng dài nằm giữa. */
        var outer = [], inner = [], half;
        var width0 = cols0 > 0 ? cols0 * w + (cols0 - 1) * gx : 0;
        var width90 = cols90 > 0 ? cols90 * h + (cols90 - 1) * gx : 0;
        if (cornerClear > 0 ? width90 < width0 : cols90 < cols0) {
            for (i = 0; i < r90; i++) { outer.push({ w: h, h: w, cols: cols90, r: true }); }
            for (i = 0; i < r0; i++) { inner.push({ w: w, h: h, cols: cols0, r: false }); }
        } else {
            for (i = 0; i < r0; i++) { outer.push({ w: w, h: h, cols: cols0, r: false }); }
            for (i = 0; i < r90; i++) { inner.push({ w: h, h: w, cols: cols90, r: true }); }
        }
        half = Math.ceil(outer.length / 2);
        specs = outer.slice(0, half).concat(inner).concat(outer.slice(half));

        for (i = 0; i < specs.length; i++) {
            /* Hai hàng trên/dưới chừa phần trái/phải cho PON; các hàng giữa
               vẫn tận dụng toàn bộ chiều rộng vùng in. */
            if (cornerClear > 0 && (i === 0 || i === specs.length - 1)) {
                specs[i].cols = Math.min(specs[i].cols,
                    fitCount(Math.max(0, binW - cornerClear * 2), specs[i].w, gx));
            }
            x = Math.max(0, (binW - (specs[i].cols * specs[i].w + (specs[i].cols - 1) * gx)) / 2);
            for (j = 0; j < specs[i].cols; j++) {
                items.push({ x: x, y: y, w: specs[i].w, h: specs[i].h, rotated: specs[i].r, angle: specs[i].r ? 90 : 0, offsetX:0, offsetY:0 });
                x += specs[i].w + gx;
            }
            y += specs[i].h + gy;
        }
        items = trim(items, maxQty);
        return center(items, binW, binH, false);
    }

    function better(a, b, binW, binH) {
        if (!a) { return b; }
        if (!b) { return a; }
        if (b.items.length !== a.items.length) {
            return b.items.length > a.items.length ? b : a;
        }
        /* Tie-break: compact used area, then narrower layout. */
        var areaA = a.usedW * a.usedH;
        var areaB = b.usedW * b.usedH;
        if (Math.abs(areaA - areaB) > 0.001) { return areaB < areaA ? b : a; }
        return b.usedW < a.usedW ? b : a;
    }

    function pack(cfg) {
        var binW = n(cfg.binW, 0), binH = n(cfg.binH, 0);
        var w = n(cfg.itemW, 0), h = n(cfg.itemH, 0);
        var gx = Math.max(0, n(cfg.gapX, 0)), gy = Math.max(0, n(cfg.gapY, gx));
        var allowRotate = cfg.allowRotate !== false;
        var maxQty = Math.max(0, Math.floor(n(cfg.maxQty, 0)));
        var cornerClear = Math.max(0, n(cfg.cornerClear, 0));
        cornerClear = Math.min(cornerClear, Math.max(0, binW / 2), Math.max(0, binH / 2));
        var best = null, c0, c90, r0, r90, cand;
        var maxC0 = fitCount(binW, w, gx);
        var maxC90 = allowRotate ? fitCount(binW, h, gx) : 0;
        var maxR0 = fitCount(binH, h, gy);
        var maxR90 = allowRotate ? fitCount(binH, w, gy) : 0;

        if (binW <= 0 || binH <= 0 || w <= 0 || h <= 0) {
            return { items: [], count: 0, usedW: 0, usedH: 0, method: "invalid" };
        }

        /* Exhaustively evaluate every mixed column combination. */
        for (c0 = 0; c0 <= maxC0; c0++) {
            for (c90 = 0; c90 <= maxC90; c90++) {
                if (c0 + c90 === 0) { continue; }
                var usedW = c0 * w + c90 * h + (c0 + c90 - 1) * gx;
                if (usedW <= binW + 0.0001) {
                    cand = columnCandidate(binW, binH, w, h, gx, gy, c0, c90, maxQty, cornerClear);
                    cand.method = cornerClear > 0 ? "corner-safe-columns" : "mixed-columns";
                    best = better(best, cand, binW, binH);
                }
            }
        }

        /* Also evaluate horizontal shelf mixtures for wide/short press sheets. */
        for (r0 = 0; r0 <= maxR0; r0++) {
            for (r90 = 0; r90 <= maxR90; r90++) {
                if (r0 + r90 === 0) { continue; }
                var usedH = r0 * h + r90 * w + (r0 + r90 - 1) * gy;
                if (usedH <= binH + 0.0001) {
                    cand = rowCandidate(binW, binH, w, h, gx, gy, r0, r90, maxQty, cornerClear);
                    cand.method = cornerClear > 0 ? "corner-safe-rows" : "mixed-rows";
                    best = better(best, cand, binW, binH);
                }
            }
        }

        if (!best) { best = { items: [], usedW: 0, usedH: 0, method: "none" }; }
        best.count = best.items.length;
        best.efficiency = best.count * w * h / (binW * binH);
        best.cornerSafe = cornerClear > 0;
        best.cornerClear = cornerClear;
        return best;
    }

    return { pack: pack };
}());
