/* Auto Nest Pro - MaxRects packer for multiple sizes (ES3 compatible). */
var ANPMultiPacker = (function () {
    function cloneRect(r) { return { x: r.x, y: r.y, w: r.w, h: r.h }; }

    function intersects(a, b) {
        return !(b.x >= a.x + a.w || b.x + b.w <= a.x || b.y >= a.y + a.h || b.y + b.h <= a.y);
    }

    function contains(a, b) {
        return b.x >= a.x && b.y >= a.y && b.x + b.w <= a.x + a.w && b.y + b.h <= a.y + a.h;
    }

    function splitFree(free, used) {
        var out = [];
        if (!intersects(free, used)) { out.push(cloneRect(free)); return out; }
        if (used.x > free.x) { out.push({ x: free.x, y: free.y, w: used.x - free.x, h: free.h }); }
        if (used.x + used.w < free.x + free.w) {
            out.push({ x: used.x + used.w, y: free.y, w: free.x + free.w - (used.x + used.w), h: free.h });
        }
        if (used.y > free.y) { out.push({ x: free.x, y: free.y, w: free.w, h: used.y - free.y }); }
        if (used.y + used.h < free.y + free.h) {
            out.push({ x: free.x, y: used.y + used.h, w: free.w, h: free.y + free.h - (used.y + used.h) });
        }
        return out;
    }

    function prune(rects) {
        var i, j;
        for (i = rects.length - 1; i >= 0; i--) {
            if (rects[i].w <= 0.0001 || rects[i].h <= 0.0001) { rects.splice(i, 1); continue; }
            for (j = rects.length - 1; j >= 0; j--) {
                if (i !== j && contains(rects[j], rects[i])) { rects.splice(i, 1); break; }
            }
        }
        return rects;
    }

    function score(free, w, h, mode) {
        var dw = free.w - w, dh = free.h - h;
        if (mode === "area") { return [free.w * free.h - w * h, Math.min(dw, dh), Math.max(dw, dh)]; }
        return [Math.min(dw, dh), Math.max(dw, dh), free.w * free.h - w * h];
    }

    function scoreLess(a, b) {
        if (!b) { return true; }
        if (a[0] !== b[0]) { return a[0] < b[0]; }
        if (a[1] !== b[1]) { return a[1] < b[1]; }
        return a[2] < b[2];
    }

    function findPosition(freeRects, item, gx, gy, allowRotate, mode) {
        var best = null, bestScore = null, i, f, fw, fh, s;
        var orientations = [{ w: item.w, h: item.h, r: false }];
        if (allowRotate && Math.abs(item.w - item.h) > 0.0001) { orientations.push({ w: item.h, h: item.w, r: true }); }
        var o;
        for (i = 0; i < freeRects.length; i++) {
            f = freeRects[i];
            for (o = 0; o < orientations.length; o++) {
                fw = orientations[o].w + gx; fh = orientations[o].h + gy;
                if (fw <= f.w + 0.0001 && fh <= f.h + 0.0001) {
                    s = score(f, fw, fh, mode);
                    if (scoreLess(s, bestScore)) {
                        bestScore = s;
                        best = {
                            x: f.x, y: f.y,
                            w: orientations[o].w, h: orientations[o].h,
                            fw: fw, fh: fh, rotated: orientations[o].r,
                            sourceIndex: item.sourceIndex, copyIndex: item.copyIndex,
                            originalW: item.w, originalH: item.h
                        };
                    }
                }
            }
        }
        return best;
    }

    function placeOrder(items, cfg, mode) {
        var freeRects = [{ x: 0, y: 0, w: cfg.binW + cfg.gapX, h: cfg.binH + cfg.gapY }];
        var placed = [], skipped = [], i, p, f, next, j;
        var clear = Math.max(0, Number(cfg.cornerClear) || 0), obstacles, oi;
        if (clear > 0) {
            obstacles = [
                {x:0,y:0,w:clear,h:clear},
                {x:cfg.binW-clear,y:0,w:clear+cfg.gapX,h:clear},
                {x:0,y:cfg.binH-clear,w:clear,h:clear+cfg.gapY},
                {x:cfg.binW-clear,y:cfg.binH-clear,w:clear+cfg.gapX,h:clear+cfg.gapY}
            ];
            for (oi = 0; oi < obstacles.length; oi++) {
                next = [];
                for (j = 0; j < freeRects.length; j++) {
                    f = splitFree(freeRects[j], obstacles[oi]);
                    while (f.length) { next.push(f.pop()); }
                }
                freeRects = prune(next);
            }
        }
        for (i = 0; i < items.length; i++) {
            p = findPosition(freeRects, items[i], cfg.gapX, cfg.gapY, cfg.allowRotate, mode);
            if (!p) { skipped.push(items[i]); continue; }
            placed.push(p);
            next = [];
            var used = { x: p.x, y: p.y, w: p.fw, h: p.fh };
            for (j = 0; j < freeRects.length; j++) {
                f = splitFree(freeRects[j], used);
                while (f.length) { next.push(f.pop()); }
            }
            freeRects = prune(next);
        }
        return { items: placed, skipped: skipped };
    }

    function order(items, kind) {
        var a = items.slice(0);
        a.sort(function (x, y) {
            if (kind === "maxside") {
                var d = Math.max(y.w, y.h) - Math.max(x.w, x.h);
                if (d) { return d; }
            } else if (kind === "height") {
                if (y.h !== x.h) { return y.h - x.h; }
            } else if (kind === "width") {
                if (y.w !== x.w) { return y.w - x.w; }
            }
            if (y.w * y.h !== x.w * x.h) { return y.w * y.h - x.w * x.h; }
            return x.sourceIndex - y.sourceIndex;
        });
        return a;
    }

    function usedArea(result) {
        var i, total = 0;
        for (i = 0; i < result.items.length; i++) { total += result.items[i].originalW * result.items[i].originalH; }
        return total;
    }

    function better(a, b) {
        if (!a) { return b; }
        if (b.items.length !== a.items.length) { return b.items.length > a.items.length ? b : a; }
        return usedArea(b) > usedArea(a) ? b : a;
    }

    function centerX(result, binW) {
        var i, minX = 1e20, maxX = -1e20;
        for (i = 0; i < result.items.length; i++) {
            minX = Math.min(minX, result.items[i].x);
            maxX = Math.max(maxX, result.items[i].x + result.items[i].w);
        }
        if (!result.items.length) { return; }
        var dx = Math.max(0, (binW - (maxX - minX)) / 2 - minX);
        for (i = 0; i < result.items.length; i++) { result.items[i].x += dx; }
    }

    function pack(cfg) {
        var kinds = ["area", "maxside", "height", "width"], modes = ["short", "area"];
        var k, m, candidate, best = null;
        for (k = 0; k < kinds.length; k++) {
            for (m = 0; m < modes.length; m++) {
                candidate = placeOrder(order(cfg.items, kinds[k]), cfg, modes[m]);
                best = better(best, candidate);
            }
        }
        if (!best) { best = { items: [], skipped: cfg.items.slice(0) }; }
        if (!(Number(cfg.cornerClear) > 0)) { centerX(best, cfg.binW); }
        best.count = best.items.length;
        best.efficiency = usedArea(best) / (cfg.binW * cfg.binH);
        best.method = "maxrects-mixed-sizes";
        if (Number(cfg.cornerClear) > 0) { best.method = "corner-safe-maxrects-mixed-sizes"; best.cornerSafe = true; }
        return best;
    }

    return { pack: pack };
}());
