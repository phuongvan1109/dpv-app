/* Auto Nest Pro - True Shape nesting engine (ES3 compatible). */
var ANPTrueShape = (function () {
    var EPS = 0.0001;
    function num(v, d) { var n = Number(v); return isNaN(n) ? d : n; }
    function clonePoint(p) { return { x: p.x, y: p.y }; }
    function polygonArea(poly) {
        var i, j, a = 0;
        for (i = 0, j = poly.length - 1; i < poly.length; j = i++) { a += poly[j].x * poly[i].y - poly[i].x * poly[j].y; }
        return Math.abs(a / 2);
    }
    function bounds(poly) {
        var i, minX = 1e20, minY = 1e20, maxX = -1e20, maxY = -1e20;
        for (i = 0; i < poly.length; i++) {
            minX = Math.min(minX, poly[i].x); minY = Math.min(minY, poly[i].y);
            maxX = Math.max(maxX, poly[i].x); maxY = Math.max(maxY, poly[i].y);
        }
        return { minX: minX, minY: minY, maxX: maxX, maxY: maxY, w: maxX - minX, h: maxY - minY };
    }
    function rotateVariant(poly, w, h, angle) {
        var rad = angle * Math.PI / 180, c = Math.cos(rad), s = Math.sin(rad), cx = w / 2, cy = h / 2;
        var out = [], i, dx, dy, b, rect = [
            { x: 0, y: 0 }, { x: w, y: 0 }, { x: w, y: h }, { x: 0, y: h }
        ], rb = [];
        for (i = 0; i < poly.length; i++) {
            dx = poly[i].x - cx; dy = poly[i].y - cy;
            out.push({ x: cx + dx * c - dy * s, y: cy + dx * s + dy * c });
        }
        for (i = 0; i < rect.length; i++) {
            dx = rect[i].x - cx; dy = rect[i].y - cy;
            rb.push({ x: cx + dx * c - dy * s, y: cy + dx * s + dy * c });
        }
        var rbb = bounds(rb), norm = ((Number(angle) % 360) + 360) % 360;
        /* V93 EXACT GAP: strict-gap chỉ dùng các góc vuông. Với 0/90/180/270,
           bbox chuẩn phải lấy từ kích thước geometricBounds thật (rect), không
           lấy từ polygon Bézier sample. Như vậy tọa độ engine == tọa độ vector xuất. */
        if (Math.abs(norm - 0) < 0.001 || Math.abs(norm - 90) < 0.001 || Math.abs(norm - 180) < 0.001 || Math.abs(norm - 270) < 0.001) {
            for (i = 0; i < out.length; i++) { out[i].x -= rbb.minX; out[i].y -= rbb.minY; }
            return { angle: angle, points: out, w: rbb.w, h: rbb.h, offsetX:0, offsetY:0 };
        }
        b = bounds(out);
        for (i = 0; i < out.length; i++) { out[i].x -= b.minX; out[i].y -= b.minY; }
        return { angle: angle, points: out, w: b.w, h: b.h,
            offsetX: rbb.minX - b.minX, offsetY: rbb.minY - b.minY };
    }
    function orientationList(poly, w, h, angles) {
        var out = [], seen = {}, i, a, v, key;
        for (i = 0; i < angles.length; i++) {
            /* 180° không giống 0° với khuôn bất đối xứng (chìa khóa, móc,
               chai...). Giữ đủ vòng 360° để dàn đầu–đuôi so le. */
            a = ((Number(angles[i]) % 360) + 360) % 360;
            v = rotateVariant(poly, w, h, a); key = Math.round(v.w * 100) + "x" + Math.round(v.h * 100) + "@" + Math.round(a * 10);
            if (!seen[key]) { seen[key] = true; out.push(v); }
        }
        return out;
    }
    function translated(poly, x, y) {
        var out = [], i; for (i = 0; i < poly.length; i++) { out.push({ x: poly[i].x + x, y: poly[i].y + y }); } return out;
    }
    function orient(a, b, c) { return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x); }
    function onSeg(a, b, p) {
        return Math.abs(orient(a, b, p)) < EPS && p.x >= Math.min(a.x, b.x) - EPS && p.x <= Math.max(a.x, b.x) + EPS &&
            p.y >= Math.min(a.y, b.y) - EPS && p.y <= Math.max(a.y, b.y) + EPS;
    }
    function segIntersects(a, b, c, d) {
        var o1 = orient(a, b, c), o2 = orient(a, b, d), o3 = orient(c, d, a), o4 = orient(c, d, b);
        if (((o1 > EPS && o2 < -EPS) || (o1 < -EPS && o2 > EPS)) && ((o3 > EPS && o4 < -EPS) || (o3 < -EPS && o4 > EPS))) { return true; }
        return onSeg(a, b, c) || onSeg(a, b, d) || onSeg(c, d, a) || onSeg(c, d, b);
    }
    function pointIn(poly, p) {
        var inside = false, i, j, a, b;
        for (i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            a = poly[i]; b = poly[j]; if (onSeg(a, b, p)) { return true; }
            if (((a.y > p.y) !== (b.y > p.y)) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) { inside = !inside; }
        }
        return inside;
    }
    function pointInStrict(poly, p) {
        var inside = false, i, j, a, b;
        for (i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            a = poly[i]; b = poly[j]; if (onSeg(a, b, p)) { return false; }
            if (((a.y > p.y) !== (b.y > p.y)) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) { inside = !inside; }
        }
        return inside;
    }
    function centroid(poly) {
        var i, j, cross, a = 0, x = 0, y = 0;
        for (i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            cross = poly[j].x * poly[i].y - poly[i].x * poly[j].y; a += cross;
            x += (poly[j].x + poly[i].x) * cross; y += (poly[j].y + poly[i].y) * cross;
        }
        if (Math.abs(a) < EPS) { return clonePoint(poly[0]); }
        return { x: x / (3 * a), y: y / (3 * a) };
    }
    function polygonsOverlap(a, b) {
        var i, j, ni, nj, o1, o2, o3, o4;
        for (i = 0; i < a.length; i++) {
            ni = (i + 1) % a.length;
            for (j = 0; j < b.length; j++) {
                nj = (j + 1) % b.length;
                o1 = orient(a[i], a[ni], b[j]); o2 = orient(a[i], a[ni], b[nj]);
                o3 = orient(b[j], b[nj], a[i]); o4 = orient(b[j], b[nj], a[ni]);
                if (((o1 > EPS && o2 < -EPS) || (o1 < -EPS && o2 > EPS)) && ((o3 > EPS && o4 < -EPS) || (o3 < -EPS && o4 > EPS))) { return true; }
            }
        }
        for (i = 0; i < a.length; i++) { if (pointInStrict(b, a[i])) { return true; } }
        for (i = 0; i < b.length; i++) { if (pointInStrict(a, b[i])) { return true; } }
        if (pointInStrict(a, centroid(b)) || pointInStrict(b, centroid(a))) { return true; }
        var ba = bounds(a), bb = bounds(b), l = Math.max(ba.minX, bb.minX), r = Math.min(ba.maxX, bb.maxX);
        var t = Math.max(ba.minY, bb.minY), bot = Math.min(ba.maxY, bb.maxY), sx, sy, sample;
        if (r - l > EPS && bot - t > EPS) {
            for (i = 1; i <= 4; i++) { for (j = 1; j <= 4; j++) {
                sx = l + (r - l) * i / 5; sy = t + (bot - t) * j / 5; sample = {x:sx,y:sy};
                if (pointInStrict(a, sample) && pointInStrict(b, sample)) { return true; }
            } }
        }
        return false;
    }
    function pointSegDist(p, a, b) {
        var dx = b.x - a.x, dy = b.y - a.y, den = dx * dx + dy * dy, t;
        if (den < EPS) { dx = p.x - a.x; dy = p.y - a.y; return Math.sqrt(dx * dx + dy * dy); }
        t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / den; t = Math.max(0, Math.min(1, t));
        dx = p.x - (a.x + t * dx); dy = p.y - (a.y + t * dy); return Math.sqrt(dx * dx + dy * dy);
    }
    function polyDistance(a, b) {
        var i, j, ni, nj, best = 1e20;
        for (i = 0; i < a.length; i++) {
            ni = (i + 1) % a.length;
            for (j = 0; j < b.length; j++) {
                nj = (j + 1) % b.length;
                if (segIntersects(a[i], a[ni], b[j], b[nj])) { return 0; }
                best = Math.min(best, pointSegDist(a[i], b[j], b[nj]), pointSegDist(b[j], a[i], a[ni]));
            }
        }
        if (pointIn(a, b[0]) || pointIn(b, a[0])) { return 0; }
        return best;
    }
    function fits(v, x, y, placed, binW, binH, gap) {
        if (x < -EPS || y < -EPS || x + v.w > binW + EPS || y + v.h > binH + EPS) { return false; }
        var poly = translated(v.points, x, y), i, p;
        for (i = 0; i < placed.length; i++) {
            p = placed[i];
            if (x > p.x + p.w + gap || p.x > x + v.w + gap || y > p.y + p.h + gap || p.y > y + v.h + gap) { continue; }
            if (!polygonsRespectGapV95(poly,p.poly,gap)) { return false; }
        }
        return poly;
    }
    function addCandidate(out, seen, x, y, binW, binH) {
        x = Math.round(x * 20) / 20; y = Math.round(y * 20) / 20;
        if (x < -EPS || y < -EPS || x > binW + EPS || y > binH + EPS) { return; }
        var k = x + ":" + y; if (!seen[k]) { seen[k] = true; out.push({ x: x, y: y }); }
    }
    function candidatePoints(placed, v, binW, binH, gap, strategy, maxCandidates) {
        var out = [], seen = {}, i, j, k, p, pv, qv, dirs = [[gap,0],[-gap,0],[0,gap],[0,-gap]];
        addCandidate(out, seen, 0, 0, binW, binH); addCandidate(out, seen, binW - v.w, 0, binW, binH);
        addCandidate(out, seen, 0, binH - v.h, binW, binH); addCandidate(out, seen, binW - v.w, binH - v.h, binW, binH);
        for (i = 0; i < placed.length; i++) {
            p = placed[i];
            addCandidate(out, seen, p.x + p.w + gap, p.y, binW, binH);
            addCandidate(out, seen, p.x - v.w - gap, p.y, binW, binH);
            addCandidate(out, seen, p.x, p.y + p.h + gap, binW, binH);
            addCandidate(out, seen, p.x, p.y - v.h - gap, binW, binH);
            for (j = 0; j < p.poly.length; j += Math.max(1, Math.floor(p.poly.length / 4))) {
                pv = p.poly[j];
                for (k = 0; k < v.points.length; k += Math.max(1, Math.floor(v.points.length / 4))) {
                    qv = v.points[k];
                    for (var d = 0; d < dirs.length; d++) {
                        addCandidate(out, seen, pv.x - qv.x + dirs[d][0], pv.y - qv.y + dirs[d][1], binW, binH);
                    }
                }
            }
        }
        out.sort(function (a, b) {
            if (strategy === 1) { return a.x !== b.x ? a.x - b.x : a.y - b.y; }
            if (strategy === 2) { return a.y !== b.y ? b.y - a.y : a.x - b.x; }
            if (strategy === 3) { return a.x !== b.x ? b.x - a.x : a.y - b.y; }
            return a.y !== b.y ? a.y - b.y : a.x - b.x;
        });
        maxCandidates = Math.max(24, Number(maxCandidates) || 180);
        return out.length > maxCandidates ? out.slice(0, maxCandidates) : out;
    }
    function placedBoundsV45(placed) {
        var i, p, minX = 1e20, minY = 1e20, maxX = -1e20, maxY = -1e20;
        if (!placed || !placed.length) { return null; }
        for (i = 0; i < placed.length; i++) {
            p = placed[i]; minX = Math.min(minX, p.x); minY = Math.min(minY, p.y);
            maxX = Math.max(maxX, p.x + p.w); maxY = Math.max(maxY, p.y + p.h);
        }
        return { minX:minX, minY:minY, maxX:maxX, maxY:maxY };
    }
    function compactScoreBoundsV45(x, y, v, pb, strategy) {
        var maxX = x + v.w, maxY = y + v.h, minX = x, minY = y;
        if (pb) {
            minX = Math.min(minX, pb.minX); minY = Math.min(minY, pb.minY);
            maxX = Math.max(maxX, pb.maxX); maxY = Math.max(maxY, pb.maxY);
        }
        if (strategy === 1 || strategy === 3) { return (maxX - minX) * 10000 + (maxY - minY); }
        return (maxY - minY) * 10000 + (maxX - minX);
    }
    function compactScore(x, y, v, placed, strategy) {
        return compactScoreBoundsV45(x, y, v, placedBoundsV45(placed), strategy);
    }
    function greedy(variants, cfg, strategy, shift) {
        var placed = [], limit = cfg.maxQty > 0 ? cfg.maxQty : Math.min(500, Math.ceil(cfg.binW * cfg.binH / Math.max(0.01, cfg.area)) + 8);
        var n, vi, ci, v, pts, poly, best, score, order = variants.slice(0), rotated, placedBox;
        for (n = 0; n < shift; n++) { order.push(order.shift()); }
        while (placed.length < limit) {
            best = null; placedBox = placedBoundsV45(placed);
            for (vi = 0; vi < order.length; vi++) {
                v = order[vi]; pts = candidatePoints(placed, v, cfg.binW, cfg.binH, cfg.gap, strategy, cfg.fast ? 72 : 180);
                for (ci = 0; ci < pts.length; ci++) {
                    poly = fits(v, pts[ci].x, pts[ci].y, placed, cfg.binW, cfg.binH, cfg.gap);
                    if (!poly) { continue; }
                    score = compactScoreBoundsV45(pts[ci].x, pts[ci].y, v, placedBox, strategy) + vi * 0.0001;
                    if (!best || score < best.score) { best = { score: score, v: v, x: pts[ci].x, y: pts[ci].y, poly: poly }; }
                    if (ci > (cfg.fast ? 58 : 150) && best) { break; }
                }
            }
            if (!best) { break; }
            rotated = Math.abs(best.v.angle - 90) < 0.001;
            placed.push({ x: best.x, y: best.y, w: best.v.w, h: best.v.h, angle: best.v.angle,
                rotated: rotated, offsetX: best.v.offsetX, offsetY: best.v.offsetY, poly: best.poly });
        }
        return placed;
    }
    function honeycomb(cfg) {
        var d = Math.max(cfg.shape.w, cfg.shape.h), pitch = d + cfg.gap;
        var rowStep = Math.sqrt(Math.max(0, pitch * pitch - (pitch / 2) * (pitch / 2)));
        var best = [], startParity, y, row, x0, x, items, col, y0;
        /* Luôn so sánh cả lưới vuông vì một số khổ vuông cho kết quả tốt hơn tổ ong. */
        items = [];
        for (y = 0; y + d <= cfg.binH + EPS; y += pitch) { for (x = 0; x + d <= cfg.binW + EPS; x += pitch) {
            items.push({ x:x,y:y,w:d,h:d,angle:0,rotated:false,offsetX:0,offsetY:0 });
            if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
        } if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; } }
        best = items;
        for (startParity = 0; startParity < 2; startParity++) {
            items = []; row = 0; y = 0;
            while (y + d <= cfg.binH + EPS) {
                x0 = ((row + startParity) % 2) ? pitch / 2 : 0; x = x0;
                while (x + d <= cfg.binW + EPS) {
                    items.push({ x: x, y: y, w: d, h: d, angle: 0, rotated: false, offsetX: 0, offsetY: 0 });
                    if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
                    x += pitch;
                }
                if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
                row++; y = row * rowStep;
            }
            if (betterItemsV100(best,items) === items) { best = items; }
            items = []; col = 0; x = 0;
            while (x + d <= cfg.binW + EPS) {
                y0 = ((col + startParity) % 2) ? pitch / 2 : 0; y = y0;
                while (y + d <= cfg.binH + EPS) {
                    items.push({ x:x,y:y,w:d,h:d,angle:0,rotated:false,offsetX:0,offsetY:0 });
                    if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
                    y += pitch;
                }
                if (cfg.maxQty > 0 && items.length >= cfg.maxQty) { break; }
                col++; x = col * rowStep;
            }
            if (betterItemsV100(best,items) === items) { best = items; }
        }
        return { items: best, count: best.length, method: "true-shape-honeycomb", efficiency: best.length * cfg.area / (cfg.binW * cfg.binH) };
    }
    /* Lattice so le: chỉ kiểm tra một cặp khuôn thật để tìm bước hàng, sau đó
       dựng lưới đầu–đuôi. Đây là đường chạy O(n), dùng cho khuôn bất đối xứng
       số lượng lớn thay vì phép thử polygon O(n²) gây lag Illustrator. */

    /* V95 performance: kiểm tra "đủ gap hay chưa" trực tiếp, không tính
       minimum distance của mọi cặp segment khi không cần thiết. */
    function segBoxGapLowerV95(a,b,c,d) {
        var aminX=Math.min(a.x,b.x),amaxX=Math.max(a.x,b.x),aminY=Math.min(a.y,b.y),amaxY=Math.max(a.y,b.y);
        var bminX=Math.min(c.x,d.x),bmaxX=Math.max(c.x,d.x),bminY=Math.min(c.y,d.y),bmaxY=Math.max(c.y,d.y);
        var dx=0,dy=0;
        if(amaxX<bminX){dx=bminX-amaxX;}else if(bmaxX<aminX){dx=aminX-bmaxX;}
        if(amaxY<bminY){dy=bminY-amaxY;}else if(bmaxY<aminY){dy=aminY-bmaxY;}
        return Math.sqrt(dx*dx+dy*dy);
    }
    function polygonsRespectGapV95(a,b,gap) {
        gap=Math.max(0,Number(gap)||0);
        if(gap<=EPS){return !polygonsOverlap(a,b);}
        var i,j,ni,nj,lower,dist;
        for(i=0;i<a.length;i++){
            ni=(i+1)%a.length;
            for(j=0;j<b.length;j++){
                nj=(j+1)%b.length;
                lower=segBoxGapLowerV95(a[i],a[ni],b[j],b[nj]);
                if(lower>=gap-EPS){continue;}
                if(segIntersects(a[i],a[ni],b[j],b[nj])){return false;}
                dist=Math.min(pointSegDist(a[i],b[j],b[nj]),pointSegDist(a[ni],b[j],b[nj]),
                    pointSegDist(b[j],a[i],a[ni]),pointSegDist(b[nj],a[i],a[ni]));
                if(dist<gap-EPS){return false;}
            }
        }
        if(pointIn(a,b[0])||pointIn(b,a[0])){return false;}
        return true;
    }

    function pairFits(a, b, dx, dy, gap) {
        var pa = a.points, pb = translated(b.points, dx, dy), ba = bounds(pa), bb = bounds(pb);
        if (bb.maxX < ba.minX - gap || ba.maxX < bb.minX - gap || bb.maxY < ba.minY - gap || ba.maxY < bb.minY - gap) { return true; }
        return polygonsRespectGapV95(pa,pb,gap);
    }
    /* V94 EXACT ORTHOGONAL GAP
       "Khoảng cách Pon - Ngang/Dọc" là khoảng hở theo TRỤC X/Y, không phải
       khoảng cách Euclid ngắn nhất ở góc cong. V93 dùng polyDistance nên một
       góc cong chéo có thể chạm ngưỡng 2mm trước, làm khe thẳng thực tế thành
       2.2-2.4mm. V94 tìm vị trí TIẾP XÚC theo đúng hướng dịch X/Y rồi cộng đúng
       gap cấu hình. Vì vậy gapX=2 và gapY=2 cho khe thẳng 2.000mm ở cả hai trục. */
    function pairNoOverlapV94(a, b, dx, dy) {
        var pa = a.points, pb = translated(b.points, dx, dy), ba = bounds(pa), bb = bounds(pb);
        if (bb.maxX < ba.minX - EPS || ba.maxX < bb.minX - EPS || bb.maxY < ba.minY - EPS || ba.maxY < bb.minY - EPS) { return true; }
        return !polygonsOverlap(pa, pb);
    }
    function contactPitchXV94(a, b, dy, gap, fast) {
        var span = Math.max(0.25, Math.min(a.w, a.h, b.w, b.h) / (fast ? 36 : 64));
        var hi = a.w + b.w + 1, right = hi, x, found = false, lo = -b.w - 1, i, mid;
        /* đi từ bên phải vào cho tới khi thật sự đụng polygon */
        for (x = hi; x >= lo; x -= span) {
            if (!pairNoOverlapV94(a, b, x, dy)) { found = true; break; }
            right = x;
        }
        if (!found) { return Math.max(a.w, b.w) + Math.max(0, Number(gap) || 0); } /* không có vùng tiếp xúc: dùng pitch bbox an toàn, tránh bước 0 */
        lo = x; hi = right;
        if (hi < lo) { hi = lo + span; }
        for (i = 0; i < 24 && hi - lo > 0.0002; i++) {
            mid = (lo + hi) / 2;
            if (pairNoOverlapV94(a, b, mid, dy)) { hi = mid; } else { lo = mid; }
        }
        return Math.max(0, hi + Math.max(0, Number(gap) || 0));
    }
    function contactPitchYV94(a, b, dx, gap, fast) {
        var span = Math.max(0.25, Math.min(a.w, a.h, b.w, b.h) / (fast ? 36 : 64));
        var hi = a.h + b.h + 1, bottom = hi, y, found = false, lo = -b.h - 1, i, mid;
        for (y = hi; y >= lo; y -= span) {
            if (!pairNoOverlapV94(a, b, dx, y)) { found = true; break; }
            bottom = y;
        }
        if (!found) { return Math.max(a.h, b.h) + Math.max(0, Number(gap) || 0); }
        lo = y; hi = bottom;
        if (hi < lo) { hi = lo + span; }
        for (i = 0; i < 24 && hi - lo > 0.0002; i++) {
            mid = (lo + hi) / 2;
            if (pairNoOverlapV94(a, b, dx, mid)) { hi = mid; } else { lo = mid; }
        }
        return Math.max(0, hi + Math.max(0, Number(gap) || 0));
    }
    function fitsOrthogonalV94(v, x, y, placed, binW, binH) {
        if (x < -EPS || y < -EPS || x + v.w > binW + EPS || y + v.h > binH + EPS) { return false; }
        var poly = translated(v.points, x, y), i, p;
        for (i = 0; i < placed.length; i++) {
            p = placed[i];
            if (x > p.x + p.w + EPS || p.x > x + v.w + EPS || y > p.y + p.h + EPS || p.y > y + v.h + EPS) { continue; }
            if (polygonsOverlap(poly, p.poly)) { return false; }
        }
        return poly;
    }
    function variantAtAngleV34(variants, angle) {
        var i, a = ((Number(angle) % 360) + 360) % 360;
        for (i = 0; i < variants.length; i++) {
            if (Math.abs((((Number(variants[i].angle) % 360) + 360) % 360) - a) < 0.001) { return variants[i]; }
        }
        return null;
    }
    function refineFirstFitV83(testFn, lo, hi) {
        /* Tìm biên tiếp xúc + gap bằng binary search. Safety 0.002mm chỉ để
           tránh sai số float/polyDistance của polygon, không làm thay đổi khe nhìn thấy. */
        var i, mid;
        lo = Math.max(0, Number(lo) || 0); hi = Math.max(lo, Number(hi) || 0);
        for (i = 0; i < 14 && hi - lo > 0.0003; i++) {
            mid = (lo + hi) / 2;
            if (testFn(mid)) { hi = mid; } else { lo = mid; }
        }
        return hi + 0.002;
    }
    function minPitchYV34(v, gap, fast, strictGap) {
        var step = Math.max(strictGap ? 0.08 : 0.2, Math.min(v.w, v.h) / (fast ? (strictGap ? 90 : 36) : (strictGap ? 140 : 64)));
        var y, prev = 0;
        for (y = step; y <= v.h + gap + step * 2; y += step) {
            if (pairFits(v, v, 0, y, gap)) {
                return strictGap ? refineFirstFitV83(function(q){ return pairFits(v, v, 0, q, gap); }, prev, y) : y;
            }
            prev = y;
        }
        return v.h + gap;
    }
    function minPitchXV34(a, b, dy, gap, fast, strictGap) {
        var step = Math.max(strictGap ? 0.08 : 0.2, Math.min(a.w, a.h, b.w, b.h) / (fast ? (strictGap ? 100 : 42) : (strictGap ? 160 : 72)));
        var x, start = strictGap ? step : Math.max(step, Math.min(a.w, b.w) * 0.12), end = a.w + b.w + gap + step, prev = 0;
        for (x = start; x <= end; x += step) {
            if (pairFits(a, b, x, dy, gap)) {
                return strictGap ? refineFirstFitV83(function(q){ return pairFits(a, b, q, dy, gap); }, prev, x) : x;
            }
            prev = x;
        }
        return Math.max(a.w, b.w) + gap;
    }
    function maxAdjacentPitchXV34(a, b, shiftY, pitchY, gap, fast, strictGap) {
        return Math.max(minPitchXV34(a, b, shiftY, gap, fast, strictGap),
            minPitchXV34(a, b, shiftY - pitchY, gap, fast, strictGap),
            minPitchXV34(a, b, shiftY + pitchY, gap, fast, strictGap));
    }

    /* V95 PROFILE-LATTICE EXACT GAP
       Với KHUÔN ĐẶC BIỆT, tính envelope trái/phải và trên/dưới theo scanline.
       Pitch X/Y được suy ra trực tiếp từ envelope nên không cần quét va chạm
       O(n²) hàng nghìn lần. Solver thử cả dàn theo cột + theo hàng, tất cả
       cặp góc 0/90/180/270 và 8 pha lệch, ưu tiên số con trước. */
    function profileStepV95(a,b){
        var d=Math.max(0.1,Math.min(a.w,a.h,b?b.w:a.w,b?b.h:a.h));
        return Math.max(0.025,Math.min(0.055,d/500));
    }
    function rawScanXRangeV95(v,y){
        var xs=[],p=v.points,i,a,b,lo,hi,t;
        for(i=0;i<p.length;i++){
            a=p[i];b=p[(i+1)%p.length];
            if(Math.abs(Number(a.y)-Number(b.y))<1e-9){continue;}
            lo=Math.min(Number(a.y),Number(b.y));hi=Math.max(Number(a.y),Number(b.y));
            if(y<lo-EPS||y>=hi-EPS){continue;}
            t=(y-Number(a.y))/(Number(b.y)-Number(a.y));xs.push(Number(a.x)+t*(Number(b.x)-Number(a.x)));
        }
        if(!xs.length){return null;} xs.sort(function(a,b){return a-b;}); return [xs[0],xs[xs.length-1]];
    }
    function rawScanYRangeV95(v,x){
        var ys=[],p=v.points,i,a,b,lo,hi,t;
        for(i=0;i<p.length;i++){
            a=p[i];b=p[(i+1)%p.length];
            if(Math.abs(Number(a.x)-Number(b.x))<1e-9){continue;}
            lo=Math.min(Number(a.x),Number(b.x));hi=Math.max(Number(a.x),Number(b.x));
            if(x<lo-EPS||x>=hi-EPS){continue;}
            t=(x-Number(a.x))/(Number(b.x)-Number(a.x));ys.push(Number(a.y)+t*(Number(b.y)-Number(a.y)));
        }
        if(!ys.length){return null;} ys.sort(function(a,b){return a-b;}); return [ys[0],ys[ys.length-1]];
    }
    function ensureProfileV95(v){
        if(v._anpProfileV95){return v._anpProfileV95;}
        var st=profileStepV95(v,v),ny=Math.max(1,Math.ceil(Number(v.h)/st)),nx=Math.max(1,Math.ceil(Number(v.w)/st));
        var L=[],R=[],T=[],B=[],i,p0,p1,p2,lo,hi,y0,y1,yc,x0,x1,xc,eps=Math.min(0.00005,st*0.01);
        for(i=0;i<ny;i++){
            y0=i*st;y1=Math.min(Number(v.h),(i+1)*st);yc=(y0+y1)/2;lo=1e30;hi=-1e30;
            p0=rawScanXRangeV95(v,Math.min(Number(v.h)-eps,y0+eps));p1=rawScanXRangeV95(v,yc);p2=rawScanXRangeV95(v,Math.max(eps,y1-eps));
            if(p0){lo=Math.min(lo,p0[0]);hi=Math.max(hi,p0[1]);}if(p1){lo=Math.min(lo,p1[0]);hi=Math.max(hi,p1[1]);}if(p2){lo=Math.min(lo,p2[0]);hi=Math.max(hi,p2[1]);}
            L[i]=lo===1e30?null:lo;R[i]=hi===-1e30?null:hi;
        }
        for(i=0;i<nx;i++){
            x0=i*st;x1=Math.min(Number(v.w),(i+1)*st);xc=(x0+x1)/2;lo=1e30;hi=-1e30;
            p0=rawScanYRangeV95(v,Math.min(Number(v.w)-eps,x0+eps));p1=rawScanYRangeV95(v,xc);p2=rawScanYRangeV95(v,Math.max(eps,x1-eps));
            if(p0){lo=Math.min(lo,p0[0]);hi=Math.max(hi,p0[1]);}if(p1){lo=Math.min(lo,p1[0]);hi=Math.max(hi,p1[1]);}if(p2){lo=Math.min(lo,p2[0]);hi=Math.max(hi,p2[1]);}
            T[i]=lo===1e30?null:lo;B[i]=hi===-1e30?null:hi;
        }
        v._anpProfileV95={step:st,left:L,right:R,top:T,bottom:B,ny:ny,nx:nx};return v._anpProfileV95;
    }
    function scanXRangeV95(v,y){
        var p=ensureProfileV95(v),i;if(y<0||y>Number(v.h)+EPS){return null;}i=Math.floor(Math.max(0,Math.min(Number(v.h)-EPS,y))/p.step);if(i<0){i=0;}if(i>=p.ny){i=p.ny-1;}if(p.left[i]===null||p.right[i]===null){return null;}return [p.left[i],p.right[i]];
    }
    function scanYRangeV95(v,x){
        var p=ensureProfileV95(v),i;if(x<0||x>Number(v.w)+EPS){return null;}i=Math.floor(Math.max(0,Math.min(Number(v.w)-EPS,x))/p.step);if(i<0){i=0;}if(i>=p.nx){i=p.nx-1;}if(p.top[i]===null||p.bottom[i]===null){return null;}return [p.top[i],p.bottom[i]];
    }
    function profilePitchXV95(a,b,dy,gap){
        var st=profileStepV95(a,b),ys=Math.max(0,Number(dy)),ye=Math.min(Number(a.h),Number(dy)+Number(b.h));
        var y,ra,rb,req=-1e30,seen=false;
        if(ye<=ys+EPS){return 0;}
        for(y=ys+st*0.5;y<ye;y+=st){
            ra=scanXRangeV95(a,y);rb=scanXRangeV95(b,y-Number(dy)); if(!ra||!rb){continue;}
            seen=true; req=Math.max(req,Number(ra[1])+Number(gap)-Number(rb[0]));
        }
        return seen?Math.max(0,req+0.006):0;
    }
    function profilePitchYV95(a,b,dx,gap){
        var st=profileStepV95(a,b),xs=Math.max(0,Number(dx)),xe=Math.min(Number(a.w),Number(dx)+Number(b.w));
        var x,ra,rb,req=-1e30,seen=false;
        if(xe<=xs+EPS){return 0;}
        for(x=xs+st*0.5;x<xe;x+=st){
            ra=scanYRangeV95(a,x);rb=scanYRangeV95(b,x-Number(dx));if(!ra||!rb){continue;}
            seen=true;req=Math.max(req,Number(ra[1])+Number(gap)-Number(rb[0]));
        }
        return seen?Math.max(0,req+0.006):0;
    }
    function profileMaxPXV95(a,b,shift,py,gap){
        var K=Math.min(5,Math.ceil((a.h+b.h)/Math.max(py,0.01))+1),k,r=0;
        for(k=-K;k<=K;k++){r=Math.max(r,profilePitchXV95(a,b,shift+k*py,gap));}return r;
    }
    function profileMaxPYV95(a,b,shift,px,gap){
        var K=Math.min(5,Math.ceil((a.w+b.w)/Math.max(px,0.01))+1),k,r=0;
        for(k=-K;k<=K;k++){r=Math.max(r,profilePitchYV95(a,b,shift+k*px,gap));}return r;
    }

    /* V100 BALANCED AUTO MAX
       Khi nhiều layout có CÙNG số con và cùng Exact Gap, ưu tiên pattern cân đối:
       - tâm từng hàng/cột gần tâm chung;
       - khối lượng hình không lệch một phía;
       - sau đó mới ưu tiên bounding-box nhỏ hơn.
       Không giảm số con và không nới gap. */
    function lineBalancePenaltyV100(items, byRows) {
        var i, it, cross, primaryMin, primaryMax, minDim=1e30, arr=[], groups=[], g, last, tol, b, globalCenter, span, penalty=0, groupCenter;
        if (!items || !items.length) { return 1e30; }
        b=placedBoundsV45(items); if(!b){return 1e30;}
        globalCenter=byRows?(b.minX+b.maxX)/2:(b.minY+b.maxY)/2;
        span=Math.max(EPS,byRows?(b.maxX-b.minX):(b.maxY-b.minY));
        for(i=0;i<items.length;i++){
            it=items[i];
            cross=byRows?(Number(it.y)+Number(it.h)/2):(Number(it.x)+Number(it.w)/2);
            primaryMin=byRows?Number(it.x):Number(it.y);
            primaryMax=byRows?(Number(it.x)+Number(it.w)):(Number(it.y)+Number(it.h));
            minDim=Math.min(minDim,byRows?Number(it.h):Number(it.w));
            arr.push({cross:cross,min:primaryMin,max:primaryMax});
        }
        arr.sort(function(a,b){return a.cross-b.cross;});
        tol=Math.max(0.08,Math.min(2.0,minDim*0.12));
        for(i=0;i<arr.length;i++){
            last=groups.length?groups[groups.length-1]:null;
            if(!last || Math.abs(arr[i].cross-last.crossMean)>tol){
                groups.push({crossMean:arr[i].cross,n:1,min:arr[i].min,max:arr[i].max});
            }else{
                last.crossMean=(last.crossMean*last.n+arr[i].cross)/(last.n+1);last.n++;
                if(arr[i].min<last.min){last.min=arr[i].min;}if(arr[i].max>last.max){last.max=arr[i].max;}
            }
        }
        for(i=0;i<groups.length;i++){
            g=groups[i];groupCenter=(g.min+g.max)/2;
            penalty += Math.abs(groupCenter-globalCenter)/span;
        }
        return groups.length?penalty/groups.length:0;
    }
    function layoutQualityV100(items) {
        var b,area,rowP,colP,i,it,mx=0,my=0,total=0,cx,cy,spanX,spanY,massP;
        if(!items||!items.length){return {balance:1e30,area:1e30};}
        b=placedBoundsV45(items);if(!b){return {balance:1e30,area:1e30};}
        spanX=Math.max(EPS,b.maxX-b.minX);spanY=Math.max(EPS,b.maxY-b.minY);
        for(i=0;i<items.length;i++){
            it=items[i];cx=Number(it.x)+Number(it.w)/2;cy=Number(it.y)+Number(it.h)/2;
            mx+=cx;my+=cy;total++;
        }
        mx/=Math.max(1,total);my/=Math.max(1,total);
        massP=Math.abs(mx-(b.minX+b.maxX)/2)/spanX + Math.abs(my-(b.minY+b.maxY)/2)/spanY;
        rowP=lineBalancePenaltyV100(items,true);colP=lineBalancePenaltyV100(items,false);
        area=spanX*spanY;
        return {balance:rowP+colP+massP*1.5,area:area};
    }
    function betterItemsV100(bestItems,candItems){
        var qb,qc,db;
        if(!candItems){return bestItems;}if(!bestItems||!bestItems.length){return candItems;}
        if(candItems.length!==bestItems.length){return candItems.length>bestItems.length?candItems:bestItems;}
        qb=layoutQualityV100(bestItems);qc=layoutQualityV100(candItems);db=qc.balance-qb.balance;
        if(db<-0.00001){return candItems;}if(db>0.00001){return bestItems;}
        if(qc.area<qb.area-EPS){return candItems;}return bestItems;
    }

    function profileBetterV95(best,cand){
        var chosen;
        if(!cand){return best;}if(!best){return cand;}
        chosen=betterItemsV100(best.items,cand.items);
        return chosen===cand.items?cand:best;
    }
    function profileColumnsV95(cfg,variants){
        var best=null,ai,bi,a,b,py,fi,frac,shift,pAB,pBA,selfX,items,x,col,v,y0,y,limit;
        var fr=[0,0.125,-0.125,0.25,-0.25,0.375,-0.375,0.5,-0.5,0.625,-0.625,0.75,-0.75,0.875,-0.875];
        limit=cfg.maxQty>0?cfg.maxQty:10000;
        for(ai=0;ai<variants.length;ai++){a=variants[ai];for(bi=0;bi<variants.length;bi++){b=variants[bi];
            py=Math.max(profilePitchYV95(a,a,0,cfg.gapY),profilePitchYV95(b,b,0,cfg.gapY));if(!(py>EPS)){continue;}
            selfX=Math.max(profilePitchXV95(a,a,0,cfg.gapX),profilePitchXV95(b,b,0,cfg.gapX));
            for(fi=0;fi<fr.length;fi++){frac=fr[fi];shift=py*frac;pAB=profileMaxPXV95(a,b,shift,py,cfg.gapX);pBA=profileMaxPXV95(b,a,-shift,py,cfg.gapX);
                if(!(pAB+pBA>EPS)||pAB+pBA+0.0001<selfX){continue;}
                items=[];x=0;col=0;
                while(x+((col%2)?b.w:a.w)<=cfg.binW+EPS){v=(col%2)?b:a;y0=(col%2)?shift:0;
                    for(y=y0;y+v.h<=cfg.binH+EPS;y+=py){items.push({x:x,y:y,w:v.w,h:v.h,angle:v.angle,rotated:Math.abs((v.angle%180)-90)<0.001,offsetX:v.offsetX,offsetY:v.offsetY});if(items.length>=limit){break;}}
                    if(items.length>=limit){break;}x+=(col%2)?pBA:pAB;col++;if(col>2000){break;}
                }
                best=profileBetterV95(best,{items:items,count:items.length,method:"true-shape-profile-columns-v95",profileGap:true,pitchY:py});
            }
        }}return best;
    }
    function profileRowsV95(cfg,variants){
        var best=null,ai,bi,a,b,px,fi,frac,shift,pAB,pBA,selfY,items,y,row,v,x0,x,limit;
        var fr=[0,0.125,-0.125,0.25,-0.25,0.375,-0.375,0.5,-0.5,0.625,-0.625,0.75,-0.75,0.875,-0.875];limit=cfg.maxQty>0?cfg.maxQty:10000;
        for(ai=0;ai<variants.length;ai++){a=variants[ai];for(bi=0;bi<variants.length;bi++){b=variants[bi];
            px=Math.max(profilePitchXV95(a,a,0,cfg.gapX),profilePitchXV95(b,b,0,cfg.gapX));if(!(px>EPS)){continue;}
            selfY=Math.max(profilePitchYV95(a,a,0,cfg.gapY),profilePitchYV95(b,b,0,cfg.gapY));
            for(fi=0;fi<fr.length;fi++){frac=fr[fi];shift=px*frac;pAB=profileMaxPYV95(a,b,shift,px,cfg.gapY);pBA=profileMaxPYV95(b,a,-shift,px,cfg.gapY);
                if(!(pAB+pBA>EPS)||pAB+pBA+0.0001<selfY){continue;}
                items=[];y=0;row=0;
                while(y+((row%2)?b.h:a.h)<=cfg.binH+EPS){v=(row%2)?b:a;x0=(row%2)?shift:0;
                    for(x=x0;x+v.w<=cfg.binW+EPS;x+=px){items.push({x:x,y:y,w:v.w,h:v.h,angle:v.angle,rotated:Math.abs((v.angle%180)-90)<0.001,offsetX:v.offsetX,offsetY:v.offsetY});if(items.length>=limit){break;}}
                    if(items.length>=limit){break;}y+=(row%2)?pBA:pAB;row++;if(row>2000){break;}
                }
                best=profileBetterV95(best,{items:items,count:items.length,method:"true-shape-profile-rows-v95",profileGap:true,pitchX:px});
            }
        }}return best;
    }
    function profilePackV95(cfg,variants){
        var a=profileColumnsV95(cfg,variants),b=profileRowsV95(cfg,variants),best=profileBetterV95(a,b);
        if(!best){return {items:[],count:0,method:"true-shape-profile-v95",profileGap:true};}
        best.count=best.items.length;best.strictGap=true;best.profileGap=true;best.efficiency=best.count*cfg.area/Math.max(EPS,cfg.binW*cfg.binH);return best;
    }

    function interlockingColumnsV34(cfg, variants) {
        var pairs = [[90,270],[270,90],[0,180],[180,0]], best = [], bestArea = 1e30, pi, a, b, py;
        var shifts, si, shift, pAB, pBA, twoPitch, items, col, x, y, v, y0, poly, local, limit, bnd, areaScore;
        limit = cfg.maxQty > 0 ? cfg.maxQty : Math.min(10000, Math.ceil(cfg.binW * cfg.binH / Math.max(0.01, cfg.area)) + 12);
        for (pi = 0; pi < pairs.length; pi++) {
            a = variantAtAngleV34(variants, pairs[pi][0]); b = variantAtAngleV34(variants, pairs[pi][1]);
            if (!a || !b) { continue; }
            py = Math.max(minPitchYV34(a, cfg.strictGap ? cfg.gapY : cfg.gap, cfg.fast, cfg.strictGap), minPitchYV34(b, cfg.strictGap ? cfg.gapY : cfg.gap, cfg.fast, cfg.strictGap));
            /* V95: thử thêm 1/4 và 3/4 bước để không mất số con khi khuôn lõm khóa lệch tâm. */
            shifts = cfg.strictGap ? [0, py*0.5,-py*0.5, py*0.25,-py*0.25, py*0.75,-py*0.75, py*0.125,-py*0.125, py*0.375,-py*0.375, py*0.625,-py*0.625, py*0.875,-py*0.875] : [0, py / 2];
            for (si = 0; si < shifts.length; si++) {
                shift = shifts[si];
                pAB = maxAdjacentPitchXV34(a, b, shift, py, cfg.strictGap ? cfg.gapX : cfg.gap, cfg.fast, cfg.strictGap);
                pBA = maxAdjacentPitchXV34(b, a, -shift, py, cfg.strictGap ? cfg.gapX : cfg.gap, cfg.fast, cfg.strictGap);
                twoPitch = pAB + pBA;
                if (!pairFits(a, a, twoPitch, 0, cfg.strictGap ? cfg.gapX : cfg.gap) || !pairFits(b, b, twoPitch, 0, cfg.strictGap ? cfg.gapX : cfg.gap)) { continue; }
                items = []; x = 0; col = 0;
                while (x + ((col % 2) ? b.w : a.w) <= cfg.binW + EPS) {
                    v = (col % 2) ? b : a; y0 = (col % 2) ? shift : 0;
                    for (y = y0; y + v.h <= cfg.binH + EPS; y += py) {
                        local = items.slice(Math.max(0, items.length - Math.ceil(cfg.binH / Math.max(EPS, py)) * 3 - 6));
                        poly = fits(v, x, y, local, cfg.binW, cfg.binH, cfg.gap);
                        if (poly) {
                            items.push({x:x,y:y,w:v.w,h:v.h,angle:v.angle,
                                rotated:Math.abs((v.angle % 180) - 90)<0.001,
                                offsetX:v.offsetX,offsetY:v.offsetY,poly:poly});
                            if (items.length >= limit) { break; }
                        }
                    }
                    if (items.length >= limit) { break; }
                    x += (col % 2) ? pBA : pAB; col++;
                }
                bnd=placedBoundsV45(items); areaScore=bnd?(bnd.maxX-bnd.minX)*(bnd.maxY-bnd.minY):1e30;
                if (betterItemsV100(best,items) === items) {
                    best = items; bestArea = areaScore;
                }
            }
        }
        return {items:best,count:best.length,method:cfg.strictGap?"true-shape-interlocking-precision-v95":"true-shape-interlocking-columns",
            strictGap:cfg.strictGap===true,efficiency:best.length * cfg.area / Math.max(EPS, cfg.binW * cfg.binH)};
    }
    function staggered(cfg, variants) {
        var best = [], bestMeta = null, ai, bi, a, b, dxs, di, dx, dy, step, found, prev, rowPitch, r, x, y, v, rowItems, limit, local, poly, keep;
        limit = cfg.maxQty > 0 ? cfg.maxQty : Math.min(10000, Math.ceil(cfg.binW * cfg.binH / Math.max(0.01, cfg.area)) + 12);
        for (ai = 0; ai < Math.min(variants.length, 6); ai++) {
            a = variants[ai];
            for (bi = 0; bi < Math.min(variants.length, 6); bi++) {
                b = variants[bi]; dxs = [0, a.w * 0.25, a.w * 0.5, a.w * 0.75];
                for (di = 0; di < dxs.length; di++) {
                    dx = dxs[di]; step = Math.max(cfg.strictGap ? 0.08 : 0.25, Math.min(a.w, a.h, b.w, b.h) / (cfg.fast ? (cfg.strictGap ? 90 : 22) : (cfg.strictGap ? 140 : 42)));
                    found = -1; prev = 0;
                    var yGap = cfg.strictGap ? cfg.gapY : cfg.gap;
                    for (dy = Math.max(cfg.strictGap ? step : gapOrZero(yGap), step); dy <= a.h + b.h + yGap + EPS; dy += step) {
                        if (pairFits(a, b, dx, dy, yGap)) {
                            found = cfg.strictGap ? refineFirstFitV83(function(q){ return pairFits(a, b, dx, q, yGap); }, prev, dy) : dy;
                            break;
                        }
                        prev = dy;
                    }
                    if (found < 0) { continue; }
                    if (!bestMeta || found < bestMeta.dy - EPS || (Math.abs(found - bestMeta.dy) < EPS && dx < bestMeta.dx)) {
                        bestMeta = { a:a, b:b, dx:dx, dy:found };
                    }
                }
            }
        }
        if (!bestMeta) { return {items:[],count:0,method:"true-shape-staggered"}; }
        for (var phase = 0; phase < 2; phase++) {
            var items = [], baseX = phase ? bestMeta.dx : 0;
            for (r = 0, y = 0; y + Math.min(bestMeta.a.h, bestMeta.b.h) <= cfg.binH + EPS; r++, y += bestMeta.dy) {
                v = (r % 2) ? bestMeta.b : bestMeta.a;
                x = baseX + ((r % 2) ? bestMeta.dx : 0);
                rowItems = [];
                rowPitch = cfg.strictGap ? minPitchXV34(v, v, 0, cfg.gapX, cfg.fast, true) : (v.w + cfg.gap);
                while (x + v.w <= cfg.binW + EPS) {
                    keep = Math.min(180, Math.ceil(cfg.binW / Math.max(EPS, Math.min(v.w, bestMeta.a.w, bestMeta.b.w))) + 12);
                    local = items.slice(Math.max(0, items.length - keep));
                    poly = fits(v, x, y, local, cfg.binW, cfg.binH, cfg.gap);
                    if (!poly) { x += rowPitch; continue; }
                    items.push({x:x,y:y,w:v.w,h:v.h,angle:v.angle,rotated:Math.abs((v.angle%180)-90)<EPS,
                        offsetX:v.offsetX,offsetY:v.offsetY,poly:poly});
                    rowItems.push({x:x,v:v}); if (items.length >= limit) { break; }
                    x += rowPitch;
                }
                if (items.length >= limit) { break; }
            }
            if (betterItemsV100(best,items) === items) { best = items; }
        }
        return {items:best,count:best.length,method:cfg.strictGap?"true-shape-staggered-precision-v95":"true-shape-staggered",
            strictGap:cfg.strictGap===true,efficiency:best.length * cfg.area / Math.max(EPS, cfg.binW * cfg.binH)};
    }
    function gapOrZero(v) { return Math.max(0, Number(v) || 0); }
    function stripPrivate(items) {
        var out = [], i, p;
        for (i = 0; i < items.length; i++) { p = items[i]; out.push({ x:p.x,y:p.y,w:p.w,h:p.h,angle:p.angle,rotated:p.rotated,offsetX:p.offsetX,offsetY:p.offsetY,
            sourceIndex:p.sourceIndex,copyIndex:p.copyIndex }); }
        return out;
    }
    function mixedAreaV45(item) {
        if (item._anpAreaV45 === undefined) { item._anpAreaV45 = polygonArea(item.shape.points); }
        return Number(item._anpAreaV45);
    }
    function mixedVariantKeyV45(job) {
        var sig = job && job.shape ? String(job.shape.signature || (job.shape.w + "x" + job.shape.h + "#" + job.shape.points.length)) : "shape";
        return String(job.sourceIndex === undefined ? "_" : job.sourceIndex) + "|" + sig;
    }
    function mixedVariantsV45(job, cfg) {
        var cache = cfg._anpVariantCacheV45 || (cfg._anpVariantCacheV45 = {}), key = mixedVariantKeyV45(job);
        if (!cache[key]) { cache[key] = orientationList(job.shape.points, job.shape.w, job.shape.h, cfg.angles); }
        return cache[key];
    }
    function mixedOrder(items, kind) {
        var out = items.slice(0); out.sort(function(a,b) {
            var aa = mixedAreaV45(a), ba = mixedAreaV45(b), d;
            if (kind === 1) { d = Math.max(b.shape.w,b.shape.h)-Math.max(a.shape.w,a.shape.h); if (Math.abs(d)>EPS) { return d; } }
            if (kind === 2) { d = b.shape.h-a.shape.h; if (Math.abs(d)>EPS) { return d; } }
            if (kind === 3) { d = b.shape.w-a.shape.w; if (Math.abs(d)>EPS) { return d; } }
            return ba-aa;
        }); return out;
    }
    function placeMixedOrder(items, cfg, strategy) {
        var placed=[], skipped=[], i, vi, ci, job, variants, pts, poly, best, score, v, placedBox;
        for (i=0;i<items.length;i++) {
            job=items[i]; variants=mixedVariantsV45(job,cfg); best=null; placedBox=placedBoundsV45(placed);
            for (vi=0;vi<variants.length;vi++) {
                v=variants[vi]; pts=candidatePoints(placed,v,cfg.binW,cfg.binH,cfg.gap,strategy,cfg.fast?72:180);
                for (ci=0;ci<pts.length;ci++) {
                    poly=fits(v,pts[ci].x,pts[ci].y,placed,cfg.binW,cfg.binH,cfg.gap); if(!poly){continue;}
                    score=compactScoreBoundsV45(pts[ci].x,pts[ci].y,v,placedBox,strategy)+vi*0.0001;
                    if(!best||score<best.score){best={score:score,v:v,x:pts[ci].x,y:pts[ci].y,poly:poly};}
                    if(ci>(cfg.fast?58:150)&&best){break;}
                }
            }
            if(!best){skipped.push(job);continue;}
            placed.push({x:best.x,y:best.y,w:best.v.w,h:best.v.h,angle:best.v.angle,
                rotated:Math.abs(best.v.angle-90)<0.001,offsetX:best.v.offsetX,offsetY:best.v.offsetY,poly:best.poly,
                sourceIndex:job.sourceIndex,copyIndex:job.copyIndex});
        }
        return {items:placed,skipped:skipped};
    }
    function packMixed(cfg) {
        var best=null,kind,strategy,cand,kindLimit=cfg.fast?2:4,strategyLimit=cfg.fast?2:4;
        /* V4.5: cache góc xoay theo source/shape cho toàn bộ các chiến lược.
           Không đổi hình học hay số candidate; chỉ tránh rotate lại cùng polygon hàng nghìn lần. */
        cfg._anpVariantCacheV45 = {};
        for(kind=0;kind<kindLimit;kind++){for(strategy=0;strategy<strategyLimit;strategy++){
            cand=placeMixedOrder(mixedOrder(cfg.items,kind),cfg,strategy);
            if(!best||cand.items.length>best.items.length){best=cand;}
        }}
        if(!best){best={items:[],skipped:cfg.items.slice(0)};}
        best.items=stripPrivate(best.items);best.count=best.items.length;best.method="true-shape-mixed";
        return best;
    }
    function pack(cfg) {
        var shape = cfg.shape, poly = shape.points, area = polygonArea(poly), angles = cfg.angles || [0, 15, 30, 45, 60, 75, 90];
        var local = { binW:num(cfg.binW,0), binH:num(cfg.binH,0), gap:Math.max(0,num(cfg.gap,0)),
            gapX:Math.max(0,num(cfg.gapX,cfg.gap)), gapY:Math.max(0,num(cfg.gapY,cfg.gap)),
            maxQty:Math.max(0,Math.floor(num(cfg.maxQty,0))), area:area, shape:shape, fast:cfg.fast===true, strictGap:cfg.strictGap===true };
        if (shape.isCircle) { return honeycomb(local); }
        var variants = orientationList(poly, shape.w, shape.h, local.strictGap ? [0,90,180,270] : angles), best = [], strategy, cand, quick = null, interlock = null, bestMethod = "true-shape-polygon";
        /* V98 CACHE HOTFIX:
           Không return sớm ở Profile FAST nữa. Exact mode phải thử TẤT CẢ họ pattern tuần hoàn
           (profile hàng/cột + khóa nhau 90/270, 0/180 + so le) rồi chọn số con lớn nhất.
           Nhờ vậy bật khe đều không tự hy sinh số con chỉ vì solver đầu tiên tìm thấy layout an toàn. */
        if (local.strictGap && cfg.stagger !== false) {
            var profileLayoutV95 = profilePackV95(local, variants), looseCfgV97, looseInterV97, looseStaggerV97, looseTargetV97 = 0;
            if (profileLayoutV95 && betterItemsV100(best,profileLayoutV95.items) === profileLayoutV95.items) {
                best = profileLayoutV95.items; bestMethod = profileLayoutV95.method;
            }
            /* Probe rất nhanh layout "không strict" để biết số con mà người dùng đang thấy khi tắt Exact Gap.
               Nếu exact profile đã bằng/vượt số đó thì không cần chạy polygon search nặng. Nếu chưa bằng,
               dùng số đó làm target và dừng ngay khi exact interlock đạt được cùng số con. */
            looseCfgV97 = {binW:local.binW,binH:local.binH,gap:local.gap,gapX:local.gapX,gapY:local.gapY,
                maxQty:local.maxQty,area:local.area,shape:local.shape,fast:true,strictGap:false};
            looseInterV97 = interlockingColumnsV34(looseCfgV97, variants);
            looseStaggerV97 = staggered(looseCfgV97, variants);
            looseTargetV97 = Math.max(looseInterV97 ? looseInterV97.count : 0, looseStaggerV97 ? looseStaggerV97.count : 0);
            /* V100: luôn thử đủ interlock + stagger ngay cả khi profile đã đạt target.
               Mục tiêu là chọn layout CÙNG số con nhưng cân đối hơn, không dừng ở pattern đầu tiên. */
            local.exactTargetCount = looseTargetV97;
            interlock = interlockingColumnsV34(local, variants);
            if (interlock && betterItemsV100(best,interlock.items) === interlock.items) { best = interlock.items; bestMethod = interlock.method; }
            quick = staggered(local, variants);
            if (quick && betterItemsV100(best,quick.items) === quick.items) { best = quick.items; bestMethod = quick.method; }
            if (best.length) {
                return {items:stripPrivate(best),count:best.length,method:"true-shape-auto-max-balanced-v100|"+bestMethod,
                    strictGap:true,precisionGap:true,autoMaxExact:true,looseTargetV97:looseTargetV97,
                    efficiency:best.length * area / Math.max(EPS, local.binW * local.binH)};
            }
        }
        if (cfg.stagger !== false) {
            interlock = interlockingColumnsV34(local, variants);
            if (interlock.count > best.length) { best = interlock.items; bestMethod = interlock.method; }
            quick = staggered(local, variants);
            if (quick.count > best.length) { best = quick.items; bestMethod = quick.method; }
            if (local.fast && best.length >= 24) { return {items:stripPrivate(best),count:best.length,method:bestMethod,
                efficiency:best.length * area / Math.max(EPS, local.binW * local.binH)}; }
        }
        var strategyLimit = local.fast ? 2 : 4;
        for (strategy = 0; strategy < strategyLimit; strategy++) {
            cand = greedy(variants, local, strategy, strategy % Math.max(1, variants.length));
            if (cand.length > best.length) { best = cand; bestMethod = "true-shape-polygon"; }
        }
        return { items: stripPrivate(best), count: best.length, method:bestMethod,
            efficiency: best.length * area / (local.binW * local.binH) };
    }
    return { pack: pack, packMixed:packMixed, polygonArea: polygonArea, polyDistance: polyDistance, rotateVariant: rotateVariant, staggered:staggered,
        interlockingColumns:interlockingColumnsV34 };
}());
