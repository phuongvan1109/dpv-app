(function (root) {
  "use strict";

  function n(v, d) { var x = Number(v); return isFinite(x) ? x : d; }
  function cloneItem(x) {
    var y = {}, k; for (k in x) { if (x.hasOwnProperty(k)) { y[k] = x[k]; } } return y;
  }
  function angles(step) {
    var out = [], a, s = Math.max(5, Math.min(90, n(step, 15)));
    for (a = 0; a < 360; a += s) { out.push(a); }
    if (out.indexOf(90) < 0) { out.push(90); }
    if (out.indexOf(180) < 0) { out.push(180); }
    return out;
  }
  function axisSymmetric(shape, axis) {
    var pts=shape&&shape.points?shape.points:[],w=n(shape&&shape.w,0),h=n(shape&&shape.h,0);
    var tol=Math.max(0.15,Math.min(Math.max(w,0.15),Math.max(h,0.15))*0.015),i,j,tx,ty,found;
    if(pts.length<3||!(w>0)||!(h>0)){return false;}
    for(i=0;i<pts.length;i++){
      tx=axis==="x"?w-n(pts[i].x,0):n(pts[i].x,0);
      ty=axis==="y"?h-n(pts[i].y,0):n(pts[i].y,0);found=false;
      for(j=0;j<pts.length;j++){
        if(Math.abs(n(pts[j].x,0)-tx)<=tol&&Math.abs(n(pts[j].y,0)-ty)<=tol){found=true;break;}
      }
      if(!found){return false;}
    }
    return true;
  }
  function smartAngles(cfg,shape){
    if(cfg.allowRotate===false){return [0];}
    if(cfg.fastMode!==true){return angles(cfg.angleStep);}
    if(shape&&shape.isCircle===true){return [0];}
    if(axisSymmetric(shape,"x")||axisSymmetric(shape,"y")){return [0,90,180,270];}
    return [0,45,90,135,180,225,270,315];
  }
  function manualShape(kind, width, height) {
    var type = String(kind || "rectangle").toLowerCase();
    var w = n(width, 0), h = type === "circle" ? w : n(height, 0), points = [], i, segments = 48;
    if (!(w > 0) || !(h > 0)) { throw new Error("Kích thước tem thủ công phải lớn hơn 0 mm."); }
    if (type === "circle") {
      var r = w / 2, a;
      for (i = 0; i < segments; i++) {
        a = Math.PI * 2 * i / segments;
        points.push({ x:r + Math.cos(a) * r, y:r + Math.sin(a) * r });
      }
      return { points:points, w:w, h:w, isCircle:true, isRectangle:false,
        fillRatio:Math.PI / 4, signature:"MANUAL_C_" + w.toFixed(3) };
    }
    points = [{x:0,y:0},{x:w,y:0},{x:w,y:h},{x:0,y:h}];
    return { points:points, w:w, h:h, isCircle:false, isRectangle:true,
      fillRatio:1, signature:"MANUAL_R_" + w.toFixed(3) + "x" + h.toFixed(3) };
  }
  function layoutBounds(items) {
    var i, item, minX=1e20, minY=1e20, maxX=-1e20, maxY=-1e20;
    if (!items || !items.length) { return {minX:0,minY:0,maxX:0,maxY:0,usedW:0,usedH:0}; }
    for (i=0;i<items.length;i++) {
      item=items[i]; minX=Math.min(minX,n(item.x,0)); minY=Math.min(minY,n(item.y,0));
      maxX=Math.max(maxX,n(item.x,0)+n(item.w,0)); maxY=Math.max(maxY,n(item.y,0)+n(item.h,0));
    }
    return {minX:minX,minY:minY,maxX:maxX,maxY:maxY,usedW:maxX-minX,usedH:maxY-minY};
  }
  function cornerShiftValid(items, dx, dy, binW, binH, clear) {
    var i,item,x,y,right,bottom,L,R,T,B;
    if (!(clear>0)) { return true; }
    for (i=0;i<items.length;i++) {
      item=items[i]; x=n(item.x,0)+dx; y=n(item.y,0)+dy; right=x+n(item.w,0); bottom=y+n(item.h,0);
      L=x<clear-0.0001; R=right>binW-clear+0.0001; T=y<clear-0.0001; B=bottom>binH-clear+0.0001;
      if ((L&&T)||(R&&T)||(L&&B)||(R&&B)) { return false; }
    }
    return true;
  }
  function bestCenterShift(layout, binW, binH, desiredX, desiredY) {
    var items=layout.items||[], clear=n(layout.cornerClear,0), best=null, i,f,cx,cy,score;
    function consider(x,y) {
      if (!cornerShiftValid(items,x,y,binW,binH,clear)) { return; }
      score=(x-desiredX)*(x-desiredX)+(y-desiredY)*(y-desiredY);
      if (!best || score<best.score) { best={x:x,y:y,score:score}; }
    }
    consider(desiredX,desiredY); if (best && best.score<0.00000001) { return best; }
    consider(desiredX,0); consider(0,desiredY); consider(0,0);
    for (i=1;i<=40;i++) { f=1-i/40; cx=desiredX*f; cy=desiredY*f;
      consider(desiredX,cy); consider(cx,desiredY); consider(cx,cy); }
    return best||{x:0,y:0,score:0};
  }
  function center(layout, binW, binH) {
    var items=layout.items||[],i,b,dx,dy,shift;
    if (!items.length) { return layout; }
    if (layout.cornerSafe===true && layout.cornerSafeCentered!==true) {
      dx=-n(layout.edgeRelaxX,0); dy=-n(layout.edgeRelaxY,0);
      for (i=0;i<items.length;i++) { items[i].x+=dx; items[i].y+=dy; }
      layout.cornerSafeCentered=true;
    }
    b=layoutBounds(items); dx=(binW-b.usedW)/2-b.minX; dy=(binH-b.usedH)/2-b.minY;
    /* CENTER EXACT: corner-safe không được phép dịch cả bài ra khỏi tâm. */
    layout.centerExact=true;
    for (i=0;i<items.length;i++) { items[i].x+=dx; items[i].y+=dy; }
    b=layoutBounds(items); layout.usedW=b.usedW; layout.usedH=b.usedH; layout.centered=true;
    layout.centerDx=dx; layout.centerDy=dy; layout.layoutCenterX=(b.minX+b.maxX)/2; layout.layoutCenterY=(b.minY+b.maxY)/2;
    return layout;
  }
  function hardBoundsV101(layout, binW, binH) {
    var items=layout&&layout.items?layout.items:[],b,dx=0,dy=0,i,tol=0.001;
    if(!items.length){return layout;}
    b=layoutBounds(items);
    if(b.usedW>Number(binW)+tol || b.usedH>Number(binH)+tol){
      throw new Error("Bố cục vượt vùng dàn sau khi trừ lề. DPV đã chặn xuất để không phạm lề; hãy Tính nhanh lại.");
    }
    if(b.minX<0){dx=-b.minX;} if(b.maxX+dx>Number(binW)){dx+=Number(binW)-(b.maxX+dx);}
    if(b.minY<0){dy=-b.minY;} if(b.maxY+dy>Number(binH)){dy+=Number(binH)-(b.maxY+dy);}
    if(Math.abs(dx)>0.000001||Math.abs(dy)>0.000001){for(i=0;i<items.length;i++){items[i].x+=dx;items[i].y+=dy;}}
    b=layoutBounds(items);
    for(i=0;i<items.length;i++){
      if(Number(items[i].x)<-tol||Number(items[i].y)<-tol||Number(items[i].x)+Number(items[i].w)>Number(binW)+tol||Number(items[i].y)+Number(items[i].h)>Number(binH)+tol){
        throw new Error("Bố cục có chi tiết vượt lề an toàn. DPV đã chặn xuất thay vì tạo file sai.");
      }
    }
    layout.usedW=b.usedW;layout.usedH=b.usedH;layout.hardMarginV101=true;return layout;
  }
  function better(a, b) {
    if (!a) { return b; } if (!b) { return a; }
    if (a.items.length !== b.items.length) { return b.items.length > a.items.length ? b : a; }
    var aa = n(a.usedW, 0) * n(a.usedH, 0), ba = n(b.usedW, 0) * n(b.usedH, 0);
    return ba < aa ? b : a;
  }
  function cornerClear(cfg, binW, binH) {
    if (!cfg || cfg.cornerSafe !== true || cfg.demiMode === true) { return 0; }
    var clear = Math.max(0, n(cfg.cornerZone, 0) - Math.max(0, n(cfg.margin, 0)));
    return Math.min(clear, Math.max(0, binW / 2), Math.max(0, binH / 2));
  }
  function applyCornerSafe(layout, cfg, binW, binH) {
    var clear = cornerClear(cfg, binW, binH), items, kept = [], removed = [], i, item;
    if (!layout || clear <= 0) { return layout; }
    items = layout.items || [];
    for (i = 0; i < items.length; i++) {
      item = items[i];
      var atLeft = n(item.x, 0) < clear - 0.0001;
      var atRight = n(item.x, 0) + n(item.w, 0) > binW - clear + 0.0001;
      var atTop = n(item.y, 0) < clear - 0.0001;
      var atBottom = n(item.y, 0) + n(item.h, 0) > binH - clear + 0.0001;
      if ((atLeft && atTop) || (atRight && atTop) || (atLeft && atBottom) || (atRight && atBottom)) {
        removed.push(item);
      } else { kept.push(item); }
    }
    layout.items = kept; layout.count = kept.length; layout.cornerRemoved = removed;
    layout.cornerSafe = true; layout.cornerClear = clear;
    if (String(layout.method || "").indexOf("corner-safe") < 0) { layout.method = "corner-safe-" + (layout.method || "layout"); }
    return layout;
  }
  function demiCandidate(w, h, binW, binH, maxQty, rotated) {
    var cw = rotated ? h : w, ch = rotated ? w : h;
    var maxCols = Math.floor((binW + 0.0001) / cw), maxRows = Math.floor((binH + 0.0001) / ch);
    var capacity = Math.max(0, maxCols * maxRows), limit = Math.max(0, Math.floor(n(maxQty, 0)));
    var qty = limit > 0 ? Math.min(capacity, limit) : capacity;
    var cols = Math.min(maxCols, qty), rows = cols ? Math.ceil(qty / cols) : 0;
    var items = [], r, c, inRow, startCol, made = 0;
    for (r = 0; r < rows; r++) {
      inRow = Math.min(cols, qty - made); startCol = Math.floor((cols - inRow) / 2);
      for (c = 0; c < inRow; c++) {
        items.push({ x:(startCol + c) * cw, y:r * ch, w:cw, h:ch, rotated:rotated, angle:rotated ? 90 : 0 });
        made++;
      }
    }
    return { items:items, count:items.length, usedW:cols * cw, usedH:rows * ch, method:"demi-grid" };
  }
  function demi(cfg, w, h, binW, binH, maxQty) {
    var a = demiCandidate(w, h, binW, binH, maxQty, false), b = null;
    if (cfg.allowRotate !== false && Math.abs(w - h) > 0.0001) { b = demiCandidate(w, h, binW, binH, maxQty, true); }
    var best = b && b.count > a.count ? b : a;
    best.efficiency = best.count * w * h / Math.max(0.0001, binW * binH);
    return best;
  }
  function scaleShape(shape, w, h) {
    if (!shape || !shape.points) { return shape; }
    var sx = w / Math.max(0.0001, n(shape.w, w)), sy = h / Math.max(0.0001, n(shape.h, h));
    var pts = [], i;
    for (i = 0; i < shape.points.length; i++) { pts.push({ x:shape.points[i].x * sx, y:shape.points[i].y * sy }); }
    return { points:pts, w:w, h:h, isCircle:shape.isCircle === true, isRectangle:shape.isRectangle === true,
      fillRatio:n(shape.fillRatio, 0), signature:shape.signature || "" };
  }

  function uniformGridCandidateV82(cfg, w, h, binW, binH, maxQty, rotated) {
    var gx=Math.max(0,n(cfg.gapX,0)), gy=Math.max(0,n(cfg.gapY,0));
    var cw=rotated?h:w, ch=rotated?w:h;
    var cols=Math.floor((binW+gx+0.0001)/(cw+gx)), rows=Math.floor((binH+gy+0.0001)/(ch+gy));
    var items=[], r,c, usedW,usedH,startX,startY,limit=Math.max(0,Math.floor(n(maxQty,0)));
    if(cols<1||rows<1){return {items:[],count:0,usedW:0,usedH:0,method:rotated?'uniform-grid-90':'uniform-grid-0',edgeRelaxX:0,edgeRelaxY:0};}
    usedW=cols*cw+(cols-1)*gx; usedH=rows*ch+(rows-1)*gy;
    startX=(binW-usedW)/2; startY=(binH-usedH)/2;
    for(r=0;r<rows;r++){
      for(c=0;c<cols;c++){
        if(limit>0 && items.length>=limit){break;}
        items.push({x:startX+c*(cw+gx),y:startY+r*(ch+gy),w:cw,h:ch,rotated:rotated===true,angle:rotated?90:0});
      }
      if(limit>0 && items.length>=limit){break;}
    }
    var out={items:items,count:items.length,usedW:usedW,usedH:usedH,method:rotated?'uniform-grid-90':'uniform-grid-0',edgeRelaxX:0,edgeRelaxY:0};
    out=applyCornerSafe(out,cfg,binW,binH); out.count=out.items.length;
    out.efficiency=out.count*w*h/Math.max(0.0001,binW*binH); out.uniformGap=true;
    return out;
  }
  function uniformGridV82(cfg,w,h,binW,binH,maxQty){
    var a=uniformGridCandidateV82(cfg,w,h,binW,binH,maxQty,false), b=null;
    if(cfg.allowRotate!==false && Math.abs(w-h)>0.0001){b=uniformGridCandidateV82(cfg,w,h,binW,binH,maxQty,true);}
    if(!b){return a;} if(b.count!==a.count){return b.count>a.count?b:a;}
    return (b.usedW*b.usedH<a.usedW*a.usedH)?b:a;
  }


  /* V132 SAFETY: every mixed 0/90 candidate must be a real, axis-aligned
     non-overlapping placement with the requested X/Y gap.  It also receives an
     explicit angle so the live KHUON_BE preview and Illustrator cache interpret
     rotated cells identically. */
  function normalizeAnglesV132(layout) {
    var items=layout&&layout.items?layout.items:[],i,it;
    for(i=0;i<items.length;i++){
      it=items[i];
      if(it.angle===undefined||!isFinite(Number(it.angle))){it.angle=it.rotated===true?90:0;}
      it.rotated=Math.abs((Number(it.angle)%180+180)%180-90)<0.001;
      if(it.offsetX===undefined){it.offsetX=0;} if(it.offsetY===undefined){it.offsetY=0;}
    }
    return layout;
  }
  function exactGapSafeV132(layout,binW,binH,gx,gy){
    var items=layout&&layout.items?layout.items:[],i,j,a,b,tol=0.0005;
    gx=Math.max(0,n(gx,0));gy=Math.max(0,n(gy,0));
    for(i=0;i<items.length;i++){
      a=items[i];
      if(n(a.x,0)<-tol||n(a.y,0)<-tol||n(a.x,0)+n(a.w,0)>binW+tol||n(a.y,0)+n(a.h,0)>binH+tol){return false;}
      for(j=i+1;j<items.length;j++){
        b=items[j];
        if(!(n(a.x,0)+n(a.w,0)+gx<=n(b.x,0)+tol ||
             n(b.x,0)+n(b.w,0)+gx<=n(a.x,0)+tol ||
             n(a.y,0)+n(a.h,0)+gy<=n(b.y,0)+tol ||
             n(b.y,0)+n(b.h,0)+gy<=n(a.y,0)+tol)){return false;}
      }
    }
    return true;
  }

  /* V131 MIXED ROTATION MAX
     Rectangle/manual/artboard jobs with Exact Gap used to stop at one orientation
     whenever uniformGap was ON.  That leaves large dead strips for long/narrow jobs.
     V131 evaluates BOTH:
       1) the stable one-orientation exact grid, and
       2) every 0/90 mixed row/column shelf combination from ANPPacker.
     The mixed candidate is accepted ONLY when it physically fits the hard bin and
     produces MORE pieces.  On a tie we deliberately keep the regular grid, which
     preserves the user's production preference: straight/easy layout unless a mixed
     rotation genuinely increases yield.  Gap X/Y stay exact because ANPPacker builds
     shelves using item dimension + the requested axis gap, not a relaxed collision gap. */
  function mixedExactV131(cfg,w,h,binW,binH,maxQty){
    var regular=uniformGridV82(cfg,w,h,binW,binH,maxQty), mixed=null, clear=cornerClear(cfg,binW,binH);
    if(cfg.allowRotate!==false && Math.abs(w-h)>0.0001 && root.ANPPacker && root.ANPPacker.pack){
      mixed=root.ANPPacker.pack({binW:binW,binH:binH,itemW:w,itemH:h,
        gapX:Math.max(0,n(cfg.gapX,0)),gapY:Math.max(0,n(cfg.gapY,0)),
        allowRotate:true,maxQty:maxQty||0,cornerClear:clear});
      mixed=normalizeAnglesV132(mixed);
      mixed=applyCornerSafe(mixed,cfg,binW,binH);
      mixed=normalizeAnglesV132(mixed);
      if(!exactGapSafeV132(mixed,binW,binH,cfg.gapX,cfg.gapY)){mixed=null;}
      if(mixed){
        mixed.count=mixed.items.length;
        mixed.efficiency=mixed.count*w*h/Math.max(0.0001,binW*binH);
        mixed.uniformGap=true; mixed.strictGap=true; mixed.mixedRotationV131=true; mixed.mixedRotationSafeV132=true;
        mixed.exactGapX=Math.max(0,n(cfg.gapX,0)); mixed.exactGapY=Math.max(0,n(cfg.gapY,0));
      }
    }
    regular=normalizeAnglesV132(regular); regular.count=regular.items.length; regular.uniformGap=true; regular.strictGap=true;
    /* MAX COUNT first. Tie => regular straight grid, never mixed just for appearance. */
    if(mixed && mixed.count>regular.count){
      mixed.method='mixed-exact-max-v131|'+String(mixed.method||'mixed');
      return mixed;
    }
    regular.method='regular-exact-v131|'+String(regular.method||'uniform-grid');
    return regular;
  }

  function equal(cfg, w, h, shape, binW, binH, maxQty) {
    if (cfg.demiMode) { return center(demi(cfg, w, h, binW, binH, maxQty), binW, binH); }
    /* V83: nếu là KHUÔN ĐẶC BIỆT + khe đều, vẫn cho xoay chiều. Khoảng cách
       được đo trên contour thật, không dùng bbox và không ép toàn tờ một hướng. */
    if (cfg.uniformGap === true && cfg.trueShape === true && cfg.specialStagger !== false &&
        shape && shape.isRectangle !== true && shape.points && shape.points.length >= 3) {
      var exactGapX = Math.max(0, n(cfg.gapX,0)), exactGapY = Math.max(0, n(cfg.gapY,0));
      var exact = root.ANPTrueShape.pack({binW:binW,binH:binH,shape:scaleShape(shape,w,h),gap:Math.max(exactGapX,exactGapY),gapX:exactGapX,gapY:exactGapY,
        angles:smartAngles(cfg,shape),maxQty:maxQty||0,fast:cfg.fastMode===true,stagger:true,strictGap:true});
      exact = applyCornerSafe(exact,cfg,binW,binH); exact.count=exact.items.length; exact.uniformGap=true; exact.strictGap=true;
      exact.efficiency=exact.count*w*h/Math.max(0.0001,binW*binH);
      exact=center(exact,binW,binH); return hardBoundsV101(exact,binW,binH);
    }
    if (cfg.uniformGap === true) { return hardBoundsV101(center(mixedExactV131(cfg, w, h, binW, binH, maxQty), binW, binH),binW,binH); }
    var gx = n(cfg.gapX, 0), gy = n(cfg.gapY, 0), margin = n(cfg.margin, 0);
    var rx = 0, ry = 0, trials = [{x:0,y:0}], best = null, trueBest = null, i, t, cand; /* V101: lề là HARD LIMIT, không nới bin vào phần lề. */
    var directCircle = cfg.trueShape && shape && shape.isCircle === true && shape.points && shape.points.length >= 3;
    if (rx > 0) { trials.push({x:rx,y:0}); } if (ry > 0) { trials.push({x:0,y:ry}); }
    if (rx > 0 && ry > 0) { trials.push({x:rx,y:ry}); }
    if (!directCircle) {
      for (i = 0; i < trials.length; i++) {
        t = trials[i]; cand = root.ANPPacker.pack({ binW:binW + t.x * 2, binH:binH + t.y * 2,
          itemW:w, itemH:h, gapX:gx, gapY:gy, allowRotate:cfg.allowRotate !== false, maxQty:maxQty || 0,
          cornerClear:cornerClear(cfg, binW, binH) });
        cand.edgeRelaxX = t.x; cand.edgeRelaxY = t.y; best = better(best, cand);
      }
    }
    if (cfg.trueShape && shape && !shape.isRectangle && shape.points && shape.points.length >= 3) {
      var skip = cfg.fastMode && cfg.specialStagger === false && !shape.isCircle && (n(shape.fillRatio, 0) >= 0.9 || best.count > 80);
      if (!skip) {
        var shapeAngles = smartAngles(cfg, shape);
        for (i = 0; i < trials.length; i++) {
          t = trials[i]; cand = root.ANPTrueShape.pack({ binW:binW + t.x * 2, binH:binH + t.y * 2,
            shape:scaleShape(shape, w, h), gap:Math.max(gx, gy), angles:shapeAngles,
            maxQty:maxQty || 0, fast:cfg.fastMode === true, stagger:cfg.specialStagger !== false });
          cand = applyCornerSafe(cand, cfg, binW + t.x * 2, binH + t.y * 2);
          cand.edgeRelaxX = t.x; cand.edgeRelaxY = t.y; trueBest = better(trueBest, cand);
        }
      }
    }
    /* KHUON_BE thật luôn ưu tiên hơn lưới bbox, tránh đếm nhiều nhưng chồng khuôn. */
    if (trueBest) { best = trueBest; }
    best = applyCornerSafe(best, cfg, binW, binH);
    best.count = best.items.length; best.efficiency = best.count * w * h / Math.max(0.0001, binW * binH);
    best.edgeOptimized = n(best.edgeRelaxX, 0) > 0 || n(best.edgeRelaxY, 0) > 0;
    return hardBoundsV101(center(best, binW, binH),binW,binH);
  }
  function sameSize(sources) {
    var i, w = n(sources[0].width, 0), h = n(sources[0].height, 0);
    for (i = 1; i < sources.length; i++) {
      if (Math.abs(n(sources[i].width, 0) - w) > 0.01 || Math.abs(n(sources[i].height, 0) - h) > 0.01) { return false; }
    }
    return true;
  }
  function jobs(sources, maxQty) {
    var remaining = [], out = [], i, active = true, count = 0, cap = Math.max(0, Math.floor(n(maxQty, 0)));
    for (i = 0; i < sources.length; i++) { remaining[i] = Math.max(0, Math.floor(n(sources[i].quantity, 0))); }
    while (active) {
      active = false;
      for (i = 0; i < sources.length; i++) {
        if (remaining[i] > 0) {
          out.push({ w:n(sources[i].width, 0), h:n(sources[i].height, 0), sourceIndex:i, copyIndex:count++ });
          remaining[i]--; active = true; if (cap && out.length >= cap) { return out; }
        }
      }
    }
    return out;
  }
  function packSources(cfg, sources) {
    var binW = n(cfg.paperW, 0) - n(cfg.margin, 0) * 2;
    var binH = n(cfg.paperH, 0) - n(cfg.margin, 0) * 2, layout, list, i;
    if (!sources.length) { throw new Error("Chưa có file cần dàn."); }
    if (binW <= 0 || binH <= 0) { throw new Error("Lề đang lớn hơn khổ in."); }
    if (cfg.demiMode && !sameSize(sources)) { throw new Error("Bế 1 dao Demi chỉ nhận các mẫu cùng kích thước."); }
    if (sources.length === 1 && n(sources[0].quantity, 0) === 0) {
      layout = equal(cfg, n(sources[0].width, 0), n(sources[0].height, 0), sources[0].shape,
        binW, binH, n(cfg.maxQty, 0));
      for (i = 0; i < layout.items.length; i++) { layout.items[i].sourceIndex = 0; layout.items[i].copyIndex = i; }
      layout.skipped = [];
    } else {
      list = jobs(sources, cfg.maxQty);
      if (!list.length) { throw new Error("Khi ghép nhiều mẫu, SL phải từ 1 trở lên."); }
      if (sameSize(sources)) {
        layout = equal(cfg, n(sources[0].width, 0), n(sources[0].height, 0), sources[0].shape,
          binW, binH, list.length);
        for (i = 0; i < layout.items.length; i++) {
          layout.items[i].sourceIndex = list[i].sourceIndex; layout.items[i].copyIndex = list[i].copyIndex;
        }
        layout.skipped = list.slice(layout.items.length);
      } else {
        layout = root.ANPMultiPacker.pack({ binW:binW, binH:binH, gapX:n(cfg.gapX, 0), gapY:n(cfg.gapY, 0),
          allowRotate:cfg.allowRotate !== false, items:list, cornerClear:cornerClear(cfg, binW, binH) });
        layout = applyCornerSafe(layout, cfg, binW, binH);
      }
    }
    layout = applyCornerSafe(layout, cfg, binW, binH);
    layout.binW = binW; layout.binH = binH; layout.count = layout.items.length;
    return hardBoundsV101(center(layout, binW, binH),binW,binH);
  }
  function groupArtboards(artboards) {
    var groups = [], i, j, a, found;
    for (i = 0; i < artboards.length; i++) {
      a = artboards[i]; found = null;
      for (j = 0; j < groups.length; j++) {
        if (Math.abs(groups[j].width - a.width) <= 0.05 && Math.abs(groups[j].height - a.height) <= 0.05 &&
            (!a.shape || !groups[j].shape || String(a.shape.signature||"") === String(groups[j].shape.signature||""))) { found = groups[j]; break; }
      }
      if (!found) { found = { groupNumber:groups.length + 1, width:a.width, height:a.height, shape:a.shape || null, artboards:[] }; groups.push(found); }
      found.artboards.push(a);
    }
    return groups;
  }
  function preview(cfg) {
    if (cfg.mode === "artboards") {
      var groups = groupArtboards(cfg.artboards || []), out = [], i, layout;
      if (cfg.duplexMode === true) {
        if (cfg.finishCropMarks !== true) { throw new Error("In 2 mặt chỉ dùng với PON cắt theo thành phẩm."); }
        if (!cfg.artboards || cfg.artboards.length !== 2) { throw new Error("In 2 mặt cần đúng 2 artboard."); }
        if (groups.length !== 1) { throw new Error("Hai artboard in 2 mặt phải cùng kích thước."); }
      }
      for (i = 0; i < groups.length; i++) {
        layout = equal(cfg, groups[i].width, groups[i].height, groups[i].shape,
          cfg.paperW - cfg.margin * 2, cfg.paperH - cfg.margin * 2, cfg.maxQty || 0);
        out.push({ groupNumber:groups[i].groupNumber, width:groups[i].width, height:groups[i].height,
          printFiles:groups[i].artboards.length, countPerSheet:layout.count, method:layout.method,
          efficiency:layout.efficiency, edgeOptimized:layout.edgeOptimized === true,
          cornerSafe:layout.cornerSafe === true, cornerClear:n(layout.cornerClear, 0) });
      }
      return { ok:true, mode:"artboards", groups:out, groupCount:out.length,
        printFileCount:cfg.duplexMode === true ? 1 : (cfg.artboards || []).length,
        pageCount:cfg.duplexMode === true ? 2 : (cfg.artboards || []).length,
        dieFileCount:cfg.finishCropMarks === true ? 0 : out.length,
        cattp:cfg.finishCropMarks === true, duplex:cfg.duplexMode === true,
        duplexFlip:String(cfg.duplexFlip || "abComplementary"), layout:out.length ? equal(cfg, out[0].width, out[0].height,
          groups[0].shape, cfg.paperW - cfg.margin * 2, cfg.paperH - cfg.margin * 2, cfg.maxQty || 0) : null };
    }
    var result = packSources(cfg, cfg.sources || []), rotated = 0, angled = 0, k;
    for (k = 0; k < result.items.length; k++) {
      if (result.items[k].rotated) { rotated++; }
      if (Math.abs(n(result.items[k].angle, 0)) > 0.001) { angled++; }
    }
    return { ok:true, mode:cfg.mode === "manual" ? "manual" : "files", count:result.count, rotated:rotated, normal:result.count - rotated,
      angled:angled, skipped:result.skipped ? result.skipped.length : 0, method:result.method,
      efficiency:result.efficiency || 0, cornerSafe:result.cornerSafe === true,
      cornerClear:n(result.cornerClear, 0), layout:result };
  }

  root.VDPROEngine = { preview:preview, packSources:packSources, equal:equal, demi:demi,
    manualShape:manualShape, version:"0.1.20-v132-mixed-rotation-safe" };
  if (typeof module !== "undefined" && module.exports) { module.exports = root.VDPROEngine; }
}(this));
