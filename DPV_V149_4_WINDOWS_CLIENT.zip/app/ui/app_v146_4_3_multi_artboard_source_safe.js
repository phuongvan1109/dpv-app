/* DPV V146.4.3 MULTI ARTBOARD SOURCE SAFE — additive UI only.
   Uses the existing stable ListArtboards/useArtboards pipeline.
   Does not override Core/Bridge/GetActiveSource/GetManualDieSource. */
(function(){
  'use strict';
  function $(id){return document.getElementById(id);} 
  function trigger(el){ if(!el)return; try{el.click();}catch(e){ try{var ev=document.createEvent('MouseEvents');ev.initMouseEvent('click',true,true,window,1,0,0,0,0,false,false,false,false,0,null);el.dispatchEvent(ev);}catch(x){} } }
  function addUI(){
    var bar=$('activeBtn')&&$('activeBtn').parentNode; if(!bar||$('v14643MultiAbBtn'))return !!bar;
    var b=document.createElement('button'); b.id='v14643MultiAbBtn'; b.className='button accent'; b.type='button'; b.textContent='Lấy nhiều artboard đang mở';
    var all=document.createElement('button'); all.id='v14643AllAbBtn'; all.className='button'; all.type='button'; all.textContent='Tất cả artboard + KHUON_BE';
    bar.insertBefore(b,$('manualSizeBtn')||null); bar.insertBefore(all,$('manualSizeBtn')||null);
    if($('artboardsBtn')) $('artboardsBtn').textContent='Chọn nhiều artboard';
    var note=document.createElement('div'); note.id='v14643MultiAbNote'; note.className='v14643-note';
    note.innerHTML='<b>MULTI ARTBOARD · V146.4.3 SAFE</b><br>File AI nhiều artboard: mỗi artboard được coi là một nguồn dàn riêng. DPV tự đọc <b>KHUON_BE</b> trong từng artboard; nếu không tìm thấy thì dùng kích thước artboard. Không thay luồng “Lấy file đang mở” / “Lấy khuôn đang chọn” cũ.';
    bar.parentNode.insertBefore(note,bar.nextSibling);
    b.onclick=function(){ trigger($('artboardsBtn')); };
    all.onclick=function(){
      window.__DPV14643_USE_ALL_AB=true;
      trigger($('artboardsBtn'));
      var tries=0,iv=setInterval(function(){
        tries++;
        var chooser=$('artboardChooser'), checks=document.querySelectorAll('.ab-check');
        if(checks.length){
          for(var i=0;i<checks.length;i++)checks[i].checked=true;
          clearInterval(iv); window.__DPV14643_USE_ALL_AB=false; setTimeout(function(){trigger($('useArtboards'));},60);
        } else if(tries>80){ clearInterval(iv); window.__DPV14643_USE_ALL_AB=false; }
      },100);
    };
    return true;
  }
  function decorateChooser(){
    var c=$('artboardChooser'); if(!c||$('v14643ChooserHint'))return;
    var d=document.createElement('div'); d.id='v14643ChooserHint'; d.className='v14643-hint';
    d.innerHTML='✓ Có thể tick <b>nhiều artboard cùng lúc</b>. Sau khi bấm “Dùng các artboard đã chọn”, danh sách Nguồn in sẽ có từng artboard riêng và Build sẽ xử lý tất cả trong một lần.';
    var list=$('artboardList'); if(list&&list.parentNode)list.parentNode.insertBefore(d,list);
  }
  function start(){ addUI(); decorateChooser(); }
  var n=0,t=setInterval(function(){n++;start();if(n>80)clearInterval(t);},400);
  document.addEventListener('click',function(){setTimeout(start,40);},false);
})();
