(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function fixDataInfo(){
    var el=$('vdpDataInfo');
    if(!el)return;
    /* vdpDataInfo used to reuse class source-card. That caused Core V101
       syncSources() to mistake CSV info for an imposition source card. */
    if((' '+el.className+' ').indexOf(' source-card ')>=0){
      el.className=(' '+el.className+' ').replace(' source-card ',' vdp-data-info-card ').replace(/^\s+|\s+$/g,'');
    }
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;
    if(v)v.innerHTML='V121 VDP SOURCE SCOPE FIX · CORE V101 STABLE';
  }
  function start(){fixDataInfo();mark();setInterval(fixDataInfo,350);}
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);
  }else start();
})();