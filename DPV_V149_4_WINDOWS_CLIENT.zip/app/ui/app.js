(function () {
  "use strict";
  var sources = [], pendingArtboards = [], artboardDocumentName = "", artboardMode = false, manualSizeMode = false, busyState = false, connectWatchdog = 0;
  var vdp = { filePath:"", sourceFolder:"", fileName:"", headers:[], records:[], targets:[] };
  var $ = function (id) { return document.getElementById(id); };
  function requiredEl(id) {
    var node = $(id);
    if (!node) { throw new Error("Thiếu control giao diện: #" + id + ". Hãy đóng DPV và cài lại bản V87 để xóa cache giao diện cũ."); }
    return node;
  }

  function now() { var d = new Date(); return ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2) + ":" + ("0" + d.getSeconds()).slice(-2); }
  function log(message) {
    var row = document.createElement("div"); row.className = "log-line"; row.innerText = "[" + now() + "] " + message;
    $("log").appendChild(row); $("log").scrollTop = $("log").scrollHeight;
  }
  function status(message, kind) {
    $("status").className = "status " + (kind || ""); $("status").innerText = message; log(message);
  }
  function setBusy(on, message) {
    busyState = on; var ids = ["connectBtn","activeBtn","multiBtn","artboardsBtn","manualBtn","manualSizeBtn","hostPreviewBtn","diePreviewBtn","buildBtn","vdpChooseDataBtn","vdpReloadDataBtn","vdpScanTargetsBtn","vdpClearTargetsBtn","vdpPreviewBtn","vdpRestoreBtn","vdpBuildBtn","vdpCombineExistingBtn"];
    for (var i = 0; i < ids.length; i++) { if ($(ids[i])) { $(ids[i]).disabled = on; } }
    if (!on && manualSizeMode) { $("hostPreviewBtn").disabled = true; $("diePreviewBtn").disabled = false; $("buildBtn").disabled = true; }
    $("progressBar").className = on ? "progress-bar busy" : "progress-bar";
    if (message) { status(message, on ? "work" : ""); }
  }
  function parse(raw) {
    try { return JSON.parse(String(raw || "")); }
    catch (e) { return { ok:false, error:"Bridge trả dữ liệu không hợp lệ: " + raw }; }
  }
  function html(value) {
    return String(value == null ? "" : value).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }
  function num(id) { return Number(requiredEl(id).value); }
  function check(id) { return requiredEl(id).checked === true; }
  function fmt(v) { return String(Math.round(Number(v) * 100) / 100); }
  function perfTime(ms) {
    ms = Number(ms || 0);
    if (ms < 1000) { return Math.round(ms) + " ms"; }
    if (ms < 60000) { return (Math.round(ms / 100) / 10) + " s"; }
    return Math.floor(ms / 60000) + "m " + Math.round((ms % 60000) / 1000) + "s";
  }
  function logPerformanceV48(r) {
    var p = r && r.performance, i, s, b, msg;
    if (!p || !p.stages) { log("PERF: Bridge chưa trả dữ liệu profiler."); return ""; }
    log("========== DPV PERFORMANCE PROFILER V5.0 ==========");
    log("TỔNG TRONG ILLUSTRATOR SCRIPT: " + perfTime(p.totalMs));
    if (p.nativeTotalMs != null) { log("TỔNG THỰC TẾ C#/COM → ILLUSTRATOR: " + perfTime(p.nativeTotalMs)); }
    if (p.nativeBridgeOverheadMs != null) { log("OVERHEAD Bridge/COM/nạp script: " + perfTime(p.nativeBridgeOverheadMs)); }
    for (i = 0; i < p.stages.length; i++) {
      s = p.stages[i];
      log("TIME " + s.name + ": " + perfTime(s.ms) + "  (" + (s.percent == null ? "-" : s.percent) + "%)");
    }
    if (p.buildStats) {
      var bs = p.buildStats;
      log("LINK BATCH V4.9: " + bs.total + " Link | tạo trực tiếp " + bs.primitiveLinks +
        " | clone group " + bs.groupClones + " | giảm khoảng " + bs.savedDuplicateOps + " lệnh duplicate");
    }
    if (p.bottlenecks && p.bottlenecks.length) {
      log("---------- 3 CÔNG ĐOẠN CHẬM NHẤT ----------");
      for (i = 0; i < p.bottlenecks.length; i++) {
        b = p.bottlenecks[i];
        log((i + 1) + ". " + b.name + " = " + perfTime(b.ms) + " (" + b.percent + "%)");
      }
      msg = p.bottlenecks[0].name + " · " + perfTime(p.bottlenecks[0].ms) + " · " + p.bottlenecks[0].percent + "%";
      return msg;
    }
    return "";
  }
  function macBridgeReady() { return window.DPVNative && typeof window.DPVNative.invoke === "function"; }
  function externalReady() {
    return macBridgeReady() || (window.external && typeof window.external.ConnectIllustrator !== "undefined");
  }
  function bridgeCall(method, args, done) {
    args = args || [];
    if (macBridgeReady()) {
      window.DPVNative.invoke(method, args).then(function (value) {
        if (done) { done(value); }
      }).catch(function (error) {
        setBusy(false); status((error && error.message) || String(error || "DPV® macOS Bridge báo lỗi."), "error");
      });
      return;
    }
    if (!externalReady() || typeof window.external[method] === "undefined") {
      setBusy(false); status("DPV® Bridge chưa sẵn sàng.", "error"); return;
    }
    try {
      // window.external is an IDispatch COM object in the Windows WebBrowser
      // control. Function.apply() is not supported reliably by that object and
      // raises "Invalid procedure call or argument". Invoke the dispatch member
      // directly, preserving its COM argument list.
      var value;
      if (args.length === 0) { value = window.external[method](); }
      else if (args.length === 1) { value = window.external[method](args[0]); }
      else if (args.length === 2) { value = window.external[method](args[0], args[1]); }
      else { throw new Error("DPV® Bridge không hỗ trợ quá 2 tham số."); }
      if (done) { done(value); }
    } catch (error) {
      setBusy(false);
      var bridgeMsg="Windows Bridge không gọi được " + method + ": " + ((error && error.message) || String(error));
      if(String(method||"").indexOf("VariableData")>=0 || method==="ScanVariableTargets"){vdpStatus(bridgeMsg,"error");}
      else{status(bridgeMsg,"error");}
    }
  }

  function clearConnectWatchdog() {
    if (connectWatchdog) { window.clearTimeout(connectWatchdog); connectWatchdog = 0; }
  }

  function startConnectWatchdog() {
    clearConnectWatchdog();
    connectWatchdog = window.setTimeout(function () {
      connectWatchdog = 0;
      if (!busyState) { return; }
      setBusy(false); setConnected(false);
      status("Illustrator không phản hồi sau 15 giây. Hãy đóng hộp thoại đang chờ trong Illustrator, mở xong Illustrator rồi bấm Kết nối lại; DPV và Illustrator phải chạy cùng quyền (không chạy một ứng dụng bằng Administrator).", "error");
    }, 15000);
  }

  function setConnected(ok, info) {
    $("connectionDot").className = "dot " + (ok ? "online" : "offline");
    $("connectionText").innerText = ok ? (info || "Đã kết nối Illustrator") : "Chưa kết nối Illustrator";
  }

  function refreshOutputActions() {
    $("hostPreviewBtn").disabled = busyState || manualSizeMode;
    $("diePreviewBtn").disabled = busyState;
    $("buildBtn").disabled = busyState || manualSizeMode;
    if (manualSizeMode) {
      $("hostPreviewBtn").title = $("buildBtn").title = "Hãy chọn file thiết kế nếu muốn đối chiếu hoặc xuất trong Illustrator.";
      $("diePreviewBtn").title = "Mở trực tiếp khuôn thủ công trong Illustrator, không lưu file.";
      $("diePreviewBtn").innerText = "View khuôn trực tiếp qua Illustrator";
    } else {
      $("hostPreviewBtn").title = $("diePreviewBtn").title = $("buildBtn").title = "";
      $("diePreviewBtn").innerText = "Mở xem trước khuôn";
    }
  }

  function syncSources() {
    var cards = document.querySelectorAll(".source-card"), next = [], i, idx, src, q;
    for (i = 0; i < cards.length; i++) {
      idx = Number(cards[i].getAttribute("data-index")); src = sources[idx]; if (!src) { continue; }
      var wInput = cards[i].querySelector(".src-w"), hInput = cards[i].querySelector(".src-h");
      if (!wInput || !hInput) { throw new Error("Card nguồn bị lệch phiên bản giao diện. Hãy đóng DPV rồi cài lại V87."); }
      src.width = Number(wInput.value);
      src.height = Number(hInput.value);
      q = cards[i].querySelector(".src-q"); src.quantity = q ? Math.max(0, Math.floor(Number(q.value) || 0)) : 0;
      next.push(src);
    }
    sources = next;
  }

  function renderSources() {
    var box = $("sourceList"), out = "", i, s, badge;
    if (!sources.length) {
      manualSizeMode = false; refreshOutputActions();
      box.innerHTML = '<div class="empty">Chưa có nguồn in. Có thể lấy file từ Illustrator hoặc nhập kích thước tem để tính nhanh.</div>';
      localPreview(false); return;
    }
    for (i = 0; i < sources.length; i++) {
      s = sources[i];
      if (s.manualSize) { badge = '<span class="source-badge manual">' + (s.shape && s.shape.isCircle ? 'Hình tròn thủ công' : 'Kích thước thủ công') + '</span>'; }
      else if (s.shapeDeferred) { badge = '<span class="source-badge warn">Đọc nhanh · khuôn khi xuất</span>'; }
      else { badge = s.dieFallback ? '<span class="source-badge warn">Dùng artboard</span>' : '<span class="source-badge">Đã nhận shape khuôn</span>'; }
      out += '<div class="source-card" data-index="' + i + '"><div class="source-head">' +
        '<span class="source-name" title="' + html(s.path || s.name) + '">' + (i + 1) + '. ' + html(s.name) + '</span>' + badge +
        '<button class="remove-source" data-remove="' + i + '">×</button></div><div class="source-values">' +
        '<label>Rộng mm<input class="src-w" type="number" min="0.1" step="0.01" value="' + fmt(s.width) + '"' + (s.manualSize ? ' readonly' : '') + '></label>' +
        '<label>Cao mm<input class="src-h" type="number" min="0.1" step="0.01" value="' + fmt(s.height) + '"' + (s.manualSize ? ' readonly' : '') + '></label>' +
        (s.manualSize ? '<label>Chế độ<input type="text" readonly value="Xem tối đa"></label>' : artboardMode ? '<label>Chế độ<input type="text" readonly value="Tự đầy khổ"></label>' :
          '<label>SL<input class="src-q" type="number" min="0" step="1" value="' + Math.max(0, Number(s.quantity) || 0) + '"></label>') +
        '</div></div>';
    }
    box.innerHTML = out;
    var removes = document.querySelectorAll(".remove-source"), inputs = box.querySelectorAll("input");
    for (i = 0; i < removes.length; i++) {
      removes[i].addEventListener("click", function () {
        syncSources(); sources.splice(Number(this.getAttribute("data-remove")), 1);
        if (!sources.length) { manualSizeMode = false; }
        renderSources();
      });
    }
    for (i = 0; i < inputs.length; i++) { inputs[i].addEventListener("change", function () { syncSources(); localPreview(false); }); }
    refreshOutputActions(); localPreview(false);
  }

  function config() {
    syncSources();
    var c = {
      sources:sources, artboards:artboardMode ? sources : [], mode:artboardMode ? "artboards" : (manualSizeMode ? "manual" : "files"),
      dieHint:requiredEl("dieHint").value, jobName:artboardMode && artboardDocumentName ? artboardDocumentName :
        (sources.length === 1 ? sources[0].name : "GHEP_" + sources.length + "_MAU"),
      paperW:num("paperW"), paperH:num("paperH"), margin:num("margin"), header:num("header"),
      gapX:num("gapX"), gapY:num("gapY"), maxQty:Math.max(0, Math.floor(num("maxQty") || 0)),
      linkBleed:num("linkBleed"), allowRotate:check("allowRotate"), addTitle:check("addTitle"),
      trueShape:check("trueShape"), specialStagger:check("specialStagger"), uniformGap:check("uniformGap"), fastMode:check("fastMode"), angleStep:Number(requiredEl("angleStep").value),
      cornerSafe:check("cornerSafe"), cornerZone:Math.max(0, num("cornerZone") || 0),
      demiMode:check("demiMode"), demiExtend:num("demiExtend"),
      ponPath:requiredEl("ponPath").value, fitPon:check("fitPon"), autoPon:check("autoPon"),
      ponProcessBlack:check("ponProcessBlack"), cornerPonRed:check("cornerPonRed"),
      finishCropMarks:check("finishCropMarks"),
      finishMarkLength:Math.max(0.1, num("finishMarkLength") || 6),
      finishMarkGap:Math.max(0, num("finishMarkGap") || 0),
      duplexMode:check("duplexMode"), duplexFlip:String(requiredEl("duplexFlip").value || "tumble180"), dieAsLink:false,
      preservePrintColor:check("preservePrintColor"), outputPath:requiredEl("outputPath").value
    };
    if (!sources.length) { throw new Error("Chưa có file hoặc artboard cần dàn."); }
    if (!(c.paperW > 0) || !(c.paperH > 0) || c.margin < 0 || c.paperW <= c.margin * 2 || c.paperH <= c.margin * 2) {
      throw new Error("Thông số khổ in hoặc lề không hợp lệ.");
    }
    if (c.duplexMode) {
      if (!c.finishCropMarks) { throw new Error("In 2 mặt chỉ dùng cùng chức năng PON cắt theo thành phẩm."); }
      if (!artboardMode || sources.length !== 2) { throw new Error("In 2 mặt cần chọn đúng 2 artboard: mặt trước rồi mặt sau."); }
      if (Math.abs(Number(sources[0].width) - Number(sources[1].width)) > 0.05 ||
          Math.abs(Number(sources[0].height) - Number(sources[1].height)) > 0.05) {
        throw new Error("Hai artboard in 2 mặt phải cùng kích thước thành phẩm.");
      }
    }
    return c;
  }

  function methodName(method) {
    if (method === "demi-grid") { return "Bế 1 dao Demi – lưới thẳng"; }
    if (method === "true-shape-honeycomb") { return "True‑Shape tổ ong"; }
    if (method === "true-shape-polygon") { return "True‑Shape polygon"; }
    if (method === "true-shape-staggered-exact") { return "Khuôn đặc biệt xoay · khe đều chính xác"; }
    if (method === "true-shape-interlocking-columns-exact") { return "Khuôn đặc biệt khóa nhau 90°/270° · khe đều chính xác"; }
    if (method === "true-shape-staggered") { return "True‑Shape khuôn đặc biệt – so le"; }
    if (method === "true-shape-interlocking-columns") { return "True‑Shape cột khóa nhau 90°/270°"; }
    if (String(method || "").indexOf("uniform-grid") === 0) { return "Lưới đều tuyệt đối · một hướng"; }
    if (method === "true-shape-mixed") { return "True‑Shape nhiều khuôn"; }
    if (method === "maxrects-mixed-sizes") { return "MaxRects nhiều kích thước"; }
    if (String(method || "").indexOf("corner-safe") >= 0) { return "Tối ưu chừa PON bốn góc"; }
    return "Cột/hàng xoay tối ưu";
  }

  function clearLayoutCanvas(message) {
    var canvas = $("layoutCanvas"), ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#f4f0de"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#716f65"; ctx.font = "13px Segoe UI, Arial"; ctx.textAlign = "center";
    ctx.fillText(message || "Chưa có bố cục", canvas.width / 2, canvas.height / 2);
    $("layoutCaption").innerText = message || "Chưa có bố cục";
  }

  function drawLayout(result, c) {
    var layout = result && result.layout, canvas = $("layoutCanvas"), ctx = canvas.getContext("2d");
    if (!layout || !layout.items || !layout.items.length) { clearLayoutCanvas("Chưa có bố cục để vẽ"); return; }
    var pad = 12, paperW = Number(c.paperW), paperH = Number(c.paperH);
    var scale = Math.min((canvas.width - pad * 2) / paperW, (canvas.height - pad * 2) / paperH);
    var sheetW = paperW * scale, sheetH = paperH * scale;
    var ox = (canvas.width - sheetW) / 2, oy = (canvas.height - sheetH) / 2;
    var colors = ["#ffbf00", "#08a878", "#ff5b24", "#13a8b8", "#74bd43", "#e59f00"];
    var items = layout.items, maxDraw = 2200, stride = Math.max(1, Math.ceil(items.length / maxDraw));
    var i, item, source, isCircle, x, y, w, h, color;
    ctx.clearRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = "#f4f0de"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#fffef7"; ctx.fillRect(ox, oy, sheetW, sheetH);
    ctx.strokeStyle = "#17181c"; ctx.lineWidth = 1.2; ctx.strokeRect(ox + .5, oy + .5, sheetW - 1, sheetH - 1);
    ctx.save(); ctx.strokeStyle = "rgba(8,168,120,.72)"; ctx.lineWidth = 1;
    if (ctx.setLineDash) { ctx.setLineDash([4, 3]); }
    ctx.strokeRect(ox + c.margin * scale, oy + c.margin * scale,
      Math.max(0, (paperW - c.margin * 2) * scale), Math.max(0, (paperH - c.margin * 2) * scale));
    ctx.restore();
    if (c.cornerSafe && Number(c.cornerZone) > 0) {
      var zone = Math.min(Number(c.cornerZone), paperW / 2, paperH / 2) * scale;
      ctx.save(); ctx.fillStyle = "rgba(255,191,0,.13)"; ctx.strokeStyle = "rgba(255,191,0,.62)";
      if (ctx.setLineDash) { ctx.setLineDash([3, 3]); }
      ctx.fillRect(ox, oy, zone, zone); ctx.strokeRect(ox, oy, zone, zone);
      ctx.fillRect(ox + sheetW - zone, oy, zone, zone); ctx.strokeRect(ox + sheetW - zone, oy, zone, zone);
      ctx.fillRect(ox, oy + sheetH - zone, zone, zone); ctx.strokeRect(ox, oy + sheetH - zone, zone, zone);
      ctx.fillRect(ox + sheetW - zone, oy + sheetH - zone, zone, zone);
      ctx.strokeRect(ox + sheetW - zone, oy + sheetH - zone, zone, zone); ctx.restore();
    }
    for (i = 0; i < items.length; i += stride) {
      item = items[i]; source = c.sources[Math.max(0, Number(item.sourceIndex) || 0)] || c.sources[0] || {};
      isCircle = source.shape && source.shape.isCircle === true;
      color = colors[(Number(item.sourceIndex) || 0) % colors.length];
      x = ox + (Number(c.margin) + Number(item.x) + Number(item.offsetX || 0)) * scale;
      y = oy + (Number(c.margin) + Number(item.y) + Number(item.offsetY || 0)) * scale;
      w = Number(item.w) * scale; h = Number(item.h) * scale;
      ctx.beginPath();
      if (isCircle) { ctx.arc(x + w / 2, y + h / 2, Math.min(w, h) / 2, 0, Math.PI * 2, false); }
      else { ctx.rect(x, y, w, h); }
      ctx.fillStyle = color; ctx.globalAlpha = .16; ctx.fill(); ctx.globalAlpha = 1;
      ctx.strokeStyle = color; ctx.lineWidth = Math.max(.55, Math.min(1.2, scale * .13)); ctx.stroke();
    }
    $("layoutCaption").innerText = items.length + " con trên " + fmt(paperW) + "×" + fmt(paperH) + " mm" +
      (c.cornerSafe ? " · chừa PON " + fmt(c.cornerZone) + "mm" : "") +
      (stride > 1 ? " · sơ đồ rút gọn để giữ nhẹ" : "");
  }

  function showLocal(result, c) {
    if (result.mode === "artboards") {
      var details = [], firstCount = result.groups.length ? result.groups[0].countPerSheet : 0;
      for (var i = 0; i < result.groups.length; i++) {
        details.push("Nhóm " + result.groups[i].groupNumber + ": " + result.groups[i].width + "×" + result.groups[i].height + " = " + result.groups[i].countPerSheet + " con");
      }
      $("previewCount").innerText = result.groups.length === 1 ? firstCount : result.groupCount;
      $("previewMethod").innerText = result.duplex ?
        "1 FILE IN CATTP · 2 TRANG A/B · MẶT B BÙ GÓC THEO A" : result.cattp ?
        result.printFileCount + " FILE IN CATTP · KHÔNG XUẤT KHUÔN" :
        result.printFileCount + " FILE IN · " + result.dieFileCount + " FILE KHUÔN";
      $("previewDetails").innerText = details.join(" | "); $("efficiency").innerText = "Theo nhóm"; $("modeLabel").innerText = "Artboard";
    } else {
      $("previewCount").innerText = result.count;
      $("previewMethod").innerText = methodName(result.method);
      if (result.mode === "manual") {
        var manualSource = c.sources[0], shapeName = manualSource.shape && manualSource.shape.isCircle ? "Tròn Ø" : "Tem";
        $("previewDetails").innerText = shapeName + " " + fmt(manualSource.width) + (manualSource.shape && manualSource.shape.isCircle ? "" : "×" + fmt(manualSource.height)) +
          " mm · khổ " + fmt(c.paperW) + "×" + fmt(c.paperH) + " mm";
        $("modeLabel").innerText = "Thủ công";
      } else {
        $("previewDetails").innerText = result.rotated + " xoay · " + result.normal + " không xoay" + (result.skipped ? " · dư " + result.skipped : "");
        $("modeLabel").innerText = "File";
      }
      $("efficiency").innerText = (Math.round(result.efficiency * 1000) / 10) + "%";
    }
    $("engineState").innerText = "DPV® Desktop"; drawLayout(result, c);
  }

  function localPreview(showStatus) {
    try {
      var c = config(), result = VDPROEngine.preview(c); showLocal(result, c);
      if (showStatus) { status(result.mode === "manual" ? "Đã tính số con từ kích thước tem, không dùng Illustrator." : "Đã tính bố cục bên ngoài Illustrator.", "ok"); }
      return result;
    } catch (e) {
      $("previewCount").innerText = "0"; $("previewMethod").innerText = e.message;
      $("previewDetails").innerText = "Bổ sung nguồn hoặc kiểm tra lại thông số.";
      clearLayoutCanvas("Chưa có bố cục");
      if (showStatus) { status(e.message, "error"); }
      return null;
    }
  }

  function syncManualShapeFields() {
    var circle = $("manualShape").value === "circle";
    $("manualWidthLabel").innerText = circle ? "Đường kính (mm)" : "Rộng tem (mm)";
    $("manualHeightField").className = circle ? "field hidden" : "field";
  }

  function openManualSize() {
    if (manualSizeMode && sources.length && sources[0].manualSize) {
      $("manualName").value = sources[0].name || "Tem nhập thủ công";
      $("manualShape").value = sources[0].shape && sources[0].shape.isCircle ? "circle" : "rectangle";
      $("manualW").value = fmt(sources[0].width); $("manualH").value = fmt(sources[0].height);
    }
    syncManualShapeFields(); $("manualSizeBox").className = "manual-size-box";
    status("Nhập kích thước tem rồi bấm Tính và xem trước trên khổ.", "ok");
  }

  function applyManualSize() {
    var kind = $("manualShape").value, w = num("manualW"), h = kind === "circle" ? w : num("manualH");
    if (!(w > 0) || !(h > 0)) { status("Kích thước tem phải lớn hơn 0 mm.", "error"); return; }
    var shape;
    try { shape = VDPROEngine.manualShape(kind, w, h); }
    catch (e) { status(e.message, "error"); return; }
    $("maxQty").value = "0";
    if (kind === "circle") { $("trueShape").checked = true; $("demiMode").checked = false; }
    artboardMode = false; manualSizeMode = true;
    sources = [{ name:$("manualName").value || (kind === "circle" ? "Tem tròn" : "Tem chữ nhật"),
      width:w, height:h, quantity:0, manualSize:true, dieFallback:false, shape:shape }];
    $("manualSizeBox").className = "manual-size-box hidden"; renderSources(); refreshOutputActions();
    localPreview(true);
  }

  function connect() {
    if (!externalReady()) { status("DPV® Bridge chưa sẵn sàng.", "error"); return; }
    setBusy(true, "Đang kết nối Adobe Illustrator 2024–2026…"); startConnectWatchdog(); bridgeCall("ConnectIllustrator", [true]);
  }
  function getActive(manual) {
    if (!externalReady()) { return; } setBusy(true, manual ? "Đang đọc KHUON_BE đang chọn…" : "Đang đọc file Illustrator đang mở…");
    if (manual) { bridgeCall("GetManualDieSource"); } else { bridgeCall("GetActiveSource", [requiredEl("dieHint").value]); }
  }
  function chooseMultiple() {
    bridgeCall("ChooseSourceFiles", [], function (raw) {
      var files = parse(raw);
      if (!files.length) { return; } setBusy(true, "Illustrator đang đọc " + files.length + " file nguồn…");
      bridgeCall("InspectSourceFiles", [JSON.stringify(files), requiredEl("dieHint").value]);
    });
  }
  function listArtboards() { setBusy(true, "Đang đọc danh sách artboard từ Illustrator…"); bridgeCall("ListArtboards", [requiredEl("dieHint").value]); }
  function renderArtboards() {
    var out = "", i, a;
    for (i = 0; i < pendingArtboards.length; i++) {
      a = pendingArtboards[i];
      out += '<label class="artboard-option"><input class="ab-check" type="checkbox" data-index="' + i + '" checked>' +
        '<span><strong>' + html(a.displayIndex || (i + 1)) + '. ' + html(a.name) + '</strong><small>' + (a.dieFallback ? 'Dùng artboard' : 'Có KHUON_BE') + '</small></span>' +
        '<span class="artboard-size">' + fmt(a.width) + ' × ' + fmt(a.height) + ' mm</span></label>';
    }
    $("artboardList").innerHTML = out; $("artboardChooser").className = "artboard-box";
  }
  function useArtboards() {
    var checks = document.querySelectorAll(".ab-check"), selected = [], i, idx;
    for (i = 0; i < checks.length; i++) { if (checks[i].checked) { idx = Number(checks[i].getAttribute("data-index")); selected.push(pendingArtboards[idx]); } }
    if (!selected.length) { status("Bạn chưa chọn artboard nào.", "error"); return; }
    if (check("duplexMode") && selected.length !== 2) { status("In 2 mặt cần chọn đúng 2 artboard: mặt trước rồi mặt sau.", "error"); return; }
    artboardMode = true; manualSizeMode = false; sources = selected; $("artboardChooser").className = "artboard-box hidden"; renderSources();
    status("Đã nhận " + sources.length + " artboard; DPV® sẽ tự nhóm kích thước.", "ok");
  }

  function hostPreview() {
    if (manualSizeMode) { status("Chế độ nhập kích thước chỉ xem số con trong DPV®. Hãy chọn file thiết kế trước khi đối chiếu Illustrator.", "error"); return; }
    var c; try { c = config(); } catch (e) { status(e.message, "error"); return; }
    setBusy(true, "Đang đối chiếu bố cục với Illustrator…");
    bridgeCall("PreviewInIllustrator", [JSON.stringify(c), c.mode]);
  }
  function diePreview() {
    var c; try { c = config(); } catch (e) { status(e.message, "error"); return; }
    setBusy(true, manualSizeMode ? "Illustrator đang dựng khuôn trực tiếp từ kích thước đã nhập…" : "Illustrator đang dựng bản xem trước khuôn, không lưu file…");
    if (manualSizeMode) { bridgeCall("OpenManualDiePreview", [JSON.stringify(c)]); }
    else { bridgeCall("OpenDiePreview", [JSON.stringify(c)]); }
  }
  function build() {
    if (manualSizeMode) { status("Hãy lấy file thiết kế hoặc chọn file nguồn trước khi xuất FILE IN/KHUÔN.", "error"); return; }
    var c; try { c = config(); } catch (e) { status(e.message, "error"); return; }
    if (!c.outputPath) { status("Hãy chọn thư mục xuất trước khi dàn.", "error"); return; }
    setBusy(true, c.duplexMode ?
      "DPV® V65: dựng PDF A/B cùng vị trí, mặt B bù góc theo mặt A…" : c.finishCropMarks ?
      "DPV® V65: dựng FILE IN CATTP và PON biên bậc thang…" :
      "DPV® V84: PDF gộp nhiều trang thật + giữ khe đều + Link/Khuôn…");
    bridgeCall("Build", [JSON.stringify(c), c.mode]);
  }


  function vdpStatus(message, kind) {
    if (!$('vdpStatus')) { return; }
    $('vdpStatus').className = 'status ' + (kind || ''); $('vdpStatus').innerText = message;
    log('VDP: ' + message);
  }

  function vdpNormalize(value) {
    return String(value == null ? '' : value).toLowerCase().replace(/^\s+|\s+$/g,'').replace(/[^a-z0-9à-ỹ]+/g,'');
  }

  function vdpDetectDelimiter(text) {
    var line = String(text || '').replace(/^\ufeff/, '').split(/\r?\n/)[0] || '', candidates = [',',';','\t'], best=',', bestCount=-1, i, j, count, q;
    for (i=0;i<candidates.length;i++) {
      count=0; q=false;
      for (j=0;j<line.length;j++) { if(line.charAt(j)==='"'){q=!q;} else if(!q && line.charAt(j)===candidates[i]){count++;} }
      if(count>bestCount){bestCount=count;best=candidates[i];}
    }
    return best;
  }

  function vdpParseDelimited(text) {
    text = String(text || '').replace(/^\ufeff/, '');
    var delimiter = vdpDetectDelimiter(text), rows=[], row=[], cell='', quote=false, i, ch, next;
    for(i=0;i<text.length;i++){
      ch=text.charAt(i); next=i+1<text.length?text.charAt(i+1):'';
      if(ch==='"') { if(quote && next==='"'){cell+='"';i++;} else {quote=!quote;} }
      else if(ch===delimiter && !quote){row.push(cell);cell='';}
      else if((ch==='\n' || ch==='\r') && !quote){ if(ch==='\r'&&next==='\n'){i++;} row.push(cell);cell=''; if(row.length>1 || String(row[0]||'').replace(/\s/g,'')){rows.push(row);} row=[]; }
      else {cell+=ch;}
    }
    if(cell!=='' || row.length){row.push(cell);rows.push(row);}
    if(!rows.length){return {headers:[],records:[],delimiter:delimiter};}
    var headers=[], used={}, h, base, n, r, obj, records=[];
    for(i=0;i<rows[0].length;i++){
      base=String(rows[0][i]||'').replace(/^\s+|\s+$/g,'') || ('FIELD_'+(i+1)); h=base; n=2;
      while(used[h]){h=base+'_'+n;n++;} used[h]=true; headers.push(h);
    }
    for(i=1;i<rows.length;i++){
      r=rows[i]; obj={}; for(h=0;h<headers.length;h++){obj[headers[h]]=r[h]!==undefined?r[h]:'';} records.push(obj);
    }
    return {headers:headers,records:records,delimiter:delimiter};
  }

  function vdpRenderData() {
    $('vdpRecordCount').value=String(vdp.records.length); $('vdpFieldCount').value=String(vdp.headers.length);
    $('vdpDataInfo').className='source-card'; $('vdpDataInfo').innerHTML=vdp.fileName ? '<strong>'+html(vdp.fileName)+'</strong><br><small>'+html(vdp.filePath)+'</small>' : 'Chưa chọn dữ liệu.';
    var head='', body='', i,j,maxRows=Math.min(vdp.records.length,12);
    if(vdp.headers.length){head='<tr>';for(i=0;i<vdp.headers.length;i++){head+='<th>'+html(vdp.headers[i])+'</th>';}head+='</tr>';}
    for(i=0;i<maxRows;i++){body+='<tr>';for(j=0;j<vdp.headers.length;j++){body+='<td title="'+html(vdp.records[i][vdp.headers[j]])+'">'+html(vdp.records[i][vdp.headers[j]])+'</td>';}body+='</tr>';}
    $('vdpDataHead').innerHTML=head; $('vdpDataBody').innerHTML=body;
    $('vdpFrom').value=vdp.records.length?'1':'1'; $('vdpTo').value=String(Math.max(1,vdp.records.length)); $('vdpRecordIndex').max=String(Math.max(1,vdp.records.length));
    var opts='<option value="">Số thứ tự record</option>'; for(i=0;i<vdp.headers.length;i++){opts+='<option value="'+html(vdp.headers[i])+'">'+html(vdp.headers[i])+'</option>';}$('vdpFileNameField').innerHTML=opts;
    vdpRenderMappings();
  }

  function vdpLoadFileResult(raw) {
    var r=parse(raw); if(!r.ok){vdpStatus(r.error||'Không đọc được file dữ liệu.','error');return;}
    var parsed=vdpParseDelimited(r.text||''); if(!parsed.headers.length){vdpStatus('File không có dòng tiêu đề/cột dữ liệu.','error');return;}
    vdp.filePath=r.path||''; vdp.sourceFolder=r.folder||''; vdp.fileName=r.name||''; vdp.headers=parsed.headers; vdp.records=parsed.records;
    vdpRenderData(); vdpStatus('Đã đọc '+vdp.records.length+' record · '+vdp.headers.length+' cột.','ok');
  }

  function vdpChooseData() { bridgeCall('ChooseVariableDataFile',[],function(raw){if(raw){vdpLoadFileResult(raw);}}); }

  function vdpActionOptions(selected) {
    var a=[['text','Text'],['image','Image relink'],['visibility','Ẩn / hiện'],['fillColor','Fill Color']], out='',i;
    for(i=0;i<a.length;i++){out+='<option value="'+a[i][0]+'"'+(a[i][0]===selected?' selected':'')+'>'+a[i][1]+'</option>';} return out;
  }
  function vdpFieldOptions(selected) {
    var out='<option value="">— Chọn cột dữ liệu —</option>',i; for(i=0;i<vdp.headers.length;i++){out+='<option value="'+html(vdp.headers[i])+'"'+(vdp.headers[i]===selected?' selected':'')+'>'+html(vdp.headers[i])+'</option>';} return out;
  }
  function vdpBestField(target) {
    var t=vdpNormalize(target.label), i, h; if(!t){return '';}
    for(i=0;i<vdp.headers.length;i++){h=vdpNormalize(vdp.headers[i]);if(h===t){return vdp.headers[i];}}
    for(i=0;i<vdp.headers.length;i++){h=vdpNormalize(vdp.headers[i]);if(h && (t.indexOf(h)>=0 || h.indexOf(t)>=0)){return vdp.headers[i];}}
    return '';
  }
  function vdpRemoveTarget(index) {
    vdpSyncMappings();
    if(index < 0 || index >= vdp.targets.length){return;}
    vdp.targets.splice(index,1);
    vdpRenderMappings(false);
    vdpStatus('Còn '+vdp.targets.length+' vị trí biến đổi.','ok');
  }
  function vdpRenderMappings(forceAuto) {
    var out='',i,t,selectedField,buttons; if(!vdp.targets.length){$('vdpMappings').innerHTML='<div class="empty compact-empty">Chưa có đối tượng để map.</div>';return;}
    for(i=0;i<vdp.targets.length;i++){
      t=vdp.targets[i]; selectedField=(forceAuto||!t.field)?vdpBestField(t):(t.field||''); if(selectedField){t.field=selectedField;}
      out+='<div class="vdp-map-row" data-vdp-index="'+i+'"><div class="vdp-map-head"><strong>'+(i+1)+'. '+html(t.label)+'</strong><span class="vdp-kind-badge">'+html(t.itemType)+'</span><button type="button" class="vdp-remove-map" data-remove-index="'+i+'" title="Xóa vị trí này">×</button></div>'+
        '<div class="vdp-map-controls"><select class="vdp-action">'+vdpActionOptions(t.action||'text')+'</select><select class="vdp-field">'+vdpFieldOptions(t.field||'')+'</select></div>'+
        '<div class="vdp-affix"><input class="vdp-prefix" type="text" placeholder="Tiền tố" value="'+html(t.prefix||'')+'"><input class="vdp-suffix" type="text" placeholder="Hậu tố" value="'+html(t.suffix||'')+'"></div></div>';
    }
    $('vdpMappings').innerHTML=out;
    buttons=$('vdpMappings').querySelectorAll('.vdp-remove-map');
    for(i=0;i<buttons.length;i++){buttons[i].addEventListener('click',function(){vdpRemoveTarget(Number(this.getAttribute('data-remove-index')));});}
  }
  function vdpSyncMappings() {
    var rows=$('vdpMappings').querySelectorAll('.vdp-map-row'),i,idx;
    for(i=0;i<rows.length;i++){idx=Number(rows[i].getAttribute('data-vdp-index'));if(!vdp.targets[idx]){continue;}vdp.targets[idx].action=rows[i].querySelector('.vdp-action').value;vdp.targets[idx].field=rows[i].querySelector('.vdp-field').value;vdp.targets[idx].prefix=rows[i].querySelector('.vdp-prefix').value;vdp.targets[idx].suffix=rows[i].querySelector('.vdp-suffix').value;}
  }
  function vdpMappingsConfig() {
    vdpSyncMappings(); var arr=[],i,t; for(i=0;i<vdp.targets.length;i++){t=vdp.targets[i];if(!t.field){continue;}arr.push({targetId:t.id,label:t.label,itemType:t.itemType,action:t.action,field:t.field,prefix:t.prefix||'',suffix:t.suffix||''});} return arr;
  }
  function vdpMergeTargets(nextTargets) {
    vdpSyncMappings();
    var seen={},i,t,added=0;
    for(i=0;i<vdp.targets.length;i++){seen[String(vdp.targets[i].id||'')]=true;}
    for(i=0;i<(nextTargets||[]).length;i++){t=nextTargets[i];if(!t || !t.id || seen[String(t.id)]){continue;}if(!t.field){t.field=vdpBestField(t);}seen[String(t.id)]=true;vdp.targets.push(t);added++;}
    return added;
  }
  function vdpScanTargets() { setBusy(true,'Đang thêm các vị trí Variable Data đang chọn trong Illustrator…'); bridgeCall('ScanVariableTargets',[]); }
  function vdpCurrentIndex() { var n=Math.floor(Number($('vdpRecordIndex').value)||1); n=Math.max(1,Math.min(Math.max(1,vdp.records.length),n));$('vdpRecordIndex').value=String(n);return n; }
  function vdpPreview() {
    if(!vdp.records.length){vdpStatus('Chưa có dữ liệu CSV/TXT.','error');return;} var maps=vdpMappingsConfig();if(!maps.length){vdpStatus('Chưa map cột dữ liệu vào đối tượng Illustrator.','error');return;}
    var idx=vdpCurrentIndex(); setBusy(true,'Đang preview Variable Data record '+idx+'…'); bridgeCall('PreviewVariableData',[JSON.stringify({record:vdp.records[idx-1],recordNumber:idx,mappings:maps,sourceFolder:vdp.sourceFolder})]);
  }
  function vdpRestore(){setBusy(true,'Đang khôi phục nội dung gốc…');bridgeCall('RestoreVariableData',[]);}
  function vdpBuild(){
    if(!vdp.records.length){vdpStatus('Chưa có dữ liệu CSV/TXT.','error');return;}
    var maps=vdpMappingsConfig(); if(!maps.length){vdpStatus('Chưa có mapping hợp lệ.','error');return;}
    var out=$('vdpOutputPath').value; if(!out){vdpStatus('Chưa chọn thư mục xuất.','error');return;}
    var exportIndividual=$('vdpExportIndividual').checked, combinePdf=$('vdpCombinePdf').checked;
    if(combinePdf && !exportIndividual){ exportIndividual=true; $('vdpExportIndividual').checked=true; }
    if(!exportIndividual){vdpStatus('V85 xuất VDP theo từng PDF record. Hãy bật “Xuất PDF riêng từng record”.','error');return;}
    var from=Math.max(1,Math.floor(Number($('vdpFrom').value)||1)),to=Math.min(vdp.records.length,Math.max(from,Math.floor(Number($('vdpTo').value)||vdp.records.length)));
    setBusy(true,'Đang render '+(to-from+1)+' PDF record'+(combinePdf?' · sau đó DPV tự Combine':'')+'…');
    bridgeCall('BuildVariableData',[JSON.stringify({dataPath:vdp.filePath,mappings:maps,sourceFolder:vdp.sourceFolder,outputPath:out,from:from,to:to,fileNameField:$('vdpFileNameField').value,filePrefix:$('vdpFilePrefix').value||'VDP',exportIndividual:exportIndividual,combinePdf:combinePdf,combinedName:$('vdpCombinedName').value||'VDP_ALL'})]);
  }

  function vdpCombineExisting(){
    setBusy(true,'Chọn các PDF để DPV Combine trực tiếp…');
    bridgeCall('CombinePdfFilesDpv',[]);
  }

  window.VDPRO_receive = function (operation, payload) {
    if (operation === "connect") { clearConnectWatchdog(); }
    if (operation === "vdpBuildProgress") {
      var pr=parse(payload);
      if(pr && pr.ok){vdpStatus("Đang xuất record "+(pr.current||0)+"/"+(pr.total||0)+" · record dữ liệu "+(pr.recordNumber||"")+" · chế độ V79 Low-RAM…","ok");}
      return;
    }
    if (operation === "vdpCombineProgress") {
      var cp=parse(payload);
      if(cp && cp.ok){vdpStatus("Đang Combine trực tiếp trong DPV: "+(cp.current||0)+"/"+(cp.total||0)+" PDF · "+(cp.pages||0)+" trang…","ok");}
      return;
    }
    if (operation === "vdpCombineExisting" && !payload) { setBusy(false); vdpStatus("Đã hủy Combine PDF.",""); return; }
    setBusy(false); var r = parse(payload);
    if (!r.ok) {
      if (operation === "connect") { setConnected(false); }
      if (String(operation || "").indexOf("vdp") === 0) { vdpStatus(r.error || "Illustrator Bridge báo lỗi.", "error"); try { if ($("vdpStatus")) { $("vdpStatus").scrollIntoView(false); } } catch (eScroll) {} }
      else { status(r.error || "Illustrator Bridge báo lỗi.", "error"); }
      return;
    }
    if (operation === "connect") {
      setConnected(true, "Illustrator " + (r.version || "") + " đã kết nối"); status("Kết nối Illustrator thành công.", "ok"); return;
    }
    setConnected(true, "Illustrator đang kết nối");
    if (operation === "vdpCombineExisting") {
      vdpStatus("Combine trực tiếp hoàn tất "+(r.combinedCount||0)+" file → "+(r.combinedPages||0)+" trang. File: "+(r.combinedFile||""),"ok"); return;
    }
    if (operation === "vdpTargets") {
      var addedTargets = vdpMergeTargets(r.targets || []);
      vdpRenderMappings(false);
      vdpStatus("Đã thêm " + addedTargets + " vị trí. Tổng đang dùng: " + vdp.targets.length + " vị trí biến đổi.", "ok"); return;
    }
    if (operation === "vdpPreview") { vdpStatus("Đã preview record " + (r.recordNumber || "") + " với " + (r.applied || 0) + " kênh biến đổi.", "ok"); return; }
    if (operation === "vdpRestore") { vdpStatus("Đã khôi phục " + (r.restored || 0) + " đối tượng về nội dung gốc.", "ok"); return; }
    if (operation === "vdpBuild") {
      var msg="Hoàn tất "+(r.count||0)+" record với "+(r.mappingCount||0)+" vị trí biến đổi.";
      if(r.fastMode==="SAME_DOCUMENT_SNAPSHOT_V78"){msg+=" Gộp V78 snapshot cùng document.";} if(r.fastMode==="STREAM_LOW_RAM_V79"||r.fastMode==="PINNED_SOURCE_STREAM_V80"||r.fastMode==="TRUE_MULTIPAGE_STREAM_V84"){msg+=" Stream Low-RAM.";} if(r.fastMode==="RECORD_PDF_THEN_DPV_COMBINE_V86"){msg+=" V86: render PDF record rồi DPV tự Combine, không cần Acrobat.";}
      if(r.fidelityClone===true){msg+=" Fidelity AI: ON.";} if(r.autoSaved===true){msg+=" Đã tự Save AI trước khi chạy.";}
      if(r.units==="mm"){msg+=" Đơn vị output: mm.";}
      if(r.individualCount){msg+=" PDF riêng: "+r.individualCount+".";}
      if(r.combinedFile){msg+=" PDF Combine: "+r.combinedFile+" ("+(r.combinedPages||0)+" trang)"+(r.combineEngine?" · "+r.combineEngine:"")+".";}
      msg+=" Thư mục: "+(r.outputFolder||"");
      vdpStatus(msg,"ok"); return;
    }
    if (operation === "activeSource") {
      artboardMode = false; artboardDocumentName = ""; manualSizeMode = false; sources = [r.source]; renderSources();
      if (r.source && r.source.shapeDeferred) {
        status("Đã lấy file nhanh trong " + perfTime(r.source.readMs) + "; chưa quét toàn bộ artwork. Số con hiện tại là ước tính theo artboard; KHUON_BE thật sẽ được đọc khi xem hoặc xuất. Có thể dùng “Lấy khuôn đang chọn” để nhận chính xác ngay.", "ok");
      } else {
        status("Đã nhận file và KHUON_BE từ Illustrator trong " + perfTime(r.source && r.source.readMs) + ".", "ok");
      }
      return;
    }
    if (operation === "inspectSources") {
      artboardMode = false; artboardDocumentName = ""; manualSizeMode = false; sources = r.sources || []; renderSources(); status("Đã nhận " + sources.length + " file nguồn.", "ok"); return;
    }
    if (operation === "listArtboards") {
      pendingArtboards = r.artboards || []; artboardDocumentName = r.documentName || ""; renderArtboards(); status("Chọn các artboard cần dàn.", "ok"); return;
    }
    if (operation === "hostPreview") {
      if (r.groups) {
        $("previewMethod").innerText = r.duplex ?
          "Illustrator xác nhận: 1 PDF · 2 TRANG A/B · B XOAY ĐÚNG CHIỀU MÁY" : r.cattp ?
          "Illustrator xác nhận: " + r.printFileCount + " IN CATTP · KHÔNG KHUÔN" :
          "Illustrator xác nhận: " + r.printFileCount + " IN · " + r.dieFileCount + " KHUÔN";
      } else {
        $("previewCount").innerText = r.count; $("previewMethod").innerText = r.methodLabel || "Illustrator Preview";
      }
      $("engineState").innerText = "Đã đối chiếu AI"; status("Illustrator đã xác nhận bố cục.", "ok"); return;
    }
    if (operation === "diePreview") {
      status(r.manual ? "Đã mở trực tiếp " + r.count + " khuôn trong Illustrator; chưa lưu file." : "Đã mở bản xem trước khuôn trong Illustrator; chưa lưu file.", "ok"); return;
    }
    if (operation === "build") {
      var slowest = logPerformanceV48(r);
      if (r.printFileCount !== undefined) {
        status(r.duplex ?
          "Hoàn tất: đã tạo 1 FILE IN CATTP gồm 2 trang/artboard A–B; mặt B đã xoay đúng chiều máy trở giấy, chỉ có PON CATTP và không tạo FILE KHUÔN." + (slowest ? " Chậm nhất: " + slowest : "") : r.cattp ?
          "Hoàn tất: " + r.printFileCount + " FILE IN CATTP; PON cắt nằm chung file in, không tạo FILE KHUÔN." + (slowest ? " Chậm nhất: " + slowest : "") :
          "Hoàn tất: " + r.printFileCount + " FILE IN và " + r.dieFileCount + " FILE KHUÔN." + (slowest ? " Chậm nhất: " + slowest : ""), "ok");
      }
      else { status("Hoàn tất " + r.count + " con." + (slowest ? " Chậm nhất: " + slowest : "") + " Xem Nhật ký Bridge để thấy toàn bộ thời gian.", "ok"); }
    }
  };


  $("vdpOpenBtn").addEventListener("click", function(){ $("vdpPanel").className="vdp-overlay"; });
  $("vdpCloseBtn").addEventListener("click", function(){ $("vdpPanel").className="vdp-overlay hidden"; });
  $("vdpChooseDataBtn").addEventListener("click", vdpChooseData);
  $("vdpReloadDataBtn").addEventListener("click", function(){ if(!vdp.filePath){vdpChooseData();return;} bridgeCall("ReadVariableDataFile",[vdp.filePath],function(raw){if(raw){vdpLoadFileResult(raw);}}); });
  $("vdpScanTargetsBtn").addEventListener("click", vdpScanTargets);
  $("vdpClearTargetsBtn").addEventListener("click", function(){vdp.targets=[];vdpRenderMappings(false);vdpStatus("Đã xóa toàn bộ kênh biến đổi.","ok");});
  $("vdpAutoMapBtn").addEventListener("click", function(){ vdpSyncMappings(); vdpRenderMappings(true); vdpStatus("Đã thử tự map theo tên cột và tên đối tượng.","ok"); });
  $("vdpPrevBtn").addEventListener("click", function(){ $("vdpRecordIndex").value=String(Math.max(1,vdpCurrentIndex()-1)); vdpPreview(); });
  $("vdpNextBtn").addEventListener("click", function(){ $("vdpRecordIndex").value=String(Math.min(Math.max(1,vdp.records.length),vdpCurrentIndex()+1)); vdpPreview(); });
  $("vdpPreviewBtn").addEventListener("click", vdpPreview);
  $("vdpRestoreBtn").addEventListener("click", vdpRestore);
  $("vdpOutputBtn").addEventListener("click", function(){ bridgeCall("ChooseOutputFolder",[],function(p){if(p){$("vdpOutputPath").value=p;vdpStatus("Đã chọn thư mục xuất.","ok");}}); });
  $("vdpBuildBtn").addEventListener("click", vdpBuild);
    if($('vdpCombineExistingBtn')){$('vdpCombineExistingBtn').addEventListener('click',vdpCombineExisting);}

  $("connectBtn").addEventListener("click", connect);
  $("activeBtn").addEventListener("click", function () { getActive(false); });
  $("manualBtn").addEventListener("click", function () { getActive(true); });
  $("manualSizeBtn").addEventListener("click", openManualSize);
  $("closeManualSize").addEventListener("click", function () { $("manualSizeBox").className = "manual-size-box hidden"; });
  $("manualShape").addEventListener("change", syncManualShapeFields);
  $("applyManualSize").addEventListener("click", applyManualSize);
  $("multiBtn").addEventListener("click", chooseMultiple);
  $("artboardsBtn").addEventListener("click", listArtboards);
  $("closeArtboards").addEventListener("click", function () { $("artboardChooser").className = "artboard-box hidden"; });
  $("allArtboards").addEventListener("click", function () { var c=document.querySelectorAll(".ab-check"); for(var i=0;i<c.length;i++){c[i].checked=true;} });
  $("noneArtboards").addEventListener("click", function () { var c=document.querySelectorAll(".ab-check"); for(var i=0;i<c.length;i++){c[i].checked=false;} });
  $("useArtboards").addEventListener("click", useArtboards);
  $("localPreviewBtn").addEventListener("click", function () { localPreview(true); });
  $("hostPreviewBtn").addEventListener("click", hostPreview);
  $("diePreviewBtn").addEventListener("click", diePreview);
  $("buildBtn").addEventListener("click", build);
  $("outputBtn").addEventListener("click", function () { bridgeCall("ChooseOutputFolder", [], function(p){if(p){requiredEl("outputPath").value=p;status("Đã chọn thư mục xuất.","ok");}}); });
  $("ponBtn").addEventListener("click", function () { bridgeCall("ChoosePonFile", [], function(p){if(p){requiredEl("ponPath").value=p;status("Đã chọn file PON.","ok");}}); });
  $("clearPon").addEventListener("click", function () { requiredEl("ponPath").value=""; });
  $("clearLog").addEventListener("click", function () { $("log").innerHTML=""; });
  var demiPrevGapX = null, demiPrevGapY = null;
  function syncDemiModeV87(fromUser) {
    var demi = requiredEl("demiMode"), gx = requiredEl("gapX"), gy = requiredEl("gapY");
    var irrelevant = ["uniformGap","trueShape","specialStagger","cornerSafe","cornerZone","angleStep"];
    var i, node;
    if (demi.checked) {
      if (fromUser) { demiPrevGapX = gx.value; demiPrevGapY = gy.value; }
      gx.value = "0"; gy.value = "0"; gx.disabled = true; gy.disabled = true;
      for (i = 0; i < irrelevant.length; i++) { node = $(irrelevant[i]); if (node) { node.disabled = true; } }
    } else {
      gx.disabled = false; gy.disabled = false;
      if (fromUser && demiPrevGapX !== null) { gx.value = demiPrevGapX; gy.value = demiPrevGapY; }
      for (i = 0; i < irrelevant.length; i++) { node = $(irrelevant[i]); if (node) { node.disabled = false; } }
      syncUniformGapV83();
    }
  }
  $("demiMode").addEventListener("change", function () { syncDemiModeV87(true); localPreview(false); });
  function syncFinishCropFields() {
    var enabled = check("finishCropMarks");
    $("finishMarkLength").disabled = !enabled;
    $("finishMarkGap").disabled = !enabled;
    $("duplexMode").disabled = !enabled;
    if (!enabled) { $("duplexMode").checked = false; }
    $("duplexFlip").disabled = !enabled || !check("duplexMode");
  }
  $("finishCropMarks").addEventListener("change", function () { syncFinishCropFields(); localPreview(false); });
  $("duplexMode").addEventListener("change", function () { syncFinishCropFields(); renderSources(); localPreview(false); });


  function syncUniformGapV83(){
    /* V87: Demi là engine riêng. Không để Khe đều/True-Shape/Khuôn đặc biệt
       can thiệp UI khi Bế 1 dao đang bật. */
    if ($("demiMode") && $("demiMode").checked) { return; }
    var exactSpecial = $("uniformGap") && $("uniformGap").checked && $("specialStagger") && $("specialStagger").checked;
    if ($("specialStagger")) { $("specialStagger").disabled = false; }
    if ($("trueShape")) {
      $("trueShape").disabled = false;
      if (exactSpecial) { $("trueShape").checked = true; }
    }
  }
  if ($("uniformGap")) { $("uniformGap").addEventListener("change", function(){ syncUniformGapV83(); localPreview(false); }); }
  if ($("specialStagger")) { $("specialStagger").addEventListener("change", function(){ syncUniformGapV83(); localPreview(false); }); }
  syncUniformGapV83();
  syncDemiModeV87(false);
  var settingIds = ["paperW","paperH","margin","header","gapX","gapY","maxQty","linkBleed","allowRotate","uniformGap","trueShape","specialStagger","fastMode","cornerSafe","cornerZone","angleStep","demiExtend","cornerPonRed","finishMarkLength","finishMarkGap","duplexFlip"];
  for (var si = 0; si < settingIds.length; si++) {
    var settingNode = $(settingIds[si]);
    if (settingNode) { settingNode.addEventListener("change", function () { localPreview(false); }); }
  }

  syncFinishCropFields();
  renderSources();
  if (externalReady()) { window.setTimeout(function () { bridgeCall("ConnectIllustrator", [false]); }, 500); }
}());
