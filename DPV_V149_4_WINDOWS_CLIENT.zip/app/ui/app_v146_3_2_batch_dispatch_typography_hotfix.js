/* DPV V146.3.2 BATCH DISPATCH + BARCODE TYPOGRAPHY SAFE UI */
(function(){
  'use strict';
  var VERSION='V146.3.2',STORE='dpv_v1463_barcode_style';
  function $(id){return document.getElementById(id);}
  function load(){try{return JSON.parse(localStorage.getItem(STORE)||'{}')||{};}catch(e){return {};}}
  function save(v){try{localStorage.setItem(STORE,JSON.stringify(v||{}));}catch(e){}}
  function stateRaw(){try{return window.DPVVDP101&&window.DPVVDP101.getState?window.DPVVDP101.getState():null;}catch(e){return null;}}
  function key(m){return String((m&&m.targetId)||'');}
  function isBar(a){return a==='code128Vector'||a==='ean13Vector';}
  function styleFor(m,db){var k=key(m);return k&&db[k]?db[k]:null;}
  function installStateWrapper(){
    if(!window.DPVVDP101||window.DPVVDP101.__v14632StateWrapped)return false;
    var old=window.DPVVDP101.getState;if(typeof old!=='function')return false;
    window.DPVVDP101.getState=function(){
      var st=old(),db=load(),i,s;if(st&&st.mappings){for(i=0;i<st.mappings.length;i++){if(isBar(st.mappings[i].action)){s=styleFor(st.mappings[i],db);if(s)st.mappings[i].barcodeStyle=s;}}}return st;
    };
    window.DPVVDP101.__v14632StateWrapped=true;return true;
  }
  function ensure(){
    var root=$('vdpMappings'),card=$('v14632BatchTypographyCard');if(!root||!root.parentNode)return null;
    var old=$('v1463BarcodeTypographyCard');if(old)old.style.display='none';
    if(card)return card;
    card=document.createElement('div');card.id='v14632BatchTypographyCard';card.className='v14632-card';
    card.innerHTML='<div class="v14632-head"><strong>QR / BARCODE BATCH + TYPOGRAPHY</strong><span>'+VERSION+' SAFE</span></div>'+
      '<div class="v14632-pass">✓ Batch dispatch thật: QR · Code128 · EAN-13 được áp trực tiếp trong record/work-copy trước khi xuất PDF.</div>'+
      '<div id="v14632MapPickerWrap"></div><div id="v14632StyleBox"></div>';
    root.parentNode.insertBefore(card,root.nextSibling);return card;
  }
  function bars(){var st=stateRaw()||{},a=st.mappings||[],out=[],i;for(i=0;i<a.length;i++)if(isBar(a[i].action))out.push(a[i]);return out;}
  function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');}
  function render(){
    if(!ensure())return false;installStateWrapper();
    var maps=bars(),wrap=$('v14632MapPickerWrap'),box=$('v14632StyleBox'),db=load(),sel=$('v14632MapPicker'),idx=sel?Number(sel.value||0):0,m,cfg,k;
    if(!maps.length){wrap.innerHTML='';box.innerHTML='<div class="v14632-empty">QR không cần typography. Đổi Action sang <b>Barcode Code 128 · Vector</b> hoặc <b>Barcode EAN-13 · Vector</b> để chỉnh font/chữ dưới mã.</div>';return true;}
    if(idx>=maps.length)idx=0;
    wrap.innerHTML='<label class="v14632-pick"><span>Mapping barcode cần chỉnh</span><select id="v14632MapPicker">'+maps.map(function(x,i){return '<option value="'+i+'"'+(i===idx?' selected':'')+'>'+esc(x.label||x.field||('Barcode '+(i+1)))+' · '+(x.action==='ean13Vector'?'EAN-13':'Code 128')+'</option>';}).join('')+'</select></label>';
    m=maps[idx];k=key(m);cfg=(k&&db[k])?db[k]:{};
    function v(n,d){return cfg[n]==null?d:cfg[n];}
    box.innerHTML='<div class="v14632-grid">'+
      '<label><span>Chữ dưới mã</span><select id="v14632Show"><option value="1">Bật</option><option value="0">Tắt</option></select></label>'+
      '<label><span>Font (family/PostScript)</span><input id="v14632Font" value="'+esc(v('fontName','Arial'))+'"></label>'+
      '<label><span>Cỡ chữ (pt)</span><input id="v14632Size" type="number" min="4" step="0.1" value="'+v('fontSize',9)+'"></label>'+
      '<label><span>Tracking</span><input id="v14632Tracking" type="number" step="1" value="'+v('tracking',0)+'"></label>'+
      '<label><span>Khoảng chữ–mã (mm)</span><input id="v14632Gap" type="number" min="0" step="0.1" value="'+v('textGapMm',1.2)+'"></label>'+
      '<label><span>Chiều cao vạch (%)</span><input id="v14632Height" type="number" min="40" max="200" value="'+v('barHeightPercent',100)+'"></label>'+
      '<label><span>Độ rộng mã (%)</span><input id="v14632Width" type="number" min="60" max="140" value="'+v('barWidthPercent',100)+'"></label>'+
      '<label><span>Quiet zone (module)</span><input id="v14632Quiet" type="number" min="2" max="20" value="'+v('quietZone',10)+'"></label>'+
      '<label><span>Kiểu font</span><select id="v14632Weight"><option value="regular">Regular</option><option value="bold">Bold</option></select></label>'+
      '<label><span>Dòng chữ</span><select id="v14632TextMode"><option value="outline">Outline vector</option><option value="live">Text sống</option></select></label></div>'+
      '<div class="v14632-actions"><button id="v14632Save" class="button accent">Lưu style cho mapping này</button><button id="v14632Reset" class="button ghost">Mặc định</button></div>'+
      '<div class="v14632-help">Style được gắn vào mapping chỉ khi Preview/Build; các job cũ không barcode không bị thay đổi. Với EAN-13, nên giữ độ rộng 100% và quiet zone đủ lớn để dễ quét.</div>';
    $('v14632Show').value=String(v('showText',1));$('v14632Weight').value=String(v('fontWeight','regular'));$('v14632TextMode').value=String(v('textMode','outline'));
    $('v14632MapPicker').onchange=function(){render();};
    $('v14632Save').onclick=function(){
      db=load();db[k]={showText:Number($('v14632Show').value),fontName:$('v14632Font').value||'Arial',fontSize:Number($('v14632Size').value||9),tracking:Number($('v14632Tracking').value||0),textGapMm:Number($('v14632Gap').value||1.2),barHeightPercent:Number($('v14632Height').value||100),barWidthPercent:Number($('v14632Width').value||100),quietZone:Number($('v14632Quiet').value||10),fontWeight:$('v14632Weight').value||'regular',textMode:$('v14632TextMode').value||'outline'};save(db);if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status('Đã lưu Barcode Typography '+VERSION+'.','ok');
    };
    $('v14632Reset').onclick=function(){db=load();delete db[k];save(db);render();};return true;
  }
  var t=0,tm=setInterval(function(){t++;if((installStateWrapper()&&render())||t>100)clearInterval(tm);},400);
  document.addEventListener('click',function(){setTimeout(function(){installStateWrapper();render();},40);},false);
})();
