(function(){
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;
    if(v)v.innerHTML='V138 NO-STROKE FIDELITY · CORE V101 STABLE';
    var b=document.querySelector?document.querySelector('.beta-note'):null;
    if(b)b.innerHTML='<strong>DPV® V138 No-Stroke Fidelity</strong><br>VDP giữ đúng font/size của từng TextFrame và KHÔNG tự bật stroke khi chữ gốc chỉ có Fill. Nếu layout gốc Stroke=None thì số nhảy/CSV xuất ra vẫn Stroke=None.';
  }
  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',mark);}else{mark();}
})();
