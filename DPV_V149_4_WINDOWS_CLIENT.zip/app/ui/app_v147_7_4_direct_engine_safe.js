/* DPV V147.7.4 STANDALONE DIRECT ENGINE UI - FINAL OWNER */
(function(){
'use strict';
var pending=false,timer=null,receiveInstalled=false,seq=0;
function $(id){return document.getElementById(id);}function s(v){return String(v==null?'':v);}function trim(v){return s(v).replace(/^\s+|\s+$/g,'');}
function val(id,d){var e=$(id);return e?e.value:d;}function num(id,d){var e=$(id),n=Number(e&&e.value);return isNaN(n)?d:n;}
function status(m,k){var e=$('v1474StandaloneStatus');if(e){e.textContent=m;e.className='v1474-status '+(k||'');}try{if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}catch(x){}}
function eanCheck(x){var i,sum=0,n;for(i=0;i<12;i++){n=Number(x.charAt(i));sum+=(i%2===0)?n:n*3;}return String((10-(sum%10))%10);}
function fontPS(){return window.__DPV14773_FONT_PS||val('v147FontName','Arial')||'Arial';}
function cfg(batch){var mode=batch?'batch':val('v147CreateMode','single'),raw=mode==='batch'?val('v147BatchContent',''):val('v147SingleContent',''),arr;
 if(mode==='batch'){arr=s(raw).split(/\r?\n/);var a=[],i;for(i=0;i<arr.length;i++){if(trim(arr[i]))a.push(trim(arr[i]));}arr=a;}else{arr=trim(raw)?[trim(raw)]:[];}
 return {standaloneV14774:true,requester:'V14774',requestId:'R'+(++seq),codeType:val('v147CodeType','qr'),targetMode:val('v147TargetMode','selection'),values:arr,
 fontName:fontPS(),fontSize:num('v1475FontSize',num('v147FontSize',9)),showText:Number(val('v147ShowText','1')),textMode:val('v1475TextMode',val('v147TextMode','outline')),
 fontWeight:val('v1475Weight','regular'),tracking:num('v1475Tracking',0),textGapMm:num('v1475TextGap',1.2),barHeightPercent:num('v1475BarHeight',100),barWidthPercent:num('v1475BarWidth',100),quietZone:num('v1475QuietZone',10),
 widthMm:num('v1474WidthMm',50),heightMm:num('v1474HeightMm',20),columns:num('v1474Columns',4),gapMm:num('v1474GapMm',5)};}
function validate(c){var i,v,cd,j,ch;if(!c.values.length)return 'Chưa nhập nội dung QR/Barcode.';for(i=0;i<c.values.length;i++){v=c.values[i];if(c.codeType==='ean13'){if(!/^\d{12,13}$/.test(v))return 'EAN-13 dòng '+(i+1)+' phải có đúng 12 hoặc 13 số.';if(v.length===13){cd=eanCheck(v.substr(0,12));if(v.charAt(12)!==cd)return 'EAN-13 sai checksum. Số cuối đúng phải là '+cd+'.';}}if(c.codeType==='code128'){for(j=0;j<v.length;j++){ch=v.charCodeAt(j);if(ch<32||ch>126)return 'Code128 chỉ hỗ trợ ASCII 32–126.';}}}return '';}
function finish(){pending=false;if(timer){clearTimeout(timer);timer=null;}var ids=['v14774PreviewBtn','v14774CreateBtn','v14774BatchBtn'],i,e;for(i=0;i<ids.length;i++){e=$(ids[i]);if(e)e.disabled=false;}}
function handle(r){if(!r||!(r.standaloneV14774||r.engine==='DIRECT_V14774'))return false;finish();if(r.ok===false)status('Tạo mã lỗi: '+s(r.error||'Không rõ lỗi Illustrator.'),'error');else status('Đã tạo '+s(r.created||0)+' mã bằng DIRECT ENGINE trong Illustrator · '+s(r.documentName||''),'ok');return true;}
function installReceive(){if(receiveInstalled&&window.VDPRO_receive===window.__DPV14774Receive)return true;if(typeof window.VDPRO_receive!=='function')return false;var old=window.VDPRO_receive;function recv(op,payload){var r=null;if(op==='vdpPreview'){try{r=JSON.parse(s(payload||'{}'));}catch(e){}if(handle(r))return;}return old.apply(window,arguments);}window.__DPV14774Receive=recv;window.VDPRO_receive=recv;receiveInstalled=true;return true;}
function send(isPreview,isBatch){var c=cfg(!!isBatch),err=validate(c),payload,ret;if(err){status(err,'error');return false;}if(pending){status('Illustrator đang xử lý lệnh trước.','work');return false;}pending=true;['v14774PreviewBtn','v14774CreateBtn','v14774BatchBtn'].forEach(function(id){var e=$(id);if(e)e.disabled=true;});status((isPreview?'Đang Preview':'Đang tạo')+' '+c.values.length+' mã · DIRECT ENGINE V147.7.4…','work');payload=JSON.stringify(c);
 timer=setTimeout(function(){if(pending){finish();status('DIRECT ENGINE chưa nhận phản hồi sau 45 giây. Hãy bấm Kết nối lại; nếu vẫn lỗi, gửi ảnh Nhật ký Bridge.','error');}},45000);
 try{
  if(window.DPVNative&&typeof window.DPVNative.invoke==='function'){
   ret=window.DPVNative.invoke('PreviewVariableData',[payload]);if(ret&&typeof ret.then==='function'){ret.then(function(v){var r=null;try{if(v)r=typeof v==='object'?v:JSON.parse(s(v));}catch(e){}if(r)handle(r);}).catch(function(e){finish();status('Mac Bridge lỗi: '+s(e&&e.message||e),'error');});}return false;
  }
  if(window.external&&typeof window.external.PreviewVariableData!=='undefined'){window.external.PreviewVariableData(payload);return false;}
  if(window.DPVVDP101&&typeof window.DPVVDP101.bridgeCall==='function'){window.DPVVDP101.bridgeCall('PreviewVariableData',[payload]);return false;}
  finish();status('Bridge Illustrator chưa sẵn sàng.','error');
 }catch(e){finish();status('Không gửi được lệnh DIRECT ENGINE: '+s(e&&e.message||e),'error');}return false;}
function replaceButtons(){var oldIds=['v147PreviewAiBtn','v147CreateBtn','v147BatchBtn'],newIds=['v14774PreviewBtn','v14774CreateBtn','v14774BatchBtn'],labels=['Preview thật trong Illustrator','Tạo mã vào Illustrator','Tạo batch không cần VDP'],i,o,n;if($('v14774CreateBtn'))return true;for(i=0;i<3;i++){o=$(oldIds[i]);if(!o)continue;n=o.cloneNode(true);n.id=newIds[i];n.textContent=labels[i];n.__v1474=n.__v1475=n.__v14773=true;o.parentNode.insertBefore(n,o);o.style.display='none';}
 if($('v14774PreviewBtn'))$('v14774PreviewBtn').onclick=function(e){if(e&&e.preventDefault)e.preventDefault();return send(true,false);};
 if($('v14774CreateBtn'))$('v14774CreateBtn').onclick=function(e){if(e&&e.preventDefault)e.preventDefault();return send(false,false);};
 if($('v14774BatchBtn'))$('v14774BatchBtn').onclick=function(e){if(e&&e.preventDefault)e.preventDefault();return send(false,true);};
 var box=$('v1474StandaloneStatus');if(box){box.textContent='V147.7.4 DIRECT ENGINE sẵn sàng · không qua VDP mapping.';box.className='v1474-status ok';}
 return !!$('v14774CreateBtn');}
function badge(){var h=document.querySelector('#v147StudioOverlay .v1471-badge');if(h)h.textContent='V147.7.4 DIRECT';}
function boot(){replaceButtons();installReceive();badge();return true;}var t=0,iv=setInterval(function(){t++;boot();if(t>300)clearInterval(iv);},250);setTimeout(boot,30);
})();
