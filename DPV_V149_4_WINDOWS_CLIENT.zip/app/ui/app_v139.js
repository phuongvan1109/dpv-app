(function(){
  "use strict";
  var VERSION='V140 PERFORMANCE FOUNDATION';
  var STORE_PRESETS='dpv.pro.presets.v139';
  var STORE_RECENT='dpv.pro.lastSettings.v139';
  var STORE_JOBS='dpv.pro.jobs.v139';
  var STORE_PERF='dpv.pro.performance.v139';
  var MAX_JOBS=24;
  var jobState={active:null,lastMain:'',lastVdp:''};

  function byId(id){return document.getElementById(id);}
  function qs(s){return document.querySelector?document.querySelector(s):null;}
  function qsa(s){return document.querySelectorAll?document.querySelectorAll(s):[];}
  function txt(el){return el?(el.textContent||el.innerText||''):'';}
  function trim(s){return String(s==null?'':s).replace(/^\s+|\s+$/g,'');}
  function add(el,c){if(!el)return;if((' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(!el)return;el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function num(id,def){var e=byId(id),v=e?parseFloat(e.value):NaN;return isNaN(v)?def:v;}
  function checked(id){var e=byId(id);return !!(e&&e.checked);}
  function val(id){var e=byId(id);return e?String(e.value||''):'';}
  function count(sel){var a=qsa(sel);return a?a.length:0;}
  function nowLabel(){var d=new Date();function p(n){return n<10?'0'+n:String(n);}return p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());}
  function nowFull(){var d=new Date();function p(n){return n<10?'0'+n:String(n);}return p(d.getDate())+'/'+p(d.getMonth()+1)+' '+p(d.getHours())+':'+p(d.getMinutes());}
  function storeGet(k,def){try{var s=window.localStorage?localStorage.getItem(k):null;return s?JSON.parse(s):def;}catch(e){return def;}}
  function storeSet(k,v){try{if(window.localStorage)localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){return false;}}
  function fire(el,type){if(!el)return;try{var ev=document.createEvent('HTMLEvents');ev.initEvent(type,true,false);el.dispatchEvent(ev);}catch(e){try{el.fireEvent('on'+type);}catch(x){}}}
  function click(id){var e=byId(id);if(e&&e.click)e.click();}
  function showToast(msg){var t=byId('dpvToast');if(t){if('textContent'in t)t.textContent=msg;else t.innerText=msg;add(t,'show');setTimeout(function(){rem(t,'show');},2200);}}

  var settingIds=['paperW','paperH','margin','header','gapX','gapY','maxQty','linkBleed','dieHint','angleStep','cornerZone','demiExtend','finishMarkLength','finishMarkGap','duplexFlip'];
  var checkIds=['allowRotate','uniformGap','trueShape','specialStagger','fastMode','addTitle','cornerSafe','demiMode','preservePrintColor','autoPon','fitPon','ponProcessBlack','cornerPonRed','finishCropMarks','duplexMode'];
  function captureSettings(){
    var o={version:140,created:new Date().getTime(),values:{},checks:{}};var i,e;
    for(i=0;i<settingIds.length;i++){e=byId(settingIds[i]);if(e)o.values[settingIds[i]]=String(e.value||'');}
    for(i=0;i<checkIds.length;i++){e=byId(checkIds[i]);if(e)o.checks[checkIds[i]]=!!e.checked;}
    return o;
  }
  function applySettings(o){
    if(!o)return;var k,e;
    for(k in o.values){if(o.values.hasOwnProperty(k)){e=byId(k);if(e){e.value=o.values[k];fire(e,'input');fire(e,'change');}}}
    for(k in o.checks){if(o.checks.hasOwnProperty(k)){e=byId(k);if(e){e.checked=!!o.checks[k];fire(e,'change');}}}
    setTimeout(function(){click('localPreviewBtn');},80);
  }
  function saveRecent(){storeSet(STORE_RECENT,captureSettings());}

  function isOnline(){var d=byId('connectionDot');return !!(d&&(' '+d.className+' ').indexOf(' online ')>=0);}
  function sourceCount(){var n=count('#sourceList .source-card');if(n)return n;var l=byId('sourceList');if(!l)return 0;return count('#sourceList [data-index]');}
  function previewCount(){var v=parseInt(trim(txt(byId('previewCount'))),10);return isNaN(v)?0:v;}
  function vdpRecordCount(){var e=byId('vdpRecordCount'),n=e?parseInt(e.value,10):0;return isNaN(n)?0:n;}
  function vdpMappingCount(){return count('#vdpMappings .vdp-map-row');}
  function vdpMappedFields(){var rows=qsa('#vdpMappings .vdp-map-row'),ok=0,i,s;for(i=0;i<rows.length;i++){s=rows[i].querySelector?rows[i].querySelector('.vdp-field'):null;if(s&&trim(s.value))ok++;}return ok;}

  function runPreflight(){
    var a=[],pw=num('paperW',0),ph=num('paperH',0),m=num('margin',0),head=num('header',0),gx=num('gapX',0),gy=num('gapY',0),bleed=num('linkBleed',0),sc=sourceCount(),pc=previewCount(),out=trim(val('outputPath')),pon=trim(val('ponPath'));
    function item(level,title,detail){a.push({level:level,title:title,detail:detail});}
    item(isOnline()?'ok':'error','Kết nối Illustrator',isOnline()?'Illustrator đang Online.':'Chưa kết nối Illustrator; không thể Preview/Build sản xuất.');
    item(sc>0?'ok':'error','Nguồn in',sc>0?('Đã có '+sc+' nguồn/artboard cần dàn.'):'Chưa có nguồn in hoặc kích thước thủ công.');
    item(pw>0&&ph>0?'ok':'error','Khổ in',pw>0&&ph>0?(pw+' × '+ph+' mm'):'Rộng/Cao khổ phải lớn hơn 0.');
    item(m>=0&&pw>2*m&&ph>2*m?'ok':'error','Lề cứng',m>=0&&pw>2*m&&ph>2*m?('Lề '+m+' mm nằm trong khổ.'):'Lề đang lớn hơn vùng in khả dụng.');
    item(head>=0&&head<ph-2*m?'ok':'error','Vùng tiêu đề',head>=0&&head<ph-2*m?('Vùng tên file '+head+' mm.'):'Vùng tiêu đề không còn đủ chiều cao làm việc.');
    item(gx>=0&&gy>=0?'ok':'error','Khoảng cách',gx>=0&&gy>=0?('Gap ngang '+gx+' mm · dọc '+gy+' mm.'):'Gap không được âm.');
    item(bleed>=0?'ok':'error','Bleed',bleed>=0?('Bleed trong Link '+bleed+' mm.'):'Bleed không được âm.');
    item(pc>0?'ok':'warn','Layout đã tính',pc>0?('Layout hiện tại '+pc+' con/tờ.'):'Chưa Tính nhanh; nên khóa layout trước khi xuất.');
    item(out?'ok':'error','Thư mục đầu ra',out?out:'Chưa chọn thư mục xuất.');
    if(!checked('autoPon'))item(pon?'ok':'warn','PON',pon?'Đã chọn PON file.':'Auto PON đang tắt nhưng chưa chọn file PON.'); else item('ok','PON','Auto PON đang bật.');
    if(checked('duplexMode'))item(sc===2?'ok':'error','In 2 mặt A/B',sc===2?'Đúng 2 nguồn/artboard A/B.':('Đang có '+sc+' nguồn; Duplex yêu cầu đúng 2 artboard.'));
    if(checked('finishCropMarks'))item(num('finishMarkLength',0)>0?'ok':'error','CATTP',num('finishMarkLength',0)>0?('Dài '+num('finishMarkLength',0)+' mm · cách '+num('finishMarkGap',0)+' mm.'):'Chiều dài PON cắt phải > 0.');
    var vr=vdpRecordCount(),vm=vdpMappingCount(),vf=vdpMappedFields();
    if(vr>0||vm>0){
      item(vr>0?'ok':'error','VDP dữ liệu',vr>0?(vr+' record đã nạp.'):'Chưa có record VDP.');
      item(vm>0&&vf===vm?'ok':(vm>0?'warn':'error'),'VDP mapping',vm>0?(vf+'/'+vm+' kênh đã chọn cột dữ liệu.'):'Chưa có kênh biến đổi.');
      item(trim(val('vdpOutputPath'))?'ok':'warn','VDP đầu ra',trim(val('vdpOutputPath'))?trim(val('vdpOutputPath')):'Chưa chọn thư mục VDP.');
    }
    var s={ok:0,warn:0,error:0,items:a};var i;for(i=0;i<a.length;i++)s[a[i].level]++;
    return s;
  }
  function preflightMessage(s){if(s.error)return s.error+' lỗi cần sửa · '+s.warn+' cảnh báo';if(s.warn)return 'Sẵn sàng có '+s.warn+' cảnh báo';return 'Sẵn sàng sản xuất · tất cả kiểm tra đạt';}
  function updateSafety(s){
    var box=byId('dpvSafetyStrip'),lab=byId('dpvSafetyLabel');if(!box||!lab)return;s=s||runPreflight();
    rem(box,'ok');rem(box,'warn');rem(box,'error');add(box,s.error?'error':(s.warn?'warn':'ok'));lab.innerHTML=esc(preflightMessage(s));
  }
  function renderPreflight(){
    var s=runPreflight(),sum=byId('dpvPreflightSummary'),list=byId('dpvPreflightList');if(!sum||!list)return;
    sum.innerHTML='<div class="dpv-pro-stat ok"><label>ĐẠT</label><strong>'+s.ok+'</strong></div><div class="dpv-pro-stat warn"><label>CẢNH BÁO</label><strong>'+s.warn+'</strong></div><div class="dpv-pro-stat error"><label>LỖI</label><strong>'+s.error+'</strong></div><div class="dpv-pro-stat"><label>LAYOUT</label><strong>'+previewCount()+'</strong></div>';
    var h='',i,x,ic;for(i=0;i<s.items.length;i++){x=s.items[i];ic=x.level==='ok'?'✓':(x.level==='warn'?'!':'×');h+='<div class="dpv-check-row '+x.level+'"><span class="dpv-check-icon">'+ic+'</span><div class="dpv-check-copy"><strong>'+esc(x.title)+'</strong><small>'+esc(x.detail)+'</small></div></div>';}
    list.innerHTML=h;updateSafety(s);
  }

  function getPresets(){var p=storeGet(STORE_PRESETS,[]);return p&&p.length!=null?p:[];}
  function renderPresets(){
    var list=byId('dpvPresetList');if(!list)return;var p=getPresets(),h='',i;if(!p.length){list.innerHTML='<div class="dpv-check-row"><div class="dpv-check-copy"><strong>Chưa có preset</strong><small>Lưu bộ thông số dàn đang dùng để gọi lại trong 1 click. File nguồn/PON/output không được lưu để tránh đường dẫn cũ.</small></div></div>';return;}
    for(i=0;i<p.length;i++)h+='<div class="dpv-preset-row" data-preset-index="'+i+'"><div class="dpv-preset-main"><strong>'+esc(p[i].name)+'</strong><small>'+esc(p[i].note||'Thông số dàn DPV')+'</small></div><div class="dpv-preset-actions"><button data-preset-apply="'+i+'">Áp dụng</button><button data-preset-delete="'+i+'">Xóa</button></div></div>';
    list.innerHTML=h;var btns=qsa('[data-preset-apply]'),j;for(j=0;j<btns.length;j++)btns[j].onclick=function(){var idx=parseInt(this.getAttribute('data-preset-apply'),10),arr=getPresets();if(arr[idx]){applySettings(arr[idx].data);showToast('Đã áp dụng preset: '+arr[idx].name);closePro();}};
    btns=qsa('[data-preset-delete]');for(j=0;j<btns.length;j++)btns[j].onclick=function(){var idx=parseInt(this.getAttribute('data-preset-delete'),10),arr=getPresets();if(idx>=0&&idx<arr.length){arr.splice(idx,1);storeSet(STORE_PRESETS,arr);renderPresets();}};
  }
  function savePreset(){var n=trim(val('dpvPresetName'));if(!n){showToast('Nhập tên preset trước.');return;}var p=getPresets(),i;for(i=p.length-1;i>=0;i--)if(String(p[i].name).toLowerCase()===n.toLowerCase())p.splice(i,1);p.unshift({name:n,note:'Khổ '+val('paperW')+'×'+val('paperH')+' · Gap '+val('gapX')+'/'+val('gapY')+' · Lề '+val('margin'),data:captureSettings()});if(p.length>20)p.length=20;storeSet(STORE_PRESETS,p);byId('dpvPresetName').value='';renderPresets();showToast('Đã lưu preset '+n);}

  function getJobs(){var a=storeGet(STORE_JOBS,[]);return a&&a.length!=null?a:[];}
  function saveJobs(a){if(a.length>MAX_JOBS)a.length=MAX_JOBS;storeSet(STORE_JOBS,a);}
  function addJob(type,label){var a=getJobs(),ts=new Date().getTime(),j={id:ts,type:type,label:label,start:nowFull(),tsStart:ts,state:'running',detail:'Đã gửi lệnh.'};a.unshift(j);saveJobs(a);jobState.active=j;jobState.lastMain=trim(txt(byId('status')));jobState.lastVdp=trim(txt(byId('vdpStatus')));renderJobs();}
  function finishJob(state,detail){if(!jobState.active)return;var a=getJobs(),i,now=new Date().getTime();for(i=0;i<a.length;i++)if(a[i].id===jobState.active.id){a[i].state=state;a[i].detail=detail||a[i].detail;a[i].end=nowFull();a[i].tsEnd=now;a[i].durationMs=Math.max(0,now-(a[i].tsStart||a[i].id||now));break;}saveJobs(a);jobState.active=null;renderJobs();}
  function classifyStatus(s,el){var t=String(s||'').toLowerCase(),cn=el?String(el.className||'').toLowerCase():'';if(!t)return'';if(cn.indexOf('error')>=0||t.indexOf('lỗi')>=0||t.indexOf('error')>=0||t.indexOf('failed')>=0||t.indexOf('không thể')>=0||t.indexOf('không đọc')>=0||t.indexOf('chưa chọn')>=0||t.indexOf('chưa có')>=0)return'error';if(t.indexOf('hoàn tất')>=0||t.indexOf('đã xuất')>=0||t.indexOf('đã tính')>=0||t.indexOf('đã xác nhận')>=0||t.indexOf('đã mở')>=0||t.indexOf('complete')>=0||t.indexOf('thành công')>=0)return'done';return'info';}
  function renderJobs(){
    var live=byId('dpvLiveJob'),list=byId('dpvJobList');if(!live||!list)return;var a=getJobs(),h='',i,j;
    if(jobState.active)live.innerHTML='<strong>'+esc(jobState.active.label)+'</strong><small>'+esc(jobState.active.detail||'Đang chờ phản hồi từ engine...')+'</small><div class="dpv-live-bar"><i></i></div>';else live.innerHTML='<strong>Không có tác vụ đang chạy</strong><small>DPV sẽ ghi lịch sử Tính nhanh, Preview, Build, VDP và Combine tại đây.</small>';
    if(!a.length){list.innerHTML='<div class="dpv-check-row"><div class="dpv-check-copy"><strong>Chưa có lịch sử</strong><small>Thực hiện một tác vụ để bắt đầu ghi nhật ký.</small></div></div>';return;}
    for(i=0;i<a.length;i++){j=a[i];h+='<div class="dpv-job-row"><div class="dpv-job-main"><strong>'+esc(j.label)+'</strong><small>'+esc(j.start+(j.end?' → '+j.end:'')+(j.durationMs!=null?' · '+(j.durationMs<1000?j.durationMs+' ms':(Math.round(j.durationMs/100)/10)+' s'):'')+' · '+(j.detail||''))+'</small></div><span class="dpv-job-state '+esc(j.state||'info')+'">'+esc(j.state==='running'?'ĐANG CHẠY':(j.state==='done'?'HOÀN TẤT':(j.state==='error'?'LỖI':'THÔNG TIN')))+'</span></div>';}
    list.innerHTML=h;
  }
  function monitorStatuses(){
    var m=trim(txt(byId('status'))),v=trim(txt(byId('vdpStatus'))),s,cl;
    if(m&&m!==jobState.lastMain){jobState.lastMain=m;if(jobState.active){jobState.active.detail=m;cl=classifyStatus(m,byId('status'));if(cl==='done'||cl==='error')finishJob(cl,m);else renderJobs();}}
    if(v&&v!==jobState.lastVdp){jobState.lastVdp=v;if(jobState.active){jobState.active.detail=v;cl=classifyStatus(v,byId('vdpStatus'));if(cl==='done'||cl==='error')finishJob(cl,v);else renderJobs();}}
  }
  function bindStatusMonitor(){
    var els=[byId('status'),byId('vdpStatus')],i,el;
    if(window.MutationObserver){for(i=0;i<els.length;i++){el=els[i];if(el){(function(node){var ob=new MutationObserver(function(){monitorStatuses();});ob.observe(node,{childList:true,characterData:true,subtree:true,attributes:true,attributeFilter:['class']});})(el);}}}
    else if(document.addEventListener){for(i=0;i<els.length;i++){el=els[i];if(el)el.addEventListener('DOMSubtreeModified',monitorStatuses,false);}}
    else if(document.attachEvent){for(i=0;i<els.length;i++){el=els[i];if(el)el.attachEvent('onpropertychange',monitorStatuses);}}
    monitorStatuses();
  }
  function bindJobButton(id,type,label,save){var e=byId(id);if(!e)return;var fn=function(){if(save)saveRecent();addJob(type,label);};if(e.addEventListener)e.addEventListener('click',fn,false);else if(e.attachEvent)e.attachEvent('onclick',fn);}

  function diagData(){
    var perf=getPerf();return[
      ['Phiên bản UI',VERSION],['Core layout','V101 STABLE + Mixed Rotation Safe'],['Illustrator',isOnline()?trim(txt(byId('connectionText'))):'Offline'],['Nguồn in',String(sourceCount())],['Layout',String(previewCount())+' con/tờ'],['Khổ',val('paperW')+' × '+val('paperH')+' mm'],['Gap',val('gapX')+' / '+val('gapY')+' mm'],['Output',trim(val('outputPath'))||'Chưa chọn'],['VDP record',String(vdpRecordCount())],['VDP mapping',String(vdpMappingCount())],['UI performance',perf],['Theme',document.body.className.indexOf('dpv-dark')>=0?'Dark':'Light'],['Viewport',(document.documentElement.clientWidth||0)+' × '+(document.documentElement.clientHeight||0)],['User agent',navigator.userAgent||'']
    ];
  }
  function renderDiag(){var tb=byId('dpvDiagTable'),box=byId('dpvDiagBox');if(!tb||!box)return;var d=diagData(),h='',t='',i;for(i=0;i<d.length;i++){h+='<tr><td>'+esc(d[i][0])+'</td><td class="dpv-diag-value">'+esc(d[i][1])+'</td></tr>';t+=d[i][0]+': '+d[i][1]+'\r\n';}tb.innerHTML=h;box.value=t;renderPerf();}

  function detectWindowsLegacy(){var ua=(navigator.userAgent||'').toLowerCase();return ua.indexOf('trident')>=0||ua.indexOf('msie')>=0||ua.indexOf('windows')>=0;}
  function getPerf(){var p=storeGet(STORE_PERF,null);if(typeof p==='string')return p;if(p&&p.mode)return p.mode;return detectWindowsLegacy()?'fast':'balanced';}
  function setPerf(mode){if(mode!=='fast'&&mode!=='balanced'&&mode!=='beauty')mode='balanced';rem(document.body,'dpv-perf-fast');rem(document.body,'dpv-perf-balanced');rem(document.body,'dpv-perf-beauty');add(document.body,'dpv-perf-'+mode);storeSet(STORE_PERF,{mode:mode});renderPerf();}
  function renderPerf(){var b=qsa('.dpv-perf-choice'),p=getPerf(),i;for(i=0;i<b.length;i++){if(b[i].getAttribute('data-perf')===p)add(b[i],'active');else rem(b[i],'active');}}

  function setNavActive(name){var b=qsa('.dpv-nav-btn'),i;for(i=0;i<b.length;i++){if(b[i].getAttribute('data-nav')===name)add(b[i],'active');else rem(b[i],'active');}}
  function openPro(tab){var o=byId('dpvProOverlay');if(!o)return;add(o,'open');switchTab(tab||'preflight');if(tab==='preflight')renderPreflight();if(tab==='preset')renderPresets();if(tab==='jobs')renderJobs();if(tab==='system')renderDiag();setNavActive(tab==='preset'?'preset':tab);}
  function closePro(){var o=byId('dpvProOverlay');if(o)rem(o,'open');setNavActive('main');}
  function switchTab(tab){var ts=qsa('.dpv-pro-tab'),ps=qsa('.dpv-pro-page'),i;for(i=0;i<ts.length;i++){if(ts[i].getAttribute('data-pro-tab')===tab)add(ts[i],'active');else rem(ts[i],'active');}for(i=0;i<ps.length;i++){if(ps[i].getAttribute('data-pro-page')===tab)add(ps[i],'active');else rem(ps[i],'active');}}

  function insertProUI(){
    if(byId('dpvProOverlay'))return;
    var side=byId('dpvSidebar'),nav=side&&side.querySelector?side.querySelector('.dpv-nav'):null,settingsBtn=nav&&nav.querySelector?nav.querySelector('[data-nav="settings"]'):null,b;
    if(nav){
      b=document.createElement('button');b.className='dpv-nav-btn';b.setAttribute('data-nav','preflight');b.innerHTML='<span class="dpv-nav-icon">✓</span>Preflight';nav.insertBefore(b,settingsBtn||null);
      b=document.createElement('button');b.className='dpv-nav-btn';b.setAttribute('data-nav','jobs');b.innerHTML='<span class="dpv-nav-icon">◌</span>Trung tâm Job';nav.insertBefore(b,settingsBtn||null);
    }
    var res=qs('.result-column'),status=byId('status');if(res&&status){var strip=document.createElement('div');strip.id='dpvSafetyStrip';strip.className='dpv-safety-strip';strip.innerHTML='<div class="dpv-safety-left"><span class="dpv-safety-dot"></span><span id="dpvSafetyLabel" class="dpv-safety-label">Preflight chưa chạy</span></div><button id="dpvSafetyBtn" class="button tiny dpv-safety-btn">Kiểm tra</button>';res.insertBefore(strip,status);}
    var o=document.createElement('div');o.id='dpvProOverlay';o.className='dpv-pro-overlay';o.innerHTML=''
      +'<div class="dpv-pro-window"><div class="dpv-pro-head"><div class="dpv-pro-head-left"><span class="dpv-pro-badge">PRO</span><div><h2 class="dpv-pro-title">DPV Pro Center</h2><p class="dpv-pro-sub">Preflight · Preset · Job History · System Diagnostics · UI Performance</p></div></div><button id="dpvProClose" class="dpv-pro-close">×</button></div>'
      +'<div class="dpv-pro-tabs"><button class="dpv-pro-tab active" data-pro-tab="preflight">Preflight</button><button class="dpv-pro-tab" data-pro-tab="preset">Preset</button><button class="dpv-pro-tab" data-pro-tab="jobs">Job Center</button><button class="dpv-pro-tab" data-pro-tab="system">System</button></div>'
      +'<div class="dpv-pro-body">'
      +'<section class="dpv-pro-page active" data-pro-page="preflight"><div id="dpvPreflightSummary" class="dpv-pro-summary"></div><div class="dpv-pro-grid"><div class="dpv-pro-card"><h3>Preflight sản xuất</h3><p>Kiểm tra trạng thái nguồn, khổ/lề/gap, layout, PON/CATTP, Duplex và VDP trước khi xuất. Đây là kiểm tra không phá file và không thay Core V101.</p><div id="dpvPreflightList" class="dpv-preflight-list"></div><div class="dpv-pro-toolbar"><button id="dpvPreflightRun" class="button primary">Chạy lại</button><button id="dpvPreflightCalc" class="button">Tính nhanh bố cục</button><button id="dpvPreflightOutput" class="button">Chọn đầu ra</button></div></div><div class="dpv-pro-card"><h3>Quy tắc an toàn</h3><p><strong>Không tự sửa file Illustrator.</strong> Preflight chỉ báo lỗi/cảnh báo. Các chức năng Build/VDP vẫn dùng nguyên pipeline đã ổn định.</p><p>Khuyến nghị trước job lớn: Preflight → Tính nhanh → Preview 1 record → chạy batch.</p></div></div></section>'
      +'<section class="dpv-pro-page" data-pro-page="preset"><div class="dpv-pro-grid"><div class="dpv-pro-card"><h3>Thư viện preset dàn</h3><p>Lưu khổ, lề, gap, bleed, rotate, Exact Gap, PON/CATTP, Duplex và các thông số sản xuất. Không lưu đường dẫn file để tránh mở nhầm job cũ.</p><div class="dpv-pro-toolbar"><input id="dpvPresetName" class="dpv-pro-name" type="text" placeholder="Tên preset, ví dụ Tem 54x81 - 320x390"><button id="dpvPresetSave" class="button primary">Lưu hiện tại</button><button id="dpvPresetRestore" class="button">Khôi phục lần gần nhất</button></div><div id="dpvPresetList" class="dpv-preset-list"></div></div></div></section>'
      +'<section class="dpv-pro-page" data-pro-page="jobs"><div class="dpv-pro-grid"><div class="dpv-pro-card"><h3>Tác vụ hiện tại</h3><div id="dpvLiveJob" class="dpv-live-job"></div></div><div class="dpv-pro-card"><h3>Lịch sử thao tác</h3><p>Ghi nhẹ trên máy: Tính nhanh, Preview, Build, VDP, Combine. Không đọc/ghi artwork.</p><div class="dpv-pro-toolbar"><button id="dpvJobsClear" class="button">Xóa lịch sử</button></div><div id="dpvJobList" class="dpv-job-list"></div></div></div></section>'
      +'<section class="dpv-pro-page" data-pro-page="system"><div class="dpv-pro-grid"><div class="dpv-pro-card"><h3>Hiệu năng giao diện</h3><p>Chỉ thay hiệu ứng UI, không thay thuật toán dàn hoặc chất lượng PDF.</p><div class="dpv-perf-selector"><button class="dpv-perf-choice" data-perf="fast">Nhanh · ít hiệu ứng</button><button class="dpv-perf-choice" data-perf="balanced">Cân bằng</button><button class="dpv-perf-choice" data-perf="beauty">Đẹp · nhiều hiệu ứng</button></div><div class="dpv-pro-toolbar"><button id="dpvProTheme" class="button">Đổi Light / Dark</button></div></div><div class="dpv-pro-card"><h3>Diagnostics</h3><table class="dpv-diag-table"><tbody id="dpvDiagTable"></tbody></table><textarea id="dpvDiagBox" class="dpv-diag-box" readonly></textarea></div></div></section>'
      +'</div></div>';
    document.body.appendChild(o);

    var menu=document.createElement('div');menu.id='dpvCommandMenu';menu.className='dpv-command-menu';var sw=qs('.dpv-search-wrap');if(sw)sw.appendChild(menu);
    var set=byId('dpvSettings');if(set){var row=document.createElement('div');row.className='dpv-settings-row';row.innerHTML='<span>Pro Center</span><button id="dpvOpenProSettings" class="button tiny">Mở hệ thống</button>';set.appendChild(row);}
  }

  var commands=[
    {name:'Dàn file',keys:'dan file main',run:function(){var p=byId('vdpPanel');if(p)add(p,'hidden');setNavActive('main');}},
    {name:'Biến đổi dữ liệu VDP',keys:'vdp bien doi du lieu',run:function(){click('vdpOpenBtn');setNavActive('vdp');}},
    {name:'Tính nhanh trên DPV',keys:'tinh nhanh layout preview',run:function(){click('localPreviewBtn');}},
    {name:'Đối chiếu bằng Illustrator',keys:'illustrator preview doi chieu',run:function(){click('hostPreviewBtn');}},
    {name:'View khuôn trực tiếp qua Illustrator',keys:'view khuon die preview',run:function(){click('diePreviewBtn');}},
    {name:'Dàn Link & xuất IN/KHUÔN',keys:'build xuat in khuon dan link',run:function(){click('buildBtn');}},
    {name:'Chọn PON',keys:'pon file',run:function(){click('ponBtn');}},
    {name:'Chọn thư mục đầu ra',keys:'output thu muc xuat',run:function(){click('outputBtn');}},
    {name:'Preflight sản xuất',keys:'preflight kiem tra loi',run:function(){openPro('preflight');}},
    {name:'Thư viện preset',keys:'preset thu vien thong so',run:function(){openPro('preset');}},
    {name:'Trung tâm Job',keys:'job history lich su',run:function(){openPro('jobs');}},
    {name:'Diagnostics & hiệu năng',keys:'system diagnostics hieu nang',run:function(){openPro('system');}},
    {name:'Đổi Light / Dark',keys:'theme dark light giao dien',run:function(){var b=byId('dpvThemeSwitch');if(b)click('dpvThemeSwitch');}}
  ];
  function filteredCommands(q){q=trim(q).toLowerCase();var a=[],i,c,s;for(i=0;i<commands.length;i++){c=commands[i];s=(c.name+' '+c.keys).toLowerCase();if(!q||s.indexOf(q)>=0)a.push(c);}return a;}
  function renderCommands(){var inp=byId('dpvSearch'),m=byId('dpvCommandMenu');if(!inp||!m)return;var a=filteredCommands(inp.value),h='',i;for(i=0;i<a.length&&i<9;i++)h+='<button class="dpv-command-item'+(i===0?' selected':'')+'" data-command-index="'+commands.indexOf(a[i])+'"><span>'+esc(a[i].name)+'</span><small>Enter</small></button>';m.innerHTML=h;if(a.length)add(m,'open');else rem(m,'open');var b=qsa('.dpv-command-item'),j;for(j=0;j<b.length;j++)b[j].onclick=function(){var idx=parseInt(this.getAttribute('data-command-index'),10);rem(m,'open');inp.value='';if(commands[idx])commands[idx].run();};}
  function bindCommandPalette(){var inp=byId('dpvSearch'),m=byId('dpvCommandMenu');if(!inp||!m)return;inp.placeholder='Tìm lệnh: VDP, Preflight, PON, Preset...';inp.onfocus=function(){renderCommands();};inp.oninput=function(){renderCommands();};inp.onkeydown=function(e){e=e||window.event;if(e.keyCode===27){rem(m,'open');inp.blur();return;}if(e.keyCode===13){var a=filteredCommands(inp.value);if(a.length){rem(m,'open');inp.value='';a[0].run();try{e.preventDefault();}catch(x){}return false;}}};inp.onblur=function(){setTimeout(function(){rem(m,'open');},180);};}

  function bindUI(){
    var tabs=qsa('.dpv-pro-tab'),i;for(i=0;i<tabs.length;i++)tabs[i].onclick=function(){var t=this.getAttribute('data-pro-tab');switchTab(t);if(t==='preflight')renderPreflight();if(t==='preset')renderPresets();if(t==='jobs')renderJobs();if(t==='system')renderDiag();};
    if(byId('dpvProClose'))byId('dpvProClose').onclick=closePro;if(byId('dpvSafetyBtn'))byId('dpvSafetyBtn').onclick=function(){openPro('preflight');};
    if(byId('dpvPreflightRun'))byId('dpvPreflightRun').onclick=renderPreflight;if(byId('dpvPreflightCalc'))byId('dpvPreflightCalc').onclick=function(){click('localPreviewBtn');setTimeout(renderPreflight,220);};if(byId('dpvPreflightOutput'))byId('dpvPreflightOutput').onclick=function(){click('outputBtn');};
    if(byId('dpvPresetSave'))byId('dpvPresetSave').onclick=savePreset;if(byId('dpvPresetRestore'))byId('dpvPresetRestore').onclick=function(){var r=storeGet(STORE_RECENT,null);if(r){applySettings(r);showToast('Đã khôi phục thông số gần nhất.');closePro();}else showToast('Chưa có thông số gần nhất.');};
    if(byId('dpvJobsClear'))byId('dpvJobsClear').onclick=function(){storeSet(STORE_JOBS,[]);jobState.active=null;renderJobs();};
    var perf=qsa('.dpv-perf-choice');for(i=0;i<perf.length;i++)perf[i].onclick=function(){setPerf(this.getAttribute('data-perf'));renderDiag();};
    if(byId('dpvProTheme'))byId('dpvProTheme').onclick=function(){click('dpvThemeSwitch');setTimeout(renderDiag,80);};if(byId('dpvOpenProSettings'))byId('dpvOpenProSettings').onclick=function(){var s=byId('dpvSettings');if(s)rem(s,'open');openPro('system');};
    var presetNav=qs('.dpv-nav-btn[data-nav="preset"]'),preNav=qs('.dpv-nav-btn[data-nav="preflight"]'),jobNav=qs('.dpv-nav-btn[data-nav="jobs"]');if(presetNav)presetNav.onclick=function(){openPro('preset');};if(preNav)preNav.onclick=function(){openPro('preflight');};if(jobNav)jobNav.onclick=function(){openPro('jobs');};
    var ov=byId('dpvProOverlay');if(ov)ov.onclick=function(e){e=e||window.event;if((e.target||e.srcElement)===ov)closePro();};
    bindCommandPalette();
    bindJobButton('localPreviewBtn','layout','Tính nhanh bố cục',true);bindJobButton('hostPreviewBtn','preview','Đối chiếu Illustrator',false);bindJobButton('diePreviewBtn','die','View khuôn Illustrator',false);bindJobButton('buildBtn','build','Dàn Link & xuất IN/KHUÔN',true);bindJobButton('vdpBuildBtn','vdp','VDP / VDP Sheet',false);bindJobButton('vdpCombineExistingBtn','combine','Combine PDF',false);
  }

  function updateVersion(){var v=qs('.version-badge');if(v)v.innerHTML='V140 PERFORMANCE · CORE V101 STABLE';var b=qs('.beta-note');if(b)b.innerHTML='<strong>DPV® V140 Performance Foundation · Core V101 Stable</strong><br>Release Bundle · Job Monitor event-driven · Diagnostics · Ctrl+K Command Palette. Không thay engine dàn, VDP, PON, Duplex hay Bridge Illustrator.';var card=qs('.dpv-side-card');if(card)card.innerHTML='<strong><span class="dpv-side-dot"></span>Core V101 STABLE</strong>Engine sản xuất được giữ nguyên.<br>V140 tối ưu runtime + UI.';}
  function start(){insertProUI();add(document.body,'dpv-pro-polish');setPerf(getPerf());updateVersion();bindUI();bindStatusMonitor();renderPreflight();renderPresets();renderJobs();renderDiag();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',function(){setTimeout(start,30);},false);else window.attachEvent('onload',function(){setTimeout(start,30);});}else setTimeout(start,30);
})();
