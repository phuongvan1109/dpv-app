(function(){
  "use strict";
  function byId(id){ return document.getElementById(id); }
  function setText(el,v){ if(!el)return; if('textContent' in el)el.textContent=v; else el.innerText=v; }
  function addLog(msg){
    var box=byId('log'); if(!box)return;
    var d=new Date(), z=function(n){return (n<10?'0':'')+n;};
    var row=document.createElement('div'); row.className='log-line';
    setText(row,'['+z(d.getHours())+':'+z(d.getMinutes())+':'+z(d.getSeconds())+'] '+msg);
    box.appendChild(row); box.scrollTop=box.scrollHeight;
  }
  function showStatus(msg,kind){
    var s=byId('status'); if(s){s.className='status '+(kind||'');setText(s,msg);} addLog(msg);
    var t=byId('dpvToast'); if(t){setText(t,msg); if((' '+t.className+' ').indexOf(' show ')<0)t.className+=' show'; setTimeout(function(){t.className=(' '+t.className+' ').replace(' show ',' ').replace(/^\s+|\s+$/g,'');},1800);}
  }
  function callNative(method,args,done,fail){
    args=args||[];
    try{
      if(window.DPVNative && typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke(method,args).then(function(v){done(v);}).catch(function(e){fail((e&&e.message)||String(e));});
        return;
      }
      if(window.external && typeof window.external[method] !== 'undefined'){
        var v;
        if(args.length===0)v=window.external[method]();
        else if(args.length===1)v=window.external[method](args[0]);
        else if(args.length===2)v=window.external[method](args[0],args[1]);
        else throw new Error('Quá nhiều tham số Bridge.');
        done(v); return;
      }
      fail('DPV Bridge chưa sẵn sàng.');
    }catch(e){fail((e&&e.message)||String(e));}
  }
  function bindPonPicker(){
    var old=byId('ponBtn'); if(!old||!old.parentNode)return;
    /* Replace the node to remove any older click/ripple handlers attached by cached UI layers. */
    var btn=old.cloneNode(true); btn.id='ponBtn'; btn.className=(btn.className||'')+' dpv-native-dialog-button';
    old.parentNode.replaceChild(btn,old);
    btn.onclick=function(ev){
      ev=ev||window.event; try{if(ev.preventDefault)ev.preventDefault();}catch(x){}
      if(btn.disabled)return false;
      btn.disabled=true; setText(btn,'Đang mở...');
      callNative('ChoosePonFile',[],function(path){
        btn.disabled=false; setText(btn,'Chọn PON');
        path=String(path||'');
        if(path){var p=byId('ponPath'); if(p){p.value=path; try{var e=document.createEvent('HTMLEvents');e.initEvent('change',true,false);p.dispatchEvent(e);}catch(x){}} showStatus('Đã chọn file PON.','ok');}
        else showStatus('Đã hủy chọn PON.','');
      },function(err){btn.disabled=false;setText(btn,'Chọn PON');showStatus('Không mở được hộp thoại PON: '+err,'error');});
      return false;
    };
  }
  function markVersion(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)setText(v,'V108 ICON · PON HOTFIX · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V108 ICON · PON HOTFIX · CORE V101 STABLE</strong><br>Sửa nút Chọn PON trên Windows + Mac Intel · không thay engine dàn V101.';
  }
  function start(){bindPonPicker();markVersion();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();
