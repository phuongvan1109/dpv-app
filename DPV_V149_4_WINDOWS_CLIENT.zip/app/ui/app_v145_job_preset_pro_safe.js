/* DPV V145 — JOB PRESET PRO SAFE ADD-ON
   Additive-only rules:
   - Does NOT override Core V101, Bridge, VDP, Cut & Stack, Duplex, Recovery or Production Planner handlers.
   - Keeps legacy DPV preset library untouched.
   - Never stores source/data/PON/output paths.
   - Applies saved values only after an explicit user click.
*/
(function () {
  'use strict';
  var STORE='dpv.v145.jobPresetPro.safe';
  var MAX=30, booted=false, retry=0, pendingVDP=null;
  var GROUPS={
    layout:['paperW','paperH','margin','header','gapX','gapY','maxQty','linkBleed','allowRotate','uniformGap','trueShape','specialStagger','fastMode','addTitle','cornerSafe','demiMode','preservePrintColor','angleStep','cornerZone','demiExtend'],
    finish:['autoPon','fitPon','ponProcessBlack','dieAsLink','cornerPonRed','finishCropMarks','finishMarkLength','finishMarkGap'],
    duplex:['duplexMode','duplexFlip'],
    planner:['v144TargetQty','v144WastePct','v144SheetCost','v144PrintCost','v144SetupCost'],
    vdp:['vdpFileNameField','vdpFilePrefix','vdpExportIndividual','vdpCombinePdf','vdpCombinedName','vdpSheetOrder','vdpLastSheetMode','vdpSheetKeepRecords','vdpSheetCombine','vdpSheetPrefix','vdpSheetCombinedName','vdpSheetUsePon','v1421NameTemplate']
  };
  var NEVER_SAVE={ponPath:1,outputPath:1,vdpOutputPath:1};
  function $(id){return document.getElementById(id);}
  function q(sel,root){return (root||document).querySelector?(root||document).querySelector(sel):null;}
  function qa(sel,root){return (root||document).querySelectorAll?(root||document).querySelectorAll(sel):[];}
  function trim(s){return String(s==null?'':s).replace(/^\s+|\s+$/g,'');}
  function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function now(){return new Date().getTime();}
  function fire(el,type){if(!el)return;try{var ev=document.createEvent('HTMLEvents');ev.initEvent(type,true,false);el.dispatchEvent(ev);}catch(e){try{el.fireEvent('on'+type);}catch(x){}}}
  function storeGet(){try{var r=window.localStorage?localStorage.getItem(STORE):null;var a=r?JSON.parse(r):[];return a&&a.length!=null?a:[];}catch(e){return [];}}
  function storeSet(a){try{if(window.localStorage){localStorage.setItem(STORE,JSON.stringify(a));return true;}}catch(e){}return false;}
  function getValue(id){var e=$(id);if(!e||NEVER_SAVE[id])return null;var t=String(e.type||'').toLowerCase();if(t==='checkbox'||t==='radio')return {kind:'checked',value:!!e.checked};return {kind:'value',value:String(e.value==null?'':e.value)};}
  function setValue(id,obj){var e=$(id);if(!e||!obj||NEVER_SAVE[id])return false;try{if(obj.kind==='checked')e.checked=!!obj.value;else e.value=String(obj.value==null?'':obj.value);fire(e,'change');fire(e,'input');return true;}catch(x){return false;}}
  function captureGroup(name){var ids=GROUPS[name]||[],o={},i,v;for(i=0;i<ids.length;i++){v=getValue(ids[i]);if(v)o[ids[i]]=v;}return o;}
  function capture(){return {schema:145,createdAt:now(),groups:{layout:captureGroup('layout'),finish:captureGroup('finish'),duplex:captureGroup('duplex'),planner:captureGroup('planner'),vdp:captureGroup('vdp')}};}
  function applyGroup(o){var k,n=0;if(!o)return 0;for(k in o){if(Object.prototype.hasOwnProperty.call(o,k)&&setValue(k,o[k]))n++;}return n;}
  function applyPresetData(data){var n=0,g=data&&data.groups?data.groups:{};n+=applyGroup(g.layout);n+=applyGroup(g.finish);n+=applyGroup(g.duplex);n+=applyGroup(g.planner);pendingVDP=g.vdp||null;n+=applyGroup(g.vdp);try{if(window.DPVProductionPlannerV144&&window.DPVProductionPlannerV144.recalc)window.setTimeout(window.DPVProductionPlannerV144.recalc,100);}catch(e){}var b=$('localPreviewBtn');if(b)window.setTimeout(function(){try{b.click();}catch(x){}},180);return n;}
  function summary(data){var g=data&&data.groups?data.groups:{},L=g.layout||{},D=g.duplex||{},P=g.planner||{},V=g.vdp||{};function v(o,k,d){return o[k]?o[k].value:d;}var a=[];a.push('Khổ '+v(L,'paperW','?')+'×'+v(L,'paperH','?'));a.push('Gap '+v(L,'gapX','?')+'/'+v(L,'gapY','?'));a.push('Lề '+v(L,'margin','?'));if(D.duplexMode&&D.duplexMode.value)a.push('Duplex');if(P.v144TargetQty&&Number(P.v144TargetQty.value)>0)a.push('SL '+P.v144TargetQty.value);if(V.vdpFilePrefix&&trim(V.vdpFilePrefix.value))a.push('VDP '+V.vdpFilePrefix.value);return a.join(' · ');}
  function formatDate(ms){try{var d=new Date(ms||0);return ('0'+d.getDate()).slice(-2)+'/'+('0'+(d.getMonth()+1)).slice(-2)+' '+('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2);}catch(e){return '';}}
  function toast(s,type){var e=$('v145Msg');if(!e)return;e.className='v145-msg '+(type||'');if('textContent' in e)e.textContent=s;else e.innerText=s;}
  function render(){var host=$('v145List');if(!host)return;var a=storeGet(),h='',i,p;if(!a.length){host.innerHTML='<div class="v145-empty">Chưa có Job Preset Pro. Nhập tên rồi bấm <b>Lưu job hiện tại</b>.</div>';return;}for(i=0;i<a.length;i++){p=a[i];h+='<div class="v145-row"><div class="v145-main"><div><b>'+esc(p.name||('Job '+(i+1)))+'</b>'+(p.favorite?'<span class="v145-star">★</span>':'')+'</div><small>'+esc(summary(p.data))+'</small><em>'+esc(formatDate(p.updatedAt||p.createdAt))+'</em></div><div class="v145-actions"><button data-v145-apply="'+i+'" class="primary">Áp dụng</button><button data-v145-fav="'+i+'">'+(p.favorite?'Bỏ ★':'★')+'</button><button data-v145-copy="'+i+'">Copy JSON</button><button data-v145-del="'+i+'" class="danger">Xóa</button></div></div>';}
host.innerHTML=h;bindRows();}
  function saveCurrent(){var name=trim(($('v145Name')||{}).value||'');if(!name){toast('Nhập tên job preset trước.','warn');return;}var a=storeGet(),i,old=null;for(i=0;i<a.length;i++){if(String(a[i].name||'').toLowerCase()===name.toLowerCase()){old=a.splice(i,1)[0];break;}}var t=now(),p={name:name,createdAt:old?old.createdAt:t,updatedAt:t,favorite:old?!!old.favorite:false,data:capture()};a.unshift(p);a.sort(function(x,y){if(!!x.favorite!==!!y.favorite)return x.favorite?-1:1;return (y.updatedAt||0)-(x.updatedAt||0);});if(a.length>MAX)a.length=MAX;storeSet(a);$('v145Name').value='';render();toast('Đã lưu Job Preset Pro “'+name+'”. Không lưu đường dẫn file/PON/output.','ok');}
  function applyIndex(i){var a=storeGet(),p=a[i];if(!p)return;var n=applyPresetData(p.data);p.updatedAt=now();a.splice(i,1);a.unshift(p);storeSet(a);render();toast('Đã áp dụng '+n+' thiết lập từ “'+p.name+'”. Hãy kiểm tra Preview trước khi Build.','ok');}
  function deleteIndex(i){var a=storeGet(),p=a[i];if(!p)return;if(!window.confirm('Xóa Job Preset Pro “'+p.name+'”?'))return;a.splice(i,1);storeSet(a);render();toast('Đã xóa preset.','ok');}
  function favIndex(i){var a=storeGet(),p=a[i];if(!p)return;p.favorite=!p.favorite;p.updatedAt=now();a.sort(function(x,y){if(!!x.favorite!==!!y.favorite)return x.favorite?-1:1;return (y.updatedAt||0)-(x.updatedAt||0);});storeSet(a);render();}
  function fallbackCopy(s){var ta=document.createElement('textarea');ta.value=s;ta.style.position='fixed';ta.style.left='-9999px';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');toast('Đã copy preset JSON.','ok');}catch(e){toast('Không copy tự động được.','warn');}document.body.removeChild(ta);}
  function copyText(s){try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(s).then(function(){toast('Đã copy preset JSON.','ok');},function(){fallbackCopy(s);});return;}}catch(e){}fallbackCopy(s);}
  function copyIndex(i){var a=storeGet(),p=a[i];if(!p)return;copyText(JSON.stringify({dpvJobPresetPro:145,preset:p}));}
  function importJson(){var raw=window.prompt('Dán JSON Job Preset Pro V145 vào đây:','');if(!raw)return;try{var x=JSON.parse(raw),p=x&&x.preset?x.preset:x;if(!p||!p.data||!p.data.groups)throw new Error('JSON không đúng định dạng V145.');p.name=trim(p.name)||('Imported '+formatDate(now()));p.createdAt=p.createdAt||now();p.updatedAt=now();p.favorite=!!p.favorite;var a=storeGet(),i;for(i=a.length-1;i>=0;i--)if(String(a[i].name||'').toLowerCase()===String(p.name).toLowerCase())a.splice(i,1);a.unshift(p);if(a.length>MAX)a.length=MAX;storeSet(a);render();toast('Đã nhập preset “'+p.name+'”.','ok');}catch(e){toast('Không nhập được JSON: '+String(e&&e.message?e.message:e),'warn');}}
  function bindRows(){var host=$('v145List'),bs,i,b,k;if(!host)return;bs=host.getElementsByTagName('button');for(i=0;i<bs.length;i++){b=bs[i];k=b.getAttribute('data-v145-apply');if(k!==null){b.onclick=(function(n){return function(){applyIndex(n);};}(parseInt(k,10)));continue;}k=b.getAttribute('data-v145-del');if(k!==null){b.onclick=(function(n){return function(){deleteIndex(n);};}(parseInt(k,10)));continue;}k=b.getAttribute('data-v145-fav');if(k!==null){b.onclick=(function(n){return function(){favIndex(n);};}(parseInt(k,10)));continue;}k=b.getAttribute('data-v145-copy');if(k!==null)b.onclick=(function(n){return function(){copyIndex(n);};}(parseInt(k,10)));}}
  function insert(){if($('v145JobPresetPro'))return true;var page=q('[data-pro-page="preset"]');if(!page)return false;var grid=q('.dpv-pro-grid',page)||page;var card=document.createElement('div');card.id='v145JobPresetPro';card.className='dpv-pro-card v145-card';card.innerHTML=''
   +'<div class="v145-head"><div><h3>JOB PRESET PRO · V145 SAFE</h3><p>Lưu một job hoàn chỉnh: layout + finishing/PON settings + Duplex + Production Planner + VDP output settings. <b>Không lưu đường dẫn nguồn, CSV, PON hoặc output.</b></p></div><span>ADDITIVE</span></div>'
   +'<div class="v145-toolbar"><input id="v145Name" type="text" placeholder="Tên job, ví dụ Card 90x54 · 320x390 · AB"><button id="v145Save" class="button primary">Lưu job hiện tại</button><button id="v145Import" class="button">Nhập JSON</button></div>'
   +'<div class="v145-scope"><span>LAYOUT</span><span>PON/CATTP</span><span>DUPLEX</span><span>PRODUCTION</span><span>VDP OUTPUT</span><b>NO PATHS</b></div>'
   +'<div id="v145List" class="v145-list"></div><div id="v145Msg" class="v145-msg">Sẵn sàng. Preset cũ của DPV vẫn giữ nguyên ở phía trên.</div>';
   try{grid.appendChild(card);}catch(e){return false;}
   $('v145Save').onclick=saveCurrent;$('v145Import').onclick=importJson;
   var openVdp=$('vdpOpenBtn');if(openVdp&&openVdp.addEventListener){openVdp.addEventListener('click',function(){window.setTimeout(function(){if(pendingVDP){var n=applyGroup(pendingVDP);if(n)toast('Đã áp dụng thêm '+n+' thiết lập VDP của Job Preset sau khi mở VDP.','ok');}},650);},false);}
   var inp=$('v145Name');if(inp){inp.onkeydown=function(e){e=e||window.event;if(e.keyCode===13){saveCurrent();return false;}};}
   render();window.DPVJobPresetV145={version:'145',safe:true,capture:capture,applyData:applyPresetData,list:storeGet};return true;}
  function init(){if(booted)return;if(insert()){booted=true;return;}retry++;if(retry<24)window.setTimeout(init,350);}
  function boot(){window.setTimeout(init,1450);}
  if(document.readyState==='complete')boot();else if(window.addEventListener)window.addEventListener('load',boot,false);else window.attachEvent('onload',boot);
}());
