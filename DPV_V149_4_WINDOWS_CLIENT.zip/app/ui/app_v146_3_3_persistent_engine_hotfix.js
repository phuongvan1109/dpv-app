/* DPV V146.3.3 PERSISTENT ENGINE HOTFIX UI MARKER — additive only */
(function(){
  'use strict';
  function $(id){return document.getElementById(id);}
  function add(){
    var root=$('v14632BatchTypographyCard')||$('v1462CodeHotfixCard')||$('v146QrBarcodeCard');
    if(!root||$('v14633PersistentEngineBadge')) return false;
    var d=document.createElement('div');d.id='v14633PersistentEngineBadge';d.className='v14633-badge';
    d.innerHTML='<strong>V146.3.3 · PERSISTENT ENGINE FIX</strong><span>QR / Code128 / EAN-13 batch dispatcher được cài lại ở mỗi lần Bridge gọi Illustrator — không còn phụ thuộc wrapper của lần gọi trước.</span>';
    root.insertBefore(d,root.firstChild);return true;
  }
  var n=0,t=setInterval(function(){n++;if(add()||n>80)clearInterval(t);},350);
  document.addEventListener('click',function(){setTimeout(add,30);},false);
})();
