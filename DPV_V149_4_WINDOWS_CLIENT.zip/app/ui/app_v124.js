(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function text(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function status(m,k){if(window.DPVVDP101&&typeof window.DPVVDP101.status==='function')window.DPVVDP101.status(m,k||'');}
  function getCore(){
    if(!window.DPVCoreV101||typeof window.DPVCoreV101.getConfig!=='function')throw new Error('Core V101 chưa sẵn sàng.');
    var c=window.DPVCoreV101.getConfig(),l=c&&(c.precomputedLayoutV101||c.precomputedLayoutV99);
    if(!l||!l.items||!l.items.length)throw new Error('Chưa có bố cục V101. Đóng VDP → Tính nhanh trên DPV → mở VDP lại.');
    return {config:c,layout:l};
  }
  function getState(){if(!window.DPVVDP101||typeof window.DPVVDP101.getState!=='function')throw new Error('VDP Core chưa sẵn sàng.');return window.DPVVDP101.getState();}
  function addInfo(){
    var panel=$('vdpSheetPanel'),head=panel&&panel.querySelector?panel.querySelector('.v114-sheet-head'):null;
    if(!panel||!head||$('vdpSheetSyncV124'))return;
    var d=document.createElement('div');d.id='vdpSheetSyncV124';d.className='v124-sync-info';
    d.innerHTML='<strong>Đồng bộ Dàn file:</strong> đang chờ bố cục V101.';
    head.parentNode.insertBefore(d,head.nextSibling);
    var cb=$('vdpSheetUsePon');
    if(cb&&cb.parentNode){var sp=cb.parentNode.getElementsByTagName('span');if(sp&&sp.length)text(sp[0],'Giữ PON / Auto PON / tiêu đề theo Dàn file (Bleed + CATTP luôn đồng bộ)');}
  }
  function syncInfo(){
    addInfo();var d=$('vdpSheetSyncV124');if(!d)return;
    try{
      var x=getCore(),c=x.config,p=[];
      p.push('Layout '+x.layout.items.length+' con/tờ');
      p.push('Bleed '+String(Number(c.linkBleed||0))+' mm');
      p.push(c.finishCropMarks===true?'CATTP BẬT · '+String(Number(c.finishMarkLength||6))+'mm / gap '+String(Number(c.finishMarkGap||0))+'mm':'CATTP TẮT');if(c.duplexMode===true)p.push('2 MẶT A/B · '+String(c.duplexFlip||'tumble180'));
      if(c.ponPath)p.push('PON file'); else if(c.autoPon===true)p.push('Auto PON'); else p.push('PON tắt');
      d.innerHTML='<strong>Đồng bộ Dàn file:</strong> '+p.join(' · ');
    }catch(e){d.innerHTML='<strong>Đồng bộ Dàn file:</strong> '+String(e.message||e);}
  }
  function build(){
    var btn=$('vdpSheetBuildBtn');
    try{
      var st=getState();if(!st.filePath&&!(window.DPVVDP101&&window.DPVVDP101.getRecords&&window.DPVVDP101.getRecords().length))throw new Error('Chưa có dữ liệu CSV/TXT hoặc Dãy số tự động.');if(!(Number(st.recordCount)>0))throw new Error('Dữ liệu không có record.');if(!st.mappings||!st.mappings.length)throw new Error('Chưa map dữ liệu vào đối tượng Illustrator.');
      var out=$('vdpOutputPath')?$('vdpOutputPath').value:'';if(!out)throw new Error('Chưa chọn thư mục xuất PDF.');
      var x=getCore(),c=x.config,from=Math.max(1,Math.floor(Number($('vdpFrom').value)||1)),to=Math.min(Number(st.recordCount),Math.max(from,Math.floor(Number($('vdpTo').value)||Number(st.recordCount))));
      var sourceW=Number(x.layout.sourceW||((c.sources&&c.sources.length)?c.sources[0].width:0)||0),sourceH=Number(x.layout.sourceH||((c.sources&&c.sources.length)?c.sources[0].height:0)||0);
      var sc={
        paperW:Number(c.paperW),paperH:Number(c.paperH),margin:Number(c.margin),header:Number(c.header),gapX:Number(c.gapX),gapY:Number(c.gapY),
        sourceW:sourceW,sourceH:sourceH,linkBleed:Math.max(0,Number(c.linkBleed||0)),addTitle:c.addTitle===true,
        ponPath:String(c.ponPath||''),fitPon:c.fitPon===true,autoPon:c.autoPon===true,ponProcessBlack:c.ponProcessBlack===true,cornerPonRed:c.cornerPonRed===true,
        finishCropMarks:c.finishCropMarks===true,finishMarkLength:Math.max(.1,Number(c.finishMarkLength||6)),finishMarkGap:Math.max(0,Number(c.finishMarkGap||0)),
        cornerSafe:c.cornerSafe===true,cornerZone:Math.max(0,Number(c.cornerZone||0)),preservePrintColor:c.preservePrintColor!==false,
        duplexMode:c.duplexMode===true,duplexFlip:String(c.duplexFlip||'tumble180')
      };
      /* PON/title may be manually hidden in VDP, but production bleed and CATTP
         ALWAYS follow the Dàn file configuration as requested. */
      if($('vdpSheetUsePon')&&!$('vdpSheetUsePon').checked){sc.ponPath='';sc.autoPon=false;sc.addTitle=false;}
      var cfg={
        dataPath:st.filePath,records:st.filePath?[]:((window.DPVVDP101&&window.DPVVDP101.getRecords)?window.DPVVDP101.getRecords():[]),mappings:st.mappings,sourceFolder:st.sourceFolder,outputPath:out,from:from,to:to,
        fileNameField:$('vdpFileNameField').value,filePrefix:$('vdpFilePrefix').value||'VDP',exportIndividual:$('vdpSheetKeepRecords').checked===true,combinePdf:false,
        sheetMode:true,sheetLayout:x.layout,sheetConfig:sc,sheetOrder:$('vdpSheetOrder').value,lastSheetMode:$('vdpLastSheetMode').value,
        keepRecordPdfs:$('vdpSheetKeepRecords').checked===true,combineSheets:$('vdpSheetCombine').checked===true,sheetPrefix:$('vdpSheetPrefix').value||'VDP_SHEET',sheetCombinedName:$('vdpSheetCombinedName').value||'VDP_ALL_SHEETS'
      };
      if(btn){btn.disabled=true;btn.setAttribute('data-v124-running','1');}
      status('V125: Layout V101 · Bleed '+sc.linkBleed+' mm · CATTP '+(sc.finishCropMarks?'BẬT':'TẮT')+(sc.duplexMode?' · A/B 2 mặt':'')+' · '+(to-from+1)+' record…','work');
      window.DPVVDP101.bridgeCall('BuildVariableData',[JSON.stringify(cfg)]);
    }catch(e){if(btn){btn.disabled=false;btn.removeAttribute('data-v124-running');}status('Không chạy được VDP Sheet: '+String(e&&e.message?e.message:e),'error');}
    return false;
  }
  function bind(){var b=$('vdpSheetBuildBtn');if(!b)return false;b.onclick=build;b.setAttribute('data-v124-bound','1');return true;}
  function wrapReceive(){
    if(window.__V124ReceiveWrapped||typeof window.VDPRO_receive!=='function')return;window.__V124ReceiveWrapped=true;var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){old(op,payload);try{var r=JSON.parse(String(payload||'{}')),b=$('vdpSheetBuildBtn');if(op==='vdpBuild'){if(b){b.disabled=false;b.removeAttribute('data-v124-running');}if(!r.ok)status('VDP Sheet lỗi: '+String(r.error||r.message||'Không rõ lỗi Illustrator.'),'error');else if(r.sheetMode){var m='Hoàn tất VDP Sheet: '+String(r.count||0)+' record → '+String(r.sheetCount||0)+' tờ';if(r.sheetCombinedFile)m+=' · PDF gộp: '+r.sheetCombinedFile;status(m,'ok');}}}catch(e){} };
  }
  function mark(){var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)text(v,'V125 VDP PRODUCTION FIDELITY · CORE V101');var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V125 VDP Production Fidelity · Core V101</strong><br>VDP Sheet giữ đúng khổ giấy khi Combine · Bleed dùng MediaBox và cùng công thức padding của Dàn file · PON/CATTP/2 mặt A-B đồng bộ từ cấu hình Dàn file.';}
  function start(){addInfo();syncInfo();mark();wrapReceive();var n=0,t=setInterval(function(){n++;bind();wrapReceive();if(n%5===0)syncInfo();if(n>30)clearInterval(t);},150);var r=$('vdpSheetRefresh');if(r&&r.addEventListener)r.addEventListener('click',function(){setTimeout(syncInfo,80);},false);var m=$('vdpModeSheet');if(m&&m.addEventListener)m.addEventListener('click',function(){setTimeout(syncInfo,80);},false);}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();
