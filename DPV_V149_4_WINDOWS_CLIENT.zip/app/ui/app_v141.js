(function(){
  "use strict";
  var VERSION='V141.2 PREFLIGHT PRO';
  var deepPending=false, deepResult=null, refreshTimer=0, lastLocal=null;

  function $(id){return document.getElementById(id);}
  function qs(s,r){return (r||document).querySelector?(r||document).querySelector(s):null;}
  function add(el,c){if(el&&(' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(el)el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function txt(el,v){if(!el)return;if(v===undefined)return el.textContent||el.innerText||'';if('textContent'in el)el.textContent=v;else el.innerText=v;}
  function trim(v){return String(v==null?'':v).replace(/^\s+|\s+$/g,'');}
  function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function val(id){var e=$(id);return e?String(e.value||''):'';}
  function isChecked(id){var e=$(id);return !!(e&&e.checked);}
  function parse(raw){try{return JSON.parse(String(raw||'{}'));}catch(e){return null;}}
  function own(o,k){return Object.prototype.hasOwnProperty.call(o,k);}
  function status(m,k){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}
  function state(){try{return window.DPVVDP101&&window.DPVVDP101.getState?window.DPVVDP101.getState():null;}catch(e){return null;}}
  function records(){try{return window.DPVVDP101&&window.DPVVDP101.getRecords?window.DPVVDP101.getRecords():[];}catch(e){return [];}}
  function addCheck(a,level,title,detail,firstRecord){a.push({level:level,title:title,detail:detail||'',firstRecord:firstRecord||0});}
  function safeName(v){var s=String(v==null?'':v).replace(/[\\\/:*?"<>|]+/g,'_').replace(/^\s+|\s+$/g,'');if(!s)s='record';if(s.length>90)s=s.substring(0,90);return s;}
  function hasUnsafeName(v){return /[\\\/:*?"<>|]/.test(String(v==null?'':v));}
  function colorValid(v){
    var s=trim(v),a,i,n;if(!s)return false;
    if(/^#?[0-9a-f]{6}$/i.test(s))return true;
    if(/^rgb\s*\(/i.test(s))s=s.replace(/[^0-9.,-]/g,'');
    else if(/^cmyk\s*\(/i.test(s))s=s.replace(/[^0-9.,-]/g,'');
    a=s.split(',');if(a.length!==3&&a.length!==4)return false;
    for(i=0;i<a.length;i++){n=Number(a[i]);if(isNaN(n))return false;}
    return true;
  }
  function absolutePath(v){v=trim(v);return /^[a-zA-Z]:[\\\/]/.test(v)||/^\\\\/.test(v)||/^\//.test(v);}
  function headersOf(rec){var h={},i,k;for(i=0;i<rec.length;i++){for(k in rec[i])if(own(rec[i],k))h[k]=true;}return h;}
  function rangeFor(st,rec){var total=Number(st&&st.recordCount)||rec.length||0,from=Math.floor(Number(val('vdpFrom'))||1),to=Math.floor(Number(val('vdpTo'))||total||1);if(from<1)from=1;if(to>total)to=total;return {total:total,from:from,to:to,count:(total&&to>=from)?(to-from+1):0};}
  function mappingLabel(m,i){return trim(m&&m.label)||('Kênh '+String(i+1));}
  function layoutReady(){try{var l=window.DPVCoreV101&&window.DPVCoreV101.getLayout?window.DPVCoreV101.getLayout():null;return !!(l&&l.items&&l.items.length);}catch(e){return false;}}

  function localPreflight(){
    var st=state()||{recordCount:0,mappings:[]},rec=records(),maps=st.mappings||[],r=rangeFor(st,rec),h=headersOf(rec),checks=[],i,j,m,f,act,v,blank,bad,first,seenTarget={},dupTargets=0,filenameField=val('vdpFileNameField'),prefix=val('vdpFilePrefix')||'VDP',nameSeen={},dups=0,unsafe=0,longs=0,nameBlank=0,nameMissing=false,base,rawName,relativeImageNoFolder=0;

    addCheck(checks,r.total>0?'ok':'error','Dữ liệu VDP',r.total>0?(r.total+' record đã nạp.'):'Chưa có record để chạy.');
    addCheck(checks,r.count>0?'ok':'error','Phạm vi chạy',r.count>0?('Record '+r.from+' → '+r.to+' · '+r.count+' record.'):'Từ/Đến record không hợp lệ.');
    addCheck(checks,maps.length?'ok':'error','Mapping',maps.length?(maps.length+' kênh Variable Data.'):'Chưa map dữ liệu vào đối tượng Illustrator.');
    addCheck(checks,trim(val('vdpOutputPath'))?'ok':'error','Thư mục xuất',trim(val('vdpOutputPath'))||'Chưa chọn thư mục xuất PDF.');
    if(isChecked('vdpModeSheet'))addCheck(checks,layoutReady()?'ok':'error','VDP Sheet · Core V101',layoutReady()?'Đã có layout khóa để dàn trực tiếp lên khổ.':'Chưa có layout. Đóng VDP → Tính nhanh trên DPV → mở lại VDP.');

    for(i=0;i<maps.length;i++){
      m=maps[i]||{};f=trim(m.field);act=String(m.action||'text');blank=0;bad=0;first=0;
      if(!trim(m.targetId))addCheck(checks,'error',mappingLabel(m,i),'Target ID trống; hãy chọn lại đối tượng.',0);
      if(trim(m.targetId)){if(seenTarget[trim(m.targetId)])dupTargets++;seenTarget[trim(m.targetId)]=true;}
      if(!f){addCheck(checks,'error',mappingLabel(m,i),'Chưa chọn cột dữ liệu cho kênh này.',0);continue;}
      if(r.total&& !h[f]){addCheck(checks,'error',mappingLabel(m,i),'Không tìm thấy cột “'+f+'” trong dữ liệu.',0);continue;}
      if(act==='text'&&m.itemType&&String(m.itemType)!=='TextFrame')addCheck(checks,'error',mappingLabel(m,i),'Text yêu cầu TextFrame nhưng target hiện là '+String(m.itemType)+'.',0);
      if(act==='image'&&m.itemType&&String(m.itemType)!=='PlacedItem')addCheck(checks,'error',mappingLabel(m,i),'Image relink yêu cầu PlacedItem nhưng target hiện là '+String(m.itemType)+'.',0);
      if(act!=='text'&&act!=='image'&&act!=='visibility'&&act!=='fillColor')addCheck(checks,'error',mappingLabel(m,i),'Action không được hỗ trợ: '+act,0);
      for(j=r.from-1;j<r.to&&j<rec.length;j++){
        v=rec[j]&&own(rec[j],f)?rec[j][f]:'';
        if(trim(v)===''){blank++;if(!first)first=j+1;}
        if(act==='fillColor'&&!colorValid(v)){bad++;if(!first)first=j+1;}
        if(act==='image'&&trim(v)!==''&&!absolutePath(v)&&!trim(st.sourceFolder||''))relativeImageNoFolder++;
      }
      if(act==='image'&&blank)addCheck(checks,'error',mappingLabel(m,i),blank+' record có đường dẫn ảnh trống. Illustrator sẽ dừng khi gặp record này.',first);
      else if(act==='fillColor'&&bad)addCheck(checks,'error',mappingLabel(m,i),bad+' record có Fill Color không hợp lệ.',first);
      else if(act==='text'&&blank)addCheck(checks,'warn',mappingLabel(m,i),blank+' record có text trống; DPV sẽ thay bằng chuỗi rỗng/prefix/suffix.',first);
      else addCheck(checks,'ok',mappingLabel(m,i),'Cột “'+f+'” · '+act+' · kiểm tra cục bộ đạt.');
    }
    if(dupTargets)addCheck(checks,'warn','Target bị map lặp',dupTargets+' mapping dùng lại cùng một đối tượng. Chỉ giữ nếu bạn chủ ý áp nhiều action lên cùng target.');
    if(relativeImageNoFolder)addCheck(checks,'error','Ảnh tương đối',relativeImageNoFolder+' giá trị ảnh là đường dẫn tương đối nhưng không có thư mục nguồn CSV/TXT.',0);

    if(filenameField){
      if(!h[filenameField]){nameMissing=true;addCheck(checks,'error','Tên PDF','Cột đặt tên “'+filenameField+'” không tồn tại trong dữ liệu.',0);}
    }
    if(!nameMissing&&r.count){
      for(j=r.from-1;j<r.to&&j<rec.length;j++){
        rawName=filenameField?(rec[j]&&own(rec[j],filenameField)?rec[j][filenameField]:''):String(j+1);
        if(filenameField&&trim(rawName)==='')nameBlank++;
        if(hasUnsafeName(rawName))unsafe++;
        if((String(prefix)+'_'+String(rawName)).length>90)longs++;
        base=safeName(String(prefix)+'_'+String(rawName));
        if(nameSeen[base])dups++;else nameSeen[base]=j+1;
      }
      if(dups)addCheck(checks,'warn','Tên PDF trùng',dups+' record tạo cùng tên sau khi chuẩn hóa; DPV sẽ tự thêm _2, _3… nhưng nên kiểm tra dữ liệu.',0);
      else addCheck(checks,'ok','Tên PDF','Không phát hiện tên trùng trong phạm vi đang chạy.');
      if(nameBlank)addCheck(checks,'warn','Tên PDF trống',nameBlank+' record có ô tên file trống.',0);
      if(unsafe)addCheck(checks,'warn','Ký tự tên file',unsafe+' record chứa \\ / : * ? " < > |; DPV sẽ tự đổi thành “_”.',0);
      if(longs)addCheck(checks,'warn','Tên PDF dài',longs+' record vượt 90 ký tự và sẽ bị rút gọn theo engine VDP.',0);
    }

    var summary={ok:0,warn:0,error:0,checks:checks,range:r,state:st,records:rec,mappings:maps,firstError:0},x;
    for(i=0;i<checks.length;i++){x=checks[i];summary[x.level]++;if(!summary.firstError&&x.level==='error'&&x.firstRecord)summary.firstError=x.firstRecord;}
    return summary;
  }

  function mergeChecks(local,deep){
    var out={ok:local.ok,warn:local.warn,error:local.error,checks:local.checks.slice(0),firstError:local.firstError||0},i,x;
    if(deep&&deep.checks){for(i=0;i<deep.checks.length;i++){x=deep.checks[i];out.checks.push(x);out[x.level]++;if(!out.firstError&&x.level==='error'&&x.firstRecord)out.firstError=x.firstRecord;}}
    return out;
  }
  function render(){
    lastLocal=localPreflight();var s=mergeChecks(lastLocal,deepResult),box=$('v141Preflight'),sum=$('v141Summary'),list=$('v141List'),deep=$('v141DeepState'),go=$('v141GoError'),i,x,ic,h='';if(!box||!sum||!list)return;
    rem(box,'ok');rem(box,'warn');rem(box,'error');add(box,s.error?'error':(s.warn?'warn':'ok'));
    sum.innerHTML='<div><span>ĐẠT</span><strong>'+s.ok+'</strong></div><div><span>CẢNH BÁO</span><strong>'+s.warn+'</strong></div><div><span>LỖI</span><strong>'+s.error+'</strong></div><div><span>RECORD</span><strong>'+lastLocal.range.count+'</strong></div>';
    for(i=0;i<s.checks.length;i++){x=s.checks[i];ic=x.level==='ok'?'✓':(x.level==='warn'?'!':'×');h+='<div class="v141-check '+x.level+'"><span class="v141-icon">'+ic+'</span><div><strong>'+esc(x.title)+'</strong><small>'+esc(x.detail)+'</small></div></div>';}
    list.innerHTML=h;
    if(deep){txt(deep,deepPending?'Đang kiểm tra Illustrator…':(deepResult?'Kiểm tra sâu: đã cập nhật':'Kiểm tra sâu: chưa chạy'));}
    if(go){go.disabled=!s.firstError;go.setAttribute('data-record',String(s.firstError||0));}
    var badge=$('v141Badge');if(badge)txt(badge,s.error?(s.error+' LỖI'):(s.warn?(s.warn+' CẢNH BÁO'):'SẴN SÀNG'));
  }

  function deepChecksFromResult(r){
    var a=[],missing=Number(r.missingTargetCount||0),types=Number(r.typeErrorCount||0),images=Number(r.imageMissingCount||0),colors=Number(r.colorInvalidCount||0),first=0,samples=r.imageMissing||[],detail='';
    addCheck(a,missing?'error':'ok','Target Illustrator',missing?(missing+' target không còn tồn tại trong file AI nguồn.'):(String(r.targetFound||0)+'/'+String(r.targetCount||0)+' target được tìm thấy trong Illustrator.'),Number(r.firstTargetErrorRecord||0));
    if(types)addCheck(a,'error','Loại đối tượng',types+' target không đúng loại cho action Text/Image.',0);else addCheck(a,'ok','Loại đối tượng','Target Text/Image khớp loại đối tượng Illustrator.');
    if(images){if(samples.length){detail=images+' ảnh không tìm thấy. Ví dụ record '+samples[0].recordNumber+': '+samples[0].value;first=Number(samples[0].recordNumber||0);}else detail=images+' ảnh không tìm thấy.';addCheck(a,'error','File ảnh Linked',detail,first);}else if(Number(r.imageChecked||0)>0)addCheck(a,'ok','File ảnh Linked',String(r.imageChecked)+' đường dẫn ảnh tồn tại.');
    if(colors){var cs=r.colorInvalid||[];detail=colors+' giá trị màu không hợp lệ.';if(cs.length){detail+=' Ví dụ record '+cs[0].recordNumber+': '+cs[0].value;first=Number(cs[0].recordNumber||0);}addCheck(a,'error','Fill Color Illustrator',detail,first);}else if(Number(r.colorChecked||0)>0)addCheck(a,'ok','Fill Color Illustrator',String(r.colorChecked)+' giá trị màu hợp lệ.');
    addCheck(a,'ok','Work-copy V140.1','Preflight kiểm target trên source AI; khi Build, V140.1 vẫn tự rebind UUID trong work-copy.');
    return {checks:a};
  }

  function runDeep(){
    var l=localPreflight(),st=l.state||{},rec=l.records||[],r=l.range,maps=l.mappings||[],cfg,subset;
    deepResult=null;render();
    if(l.error){status('V141 Preflight: đang có '+l.error+' lỗi cục bộ. DPV vẫn kiểm tra sâu target/file để bạn thấy đầy đủ nguyên nhân.','warn');}
    if(!window.DPVVDP101||typeof window.DPVVDP101.bridgeCall!=='function'){status('V141 Preflight: Bridge chưa sẵn sàng.','error');return;}
    if(!maps.length||!r.count){status('V141 Preflight: cần dữ liệu và mapping trước khi kiểm tra sâu.','error');return;}
    cfg={preflightV141:true,dataPath:st.filePath||'',records:[],mappings:maps,sourceFolder:st.sourceFolder||'',from:r.from,to:r.to,recordOffset:0};
    if(!cfg.dataPath){subset=rec.slice(r.from-1,r.to);cfg.records=subset;cfg.from=1;cfg.to=subset.length;cfg.recordOffset=r.from-1;}
    deepPending=true;render();status('V141: Đang kiểm tra sâu target, loại đối tượng, ảnh Linked và Fill Color trong Illustrator…','work');
    window.DPVVDP101.bridgeCall('PreviewVariableData',[JSON.stringify(cfg)]);
  }

  function receiveDeep(r){deepPending=false;deepResult=deepChecksFromResult(r||{});render();var s=mergeChecks(lastLocal||localPreflight(),deepResult);status(s.error?('V141 Preflight: '+s.error+' lỗi cần sửa trước khi chạy.'):(s.warn?('V141 Preflight đạt với '+s.warn+' cảnh báo.'):'V141 Preflight đạt 100% · sẵn sàng chạy VDP.'),s.error?'error':'ok');}

  function wrapReceive(){
    if(window.__V141ReceiveWrapped||typeof window.VDPRO_receive!=='function')return;window.__V141ReceiveWrapped=true;var old=window.VDPRO_receive;
    window.VDPRO_receive=function(operation,payload){
      if(operation==='vdpPreview'&&deepPending){var r=parse(payload);if(r&&r.ok&&r.preflightV141){receiveDeep(r);return;}deepPending=false;deepResult={checks:[{level:'error',title:'Kiểm tra sâu Illustrator',detail:(r&&r.error)||'Illustrator không trả kết quả Preflight.',firstRecord:0}]};render();}
      return old.apply(window,arguments);
    };
  }

  function insertUI(){
    if($('v141Preflight'))return true;var card=qs('#vdpPanel .vdp-grid .vdp-card:last-child');if(!card)return false;var anchor=$('vdpBuildBtn');if(!anchor)return false;
    var box=document.createElement('div');box.id='v141Preflight';box.className='v141-preflight';box.innerHTML=''
      +'<div class="v141-head"><div><span class="v141-kicker">VDP PREFLIGHT PRO</span><strong>Kiểm tra trước khi chạy</strong><small id="v141DeepState">Kiểm tra sâu: chưa chạy</small></div><span id="v141Badge" class="v141-badge">CHƯA KIỂM TRA</span></div>'
      +'<div id="v141Summary" class="v141-summary"></div>'
      +'<div class="v141-toolbar"><button id="v141DeepBtn" type="button" class="button primary">Kiểm tra sâu Illustrator</button><button id="v141GoError" type="button" class="button" disabled>Đi tới record lỗi đầu</button></div>'
      +'<div id="v141List" class="v141-list"></div>';
    anchor.parentNode.insertBefore(box,anchor);
    $('v141DeepBtn').onclick=runDeep;
    $('v141GoError').onclick=function(){var n=Number(this.getAttribute('data-record')||0),e=$('vdpRecordIndex');if(n&&e){e.value=String(n);status('Đã chuyển tới record '+n+' để kiểm tra/Preview.','ok');try{e.scrollIntoView(false);}catch(x){}}};
    return true;
  }

  function scheduleRender(){if(refreshTimer)window.clearTimeout(refreshTimer);refreshTimer=window.setTimeout(function(){deepResult=null;render();},180);}
  function bindLive(){var p=$('vdpPanel');if(!p||p.getAttribute('data-v141-live'))return;p.setAttribute('data-v141-live','1');if(p.addEventListener){p.addEventListener('change',scheduleRender,false);p.addEventListener('input',scheduleRender,false);}else if(p.attachEvent){p.attachEvent('onchange',scheduleRender);p.attachEvent('onkeyup',scheduleRender);}}
  function updateVersion(){var v=qs('.version-badge');if(v)v.innerHTML='V141.2 PREFLIGHT PRO · CORE V101 STABLE';var b=qs('.beta-note');if(b)b.innerHTML='<strong>DPV® V141.2 Preflight Pro · Core V101 Stable</strong><br>Kiểm dữ liệu VDP trước khi chạy: mapping, record rỗng, kiểu target, tên PDF trùng, ảnh Linked, Fill Color và target Illustrator. Giữ nguyên Core V101 + V140.1 Work-Copy Rebind.';}
  function start(){if(!insertUI()){window.setTimeout(start,120);return;}wrapReceive();bindLive();updateVersion();render();window.DPVPreflightV141={run:render,runDeep:runDeep,getLocal:localPreflight};}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();
