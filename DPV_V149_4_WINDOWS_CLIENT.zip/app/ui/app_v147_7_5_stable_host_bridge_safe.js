/* DPV V147.7.5 STABLE HOST STANDALONE BRIDGE SAFE
   Final safety owner:
   - V147.7.4 direct-engine buttons are disabled/removed.
   - Standalone creation returns to the proven V147.4 host path (standaloneV1474).
   - V147.7.3 font/cache UI remains the final font state.
   - No new JSX engine is injected.
*/
(function(){
'use strict';
function $(id){return document.getElementById(id);}
function hide(id){var e=$(id);if(e){e.style.display='none';e.disabled=true;}}
function badge(){
 var h=document.querySelector('#v147StudioOverlay .v1471-badge');
 if(h)h.textContent='V147.7.5 STABLE BRIDGE';
 var st=$('v1474StandaloneStatus');
 if(st && (!st.textContent || /DIRECT ENGINE|V147\.7\.4/i.test(st.textContent))){
   st.textContent='V147.7.5 STABLE HOST · Standalone dùng engine V147.4 đã kiểm chứng.';
   st.className='v1474-status ok';
 }
}
function restoreOldButtons(){
 hide('v14774PreviewBtn');hide('v14774CreateBtn');hide('v14774BatchBtn');
 var ids=['v147PreviewAiBtn','v147CreateBtn','v147BatchBtn'],i,e;
 for(i=0;i<ids.length;i++){e=$(ids[i]);if(e){e.style.display='';e.disabled=false;}}
 badge();
 return !!$('v147CreateBtn');
}
var n=0,t=setInterval(function(){n++;restoreOldButtons();if(n>240)clearInterval(t);},250);
setTimeout(restoreOldButtons,20);
})();
