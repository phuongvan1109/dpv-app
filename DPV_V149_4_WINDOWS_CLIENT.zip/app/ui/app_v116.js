(function(){
  "use strict";
  function add(el,c){ if(!el)return; if((" "+el.className+" ").indexOf(" "+c+" ")<0) el.className += (el.className?" ":"")+c; }
  function rem(el,c){ if(!el)return; el.className=(" "+el.className+" ").replace(" "+c+" "," ").replace(/^\s+|\s+$/g,""); }
  function qs(s){ return document.querySelector ? document.querySelector(s) : null; }
  var lastW=0,lastH=0,tm=0;

  function setClassFlag(b,name,on){ if(on)add(b,name); else rem(b,name); }

  function relayout(){
    var b=document.body;
    var de=document.documentElement||{};
    var w=de.clientWidth||window.innerWidth||1400;
    var h=de.clientHeight||window.innerHeight||850;
    var sidebar=qs('.dpv-sidebar');
    var topbar=qs('.topbar');
    var workspace=qs('.workspace');
    var sidebarW=sidebar ? (sidebar.offsetWidth||0) : 0;
    var usable=w - sidebarW - 32;

    rem(b,'dpv-layout-medium'); rem(b,'dpv-layout-two'); rem(b,'dpv-layout-stack');
    rem(b,'dpv-short-window'); rem(b,'dpv-tight-topbar'); rem(b,'dpv-mini-topbar'); rem(b,'dpv-compact-sidebar');

    /* Collapse sidebar earlier on Windows DPI-scaled screens. */
    if(w < 1560) add(b,'dpv-compact-sidebar');
    sidebarW=(qs('.dpv-sidebar') ? (qs('.dpv-sidebar').offsetWidth||sidebarW) : sidebarW);
    usable=w - sidebarW - 32;

    if(usable >= 1180) add(b,'dpv-layout-medium');
    else if(usable >= 760) add(b,'dpv-layout-two');
    else add(b,'dpv-layout-stack');

    if(w < 1380) add(b,'dpv-tight-topbar');
    if(w < 1180) add(b,'dpv-mini-topbar');
    if(h < 820) add(b,'dpv-short-window');

    /* Real-height workspace sizing prevents hidden content after resize/maximize. */
    if(topbar && workspace){
      var topH = topbar.offsetHeight || 68;
      var target = h - topH;
      if(target < 280) target = 280;
      workspace.style.height = target + 'px';
    }

    /* Force reflow for legacy WebBrowser after maximize/restore. */
    if(workspace){ workspace.style.zoom = '1'; }
  }

  function mark(){
    var v=qs('.version-badge');
    if(v) v.innerHTML='V116 RESIZE HOTFIX · CORE V101 STABLE';
    var b=qs('.beta-note');
    if(b) b.innerHTML='<strong>DPV® V116 Resize Hotfix · Core V101 Stable</strong><br>Fix mất nội dung khi phóng to / thu nhỏ cửa sổ trên Windows · tự chia lại layout theo vùng hiển thị thật · vẫn giữ nguyên engine dàn, PON, VDP và Bridge Illustrator.';
  }

  function tick(force){
    var de=document.documentElement||{};
    var w=de.clientWidth||window.innerWidth||0;
    var h=de.clientHeight||window.innerHeight||0;
    if(force || w!==lastW || h!==lastH){
      lastW=w; lastH=h;
      relayout();
      mark();
      setTimeout(relayout, 60);
      setTimeout(relayout, 180);
    }
  }
  function onResize(){ if(tm)clearTimeout(tm); tm=setTimeout(function(){ tick(true); }, 40); }
  function start(){
    tick(true);
    if(window.addEventListener){
      window.addEventListener('resize', onResize, false);
      window.addEventListener('load', function(){ tick(true); }, false);
    }else if(window.attachEvent){
      window.attachEvent('onresize', onResize);
      window.attachEvent('onload', function(){ tick(true); });
    }
    setTimeout(function(){ tick(true); }, 250);
    setTimeout(function(){ tick(true); }, 900);
    setInterval(function(){ tick(false); }, 700);
  }
  if(document.readyState==='loading'){
    if(document.addEventListener) document.addEventListener('DOMContentLoaded', start, false);
    else window.attachEvent('onload', start);
  } else start();
})();
