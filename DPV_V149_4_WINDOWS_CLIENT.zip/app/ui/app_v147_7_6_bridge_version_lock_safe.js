/* DPV V147.7.6 BRIDGE VERSION LOCK + STANDALONE FINAL BUTTONS
   Purpose:
   - use ONLY DPVVDP101.bridgeCall (same transport as stable VDP/Preflight)
   - use new button IDs so older V147 capture listeners cannot intercept
   - consume standaloneV1474 result before older VDPRO_receive wrappers
*/
(function(){
'use strict';
var pending=false,timer=null,receiveInstalled=false;
function $(id){return document.getElementById(id);}
function s(v){return v==null?'':String(v);}
function val(id,d){var e=$(id);return e?e.value:d;}
function num(id,d){var n=Number(val(id,d));return isNaN(n)?d:n;}
function status(msg,kind){var el=$('v1474StandaloneStatus');if(el){el.textContent=msg;el.className='v1474-status '+(kind||'');}try{if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(msg,kind||'');}catch(e){}}
function values(batch){var raw=batch?val('v147BatchContent',''):val('v147SingleContent',''),arr=[],a,i,t;if(batch){a=s(raw).split(/\r?\n/);for(i=0;i<a.length;i++){t=s(a[i]).replace(/^\s+|\s+$/g,'');if(t)arr.push(t);}}else{t=s(raw).replace(/^\s+|\s+$/g,'');if(t)arr.push(t);}return arr;}
function eanCheck(s12){var i,sum=0,n;for(i=0;i<12;i++){n=Number(s12.charAt(i));sum+=(i%2===0)?n:n*3;}return String((10-(sum%10))%10);}
function validate(type,arr){var i,x,cd;if(!arr.length)return 'Chưa nhập nội dung QR/Barcode.';if(type==='ean13'){for(i=0;i<arr.length;i++){x=s(arr[i]);if(!/^\d{12,13}$/.test(x))return 'EAN-13 cần đúng 12 hoặc 13 chữ số. Record '+(i+1)+': '+x;if(x.length===13){cd=eanCheck(x.substr(0,12));if(x.charAt(12)!==cd)return 'EAN-13 sai checksum ở record '+(i+1)+'. Check digit đúng là '+cd+'.';}}}return '';}
function cfg(batch){var type=val('v147CodeType','qr'),ps=window.__DPV14773_FONT_PS||val('v147FontName','Arial'),fontSize=num('v1475FontSize',num('v147FontSize',9)),gap=num('v1475TextGap',1.2);return {
  standaloneV1474:true,
  codeType:type,
  targetMode:val('v147TargetMode','selection'),
  values:values(batch),
  fontName:ps,
  fontSize:fontSize,
  showText:Number(val('v147ShowText','1')),
  textMode:val('v1475TextMode',val('v147TextMode','outline')),
  fontWeight:val('v1475Weight','regular'),
  tracking:num('v1475Tracking',0),
  textGapMm:gap,
  barHeightPercent:num('v1475BarHeight',100),
  barWidthPercent:num('v1475BarWidth',100),
  quietZone:num('v1475QuietZone',10),
  textAlign:'center',
  widthMm:num('v1474WidthMm',50),
  heightMm:num('v1474HeightMm',20),
  columns:num('v1474Columns',4),
  gapMm:num('v1474GapMm',5),
  bridgeVersionLockV14776:true
};}
function busy(v){['v14776PreviewBtn','v14776CreateBtn','v14776BatchBtn'].forEach(function(id){var e=$(id);if(e)e.disabled=!!v;});}
function finish(){pending=false;busy(false);if(timer){clearTimeout(timer);timer=null;}}
function handle(r){if(!r||!r.standaloneV1474)return false;finish();if(r.ok===false)status('Illustrator báo lỗi tạo mã: '+s(r.error||'Không rõ lỗi.'),'error');else status('Đã tạo '+s(r.created||0)+' mã '+s(r.codeType||'')+' trong Illustrator · '+s(r.documentName||''),'ok');return true;}
function installReceive(){if(receiveInstalled&&window.VDPRO_receive===window.__DPV14776Receive)return true;if(typeof window.VDPRO_receive!=='function')return false;var old=window.VDPRO_receive;function recv(op,payload){var r=null;if(op==='vdpPreview'){try{r=JSON.parse(s(payload||'{}'));}catch(e){}if(handle(r))return;if(pending&&r){finish();if(r.ok===false)status('Bridge đã trả lỗi: '+s(r.error||'Không rõ lỗi.'),'error');else status('Bridge có phản hồi nhưng host chưa vào nhánh Standalone. Hãy thoát Illustrator hoàn toàn rồi mở lại.','error');return;}}return old.apply(window,arguments);}window.__DPV14776Receive=recv;window.VDPRO_receive=recv;receiveInstalled=true;return true;}
function send(preview,batch){var c=cfg(batch),err=validate(c.codeType,c.values);if(err){status(err,'error');return false;}if(pending){status('Illustrator đang xử lý lệnh trước.','work');return false;}if(!window.DPVVDP101||typeof window.DPVVDP101.bridgeCall!=='function'){status('Bridge Illustrator chưa sẵn sàng. Hãy bấm Kết nối.','error');return false;}pending=true;busy(true);status((preview?'Đang Preview':'Đang tạo')+' '+c.values.length+' mã '+(c.codeType==='ean13'?'EAN-13':c.codeType==='code128'?'Code128':'QR')+' · Bridge V147.7.6…','work');timer=setTimeout(function(){if(pending){finish();status('Không nhận phản hồi sau 30 giây. Nếu Illustrator vẫn Online, hãy thoát hoàn toàn Illustrator rồi mở lại một lần để reset VDPROBridge targetengine.','error');}},30000);try{window.DPVVDP101.bridgeCall('PreviewVariableData',[JSON.stringify(c)]);}catch(e){finish();status('Không gửi được lệnh: '+s(e&&e.message||e),'error');}return false;}
function replace(){if($('v14776CreateBtn'))return true;var oldIds=['v147PreviewAiBtn','v147CreateBtn','v147BatchBtn'],newIds=['v14776PreviewBtn','v14776CreateBtn','v14776BatchBtn'],labels=['Preview thật trong Illustrator','Tạo mã vào Illustrator','Tạo batch không cần VDP'],i,o,n;for(i=0;i<3;i++){o=$(oldIds[i]);if(!o)continue;n=o.cloneNode(true);n.id=newIds[i];n.textContent=labels[i];n.removeAttribute('disabled');n.disabled=false;o.parentNode.insertBefore(n,o);o.style.display='none';o.disabled=true;}
 if($('v14776PreviewBtn'))$('v14776PreviewBtn').onclick=function(e){if(e&&e.preventDefault)e.preventDefault();return send(true,false);};
 if($('v14776CreateBtn'))$('v14776CreateBtn').onclick=function(e){if(e&&e.preventDefault)e.preventDefault();return send(false,false);};
 if($('v14776BatchBtn'))$('v14776BatchBtn').onclick=function(e){if(e&&e.preventDefault)e.preventDefault();return send(false,true);};
 var st=$('v1474StandaloneStatus');if(st){st.textContent='V147.7.6 BRIDGE VERSION LOCK sẵn sàng · host chỉ load 1 lần.';st.className='v1474-status ok';}
 var badge=document.querySelector('#v147StudioOverlay .v1471-badge');if(badge)badge.textContent='V147.7.6 BRIDGE LOCK';
 return !!$('v14776CreateBtn');}
function boot(){replace();installReceive();return true;}var n=0,iv=setInterval(function(){n++;boot();if(n>240)clearInterval(iv);},250);setTimeout(boot,20);
})();
