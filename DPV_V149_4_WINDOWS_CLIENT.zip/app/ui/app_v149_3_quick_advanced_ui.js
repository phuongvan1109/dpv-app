(function(){
  "use strict";
  var VERSION="V149.3", MODE_KEY="dpv.v1493.ui.mode", FOLD_KEY="dpv.v1493.fold.";
  function byId(id){return document.getElementById(id);}
  function qs(s,r){return (r||document).querySelector?(r||document).querySelector(s):null;}
  function qsa(s,r){return (r||document).querySelectorAll?(r||document).querySelectorAll(s):[];}
  function add(el,c){if(!el)return;if((" "+el.className+" ").indexOf(" "+c+" ")<0)el.className+=(el.className?" ":"")+c;}
  function rem(el,c){if(!el)return;el.className=(" "+el.className+" ").replace(" "+c+" "," ").replace(/^\s+|\s+$/g,"");}
  function has(el,c){return !!el&&(" "+el.className+" ").indexOf(" "+c+" ")>=0;}
  function txt(el,v){if(!el)return;if("textContent" in el)el.textContent=v;else el.innerText=v;}
  function parentField(id){var n=byId(id);return n?n.parentNode:null;}
  function setStored(k,v){try{localStorage.setItem(k,v);}catch(e){}}
  function getStored(k,d){try{return localStorage.getItem(k)||d;}catch(e){return d;}}
  function formatNum(v){v=Number(v);return isFinite(v)?String(Math.round(v*100)/100):"—";}
  function selectedText(id){var n=byId(id);if(!n)return"—";if(n.options&&n.selectedIndex>=0)return n.options[n.selectedIndex].text||n.value;return n.value||"—";}
  function markAdvanced(){
    var ids=["dieHint","margin","header","maxQty","linkBleed","angleStep","cornerZone","demiExtend","finishMarkLength","finishMarkGap","duplexFlip","outputDieStart"],i,p;
    for(i=0;i<ids.length;i++){p=parentField(ids[i]);if(p)add(p,"dpv-v1493-advanced-only");}
    var buttons=["manualBtn","manualSizeBtn","hostPreviewBtn","diePreviewBtn"],b;
    for(i=0;i<buttons.length;i++){b=byId(buttons[i]);if(b)add(b,"dpv-v1493-advanced-only");}
    var settings=qs(".settings-column"),lists=settings?qsa(".option-list",settings):[],compact=settings?qsa(".form-grid.compact",settings):[];
    for(i=0;i<lists.length;i++){if(!has(lists[i],"pon-options")){add(lists[i],"dpv-v1493-advanced-block");}}
    for(i=0;i<compact.length;i++){if(!has(compact[i],"dpv-output-mode-grid")){add(compact[i],"dpv-v1493-advanced-block");}}
    var pon=qs(".pon-options"),ponPicker=qs(".settings-column .picker:not(.output)"),crop=qs(".pon-crop-settings"),notes=qsa(".settings-column .manual-note");
    if(pon)add(pon,"dpv-v1493-advanced-block");if(ponPicker)add(ponPicker,"dpv-v1493-advanced-block");if(crop)add(crop,"dpv-v1493-advanced-block");
    for(i=0;i<notes.length;i++){if(!has(notes[i],"dpv-output-mode-note"))add(notes[i],"dpv-v1493-advanced-block");}
    var res=qs(".result-column"),metric=res?qs(".metric-row",res):null,sheet=res?qs(".sheet-preview",res):null,log=res?qs(".log-box",res):null,beta=res?qs(".beta-note",res):null;
    if(metric)add(metric,"dpv-v1493-advanced-only");if(sheet)add(sheet,"dpv-v1493-advanced-only");if(log)add(log,"dpv-v1493-advanced-only");if(beta)add(beta,"dpv-v1493-advanced-only");
  }
  function summaryText(){
    var pw=byId("paperW"),ph=byId("paperH"),gx=byId("gapX"),gy=byId("gapY"),out=byId("outputMode"),rot=byId("allowRotate"),shape=byId("trueShape");
    return "Khổ "+formatNum(pw&&pw.value)+"×"+formatNum(ph&&ph.value)+" mm · Khe "+formatNum(gx&&gx.value)+"/"+formatNum(gy&&gy.value)+" mm · "+selectedText("outputMode")+" · Xoay "+(rot&&rot.checked?"ON":"OFF")+" · True‑Shape "+(shape&&shape.checked?"ON":"OFF");
  }
  function updateSummary(){var s=byId("dpvV1493QuickSummary");if(s)txt(s,summaryText());}
  function setMode(mode){
    mode=mode==="advanced"?"advanced":"quick";
    rem(document.body,"dpv-v1493-quick");rem(document.body,"dpv-v1493-advanced");add(document.body,"dpv-v1493-"+mode);setStored(MODE_KEY,mode);
    var bs=qsa("[data-v1493-mode]"),i;for(i=0;i<bs.length;i++){if(bs[i].getAttribute("data-v1493-mode")===mode)add(bs[i],"active");else rem(bs[i],"active");}
    var lab=byId("dpvV1493ModeState");if(lab)txt(lab,mode==="quick"?"QUICK · chỉ hiện thông số dùng thường xuyên":"ADVANCED · hiển thị toàn bộ thiết lập");
    updateSummary();
  }
  function makeModeUi(){
    if(byId("dpvV1493ModeBar"))return;
    var ws=qs(".workspace"),steps=byId("dpvV149Steps"),anchor=steps||qs(".workspace-columns");if(!ws||!anchor)return;
    var bar=document.createElement("div");bar.id="dpvV1493ModeBar";bar.className="dpv-v1493-modebar";
    bar.innerHTML='<div class="dpv-v1493-modecopy"><strong>GIAO DIỆN LÀM VIỆC</strong><small id="dpvV1493ModeState"></small></div><div id="dpvV1493QuickSummary" class="dpv-v1493-summary"></div><div class="dpv-v1493-modebuttons"><button type="button" data-v1493-mode="quick">⚡ Quick</button><button type="button" data-v1493-mode="advanced">⚙ Advanced</button></div>';
    if(steps&&steps.nextSibling)ws.insertBefore(bar,steps.nextSibling);else ws.insertBefore(bar,anchor);
    var bs=qsa("[data-v1493-mode]",bar),i;for(i=0;i<bs.length;i++)bs[i].onclick=function(){setMode(this.getAttribute("data-v1493-mode"));};
    setMode(getStored(MODE_KEY,"quick"));
  }
  function wrapColumn(section,key){
    if(!section||byId("dpvV1493FoldBtn_"+key))return;
    var title=qs(".panel-title",section);if(!title)return;
    var btn=document.createElement("button");btn.id="dpvV1493FoldBtn_"+key;btn.type="button";btn.className="dpv-v1493-fold-btn";btn.setAttribute("data-v1493-fold",key);btn.innerHTML="−";btn.title="Thu gọn / mở rộng";title.appendChild(btn);
    var collapsed=getStored(FOLD_KEY+key,"0")==="1";if(collapsed){add(section,"dpv-v1493-collapsed");btn.innerHTML="+";}
    btn.onclick=function(){var c=has(section,"dpv-v1493-collapsed");if(c){rem(section,"dpv-v1493-collapsed");this.innerHTML="−";setStored(FOLD_KEY+key,"0");}else{add(section,"dpv-v1493-collapsed");this.innerHTML="+";setStored(FOLD_KEY+key,"1");}};
  }
  function makeAccordion(){wrapColumn(qs(".source-column"),"source");wrapColumn(qs(".settings-column"),"settings");wrapColumn(qs(".result-column"),"result");}
  function bindSummary(){
    var ids=["paperW","paperH","gapX","gapY","outputMode","allowRotate","trueShape"],i,n;for(i=0;i<ids.length;i++){n=byId(ids[i]);if(n){if(n.addEventListener){n.addEventListener("change",updateSummary,false);n.addEventListener("input",updateSummary,false);}else if(n.attachEvent)n.attachEvent("onchange",updateSummary);}}
  }
  function addQuickHint(){
    if(byId("dpvV1493QuickHint"))return;var col=qs(".settings-column"),title=col?qs(".panel-title",col):null;if(!col||!title)return;
    var box=document.createElement("div");box.id="dpvV1493QuickHint";box.className="dpv-v1493-quick-hint";box.innerHTML='<strong>⚡ Quick Mode</strong><span>Khổ + khe + nguồn + đầu ra + Dàn. Các thiết lập PON/True‑Shape nâng cao vẫn giữ nguyên giá trị nhưng được ẩn gọn. Chuyển Advanced bất cứ lúc nào.</span>';
    if(title.nextSibling)col.insertBefore(box,title.nextSibling);else col.appendChild(box);
  }
  function forceVersion(){
    try{document.title="DPV® V149.3 — Quick/Advanced UI · Accordion · Job Queue Pro";}catch(e){}
    var v=qs(".version-badge");if(v)v.innerHTML="V149.3 · QUICK / ADVANCED UI";
    var beta=qs(".beta-note");if(beta)beta.innerHTML='<strong>DPV® V149.3 QUICK / ADVANCED UI + ACCORDION</strong><br>Quick Mode giảm rối · Advanced giữ toàn bộ thiết lập · 3 cột thu gọn độc lập · Job Queue Pro / Native Batch / Geometry Cache giữ nguyên.';
  }
  function start(){
    markAdvanced();makeModeUi();makeAccordion();addQuickHint();bindSummary();updateSummary();forceVersion();
    setTimeout(function(){markAdvanced();makeModeUi();makeAccordion();addQuickHint();updateSummary();forceVersion();},800);
    setTimeout(function(){forceVersion();},2600);
    setTimeout(function(){forceVersion();},5200);
  }
  window.DPVV1493={version:VERSION,setMode:setMode,updateSummary:updateSummary};
  if(document.readyState==="loading"){if(document.addEventListener)document.addEventListener("DOMContentLoaded",function(){setTimeout(start,160);},false);else window.attachEvent("onload",function(){setTimeout(start,160);});}else setTimeout(start,160);
})();
