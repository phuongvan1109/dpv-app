/* DPV V146.4.2 BARCODE FONT PICKER + LIVE STYLE PREVIEW SAFE */
(function(){
  'use strict';
  var VERSION='V146.4.2', STORE='dpv_v1463_barcode_style';
  var QUICK_FONTS=[
    'Arial','Arial Narrow','Arial Black','Helvetica','Helvetica Neue','Times New Roman','Courier New',
    'Myriad Pro','Minion Pro','Adobe Garamond Pro','Source Sans Pro','Source Sans 3','Source Serif Pro',
    'Roboto','Open Sans','Montserrat','Poppins','Inter','Noto Sans','Noto Serif','Futura','Avenir','Avenir Next',
    'DIN','DIN Condensed','Gill Sans','Century Gothic','Gotham','Proxima Nova','Univers','Frutiger'
  ];
  function $(id){return document.getElementById(id);}
  function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
  function load(){try{return JSON.parse(localStorage.getItem(STORE)||'{}')||{};}catch(e){return {};}}
  function save(db){try{localStorage.setItem(STORE,JSON.stringify(db||{}));}catch(e){}}
  function rawState(){try{return window.DPVVDP101&&window.DPVVDP101.getState?window.DPVVDP101.getState():null;}catch(e){return null;}}
  function records(){try{return window.DPVVDP101&&window.DPVVDP101.getRecords?window.DPVVDP101.getRecords():[];}catch(e){return [];}}
  function bars(){var st=rawState()||{},a=st.mappings||[],out=[],i;for(i=0;i<a.length;i++)if(a[i].action==='code128Vector'||a[i].action==='ean13Vector')out.push(a[i]);return out;}
  function key(m){return String((m&&m.targetId)||'');}
  function getIndex(){var s=$('v14632MapPicker');return s?Math.max(0,Number(s.value)||0):0;}
  function currentMap(){var a=bars(),i=getIndex();if(i>=a.length)i=0;return a[i]||null;}
  function currentRecord(){var r=records(),e=$('vdpRecordIndex'),n=Math.max(1,Math.floor(Number(e&&e.value)||1));if(n>r.length)n=r.length||1;return {n:n,row:r[n-1]||{}};}
  function sampleFor(m){var c=currentRecord(),v='';if(m&&m.field&&c.row[m.field]!==undefined)v=c.row[m.field];return String((m&&m.prefix)||'')+String(v==null?'':v)+String((m&&m.suffix)||'');}
  function cfgFor(m){var db=load(),k=key(m),c=k&&db[k]?db[k]:{};return c||{};}
  function quickOptions(cur){var a=QUICK_FONTS.slice(0),found=false,i,s='<option value="">— Font nhanh —</option>';for(i=0;i<a.length;i++){if(a[i]===cur)found=true;s+='<option value="'+esc(a[i])+'">'+esc(a[i])+'</option>';}if(cur&&!found)s+='<option value="'+esc(cur)+'">'+esc(cur)+' (đang dùng)</option>';return s;}
  function ensure(){
    var base=$('v14632StyleBox'); if(!base) return false;
    var old=$('v14642FontStudio'); if(old) return true;
    var box=document.createElement('div');box.id='v14642FontStudio';box.className='v14642-card';base.appendChild(box);render();return true;
  }
  function controlValue(id,fallback){var e=$(id);return e?e.value:fallback;}
  function readControls(m){
    var old=cfgFor(m);
    return {
      showText:Number(controlValue('v14632Show',old.showText==null?1:old.showText)),
      fontName:controlValue('v14642FontExact',controlValue('v14632Font',old.fontName||'Arial'))||'Arial',
      fontSize:Number(controlValue('v14642Size',controlValue('v14632Size',old.fontSize||9)))||9,
      tracking:Number(controlValue('v14642Tracking',controlValue('v14632Tracking',old.tracking||0)))||0,
      textGapMm:Number(controlValue('v14632Gap',old.textGapMm||1.2))||0,
      barHeightPercent:Number(controlValue('v14632Height',old.barHeightPercent||100))||100,
      barWidthPercent:Number(controlValue('v14632Width',old.barWidthPercent||100))||100,
      quietZone:Number(controlValue('v14632Quiet',old.quietZone||10))||10,
      fontWeight:controlValue('v14642Weight',controlValue('v14632Weight',old.fontWeight||'regular'))||'regular',
      textMode:controlValue('v14642Mode',controlValue('v14632TextMode',old.textMode||'outline'))||'outline',
      textAlign:controlValue('v14642Align',old.textAlign||'center')||'center'
    };
  }
  function saveControls(m,quiet){var k=key(m),db=load(),c=readControls(m);if(!k)return null;db[k]=c;save(db);if(!quiet&&window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status('Đã lưu Barcode Font Style · '+VERSION+'.','ok');return c;}
  function updateLegacyInputs(c){
    if($('v14632Font'))$('v14632Font').value=c.fontName;
    if($('v14632Size'))$('v14632Size').value=String(c.fontSize);
    if($('v14632Tracking'))$('v14632Tracking').value=String(c.tracking);
    if($('v14632Weight'))$('v14632Weight').value=c.fontWeight;
    if($('v14632TextMode'))$('v14632TextMode').value=c.textMode;
  }
  function previewCss(){
    var m=currentMap(); if(!m)return; var c=readControls(m),txt=sampleFor(m),pv=$('v14642TextPreview');if(!pv)return;
    pv.textContent=txt||'12089091521903';
    pv.style.fontFamily='"'+String(c.fontName).replace(/"/g,'')+'", Arial, sans-serif';
    pv.style.fontSize=Math.max(12,Math.min(40,c.fontSize*2.2))+'px';
    pv.style.fontWeight=c.fontWeight==='bold'?'700':'400';
    pv.style.letterSpacing=(c.tracking/1000*c.fontSize*2.2)+'px';
    pv.style.textAlign=c.textAlign;
    var b=$('v14642FontBadge');if(b)b.textContent=c.fontName+' · '+c.fontSize+' pt · '+(c.fontWeight==='bold'?'Bold':'Regular');
  }
  function previewIllustrator(){
    var m=currentMap(); if(!m)return; var c=saveControls(m,true);updateLegacyInputs(c);
    try{
      if(!window.DPVVDP101||!window.DPVVDP101.bridgeCall)throw new Error('Bridge chưa sẵn sàng.');
      var st=window.DPVVDP101.getState(),r=records(),e=$('vdpRecordIndex'),n=Math.max(1,Math.floor(Number(e&&e.value)||1));if(n>r.length)n=r.length||1;
      window.DPVVDP101.status('Đang Preview barcode style trong Illustrator…','ok');
      window.DPVVDP101.bridgeCall('PreviewVariableData',[JSON.stringify({record:r[n-1]||{},recordNumber:n,mappings:st.mappings||[],sourceFolder:st.sourceFolder||''})]);
    }catch(err){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status((err&&err.message)||String(err),'error');}
  }
  function render(){
    var box=$('v14642FontStudio');if(!box)return false;var m=currentMap();
    if(!m){box.innerHTML='<div class="v14642-empty">Chọn mapping Code 128 hoặc EAN-13 để mở Font Studio.</div>';return true;}
    var c=cfgFor(m),font=c.fontName||'Arial',size=c.fontSize||9,tracking=c.tracking||0,weight=c.fontWeight||'regular',mode=c.textMode||'outline',align=c.textAlign||'center',isEAN=m.action==='ean13Vector';
    box.innerHTML=''
      +'<div class="v14642-head"><div><strong>BARCODE FONT STUDIO</strong><small>'+VERSION+' SAFE · gần thao tác Illustrator</small></div><span id="v14642FontBadge"></span></div>'
      +'<div class="v14642-grid">'
      +'<label><span>Font nhanh</span><select id="v14642FontQuick">'+quickOptions(font)+'</select></label>'
      +'<label class="v14642-wide"><span>Tên font Illustrator</span><input id="v14642FontExact" value="'+esc(font)+'" placeholder="VD: MyriadPro-Regular"><small>Nhận Family name hoặc PostScript name.</small></label>'
      +'<label><span>Cỡ chữ (pt)</span><div class="v14642-step"><button data-delta="-1">−</button><input id="v14642Size" type="number" min="4" max="200" step="0.1" value="'+size+'"><button data-delta="1">+</button></div></label>'
      +'<label><span>Tracking</span><input id="v14642Tracking" type="number" step="1" value="'+tracking+'"></label>'
      +'<label><span>Kiểu font</span><select id="v14642Weight"><option value="regular">Regular</option><option value="bold">Bold</option></select></label>'
      +'<label><span>Canh chữ</span><select id="v14642Align" '+(isEAN?'disabled':'')+'><option value="left">Trái</option><option value="center">Giữa</option><option value="right">Phải</option></select><small>'+(isEAN?'EAN-13 giữ bố cục số chuẩn.':'Code128 hỗ trợ trái / giữa / phải.')+'</small></label>'
      +'<label><span>Text output</span><select id="v14642Mode"><option value="live">Text sống</option><option value="outline">Outline vector</option></select></label>'
      +'</div>'
      +'<div class="v14642-preview"><div class="v14642-preview-title">PREVIEW DÒNG CHỮ · RECORD HIỆN TẠI</div><div id="v14642TextPreview"></div></div>'
      +'<div class="v14642-actions"><button id="v14642Save" class="button accent">Lưu font/style</button><button id="v14642PreviewAI" class="button primary">Preview thật trong Illustrator</button></div>'
      +'<div class="v14642-note"><b>Text sống</b> = có thể chọn và sửa font/size tiếp trong Illustrator. <b>Outline</b> = ổn định cho in, không phụ thuộc font khi chuyển máy.</div>';
    $('v14642FontQuick').value=font;
    $('v14642Weight').value=weight;
    $('v14642Mode').value=mode;
    $('v14642Align').value=isEAN?'center':align;
    var watchers=['v14642FontExact','v14642Size','v14642Tracking','v14642Weight','v14642Mode','v14642Align'];
    for(var i=0;i<watchers.length;i++){(function(id){var e=$(id);if(e){e.oninput=previewCss;e.onchange=previewCss;}})(watchers[i]);}
    $('v14642FontQuick').onchange=function(){if(this.value)$('v14642FontExact').value=this.value;previewCss();};
    var steps=box.querySelectorAll('.v14642-step button');for(i=0;i<steps.length;i++)steps[i].onclick=function(){var e=$('v14642Size'),n=Number(e.value||9)+Number(this.getAttribute('data-delta')||0);e.value=Math.max(4,n).toFixed(1);previewCss();};
    $('v14642Save').onclick=function(){var cc=saveControls(m,false);updateLegacyInputs(cc);previewCss();};
    $('v14642PreviewAI').onclick=previewIllustrator;
    previewCss();return true;
  }
  function hook(){var style=$('v14632StyleBox');if(!style)return false;if(!ensure())return false;render();return true;}
  var t=0,tm=setInterval(function(){t++;if(hook()||t>100)clearInterval(tm);},450);
  document.addEventListener('click',function(e){if(e.target&&e.target.id&&/^v14642/.test(e.target.id))return;setTimeout(hook,80);},false);
  document.addEventListener('change',function(e){if(e.target&&e.target.id==='v14632MapPicker')setTimeout(function(){var old=$('v14642FontStudio');if(old)old.parentNode.removeChild(old);hook();},60);},false);
  window.DPV_V14642_FONT_STUDIO={render:hook,save:function(){var m=currentMap();return m?saveControls(m,true):null;}};
})();
