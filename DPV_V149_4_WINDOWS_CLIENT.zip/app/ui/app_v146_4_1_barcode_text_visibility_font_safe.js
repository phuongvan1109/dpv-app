
(function(){
  function inject(){
    var card = document.getElementById('v1463TypographyBox') || document.getElementById('v1463BarcodeTypographyCard');
    if(!card || document.getElementById('v14641FontHelp')) return !!card;
    var box = document.createElement('div');
    box.id='v14641FontHelp';
    box.style.marginTop='12px';
    box.style.padding='10px 12px';
    box.style.border='1px dashed #c9dfd3';
    box.style.borderRadius='12px';
    box.style.background='#ffffff';
    box.style.fontSize='12px';
    box.style.lineHeight='1.45';
    box.style.color='#40635a';
    box.innerHTML=''
      + '<b>V146.4.1 SAFE · Chữ dưới barcode</b><br>'
      + '• Số dưới barcode đã được ép hiện trên cùng và tô đen để không bị chìm dưới nền trắng.<br>'
      + '• Ô <b>Font chữ</b> nhận đúng tên font Illustrator (PostScript name hoặc Family name).<br>'
      + '• Ô <b>Cỡ chữ (pt)</b> dùng cùng đơn vị point như Illustrator.<br>'
      + '• Nếu muốn dễ chỉnh như trong Illustrator, chọn <b>Text output = Text sống</b>; nếu muốn in ổn định, chọn <b>Outline</b>.';
    card.appendChild(box);
    return true;
  }
  var t=0, iv=setInterval(function(){ t++; if(inject()||t>40) clearInterval(iv); }, 600);
})();
