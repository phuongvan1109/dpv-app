(function(){
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge'); if(v)v.innerHTML='V127 AI STAY OPEN · CORE V101 STABLE';
    var b=q('.beta-note'); if(b)b.innerHTML='<strong>DPV® V127 AI Stay Open · Core V101 Stable</strong><br>VDP giữ Illustrator sống sau khi xuất · luôn mở/kích hoạt lại file AI nguồn · không thay thuật toán dàn V101.';
  }
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);}else mark();
})();
