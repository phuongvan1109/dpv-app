(function(){
  "use strict";
  var VERSION="V149.1",last=null,wrapped=false;
  function byId(id){return document.getElementById(id);}
  function qs(s,r){return (r||document).querySelector?(r||document).querySelector(s):null;}
  function esc(s){return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;");}
  function txt(el,v){if(!el)return;if("textContent" in el)el.textContent=v;else el.innerText=v;}
  function metricText(m){
    if(!m)return "Cache geometry đang chờ job";
    var hit=Number(m.dieHits||0)+Number(m.layoutHits||0),miss=Number(m.dieMisses||0)+Number(m.layoutMisses||0);
    return "HIT "+hit+" · MISS "+miss+" · prewarm "+Number(m.prewarmMs||0)+" ms";
  }
  function render(m){
    if(m)last=m;
    var p=byId("dpvV1491CachePanel"),s=byId("dpvV1491CacheState"),b=byId("dpvV1491NativeBadge"),d=byId("dpvV1491CacheDetail"),hit,miss;
    if(s)txt(s,metricText(last));
    if(b){hit=last?(Number(last.dieHits||0)+Number(last.layoutHits||0)):0;miss=last?(Number(last.dieMisses||0)+Number(last.layoutMisses||0)):0;txt(b,last?("⚡ Native Batch · "+hit+"H/"+miss+"M"):"⚡ Native Batch");}
    if(d){
      if(!last)txt(d,"KHUON_BE + Layout được cache trong Illustrator persistent engine; file chưa Save chỉ cache trong đúng 1 job.");
      else txt(d,"Die "+Number(last.dieHits||0)+" hit / "+Number(last.dieMisses||0)+" miss · Layout "+Number(last.layoutHits||0)+" hit / "+Number(last.layoutMisses||0)+" miss · "+Number(last.cachedDieEntries||0)+" geometry · "+Number(last.cachedLayoutEntries||0)+" layout"+(last.persistent?" · cache qua job":" · cache theo job"));
    }
  }
  function makeUi(){
    if(byId("dpvV1491CachePanel"))return;
    var q=byId("dpvV149Queue"),host=q&&q.parentNode?q.parentNode:qs(".result-column");
    if(!host)return;
    var box=document.createElement("div");box.id="dpvV1491CachePanel";box.className="dpv-v1491-cache";
    box.innerHTML='<div class="dpv-v1491-cache-head"><strong>NATIVE BATCH BRIDGE · GEOMETRY CACHE</strong><span id="dpvV1491CacheState">Cache geometry đang chờ job</span></div><div id="dpvV1491CacheDetail" class="dpv-v1491-cache-detail">KHUON_BE + Layout được cache trong Illustrator persistent engine; file chưa Save chỉ cache trong đúng 1 job.</div>';
    if(q&&q.nextSibling)host.insertBefore(box,q.nextSibling);else host.appendChild(box);
    var conn=qs(".connection");
    if(conn&&!byId("dpvV1491NativeBadge")){var badge=document.createElement("span");badge.id="dpvV1491NativeBadge";badge.className="dpv-v1491-native-badge";badge.title="Native Batch V149.1: prewarm geometry/layout một lần trong Bridge và tái sử dụng cache an toàn.";badge.innerHTML="⚡ Native Batch";conn.insertBefore(badge,conn.firstChild);}
    render(last);
  }
  function parseMetrics(payload){
    var o=null;try{o=JSON.parse(String(payload||"{}"));}catch(e){return null;}
    return o&&o.nativeBatchV1491?o.nativeBatchV1491:null;
  }
  function wrapReceiver(){
    if(wrapped)return;
    var old=window.VDPRO_receive;if(typeof old!=="function")return;
    wrapped=true;
    var receiver=function(operation,payload){var m=parseMetrics(payload);try{old(operation,payload);}finally{if(m){render(m);try{if(window.DPVV149)window.DPVV149.nativeBatchMetrics=m;}catch(e){}}}};
    receiver.__v149wrapped=true; receiver.__v1491wrapped=true; window.VDPRO_receive=receiver;
  }
  function forceVersion(){
    try{document.title="DPV® V149.3 — Job Queue Pro · Diagnostics ZIP · Native Batch Cache";}catch(e){}
    var v=qs(".version-badge");if(v)v.innerHTML="V149.3 · JOB QUEUE PRO";
    var beta=qs(".beta-note");if(beta)beta.innerHTML='<strong>DPV® V149.3 JOB QUEUE PRO + NATIVE BATCH CACHE</strong><br>Job Queue Pro + Diagnostics ZIP · Native Batch/Geometry Cache V149.1 giữ nguyên · Core V101 không đổi.';
  }
  function start(){makeUi();wrapReceiver();forceVersion();setTimeout(function(){makeUi();wrapReceiver();forceVersion();},700);setTimeout(function(){makeUi();wrapReceiver();forceVersion();},2200);}
  window.DPVV1491={version:VERSION,lastMetrics:function(){return last;},render:render};
  if(document.readyState==="loading"){if(document.addEventListener)document.addEventListener("DOMContentLoaded",function(){setTimeout(start,120);},false);else window.attachEvent("onload",function(){setTimeout(start,120);});}else setTimeout(start,120);
})();
