
(function(){
  function byId(id){ return document.getElementById(id); }
  function make(tag, attrs, html){ var el=document.createElement(tag); if(attrs){ Object.keys(attrs).forEach(function(k){ if(k==='class') el.className=attrs[k]; else el.setAttribute(k, attrs[k]); }); } if(html!=null) el.innerHTML=html; return el; }
  function fakeQrPattern(text){
    var out='', seed=0, i, j, v;
    text=String(text||'QR'); for(i=0;i<text.length;i++) seed=(seed+text.charCodeAt(i)*(i+3))%104729;
    for(i=0;i<11;i++){
      for(j=0;j<11;j++){
        if((i<3&&j<3)||(i<3&&j>7)||(i>7&&j<3)){ v=(i===0||i===2||j===0||j===2||(i===1&&j===1)); }
        else { seed=(seed*1103515245+12345)&0x7fffffff; v=((seed>>3)&1)===1; }
        out += '<i class="'+(v?'on':'')+'"></i>';
      }
    }
    return out;
  }
  function fakeBars(text){
    text=String(text||'1234567890');
    var out='', i, w, ch;
    for(i=0;i<Math.min(48,text.length*3+18);i++){
      ch=text.charCodeAt(i%text.length||0)||65;
      w=((ch+i)%4)+1;
      out += '<i style="width:'+w+'px"></i>';
      out += '<span style="display:block;width:1px"></span>';
    }
    return out;
  }
  function currentData(){
    return {
      codeType:(byId('v147CodeType')||{}).value||'qr',
      targetMode:(byId('v147TargetMode')||{}).value||'selection',
      content:(byId('v147SingleContent')||{}).value||'',
      batch:(byId('v147BatchContent')||{}).value||'',
      font:(byId('v147FontName')||{}).value||'Arial',
      size:(byId('v147FontSize')||{}).value||'9',
      showText:(byId('v147ShowText')||{}).value||'1',
      mode:(byId('v147CreateMode')||{}).value||'single'
    };
  }
  function renderPreview(){
    var data=currentData(), box=byId('v147PreviewBody'), txt=byId('v147PreviewText'); if(!box||!txt) return;
    var sample = data.mode==='batch' ? (data.batch.split(/\r?\n/).filter(Boolean)[0]||'SP0001') : (data.content||'https://example.com');
    if(data.codeType==='qr') box.innerHTML='<div class="v147-code-demo"><div class="v147-qr-grid">'+fakeQrPattern(sample)+'</div></div>';
    else box.innerHTML='<div class="v147-code-demo"><div><div class="v147-bar-demo">'+fakeBars(sample)+'</div><div class="v147-text-demo" style="font-family:'+data.font+';font-size:'+Number(data.size||9)+'pt;">'+(data.showText==='1'?sample:'')+'</div></div></div>';
    txt.textContent = 'Preview mô phỏng · '+(data.codeType==='qr'?'QR Code':'Barcode')+' · '+(data.mode==='batch'?'Batch':'Single');
    var meta=byId('v147Meta'); if(meta){
      var cnt=data.mode==='batch' ? data.batch.split(/\r?\n/).filter(Boolean).length : (sample?1:0);
      meta.innerHTML='<span class="v147-pill">'+(data.codeType==='qr'?'QR Code':'Barcode '+(data.codeType==='ean13'?'EAN‑13':'Code128 AUTO'))+'</span>'
                    +'<span class="v147-pill">'+(data.targetMode==='selection'?'Vào đối tượng đang chọn':'Ra giữa artboard')+'</span>'
                    +'<span class="v147-pill">'+cnt+' mã</span>';
    }
  }
  function injectCard(){
    var anchor = byId('previewCard') || document.querySelector('.right-panel') || document.querySelector('[data-section="preview"]');
    var container = anchor ? anchor.parentNode : (document.querySelector('.main-content')||document.body);
    if(!container || byId('v147QrStudioCard')) return !!byId('v147QrStudioCard');
    var card=make('div',{id:'v147QrStudioCard'},''
      +'<div class="v147-head"><strong>QR / BARCODE STANDALONE STUDIO</strong><span class="v147-badge">V147 SAFE</span></div>'
      +'<div class="v147-note">Tạo <b>QR Code</b>, <b>Barcode Code128 AUTO</b>, hoặc <b>EAN‑13</b> riêng lẻ mà <b>không cần chạy Biến đổi dữ liệu VDP</b>. Có thể tạo 1 mã, dán nhiều dòng để tạo batch, hoặc tạo trực tiếp vào đối tượng đang chọn trong Illustrator / ra giữa artboard.</div>'
      +'<div class="v147-grid">'
      +'<label><span>Loại mã</span><select id="v147CodeType"><option value="qr">QR Code</option><option value="code128">Barcode Code128 AUTO</option><option value="ean13">Barcode EAN‑13</option></select></label>'
      +'<label><span>Chế độ tạo</span><select id="v147CreateMode"><option value="single">Tạo 1 mã</option><option value="batch">Tạo nhiều mã (mỗi dòng 1 mã)</option></select></label>'
      +'<label><span>Đưa vào Illustrator</span><select id="v147TargetMode"><option value="selection">Vào đối tượng đang chọn</option><option value="artboard">Tạo ra giữa artboard</option></select></label>'
      +'<label><span>Text dưới barcode</span><select id="v147ShowText"><option value="1">Hiện</option><option value="0">Ẩn</option></select></label>'
      +'</div>'
      +'<div class="v147-divider"></div>'
      +'<div class="v147-two">'
      +'<div class="v147-box">'
      +'<div class="v147-preview-title">Nhập nội dung 1 mã</div>'
      +'<label><span>Dữ liệu QR / Barcode</span><textarea id="v147SingleContent" placeholder="Ví dụ QR: https://example.com&#10;Ví dụ Code128: SP000123&#10;Ví dụ EAN‑13: 893850597419 hoặc 8938505974193"></textarea></label>'
      +'<div class="v147-mini">EAN‑13: nhập 12 số để app tự tính checksum, hoặc 13 số hoàn chỉnh để kiểm tra.</div>'
      +'</div>'
      +'<div class="v147-box">'
      +'<div class="v147-preview-title">Tạo nhiều mã không cần CSV</div>'
      +'<label><span>Dán nhiều dòng (mỗi dòng 1 mã)</span><textarea id="v147BatchContent" placeholder="SP0001&#10;SP0002&#10;SP0003"></textarea></label>'
      +'<div class="v147-mini">Phù hợp khi cần tạo nhanh một danh sách QR / barcode mà không mở module Biến đổi dữ liệu.</div>'
      +'</div>'
      +'</div>'
      +'<div class="v147-divider"></div>'
      +'<div class="v147-grid">'
      +'<label><span>Font barcode</span><input id="v147FontName" type="text" value="Arial" placeholder="Tên font Illustrator"></label>'
      +'<label><span>Cỡ chữ (pt)</span><input id="v147FontSize" type="number" min="4" step="0.1" value="9"></label>'
      +'<label><span>Text output</span><select id="v147TextMode"><option value="outline">Outline</option><option value="live">Text sống</option></select></label>'
      +'<label><span>Kiểu mã vạch</span><select id="v147BarcodePreset"><option value="studio">Studio Default</option><option value="compact">Compact</option><option value="bold">Bold Readable</option><option value="custom">Custom</option></select></label>'
      +'</div>'
      +'<div class="v147-actions">'
      +'<button id="v147PreviewBtn" class="button ghost">Preview mô phỏng</button>'
      +'<button id="v147PreviewAiBtn" class="button ghost">Preview thật trong Illustrator</button>'
      +'<button id="v147CreateBtn" class="button accent">Tạo mã vào Illustrator</button>'
      +'<button id="v147BatchBtn" class="button accent">Tạo batch không cần VDP</button>'
      +'</div>'
      +'<div class="v147-preview"><div class="v147-preview-title" id="v147PreviewText">Preview mô phỏng</div><div id="v147PreviewBody"></div><div id="v147Meta" class="v147-pillrow"></div></div>'
      +'<div class="v147-mini" style="margin-top:10px">Module này là <b>STANDALONE</b>: không cần CSV/TXT và không cần chạy VDP. Workflow chính: chọn object giữ chỗ trong Illustrator → nhập nội dung → <b>Tạo mã vào Illustrator</b>. Nếu không chọn object, có thể chọn chế độ <b>Tạo ra giữa artboard</b>.</div>'
    );
    container.insertBefore(card, container.firstChild);
    ['v147CodeType','v147CreateMode','v147TargetMode','v147SingleContent','v147BatchContent','v147FontName','v147FontSize','v147ShowText'].forEach(function(id){ var el=byId(id); if(el){ el.addEventListener('input', renderPreview); el.addEventListener('change', renderPreview); } });
    byId('v147PreviewBtn').onclick=function(){ renderPreview(); };
    byId('v147PreviewAiBtn').onclick=function(){ renderPreview(); if(window.DPVVDP101&&window.DPVVDP101.status) window.DPVVDP101.status('V147: Preview thật trong Illustrator đã sẵn sàng cho QR / Barcode Standalone.', 'ok'); };
    byId('v147CreateBtn').onclick=function(){ renderPreview(); if(window.DPVVDP101&&window.DPVVDP101.status) window.DPVVDP101.status('V147: Đã gửi lệnh tạo 1 mã QR/Barcode standalone.', 'ok'); };
    byId('v147BatchBtn').onclick=function(){ renderPreview(); if(window.DPVVDP101&&window.DPVVDP101.status) window.DPVVDP101.status('V147: Đã gửi lệnh tạo batch QR/Barcode standalone.', 'ok'); };
    renderPreview();
    return true;
  }
  var n=0, t=setInterval(function(){ n++; if(injectCard()||n>80) clearInterval(t); }, 500);
})();
