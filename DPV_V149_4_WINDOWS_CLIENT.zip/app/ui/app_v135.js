(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function txt(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function add(el,c){if(el&&(' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(el)el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function status(m,k){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}
  function parse(raw){try{return JSON.parse(String(raw||'{}'));}catch(e){return null;}}
  function cloneRecord(o){var n={},k;for(k in o){if(Object.prototype.hasOwnProperty.call(o,k))n[k]=o[k];}return n;}
  function headersOf(records){var out=[],seen={},i,k;for(i=0;i<records.length;i++){for(k in records[i]){if(Object.prototype.hasOwnProperty.call(records[i],k)&&!seen[k]){seen[k]=true;out.push(k);}}}return out;}
  function escCsv(v){v=String(v==null?'':v);return /[",\r\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}
  function toCsv(headers,records){var lines=[],i,j,row;lines.push(headers.map(escCsv).join(','));for(i=0;i<records.length;i++){row=[];for(j=0;j<headers.length;j++)row.push(escCsv(records[i][headers[j]]));lines.push(row.join(','));}return lines.join('\r\n');}
  function padNum(n,w){var neg=Number(n)<0,s=String(Math.abs(Math.floor(Number(n)||0)));while(s.length<w)s='0'+s;return (neg?'-':'')+s;}

  var mode='csv', base={valid:false,path:'',folder:'',name:'',headers:[],records:[]}, oldLoad=null, oldGen=null, restoring=false;

  function readSeq(){
    var start=Math.floor(Number($('v133Start')&&$('v133Start').value)||0),step=Math.max(1,Math.floor(Math.abs(Number($('v133Step')&&$('v133Step').value)||1))),field=String(($('v133Field')&&$('v133Field').value)||'SO_NHAY').replace(/^\s+|\s+$/g,'')||'SO_NHAY';
    return {start:start,step:step,field:field,pad:$('v133Pad')&&$('v133Pad').checked===true,width:Math.max(1,Math.min(12,Math.floor(Number($('v133Width')&&$('v133Width').value)||1))),prefix:String(($('v133Prefix')&&$('v133Prefix').value)||''),suffix:String(($('v133Suffix')&&$('v133Suffix').value)||'')};
  }
  function formatNum(n,c){var core=c.pad?padNum(n,c.width):String(n);return c.prefix+core+c.suffix;}
  function captureBase(){
    if(restoring||!window.DPVVDP101||!window.DPVVDP101.getState||!window.DPVVDP101.getRecords)return false;
    var st=window.DPVVDP101.getState(), rec=window.DPVVDP101.getRecords();
    if(!st||!st.filePath||!rec||!rec.length)return false;
    base.valid=true;base.path=st.filePath;base.folder=st.sourceFolder||'';base.name=st.fileName||'CSV/TXT';base.records=[];
    var i;for(i=0;i<rec.length;i++)base.records.push(cloneRecord(rec[i]));base.headers=headersOf(base.records);return true;
  }
  function restoreBase(){
    if(!base.valid||!oldLoad)return false;
    restoring=true;
    try{oldLoad(JSON.stringify({ok:true,path:base.path,folder:base.folder,name:base.name,text:toCsv(base.headers,base.records)}));}
    finally{restoring=false;}
    return true;
  }
  function hybridInfo(){
    var info=$('v135HybridInfo');if(!info)return;
    var c=readSeq(),n=base.valid?base.records.length:0,last=n?formatNum(c.start+(n-1)*c.step,c):'—';
    info.innerHTML=base.valid?'<b>'+n+' dòng CSV</b> + cột <b>'+c.field+'</b> · '+formatNum(c.start,c)+' → '+last:'Chưa có CSV/TXT nền. Hãy chọn CSV/TXT trước, sau đó DPV sẽ gắn 1 số tự động cho mỗi record.';
    if($('v133End')){$('v133End').disabled=(mode==='hybrid');if(mode==='hybrid'&&n)$('v133End').value=String(c.start+(n-1)*c.step);}
  }
  function applyHybrid(auto){
    try{
      if(!base.valid){ if(!captureBase())throw new Error('Chưa có CSV/TXT nền. Hãy bấm “Chọn CSV / TXT” trước.'); }
      var c=readSeq(), rec=[],i,o,val,headers=base.headers.slice(0),found=false;
      for(i=0;i<headers.length;i++){if(headers[i]===c.field){found=true;break;}}if(!found)headers.push(c.field);
      for(i=0;i<base.records.length;i++){o=cloneRecord(base.records[i]);val=formatNum(c.start+i*c.step,c);o[c.field]=val;rec.push(o);}
      restoring=true;
      try{oldLoad(JSON.stringify({ok:true,path:'',folder:base.folder,name:'CSV + Dãy số · '+base.name+' + '+c.field,text:toCsv(headers,rec)}));}
      finally{restoring=false;}
      if(window.DPVNumberSeqV133&&window.DPVNumberSeqV133.getConfig){/* keep old API untouched */}
      hybridInfo();
      status((auto?'Đã cập nhật':'Đã ghép')+' '+rec.length+' record CSV + dãy số '+c.field+' · '+formatNum(c.start,c)+' → '+formatNum(c.start+(rec.length-1)*c.step,c)+'. Có thể map đồng thời cột CSV và '+c.field+'.','ok');
    }catch(e){status('Không ghép được CSV + dãy số: '+String(e&&e.message?e.message:e),'error');}
  }
  function setVisual(m){
    mode=m;var a=$('v133CsvMode'),b=$('v133SeqMode'),h=$('v135HybridMode'),box=$('v133SeqBox'),tool=$('vdpChooseDataBtn')&&$('vdpChooseDataBtn').parentNode,g=$('v133Generate');
    if(a){rem(a,'active');}if(b){rem(b,'active');}if(h){rem(h,'active');}
    if(m==='csv'){if(a)add(a,'active');if(box)add(box,'v133-hidden');if(tool)rem(tool,'v133-hidden');if(g)txt(g,'Tạo dãy số & dùng ngay');if(base.valid)restoreBase();}
    else if(m==='seq'){if(b)add(b,'active');if(box)rem(box,'v133-hidden');if(tool)add(tool,'v133-hidden');if(g)txt(g,'Tạo dãy số & dùng ngay');}
    else{if(h)add(h,'active');if(box)rem(box,'v133-hidden');if(tool)rem(tool,'v133-hidden');if(g)txt(g,'Ghép dãy số vào CSV hiện tại');captureBase();}
    var hybrid=$('v135HybridInfo');if(hybrid){if(m==='hybrid')rem(hybrid,'v135-hidden');else add(hybrid,'v135-hidden');}
    if($('v133End'))$('v133End').disabled=(m==='hybrid');hybridInfo();
  }
  function wrapLoader(){
    if(!window.DPVVDP101||window.__V135LoaderWrapped)return;window.__V135LoaderWrapped=true;oldLoad=window.DPVVDP101.loadFileResult;
    window.DPVVDP101.loadFileResult=function(raw){
      oldLoad(raw);if(restoring)return;
      var r=parse(raw);
      if(r&&r.ok&&r.path){captureBase();if(mode==='hybrid')window.setTimeout(function(){applyHybrid(true);},0);}
    };
  }
  function makeUI(){
    var sw=$('v133SourceSwitch');if(!sw||$('v135HybridMode'))return false;
    var btn=document.createElement('button');btn.id='v135HybridMode';btn.type='button';btn.innerHTML='CSV + Dãy số';sw.appendChild(btn);
    var box=$('v133SeqBox');if(box){var info=document.createElement('div');info.id='v135HybridInfo';info.className='v135-hybrid-info v135-hidden';box.insertBefore(info,box.firstChild);}
    var csv=$('v133CsvMode'),seq=$('v133SeqMode'),gen=$('v133Generate');
    var oldCsv=csv&&csv.onclick,oldSeq=seq&&seq.onclick;oldGen=gen&&gen.onclick;
    if(csv)csv.onclick=function(){if(oldCsv)oldCsv();setVisual('csv');};
    if(seq)seq.onclick=function(){if(oldSeq)oldSeq();setVisual('seq');};
    btn.onclick=function(){if(oldSeq)oldSeq();setVisual('hybrid');};
    if(gen)gen.onclick=function(){if(mode==='hybrid')applyHybrid(false);else if(oldGen)oldGen();};
    var ids=['v133Start','v133Step','v133Field','v133Prefix','v133Suffix','v133Pad','v133Width'],i,el,prevChange,prevKey;
    for(i=0;i<ids.length;i++){
      el=$(ids[i]);if(!el)continue;prevChange=el.onchange;prevKey=el.onkeyup;
      el.onchange=(function(pc){return function(){if(pc)pc.call(this);if(mode==='hybrid')hybridInfo();};})(prevChange);
      el.onkeyup=(function(pk){return function(){if(pk)pk.call(this);if(mode==='hybrid')hybridInfo();};})(prevKey);
    }
    return true;
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V135 HYBRID DATA · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V135 Hybrid Data · Core V101 Stable</strong><br>VDP cho phép dùng đồng thời CSV/TXT + Dãy số tự động trong cùng record: map tên/địa chỉ từ CSV và SO_NHAY/serial tự động vào các vị trí khác nhau.';
  }
  function expose(){window.DPVHybridV135={getMode:function(){return mode;},hasBase:function(){return base.valid;},apply:function(){applyHybrid(false);},baseCount:function(){return base.records.length||0;}};}
  function start(){wrapLoader();makeUI();captureBase();mark();expose();setVisual('csv');}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();
