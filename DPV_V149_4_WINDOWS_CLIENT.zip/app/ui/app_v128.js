(function(){
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge'); if(v)v.innerHTML='V128 DUPLEX PHYSICAL MIRROR · CORE V101 STABLE';
    var b=q('.beta-note'); if(b)b.innerHTML='<strong>DPV® V128 Duplex Physical Mirror · Core V101 Stable</strong><br>Mặt B phản vị trí vật lý A trái ↔ B phải trong cả Dàn file và VDP Sheet · giữ AI Stay Open V127 · không thay solver V101.';
  }
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);}else mark();
})();
