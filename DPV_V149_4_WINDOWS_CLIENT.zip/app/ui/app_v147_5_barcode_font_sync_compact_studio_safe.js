/* DPV V147.5 BARCODE FONT SYNC + COMPACT STUDIO SAFE
   Additive standalone UI extension.
   Reads Illustrator app.textFonts through the existing PreviewVariableData bridge.
*/
(function(){
  'use strict';
  var pendingFonts=false, fonts=[], receiveWrapped=false;
  function $(id){return document.getElementById(id);}
  function status(msg,kind){
    var el=$('v1474StandaloneStatus');
    if(el){el.textContent=msg;el.className='v1474-status '+(kind||'');}
    try{if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(msg,kind||'');}catch(e){}
  }
  function val(id,d){var e=$(id);return e?e.value:d;}
  function num(id,d){var v=Number(val(id,d));return isNaN(v)?d:v;}
  function hideParent(id){var e=$(id),p;if(!e)return;p=e.parentNode;while(p&&p.tagName&&p.tagName.toLowerCase()!=='label'&&p.id!=='v147QrStudioCard')p=p.parentNode;if(p&&p.tagName&&p.tagName.toLowerCase()==='label')p.style.display='none';}
  function compactDataBoxes(){
    var mode=val('v147CreateMode','single'),one=$('v147SingleContent'),batch=$('v147BatchContent'),p;
    if(one){p=one.parentNode;while(p&&p.className&&String(p.className).indexOf('v147-box')<0)p=p.parentNode;if(p)p.style.display=mode==='batch'?'none':'block';}
    if(batch){p=batch.parentNode;while(p&&p.className&&String(p.className).indexOf('v147-box')<0)p=p.parentNode;if(p)p.style.display=mode==='batch'?'block':'none';}
    var adv=$('v1475BarcodeStyle'),ct=val('v147CodeType','qr');if(adv)adv.style.display=ct==='qr'?'none':'block';
    var sizes=$('v1474SizeControls');if(sizes)sizes.style.display=val('v147TargetMode','selection')==='artboard'?'block':'none';
  }
  function ensureUi(){
    var card=$('v147QrStudioCard'); if(!card)return false;
    if(!$('v1475BarcodeStyle')){
      hideParent('v147FontName');hideParent('v147FontSize');hideParent('v147TextMode');hideParent('v147BarcodePreset');
      var panel=document.createElement('div');panel.id='v1475BarcodeStyle';panel.className='v1475-style';
      panel.innerHTML=''
        +'<div class="v1475-style-head"><div><strong>BARCODE TEXT STYLE</strong><small>Font lấy trực tiếp từ Illustrator</small></div><button id="v1475AdvancedToggle" class="button ghost">Nâng cao</button></div>'
        +'<div class="v1475-basic-grid">'
        +'<label class="v1475-font-wide"><span>Font Illustrator</span><div class="v1475-fontline"><input id="v1475FontSearch" type="text" placeholder="Tìm font…"><select id="v1475FontSelect"><option value="">Đang tải font Illustrator…</option></select><button id="v1475ReloadFonts" class="button ghost" title="Đọc lại font từ Illustrator">↻</button></div></label>'
        +'<label><span>Size chữ (pt)</span><input id="v1475FontSize" type="number" min="4" step="0.1" value="9"></label>'
        +'<label><span>Cách chữ → mã (mm)</span><input id="v1475TextGap" type="number" min="0" step="0.1" value="1.2"></label>'
        +'</div>'
        +'<div id="v1475Advanced" class="v1475-advanced">'
        +'<div class="v1475-advanced-grid">'
        +'<label><span>Tracking</span><input id="v1475Tracking" type="number" step="1" value="0"></label>'
        +'<label><span>Kiểu font</span><select id="v1475Weight"><option value="regular">Regular</option><option value="bold">Bold</option></select></label>'
        +'<label><span>Text output</span><select id="v1475TextMode"><option value="outline">Outline</option><option value="live">Text sống</option></select></label>'
        +'<label><span>Chiều cao vạch (%)</span><input id="v1475BarHeight" type="number" min="40" max="200" step="1" value="100"></label>'
        +'<label><span>Bề ngang mã (%)</span><input id="v1475BarWidth" type="number" min="60" max="140" step="1" value="100"></label>'
        +'<label><span>Quiet zone</span><input id="v1475QuietZone" type="number" min="2" max="20" step="1" value="10"></label>'
        +'</div></div>'
        +'<div class="v1475-font-status" id="v1475FontStatus">Chưa đồng bộ font.</div>';
      var oldGrid=card.querySelector('.v147-grid');
      var dividers=card.querySelectorAll('.v147-divider');
      if(dividers.length)dividers[dividers.length-1].parentNode.insertBefore(panel,dividers[dividers.length-1].nextSibling); else card.appendChild(panel);
      $('v1475AdvancedToggle').onclick=function(){var a=$('v1475Advanced'),open=a.className.indexOf('open')>=0;a.className=open?'v1475-advanced':'v1475-advanced open';this.textContent=open?'Nâng cao':'Thu gọn';};
      $('v1475ReloadFonts').onclick=function(e){if(e)e.preventDefault();requestFonts(true);};
      $('v1475FontSearch').addEventListener('input',filterFonts,false);
      $('v1475FontSelect').addEventListener('change',syncSelectedFont,false);
      ['v1475FontSize','v1475TextGap','v1475Tracking','v1475Weight','v1475TextMode','v1475BarHeight','v1475BarWidth','v1475QuietZone'].forEach(function(id){var e=$(id);if(e)e.addEventListener('change',syncLegacyFields,false);});
    }
    var mode=$('v147CreateMode'),type=$('v147CodeType'),target=$('v147TargetMode');
    if(mode&&!mode.__v1475){mode.__v1475=true;mode.addEventListener('change',compactDataBoxes,false);}
    if(type&&!type.__v1475){type.__v1475=true;type.addEventListener('change',compactDataBoxes,false);}
    if(target&&!target.__v1475){target.__v1475=true;target.addEventListener('change',compactDataBoxes,false);}
    compactDataBoxes();
    syncFromLegacy();
    overrideCreateButtons();
    wrapReceive();
    /* V147.7.8: no automatic giant font-list request; remote search handles fonts. */
    return true;
  }
  function syncFromLegacy(){
    var f=$('v147FontName'),s=$('v147FontSize'),tm=$('v147TextMode');
    if(s&&$('v1475FontSize')&&!$('v1475FontSize').__init){$('v1475FontSize').value=s.value||9;$('v1475FontSize').__init=true;}
    if(tm&&$('v1475TextMode')&&!$('v1475TextMode').__init){$('v1475TextMode').value=tm.value||'outline';$('v1475TextMode').__init=true;}
    if(f&&$('v1475FontSelect')&&!$('v1475FontSelect').getAttribute('data-wanted'))$('v1475FontSelect').setAttribute('data-wanted',f.value||'Arial');
  }
  function syncLegacyFields(){
    var f=$('v147FontName'),s=$('v147FontSize'),tm=$('v147TextMode'),sel=$('v1475FontSelect');
    if(f&&sel&&sel.value)f.value=sel.value;
    if(s&&$('v1475FontSize'))s.value=$('v1475FontSize').value;
    if(tm&&$('v1475TextMode'))tm.value=$('v1475TextMode').value;
    try{var ev=document.createEvent('HTMLEvents');ev.initEvent('input',true,false);if(f)f.dispatchEvent(ev);}catch(e){}
  }
  function syncSelectedFont(){
    syncLegacyFields();
    var sel=$('v1475FontSelect'),opt=sel&&sel.options[sel.selectedIndex],st=$('v1475FontStatus');
    if(st&&opt)st.textContent='Đang chọn: '+(opt.getAttribute('data-family')||'')+' · '+sel.value+(opt.getAttribute('data-style')?' · '+opt.getAttribute('data-style'):'');
  }
  function requestFonts(manual){
    if(!window.DPVVDP101||typeof window.DPVVDP101.bridgeCall!=='function'){if(manual)status('Bridge Illustrator chưa sẵn sàng.','error');return;}
    pendingFonts=true;var st=$('v1475FontStatus');if(st)st.textContent='Đang đọc font từ Illustrator…';
    try{window.DPVVDP101.bridgeCall('PreviewVariableData',[JSON.stringify({standaloneFontListV1475:true})]);}catch(e){pendingFonts=false;if(st)st.textContent='Không đọc được font: '+(e.message||String(e));}
  }
  function populateFonts(list){
    fonts=list||[];var sel=$('v1475FontSelect'),st=$('v1475FontStatus'),wanted=sel?sel.getAttribute('data-wanted'):'';if(!sel)return;
    sel.innerHTML='';var opt=document.createElement('option');opt.value='';opt.textContent='— Chọn font Illustrator —';sel.appendChild(opt);
    for(var i=0;i<fonts.length;i++){
      var f=fonts[i]||{},o=document.createElement('option');o.value=String(f.name||f.family||'');o.textContent=String(f.family||f.name||'')+(f.style?' · '+f.style:'');o.setAttribute('data-family',String(f.family||''));o.setAttribute('data-style',String(f.style||''));o.setAttribute('data-search',(String(f.family||'')+' '+String(f.name||'')+' '+String(f.style||'')).toLowerCase());sel.appendChild(o);
    }
    if(wanted){for(i=1;i<sel.options.length;i++){if(sel.options[i].value===wanted||sel.options[i].getAttribute('data-family')===wanted){sel.selectedIndex=i;break;}}}
    if(sel.selectedIndex<=0&&sel.options.length>1)sel.selectedIndex=1;
    syncSelectedFont();if(st)st.textContent='Đã đồng bộ '+fonts.length+' font từ Illustrator.';
  }
  function filterFonts(){
    var q=String(val('v1475FontSearch','')).toLowerCase(),sel=$('v1475FontSelect'),current=sel?sel.value:'';if(!sel)return;
    for(var i=1;i<sel.options.length;i++){var o=sel.options[i],ok=!q||String(o.getAttribute('data-search')||'').indexOf(q)>=0;o.style.display=ok?'':'none';}
    if(current)sel.value=current;
  }
  function buildCfg(){
    syncLegacyFields();
    var mode=val('v147CreateMode','single'),raw=mode==='batch'?val('v147BatchContent',''):val('v147SingleContent',''),values;
    if(mode==='batch')values=String(raw||'').split(/\r?\n/).map(function(s){return s.replace(/^\s+|\s+$/g,'');}).filter(function(s){return !!s;});
    else values=[String(raw||'').replace(/^\s+|\s+$/g,'')].filter(function(s){return !!s;});
    return {
      standaloneV1474:true,codeType:val('v147CodeType','qr'),targetMode:val('v147TargetMode','selection'),values:values,
      fontName:val('v1475FontSelect',val('v147FontName','Arial')),fontSize:num('v1475FontSize',9),showText:Number(val('v147ShowText','1')),
      textMode:val('v1475TextMode','outline'),fontWeight:val('v1475Weight','regular'),tracking:num('v1475Tracking',0),textGapMm:num('v1475TextGap',1.2),
      barHeightPercent:num('v1475BarHeight',100),barWidthPercent:num('v1475BarWidth',100),quietZone:num('v1475QuietZone',10),textAlign:'center',
      widthMm:num('v1474WidthMm',50),heightMm:num('v1474HeightMm',20),columns:num('v1474Columns',4),gapMm:num('v1474GapMm',5)
    };
  }
  function sendCreate(preview,forceBatch){
    var c=buildCfg();if(forceBatch){var m=$('v147CreateMode');if(m){m.value='batch';c=buildCfg();compactDataBoxes();}}
    if(!c.values.length){status('Chưa nhập nội dung QR/Barcode.','error');return false;}
    if(!window.DPVVDP101||typeof window.DPVVDP101.bridgeCall!=='function'){status('Bridge Illustrator chưa sẵn sàng.','error');return false;}
    status((preview?'Đang Preview':'Đang tạo')+' '+c.values.length+' mã · '+(c.codeType==='qr'?'QR':c.codeType==='ean13'?'EAN‑13':'Code128')+'…','work');
    try{window.DPVVDP101.bridgeCall('PreviewVariableData',[JSON.stringify(c)]);}catch(e){status('Không gửi được lệnh: '+(e.message||String(e)),'error');}
    return false;
  }
  function overrideCreateButtons(){
    var p=$('v147PreviewAiBtn'),c=$('v147CreateBtn'),b=$('v147BatchBtn');
    if(p&&!p.__v1475){p.__v1475=true;p.onclick=function(e){if(e)e.preventDefault();return sendCreate(true,false);};}
    if(c&&!c.__v1475){c.__v1475=true;c.onclick=function(e){if(e)e.preventDefault();return sendCreate(false,false);};}
    if(b&&!b.__v1475){b.__v1475=true;b.onclick=function(e){if(e)e.preventDefault();return sendCreate(false,true);};}
  }
  function wrapReceive(){
    if(receiveWrapped||typeof window.VDPRO_receive!=='function')return false;
    receiveWrapped=true;var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){
      if(op==='vdpPreview'){
        var r=null;try{r=JSON.parse(String(payload||'{}'));}catch(e){}
        if(r&&r.standaloneFontListV1475){pendingFonts=false;if(r.ok===false){var st=$('v1475FontStatus');if(st)st.textContent='Lỗi đọc font: '+String(r.error||'');}else populateFonts(r.fonts||[]);return;}
      }
      return old.apply(window,arguments);
    };
    return true;
  }
  var tries=0,timer=setInterval(function(){tries++;ensureUi();wrapReceive();if(tries>180)clearInterval(timer);},400);
  document.addEventListener('click',function(){setTimeout(function(){ensureUi();wrapReceive();},25);},false);
})();
