/* DPV V147.7.3 STANDALONE NO-FONT-BLOCK BRIDGE SAFE
   Cross-platform Mac + Windows.
   Fixes:
   1) final standalone create handler + response handling (no stuck "Dang tao...")
   2) one canonical PostScript font state, independent of older dropdown/browser layers
   3) lightweight font search: max 30 rendered results, no 2000 live samples
   4) EAN-13 / Code128 validation before Bridge call
*/
(function(){
  'use strict';
  var VERSION='V147.7.7';
  var fonts=[], selected=null, fontsPending=false, fontTimer=null, createPending=false, createTimer=null, receiveInstalled=false, cacheLoaded=false;
  var MAX_RESULTS=40;
  var FONT_CACHE_KEY='dpv_v14777_fonts_full_v1', FONT_SELECTED_KEY='dpv_v14773_font_selected_v1';

  function $(id){return document.getElementById(id);}
  function s(v){return String(v==null?'':v);}
  function trim(v){return s(v).replace(/^\s+|\s+$/g,'');}
  function low(v){return trim(v).toLowerCase();}
  function esc(v){return s(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
  function num(id,d){var e=$(id),v=Number(e&&e.value);return isNaN(v)?d:v;}
  function val(id,d){var e=$(id);return e?e.value:d;}
  function emit(el,name){if(!el)return;try{var ev=document.createEvent('HTMLEvents');ev.initEvent(name,true,false);el.dispatchEvent(ev);}catch(x){try{if(el.fireEvent)el.fireEvent('on'+name);}catch(y){}}}
  function status(msg,kind){
    var el=$('v1474StandaloneStatus');
    if(el){el.textContent=msg;el.className='v1474-status '+(kind||'');}
    try{if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(msg,kind||'');}catch(e){}
  }

  function loadFontCache(){
    var raw,arr,ps,i;
    if(cacheLoaded)return;
    cacheLoaded=true;
    try{
      raw=window.localStorage?localStorage.getItem(FONT_CACHE_KEY):'';
      if(raw){arr=JSON.parse(raw);fonts=normalizeFonts(arr||[]);}
      ps=window.localStorage?localStorage.getItem(FONT_SELECTED_KEY):'';
      if(ps&&fonts.length){for(i=0;i<fonts.length;i++){if(fonts[i].name===ps){selected=fonts[i];window.__DPV14773_FONT_PS=ps;break;}}}
    }catch(e){}
  }
  function saveFontCache(){
    try{if(window.localStorage){localStorage.setItem(FONT_CACHE_KEY,JSON.stringify(fonts||[]));if(selected&&selected.name)localStorage.setItem(FONT_SELECTED_KEY,selected.name);}}catch(e){}
  }
  function parseNativeResult(v){
    var r=null;
    if(v==null||v==='')return null;
    if(typeof v==='object'&&v.ok!==undefined)return v;
    try{r=JSON.parse(s(v));}catch(e){}
    return r;
  }
  function finishFontPending(){
    fontsPending=false;
    if(fontTimer){clearTimeout(fontTimer);fontTimer=null;}
    var rb=$('v14772Reload');if(rb)rb.disabled=false;
  }
  function invokePreview(cfg,onDirect,onError){
    var payload=JSON.stringify(cfg),ret;
    try{
      if(window.DPVNative&&typeof window.DPVNative.invoke==='function'){
        ret=window.DPVNative.invoke('PreviewVariableData',[payload]);
        if(ret&&typeof ret.then==='function'){
          ret.then(function(v){var r=parseNativeResult(v);if(r&&onDirect)onDirect(r);}).catch(function(e){if(onError)onError((e&&e.message)||s(e));});
        }else{var rr=parseNativeResult(ret);if(rr&&onDirect)onDirect(rr);}
        return true;
      }
      if(window.external&&typeof window.external.PreviewVariableData!=='undefined'){
        window.external.PreviewVariableData(payload);
        return true;
      }
      if(window.DPVVDP101&&typeof window.DPVVDP101.bridgeCall==='function'){
        window.DPVVDP101.bridgeCall('PreviewVariableData',[payload],function(v){var r=parseNativeResult(v);if(r&&onDirect)onDirect(r);});
        return true;
      }
    }catch(e){if(onError)onError((e&&e.message)||s(e));return false;}
    if(onError)onError('Bridge Illustrator chua san sang.');
    return false;
  }

  function ensureUi(){
    var panel=$('v1475BarcodeStyle'), line, box, old71, old7, oldSearch, oldSelect;
    if(!panel) return false;

    /* Hide all older font browser layers. They remain loaded but no longer own the final state. */
    old71=$('v14771Picker'); if(old71) old71.style.display='none';
    old7=$('v1477FontBrowser'); if(old7) old7.style.display='none';
    oldSearch=$('v1475FontSearch'); if(oldSearch) oldSearch.style.display='none';
    oldSelect=$('v1475FontSelect'); if(oldSelect) oldSelect.style.display='none';

    if(!$('v14772FontPicker')){
      line=panel.querySelector('.v1475-fontline');
      box=document.createElement('div');
      box.id='v14772FontPicker';
      box.className='v14772-picker';
      box.innerHTML=''
        +'<div class="v14772-top">'
        +'<button type="button" id="v14772Selected" class="v14772-selected"><b id="v14772SelectedFamily">Chon font Illustrator</b><span id="v14772SelectedMeta">Family / Style / PostScript</span><i>v</i></button>'
        +'<button type="button" id="v14772Reload" class="v14772-reload" title="Doc lai font tu Illustrator">↻</button>'
        +'</div>'
        +'<div id="v14772Browser" class="v14772-browser" style="display:none">'
        +'<input id="v14772Search" type="text" autocomplete="off" placeholder="Tim font, vi du: UTM Avo, Myriad Pro...">'
        +'<div id="v14772Info" class="v14772-info">Dang doc font Illustrator...</div>'
        +'<div id="v14772List" class="v14772-list"></div>'
        +'</div>';
      if(line&&line.parentNode) line.parentNode.insertBefore(box,line);
      else panel.insertBefore(box,panel.firstChild);

      $('v14772Selected').onclick=function(e){if(e&&e.preventDefault)e.preventDefault();toggleBrowser();return false;};
      $('v14772Reload').onclick=function(e){if(e&&e.preventDefault)e.preventDefault();requestFonts(true);return false;};
      $('v14772Search').onkeyup=function(){renderFonts();};
      $('v14772Search').oninput=function(){renderFonts();};
      $('v14772List').onclick=function(e){fontListClick(e||window.event);};
    }
    updateSelected();
    return true;
  }

  function toggleBrowser(){
    var b=$('v14772Browser'), q=$('v14772Search'), info=$('v14772Info');
    if(!b)return;
    if(b.style.display==='none'){
      loadFontCache();b.style.display='block';renderFonts();
      if(!fonts.length&&info)info.textContent='Chua nap font. Bam nut ↻ de cap nhat font tu Illustrator.';
      try{q.focus();}catch(e){}
    } else b.style.display='none';
  }
  function closeBrowser(){var b=$('v14772Browser');if(b)b.style.display='none';}

  function normalizeFonts(list){
    var out=[], seen={},i,f,name,family,style,key;
    list=list||[];
    for(i=0;i<list.length;i++){
      f=list[i]||{}; name=trim(f.name||f.family); family=trim(f.family||name); style=trim(f.style||'Regular');
      if(!name)continue; key=low(name); if(seen[key])continue; seen[key]=1;
      out.push({name:name,family:family,style:style,search:low(family+' '+style+' '+name)});
    }
    out.sort(function(a,b){
      var aa=low(a.family),bb=low(b.family);if(aa<bb)return-1;if(aa>bb)return 1;
      aa=low(a.style);bb=low(b.style);return aa<bb?-1:aa>bb?1:0;
    });
    return out;
  }
  function chooseInitial(){
    var wanted=trim(window.__DPV14773_FONT_PS || val('v147FontName','') || ( $('v1475FontSelect') ? $('v1475FontSelect').value : '' )), i, f, best=null;
    if(wanted){
      for(i=0;i<fonts.length;i++){f=fonts[i];if(f.name===wanted){best=f;break;}}
      if(!best)for(i=0;i<fonts.length;i++){f=fonts[i];if(low(f.family)===low(wanted)){best=f;break;}}
    }
    if(!best){
      for(i=0;i<fonts.length;i++){f=fonts[i];if(low(f.family)==='arial'&&/regular|roman|normal/i.test(f.style)){best=f;break;}}
    }
    if(!best&&fonts.length)best=fonts[0];
    if(best)commitFont(best,false);
  }
  function commitFont(f,close){
    var legacy=$('v147FontName'), sel=$('v1475FontSelect'), st=$('v1475FontStatus'), opt;
    if(!f)return;
    selected=f; window.__DPV14773_FONT_PS=f.name;
    try{if(window.localStorage)localStorage.setItem(FONT_SELECTED_KEY,f.name);}catch(eCache){}
    if(legacy){legacy.value=f.name;emit(legacy,'input');emit(legacy,'change');}
    /* Keep legacy select tiny: only the committed PostScript option. */
    if(sel){
      try{
        sel.innerHTML='';
        opt=document.createElement('option');opt.value=f.name;opt.text=f.family+' / '+f.style;
        opt.setAttribute('data-family',f.family);opt.setAttribute('data-style',f.style);sel.add(opt);sel.selectedIndex=0;sel.style.display='none';
        emit(sel,'change');
      }catch(e0){}
    }
    if(st)st.textContent='Font: '+f.family+' / '+f.style+' / '+f.name;
    updateSelected();
    if(close!==false)closeBrowser();
  }
  function updateSelected(){
    var fam=$('v14772SelectedFamily'),meta=$('v14772SelectedMeta'),btn=$('v14772Selected');
    if(!fam||!meta)return;
    if(selected){
      fam.textContent=selected.family;
      meta.textContent=selected.style+' / '+selected.name;
      try{btn.style.fontFamily='"'+selected.family.replace(/"/g,'\\"')+'", Arial, sans-serif';}catch(e){}
    }else{
      fam.textContent='Chon font Illustrator';
      meta.textContent='Family / Style / PostScript';
      if(btn)btn.style.fontFamily='';
    }
  }
  function renderFonts(){
    var q=low(val('v14772Search','')),list=$('v14772List'),info=$('v14772Info'),html='',i,f,count=0;
    if(!list)return;
    if(!fonts.length){list.innerHTML='<div class="v14772-empty">Chua co danh sach font. Bam ↻ de doc font tu Illustrator.</div>';if(info)info.textContent='0 font';return;}
    for(i=0;i<fonts.length&&count<MAX_RESULTS;i++){
      f=fonts[i];if(q&&f.search.indexOf(q)<0)continue;count++;
      html+='<button type="button" class="v14772-font'+(selected&&selected.name===f.name?' selected':'')+'" data-ps="'+esc(f.name)+'">'
        +'<span class="v14772-font-name"><b>'+esc(f.family)+'</b><small>'+esc(f.style)+'</small></span>'
        +'<span class="v14772-sample" style="font-family:\''+esc(f.family)+'\', Arial, sans-serif">Sample 123</span>'
        +'<span class="v14772-ps">'+esc(f.name)+'</span></button>';
    }
    list.innerHTML=html||'<div class="v14772-empty">Khong tim thay font phu hop.</div>';
    if(info)info.textContent=(q?'Ket qua: ':'Hien thi: ')+count+' / '+fonts.length+' font';
  }
  function fontListClick(e){
    var t=e.target||e.srcElement, ps, i;
    while(t&&t!==$('v14772List')&&!(t.getAttribute&&t.getAttribute('data-ps')))t=t.parentNode;
    if(!t||t===$('v14772List'))return;
    ps=t.getAttribute('data-ps');
    for(i=0;i<fonts.length;i++)if(fonts[i].name===ps){commitFont(fonts[i],true);return;}
  }

  function requestFonts(manual){
    if(fontsPending){if(manual)status('Dang cap nhat danh sach font tu Illustrator. Vui long cho hoan tat.','work');return;}
    fontsPending=true;
    var info=$('v14772Info'),rb=$('v14772Reload');if(info)info.textContent='Dang cap nhat font tu Illustrator...';if(rb)rb.disabled=true;
    if(manual)status('Dang cap nhat font Illustrator. Tam thoi khong tao ma cho den khi cap nhat xong.','work');
    fontTimer=setTimeout(function(){
      if(fontsPending){finishFontPending();if(info)info.textContent='Cap nhat font qua lau. Danh sach cache van duoc giu.';status('Cap nhat font qua lau. Ban van co the tao ma bang font da chon/cache.','error');}
    },60000);
    invokePreview({standaloneFontListV1475:true,requester:'V14773'},function(r){
      if(!r||!r.standaloneFontListV1475)return;
      finishFontPending();
      if(r.ok===false){if(info)info.textContent='Loi font Illustrator: '+s(r.error||'Khong ro loi.');return;}
      fonts=normalizeFonts(r.fonts||[]);saveFontCache();chooseInitial();renderFonts();
      if(info)info.textContent='Da cap nhat FULL '+fonts.length+' font/style tu Illustrator.';
      var st=$('v1475FontStatus');if(st)st.textContent='Da dong bo FULL '+fonts.length+' font/style tu Illustrator · khong gioi han 2000.';
      status('Da cap nhat font Illustrator. Tao ma san sang.','ok');
    },function(err){finishFontPending();if(info)info.textContent='Loi doc font: '+s(err);status('Khong doc duoc font Illustrator: '+s(err),'error');});
  }

  function eanCheck(s12){
    var i,sum=0,n;for(i=0;i<12;i++){n=Number(s12.charAt(i));sum+=(i%2===0)?n:n*3;}return String((10-(sum%10))%10);
  }
  function validateValues(codeType,values){
    var i,v,cd;
    for(i=0;i<values.length;i++){
      v=values[i];
      if(!v)return 'Dong '+(i+1)+': noi dung rong.';
      if(codeType==='ean13'){
        if(!/^\d{12,13}$/.test(v))return 'EAN-13 dong '+(i+1)+' phai co dung 12 hoac 13 chu so. Gia tri hien tai: '+v;
        if(v.length===13){cd=eanCheck(v.substr(0,12));if(v.charAt(12)!==cd)return 'EAN-13 dong '+(i+1)+' sai checksum. So cuoi dung phai la '+cd+'.';}
      }else if(codeType==='code128'){
        for(var j=0;j<v.length;j++){var c=v.charCodeAt(j);if(c<32||c>126)return 'Code128 dong '+(i+1)+' chi ho tro ASCII 32-126.';}
      }
    }
    return '';
  }
  function buildCfg(forceBatch){
    var mode=forceBatch?'batch':val('v147CreateMode','single'),raw=mode==='batch'?val('v147BatchContent',''):val('v147SingleContent',''),values;
    if(mode==='batch')values=s(raw).split(/\r?\n/).map(function(x){return trim(x);}).filter(function(x){return !!x;});
    else values=[trim(raw)].filter(function(x){return !!x;});
    return {
      standaloneV1474:true,
      requester:'V14773',
      codeType:val('v147CodeType','qr'),
      targetMode:val('v147TargetMode','selection'),
      values:values,
      fontName:selected?selected.name:(window.__DPV14773_FONT_PS||val('v147FontName','Arial')),
      fontSize:num('v1475FontSize',num('v147FontSize',9)),
      showText:Number(val('v147ShowText','1')),
      textMode:val('v1475TextMode',val('v147TextMode','outline')),
      fontWeight:val('v1475Weight','regular'),
      tracking:num('v1475Tracking',0),
      textGapMm:num('v1475TextGap',1.2),
      barHeightPercent:num('v1475BarHeight',100),
      barWidthPercent:num('v1475BarWidth',100),
      quietZone:num('v1475QuietZone',10),
      textAlign:'center',
      widthMm:num('v1474WidthMm',50),
      heightMm:num('v1474HeightMm',20),
      columns:num('v1474Columns',4),
      gapMm:num('v1474GapMm',5)
    };
  }
  function finishPending(){
    createPending=false;
    if(createTimer){clearTimeout(createTimer);createTimer=null;}
    setButtonsBusy(false);
  }
  function setButtonsBusy(busy){
    var ids=['v147PreviewAiBtn','v147CreateBtn','v147BatchBtn'],i,e;
    for(i=0;i<ids.length;i++){e=$(ids[i]);if(e){e.disabled=!!busy;}}
  }
  function handleCreateResult(r){
    if(!r||!r.standaloneV1474)return false;
    finishPending();
    if(r.ok===false)status('Tao ma loi: '+s(r.error||'Khong ro loi Illustrator.'),'error');
    else status('Da tao '+s(r.created||0)+' ma '+s(r.codeType||'')+' trong Illustrator / '+s(r.documentName||''),'ok');
    return true;
  }
  function sendCreate(preview,forceBatch){
    var c=buildCfg(!!forceBatch),err;
    if(createPending){status('Illustrator dang xu ly lenh truoc. Vui long cho ket qua.','work');return false;}
    if(fontsPending){status('Danh sach font dang cap nhat. Cho cap nhat xong roi bam Tao ma de tranh 2 lenh Bridge chong nhau.','work');return false;}
    if(!c.values.length){status('Chua nhap noi dung QR/Barcode.','error');return false;}
    err=validateValues(c.codeType,c.values);if(err){status(err,'error');return false;}
    createPending=true;setButtonsBusy(true);
    status((preview?'Dang Preview':'Dang tao')+' '+c.values.length+' ma '+(c.codeType==='qr'?'QR':c.codeType==='ean13'?'EAN-13':'Code128')+'...','work');
    createTimer=setTimeout(function(){
      if(createPending){finishPending();status('Illustrator khong tra ket qua tao ma sau 35 giay. Thu bam Ket noi lai, sau do tao ma lai.','error');}
    },35000);
    invokePreview(c,function(r){
      if(handleCreateResult(r))return;
      if(r&&createPending&&r.ok===false){finishPending();status('Bridge Illustrator bao loi: '+s(r.error||'Khong ro loi.'),'error');}
    },function(err){finishPending();status('Khong gui duoc lenh tao ma: '+s(err),'error');});
    return false;
  }

  function installReceive(){
    if(receiveInstalled&&window.VDPRO_receive===window.__DPV14773Receive)return true;
    if(typeof window.VDPRO_receive!=='function')return false;
    var old=window.VDPRO_receive;
    function receive(op,payload){
      var r=null,info;
      if(op==='vdpPreview'){
        try{r=JSON.parse(s(payload||'{}'));}catch(e){}
        if(r&&r.standaloneFontListV1475){
          finishFontPending();
          info=$('v14772Info');
          if(r.ok===false){if(info)info.textContent='Loi font Illustrator: '+s(r.error||'Khong ro loi.');}
          else{fonts=normalizeFonts(r.fonts||[]);saveFontCache();chooseInitial();renderFonts();if(info)info.textContent='Da cap nhat FULL '+fonts.length+' font/style tu Illustrator.';var st=$('v1475FontStatus');if(st)st.textContent='Da dong bo FULL '+fonts.length+' font/style tu Illustrator · khong gioi han 2000.';}
          return;
        }
        if(r&&r.standaloneV1474){handleCreateResult(r);return;}
        if(createPending&&r){
          finishPending();
          if(r.ok===false)status('Bridge da phan hoi nhung Standalone bi loi: '+s(r.error||'Khong ro loi.'),'error');
          else status('Bridge da phan hoi nhung host Illustrator chua vao nhanh Standalone. Dong/mo lai Illustrator va cai lai V147.7.3.','error');
          return;
        }
        if(fontsPending&&r){
          finishFontPending();info=$('v14772Info');if(info)info.textContent='Host Illustrator chua tra danh sach font Standalone.';
          return;
        }
      }
      return old.apply(window,arguments);
    }
    window.__DPV14773Receive=receive;
    window.VDPRO_receive=receive;
    receiveInstalled=true;
    return true;
  }

  function bindFinalButtons(){
    var p=$('v147PreviewAiBtn'),c=$('v147CreateBtn'),b=$('v147BatchBtn');
    if(p){p.onclick=function(e){if(e&&e.preventDefault)e.preventDefault();return sendCreate(true,false);};p.__v14773=true;}
    if(c){c.onclick=function(e){if(e&&e.preventDefault)e.preventDefault();return sendCreate(false,false);};c.__v14773=true;}
    if(b){b.onclick=function(e){if(e&&e.preventDefault)e.preventDefault();return sendCreate(false,true);};b.__v14773=true;}
  }

  /* Capture phase wins over old onclick handlers on both standalone buttons. */
  function captureClick(e){
    e=e||window.event;var t=e.target||e.srcElement,id=t&&t.id;
    if(id!=='v147PreviewAiBtn'&&id!=='v147CreateBtn'&&id!=='v147BatchBtn')return;
    if(e.__dpv14773Handled)return;
    e.__dpv14773Handled=true;
    if(e.preventDefault)e.preventDefault();
    if(e.stopImmediatePropagation)e.stopImmediatePropagation();else if(e.stopPropagation)e.stopPropagation();
    sendCreate(id==='v147PreviewAiBtn',id==='v147BatchBtn');
    return false;
  }

  function boot(){
    if(!ensureUi())return false;
    installReceive();bindFinalButtons();
    /* Compact old select immediately to prevent lag if older module already rendered 2000 options. */
    var sel=$('v1475FontSelect');
    if(sel&&sel.options&&sel.options.length>50&&!fonts.length){
      /* Keep current option only until fresh list arrives into the final picker. */
      var cur=sel.value,txt=sel.options[sel.selectedIndex]?sel.options[sel.selectedIndex].text:cur;
      try{sel.innerHTML='';var o=document.createElement('option');o.value=cur;o.text=txt||cur;sel.add(o);sel.style.display='none';}catch(e){}
    }
    loadFontCache();
    if(fonts.length){chooseInitial();renderFonts();var info=$('v14772Info');if(info&&!fontsPending)info.textContent='Font cache FULL: '+fonts.length+' font/style · bam ↻ khi can cap nhat.';}
    else {var inf=$('v14772Info');if(inf&&!fontsPending)inf.textContent='Chua co cache FULL · bam ↻ de doc toan bo font/style tu Illustrator.';}
    return true;
  }

  if(document.addEventListener)document.addEventListener('click',captureClick,true);
  var tries=0,iv=setInterval(function(){tries++;boot();if(tries>240)clearInterval(iv);},300);
  setTimeout(boot,20);
})();