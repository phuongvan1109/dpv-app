(function () {
  function byId(id){ return document.getElementById(id); }
  function addClass(el, c){ if(!el)return; if((' '+el.className+' ').indexOf(' '+c+' ')<0) el.className += (el.className?' ':'')+c; }
  function removeClass(el, c){ if(!el)return; el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,''); }
  function safeStoreGet(k){ try{return window.localStorage?localStorage.getItem(k):null;}catch(e){return null;} }
  function safeStoreSet(k,v){ try{if(window.localStorage)localStorage.setItem(k,v);}catch(e){} }
  function textOf(el){ return el ? (el.textContent || el.innerText || '') : ''; }
  var toastTimer=null;
  function toast(msg){
    var t=byId('dpvToast'); if(!t)return; if('textContent' in t)t.textContent=msg; else t.innerText=msg;
    addClass(t,'show'); if(toastTimer)clearTimeout(toastTimer); toastTimer=setTimeout(function(){removeClass(t,'show');},2200);
  }
  function setTheme(theme){
    var dark=theme==='dark';
    if(dark)addClass(document.body,'dpv-dark'); else removeClass(document.body,'dpv-dark');
    var sw=byId('dpvThemeSwitch'); if(sw)sw.setAttribute('aria-pressed',dark?'true':'false');
    var light=byId('dpvThemeLightLabel'), d=byId('dpvThemeDarkLabel');
    if(light)light.style.fontWeight=dark?'650':'900'; if(d)d.style.fontWeight=dark?'900':'650';
    safeStoreSet('dpv.theme', dark?'dark':'light');
  }
  function getTheme(){ var v=safeStoreGet('dpv.theme'); return v==='dark'?'dark':'light'; }
  function insertShell(){
    if(byId('dpvSidebar'))return;
    var sidebar=document.createElement('aside'); sidebar.id='dpvSidebar'; sidebar.className='dpv-sidebar';
    sidebar.innerHTML=''
      +'<div class="dpv-side-brand"><img src="../../assets/icon/DPV-logo-128.png" alt="DPV"><div class="dpv-side-brand-copy"><strong>DPV<sup>®</sup></strong><small>PRINT WORKFLOW</small></div></div>'
      +'<nav class="dpv-nav">'
      +'<button class="dpv-nav-btn active" data-nav="main"><span class="dpv-nav-icon">▦</span>Dàn file</button>'
      +'<button class="dpv-nav-btn" data-nav="vdp"><span class="dpv-nav-icon">⛁</span>Biến đổi dữ liệu</button>'
      +'<button class="dpv-nav-btn" data-nav="combine"><span class="dpv-nav-icon">▤</span>Combine PDF</button>'
      +'<button class="dpv-nav-btn" data-nav="preset"><span class="dpv-nav-icon">▱</span>Thư viện preset</button>'
      +'<button class="dpv-nav-btn" data-nav="settings"><span class="dpv-nav-icon">⚙</span>Cài đặt</button>'
      +'</nav><div class="dpv-side-spacer"></div>'
      +'<div class="dpv-side-card"><strong><span class="dpv-side-dot"></span>Core V101 STABLE</strong>Engine dàn được khóa ổn định.<br>V102 chỉ nâng cấp giao diện.</div>'
      +'<div class="dpv-side-footer"><span class="dpv-avatar">DP</span><div class="dpv-side-user"><strong>DPV Desktop</strong><small>Windows + macOS Intel</small></div></div>';
    document.body.insertBefore(sidebar, document.body.firstChild);

    var top=document.querySelector ? document.querySelector('.topbar') : null;
    if(top){
      var search=document.createElement('div'); search.className='dpv-search-wrap'; search.innerHTML='<div class="dpv-search"><input id="dpvSearch" type="text" placeholder="Tìm nhanh chức năng, thông số..."><span class="dpv-search-key">Ctrl K</span></div>';
      var conn=top.querySelector ? top.querySelector('.connection') : null;
      if(conn)top.insertBefore(search,conn); else top.appendChild(search);
      if(conn){
        var theme=document.createElement('div'); theme.className='dpv-theme-toggle';
        theme.innerHTML='<span id="dpvThemeLightLabel" class="dpv-theme-label">☀ Light</span><button id="dpvThemeSwitch" class="dpv-theme-switch" type="button" aria-label="Đổi Light/Dark"><span class="dpv-theme-knob"></span></button><span id="dpvThemeDarkLabel" class="dpv-theme-label">Dark</span>';
        conn.appendChild(theme);
      }
    }

    var ws=document.querySelector ? document.querySelector('.workspace') : null;
    if(ws){
      var cols=document.createElement('div'); cols.className='workspace-columns';
      var kids=[],i; for(i=0;i<ws.children.length;i++){ if((' '+ws.children[i].className+' ').indexOf(' column ')>=0)kids.push(ws.children[i]); }
      for(i=0;i<kids.length;i++)cols.appendChild(kids[i]);
      var ov=document.createElement('div'); ov.className='dpv-overview'; ov.innerHTML=''
        +'<section class="dpv-hero"><div class="dpv-hero-kicker">DPV® WORKSPACE · Illustrator Automation</div><h2 id="dpvHeroTitle">Dàn file nhanh, chính xác & ổn định</h2><p id="dpvHeroText">True-Shape · Exact Gap · PON · Variable Data · PDF Combine</p><div class="dpv-hero-tags"><span class="dpv-chip">Core: V101 STABLE</span><span class="dpv-chip">UI: V103 LIVE PREVIEW</span><span id="dpvHeroSource" class="dpv-chip">Chưa có nguồn</span></div></section>'
        +'<div class="dpv-kpis"><div class="dpv-kpi"><label>SỐ CON DỰ KIẾN</label><strong id="dpvKpiCount">0</strong><small>Bố cục hiện tại</small></div><div class="dpv-kpi"><label>HIỆU SUẤT</label><strong id="dpvKpiEff">0%</strong><small id="dpvKpiEffHint">Đang chờ tính</small></div><div class="dpv-kpi"><label>ILLUSTRATOR</label><strong id="dpvKpiAi">Offline</strong><small id="dpvKpiAiHint">Bridge status</small></div></div>';
      ws.insertBefore(ov,ws.firstChild); ws.appendChild(cols);
    }
    var settings=document.createElement('div'); settings.id='dpvSettings'; settings.className='dpv-settings';
    settings.innerHTML='<h3>Cài đặt giao diện</h3><div class="dpv-settings-row"><span>Chế độ màu</span><button id="dpvSettingsTheme" class="button tiny">Đổi Light / Dark</button></div><div class="dpv-settings-row"><span>Engine dàn</span><strong>V101 STABLE · khóa</strong></div><div class="dpv-settings-row"><span>Giao diện</span><strong>V103 LIVE PREVIEW</strong></div>';
    document.body.appendChild(settings);
    var toastEl=document.createElement('div'); toastEl.id='dpvToast'; toastEl.className='dpv-toast'; document.body.appendChild(toastEl);
  }
  function setActiveNav(name){
    var btns=document.querySelectorAll?document.querySelectorAll('.dpv-nav-btn'):[]; var i;
    for(i=0;i<btns.length;i++){ if(btns[i].getAttribute('data-nav')===name)addClass(btns[i],'active'); else removeClass(btns[i],'active'); }
  }
  function openVdp(){ var b=byId('vdpOpenBtn'); if(b&&b.click)b.click(); setActiveNav('vdp'); }
  function bindNav(){
    var btns=document.querySelectorAll?document.querySelectorAll('.dpv-nav-btn'):[]; var i;
    for(i=0;i<btns.length;i++)btns[i].onclick=function(){
      var n=this.getAttribute('data-nav');
      if(n==='main'){ var p=byId('vdpPanel'); if(p)addClass(p,'hidden'); setActiveNav('main'); }
      else if(n==='vdp'){ openVdp(); }
      else if(n==='combine'){ openVdp(); setTimeout(function(){ var c=byId('vdpCombineExistingBtn'); if(c&&c.scrollIntoView)c.scrollIntoView(); toast('Combine PDF nằm trong Variable Data.'); },80); }
      else if(n==='preset'){ toast('Thư viện preset: giao diện đã sẵn sàng, engine preset chưa được thêm để giữ V101 ổn định.'); }
      else if(n==='settings'){ var s=byId('dpvSettings'); if(s){ if((' '+s.className+' ').indexOf(' open ')>=0)removeClass(s,'open'); else addClass(s,'open'); } setActiveNav('settings'); }
    };
    var close=byId('vdpCloseBtn'); if(close)close.addEventListener?close.addEventListener('click',function(){setActiveNav('main');}):null;
  }
  function bindTheme(){
    var sw=byId('dpvThemeSwitch'), st=byId('dpvSettingsTheme');
    function flip(){ setTheme(document.body.className.indexOf('dpv-dark')>=0?'light':'dark'); }
    if(sw)sw.onclick=flip; if(st)st.onclick=flip; setTheme(getTheme());
  }
  function bindSearch(){
    var inp=byId('dpvSearch'); if(!inp)return;
    document.onkeydown=function(e){ e=e||window.event; if((e.ctrlKey||e.metaKey)&&(e.keyCode===75)){ try{e.preventDefault();}catch(x){} inp.focus(); return false; } };
    inp.onkeydown=function(e){ e=e||window.event; if(e.keyCode!==13)return; var q=(inp.value||'').toLowerCase().replace(/^\s+|\s+$/g,''); if(!q)return;
      var nodes=document.querySelectorAll?document.querySelectorAll('label,strong,.button,.panel-title'):[]; var i,t;
      for(i=0;i<nodes.length;i++){ t=textOf(nodes[i]).toLowerCase(); if(t.indexOf(q)>=0){ try{nodes[i].scrollIntoView({block:'center'});}catch(x){nodes[i].scrollIntoView();} toast('Đã tìm: '+textOf(nodes[i]).replace(/^\s+|\s+$/g,'')); return; } }
      toast('Không tìm thấy “'+inp.value+'”');
    };
  }
  function syncKpis(){
    var pc=byId('previewCount'), eff=byId('efficiency'), cd=byId('connectionDot'), ct=byId('connectionText');
    var kc=byId('dpvKpiCount'), ke=byId('dpvKpiEff'), ka=byId('dpvKpiAi'), kh=byId('dpvKpiAiHint'), eh=byId('dpvKpiEffHint');
    if(kc&&pc)kc.innerHTML=textOf(pc)||'0'; if(ke&&eff)ke.innerHTML=textOf(eff)||'0%';
    var online=cd&&(' '+cd.className+' ').indexOf(' online ')>=0; if(ka)ka.innerHTML=online?'Online':'Offline'; if(kh)kh.innerHTML=online?'Illustrator đã kết nối':'Chờ kết nối';
    if(eh&&eff){ var n=parseFloat(textOf(eff)); eh.innerHTML=isNaN(n)?'Đang chờ tính':(n>=80?'Rất tốt':(n>=60?'Tốt':'Có thể tối ưu')); }
    var sl=document.querySelectorAll?document.querySelectorAll('.source-name'):[]; var hs=byId('dpvHeroSource'); if(hs)hs.innerHTML=sl&&sl.length?('Nguồn: '+textOf(sl[0])):'Chưa có nguồn';
  }
  function updateVersion(){ var v=document.querySelector?document.querySelector('.version-badge'):null; if(v)v.innerHTML='V103 LIVE PREVIEW · CORE V101 STABLE'; var beta=document.querySelector?document.querySelector('.beta-note'):null; if(beta)beta.innerHTML='<strong>DPV® V103 LIVE PREVIEW · CORE V101 STABLE</strong><br>Light/Dark hiện đại · sidebar dashboard mới · engine dàn V101 được giữ nguyên, không thay thuật toán.'; }
  function start(){ insertShell(); updateVersion(); bindTheme(); bindNav(); bindSearch(); syncKpis(); setInterval(syncKpis,1600); }
  if(document.readyState==='loading'){ if(document.addEventListener)document.addEventListener('DOMContentLoaded',start); else window.attachEvent('onload',start); } else start();
})();
