/* DPV V143.1 — PRODUCTION RECOVERY STARTUP-SAFE ADD-ON
   Stable-base rules:
   - Read-only observers on existing VDP status/buttons.
   - Does NOT replace/override Core V101, VDPRO_receive, Bridge, VDP, Cut & Stack or Duplex handlers.
   - Writes only its own localStorage keys and changes From/To only after explicit user Recovery action.
   - Sheet recovery resumes at the first record of the first sheet that was NOT confirmed exported.
   - Cut & Stack is never resumed mid-range because re-partitioning would break stack order.
*/
(function () {
  'use strict';
  var STORE = 'dpv.v143.productionRecovery.safe';
  var HISTORY = 'dpv.v143.productionRecovery.history';
  var MAX_HISTORY = 12;
  var active = null;
  var statusObserver = null;
  var statusObserved = null;
  var scanTimer = null;
  var progressTimer = null;
  var booted = false;
  var versionDone = false;
  var bound = {};
  var panelReady = false;

  function $(id) { return document.getElementById(id); }
  function q(sel, root) { return (root || document).querySelector ? (root || document).querySelector(sel) : null; }
  function qa(sel, root) { return (root || document).querySelectorAll ? (root || document).querySelectorAll(sel) : []; }
  function trim(s) { return String(s == null ? '' : s).replace(/^\s+|\s+$/g, ''); }
  function intVal(id, def) { var e=$(id), n=e?parseInt(e.value,10):NaN; return isNaN(n)?def:n; }
  function text(el, s) { if (!el) { return; } if ('textContent' in el) { el.textContent = s; } else { el.innerText = s; } }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function now() { return new Date().getTime(); }
  function storeGet(key, def) { try { var raw=window.localStorage?localStorage.getItem(key):null; return raw?JSON.parse(raw):def; } catch(e) { return def; } }
  function storeSet(key, val) { try { if(window.localStorage){localStorage.setItem(key,JSON.stringify(val)); return true;} } catch(e) {} return false; }
  function fire(el, type) { if(!el)return; try{var ev=document.createEvent('HTMLEvents');ev.initEvent(type,true,false);el.dispatchEvent(ev);}catch(e){try{el.fireEvent('on'+type);}catch(x){}} }
  function click(el) { try { if (el && el.click) { el.click(); return true; } } catch(e) {} return false; }
  function fmtTime(ms) {
    ms=Math.max(0,Number(ms)||0); var sec=Math.round(ms/1000), m=Math.floor(sec/60), s=sec%60, h=Math.floor(m/60); m=m%60;
    if(h>0)return h+'h '+m+'m'; if(m>0)return m+'m '+s+'s'; return s+'s';
  }
  function fmtClock(ts) { var d=new Date(ts||now()); function p(n){return n<10?'0'+n:String(n);} return p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds()); }
  function getState() { try { return window.DPVVDP101&&window.DPVVDP101.getState?window.DPVVDP101.getState():null; } catch(e){ return null; } }
  function getSlots() { try { var l=window.DPVCoreV101&&window.DPVCoreV101.getLayout?window.DPVCoreV101.getLayout():null; return l&&l.items?l.items.length:0; } catch(e){ return 0; } }
  function outputPath() { var e=$('vdpOutputPath'); return e?String(e.value||''):''; }
  function isChecked(id) { var e=$(id); return !!(e&&e.checked); }
  function currentMode(sourceId) {
    if(sourceId==='v1422Build')return 'cutstack';
    if(sourceId==='v1421SmartBuild')return 'record-smart';
    if(sourceId==='vdpSheetBuildBtn')return 'sheet';
    if(sourceId==='vdpBuildBtn')return 'record';
    if(isChecked('vdpModeSheet'))return 'sheet';
    return 'record';
  }
  function modeLabel(m) { return m==='sheet'?'VDP SHEET':(m==='cutstack'?'CUT & STACK':(m==='record-smart'?'VDP SMART':'PDF RECORD')); }
  function snapshotStart(sourceId) {
    var st=getState(), cnt=st&&st.recordCount?Number(st.recordCount):intVal('vdpRecordCount',0), from=Math.max(1,intVal('vdpFrom',1)), to=intVal('vdpTo',cnt||from);
    if(cnt>0)to=Math.min(cnt,Math.max(from,to||cnt)); else to=Math.max(from,to);
    var mode=currentMode(sourceId), slots=(mode==='sheet'||mode==='cutstack')?getSlots():0;
    active={
      version:143,id:now(),mode:mode,sourceId:sourceId,from:from,to:to,total:Math.max(0,to-from+1),recordCount:cnt||0,
      outputPath:outputPath(),fileName:(st&&st.fileName)||'',filePrefix:($('vdpFilePrefix')?String($('vdpFilePrefix').value||''):''),
      startedAt:now(),updatedAt:now(),state:'running',lastDone:from-1,currentDone:0,lastSafeRecord:from-1,
      sheetSlots:slots,sheetDone:0,sheetTotal:slots?Math.ceil(Math.max(0,to-from+1)/slots):0,lastStatus:'Đã bắt đầu '+modeLabel(mode)+'.',
      combineRecord:isChecked('vdpCombinePdf'),combineSheets:isChecked('vdpSheetCombine')
    };
    persistActive(); pushHistory(active, true); render(); window.setTimeout(parseStatus,35);
  }
  function persistActive() { if(active){active.updatedAt=now();storeSet(STORE,active);} }
  function clearActiveStorage() { try{if(window.localStorage)localStorage.removeItem(STORE);}catch(e){} }
  function pushHistory(s, replace) {
    if(!s)return; var a=storeGet(HISTORY,[]), i, copy={}; for(i in s){if(s.hasOwnProperty(i))copy[i]=s[i];}
    if(replace&&a.length&&a[0].id===copy.id)a[0]=copy; else { for(i=a.length-1;i>=0;i--){if(a[i]&&a[i].id===copy.id)a.splice(i,1);} a.unshift(copy); }
    if(a.length>MAX_HISTORY)a.length=MAX_HISTORY; storeSet(HISTORY,a);
  }
  function restoreStored() {
    var s=storeGet(STORE,null); if(!s||!s.id)return;
    /* A running session left in storage means the app/bridge was interrupted. */
    if(s.state==='running'){s.state='interrupted';s.lastStatus='Phiên trước bị gián đoạn trước khi DPV nhận hoàn tất.';}
    active=s; pushHistory(active,true); persistActive();
  }
  function markDone(statusText) {
    if(!active)return; active.state='done';active.lastDone=active.to;active.lastSafeRecord=active.to;active.currentDone=active.total;active.lastStatus=statusText||'Hoàn tất.';active.finishedAt=now();persistActive();pushHistory(active,true);render();
  }
  function markError(statusText) {
    if(!active)return; active.state='error';active.lastStatus=statusText||'Batch báo lỗi.';active.finishedAt=now();persistActive();pushHistory(active,true);render();
  }
  function parseStatus() {
    var e=$('vdpStatus'), s=trim(e?(e.textContent||e.innerText||''):''); if(!s||!active)return;
    if(s===active.__seenStatus)return;active.__seenStatus=s;active.lastStatus=s;active.updatedAt=now();
    var m, current, total, rec, sd, st;
    /* Record pipeline: progress is pushed AFTER a successful batch step. */
    m=/Đang xuất record\s+(\d+)\s*\/\s*(\d+).*?record dữ liệu\s+(\d+)/i.exec(s);
    if(m && (active.mode==='record'||active.mode==='record-smart')) {
      current=parseInt(m[1],10)||0;total=parseInt(m[2],10)||active.total;rec=parseInt(m[3],10)||active.lastDone;
      active.currentDone=Math.max(active.currentDone||0,current);active.total=total||active.total;active.lastDone=Math.max(active.lastDone||active.from-1,rec);active.lastSafeRecord=active.lastDone;
    }
    /* Sheet wrappers expose a sheet checkpoint only when an output sheet was actually created. */
    m=/VDP Sheet\s*·\s*record\s+(\d+)\s*\/\s*(\d+)(?:.*?(?:vừa|đã)\s*xuất tờ\s+(\d+)\s*\/\s*(\d+))?/i.exec(s);
    if(m && (active.mode==='sheet'||active.mode==='cutstack')) {
      current=parseInt(m[1],10)||0;total=parseInt(m[2],10)||active.total;active.currentDone=Math.max(active.currentDone||0,current);active.total=total||active.total;
      if(m[3]) { sd=parseInt(m[3],10)||0;st=parseInt(m[4],10)||active.sheetTotal;active.sheetDone=Math.max(active.sheetDone||0,sd);active.sheetTotal=st||active.sheetTotal;
        if(active.sheetSlots>0){active.lastSafeRecord=Math.min(active.to,active.from+(active.sheetDone*active.sheetSlots)-1);active.lastDone=active.lastSafeRecord;}
      }
    }
    /* V122 may show progress before V114 text. This is visual only, not a safe checkpoint. */
    m=/Đang gửi\s+(\d+)\s+record/i.exec(s); if(m&&active.currentDone===0){active.total=parseInt(m[1],10)||active.total;}
    if(/Hoàn tất VDP Sheet|Hoàn tất\s*:?\s*\d+\s+record|Combine trực tiếp hoàn tất/i.test(s)){markDone(s);return;}
    if(/VDP Sheet lỗi|Batch VDP.*lỗi|Không chạy được VDP Sheet|Không chạy được|\blỗi\b|\berror\b|\bfailed\b|null is not an object/i.test(s) && !/0 lỗi/i.test(s)){markError(s);return;}
    persistActive();pushHistory(active,true);render();
  }
  function percent() {
    if(!active||!active.total)return 0; var d=active.currentDone||0; if(active.state==='done')d=active.total; return Math.max(0,Math.min(100,Math.round(d*1000/active.total)/10));
  }
  function etaText() {
    if(!active||active.state!=='running'||!active.currentDone)return '—'; var elapsed=now()-active.startedAt, per=elapsed/Math.max(1,active.currentDone), remain=Math.max(0,active.total-active.currentDone); return fmtTime(per*remain);
  }
  function recoveryStart() {
    if(!active)return null;
    if(active.mode==='cutstack')return null;
    if(active.mode==='sheet') {
      if(!(active.sheetSlots>0))return null;
      return Math.max(active.from,Math.min(active.to+1,active.from+(active.sheetDone||0)*active.sheetSlots));
    }
    return Math.max(active.from,Math.min(active.to+1,(active.lastSafeRecord||active.from-1)+1));
  }
  function safeReason() {
    if(!active)return 'Chưa có checkpoint.';
    if(active.mode==='cutstack')return 'CUT & STACK phụ thuộc toàn bộ range; không resume giữa chừng để tránh sai thứ tự xấp.';
    var n=recoveryStart(); if(n==null)return 'Chưa xác định được điểm tiếp tục.'; if(n>active.to)return 'Batch đã tới cuối range.';
    if(active.mode==='sheet')return 'Tiếp tục từ record '+n+' = đầu tờ chưa được xác nhận xuất. Tờ đang dang dở sẽ được chạy lại đầy đủ.';
    return 'Tiếp tục từ record '+n+'. Progress record chỉ được ghi sau khi bước Illustrator trả OK.';
  }
  function renderHistory() {
    var box=$('v143History');if(!box)return;var a=storeGet(HISTORY,[]),h='',i,x,state;
    if(!a.length){box.innerHTML='<div class="v143-empty">Chưa có phiên recovery.</div>';return;}
    for(i=0;i<a.length&&i<6;i++){x=a[i];state=x.state||'info';h+='<div class="v143-h-row"><span class="v143-h-state '+esc(state)+'"></span><div><b>'+esc(modeLabel(x.mode))+' · '+esc(String(x.from))+'→'+esc(String(x.to))+'</b><small>'+esc(fmtClock(x.startedAt))+' · '+esc(x.lastStatus||'')+'</small></div></div>';}
    box.innerHTML=h;
  }
  function render() {
    var card=$('v143RecoveryPanel'); if(!card)return;
    if(!active){
      text($('v143Mode'),'CHƯA CÓ JOB');text($('v143Range'),'—');text($('v143Checkpoint'),'—');text($('v143Eta'),'—');text($('v143Percent'),'0%');
      var bar=$('v143Bar');if(bar)bar.style.width='0%';text($('v143Reason'),'DPV sẽ tự ghi checkpoint khi bạn chạy PDF record, VDP Sheet hoặc Cut & Stack.');
      if($('v143Resume'))$('v143Resume').disabled=true;if($('v143RestoreRange'))$('v143RestoreRange').disabled=true;renderHistory();return;
    }
    var p=percent(), rs=recoveryStart(), state=active.state||'info';
    text($('v143Mode'),modeLabel(active.mode)+' · '+String(state).toUpperCase());
    text($('v143Range'),active.from+' → '+active.to);
    if(active.mode==='sheet'||active.mode==='cutstack')text($('v143Checkpoint'),(active.sheetDone||0)+'/'+(active.sheetTotal||0)+' tờ · safe '+(active.lastSafeRecord>=active.from?active.lastSafeRecord:'—'));
    else text($('v143Checkpoint'),active.lastSafeRecord>=active.from?String(active.lastSafeRecord):'chưa có');
    text($('v143Eta'),active.state==='running'?etaText():(active.finishedAt?fmtTime(active.finishedAt-active.startedAt):'—'));
    text($('v143Percent'),p+'%');var bar=$('v143Bar');if(bar)bar.style.width=p+'%';
    text($('v143Reason'),safeReason());
    var resume=$('v143Resume');if(resume){resume.disabled=(active.mode==='cutstack'||rs==null||rs>active.to||active.state==='done'||active.state==='running');text(resume,active.mode==='sheet'?'Tiếp tục từ tờ an toàn':'Tiếp tục từ checkpoint');}
    var rr=$('v143RestoreRange');if(rr)rr.disabled=false;
    var badge=$('v143StateBadge');if(badge){badge.className='v143-state '+state;text(badge,state==='running'?'ĐANG CHẠY':(state==='done'?'HOÀN TẤT':(state==='error'?'LỖI':(state==='interrupted'?'GIÁN ĐOẠN':'CHECKPOINT'))));}
    renderHistory();
  }
  function restoreRangeOnly() {
    if(!active)return;var f=$('vdpFrom'),t=$('vdpTo');if(f){f.value=String(active.from);fire(f,'change');}if(t){t.value=String(active.to);fire(t,'change');}
    if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status('V143.1: Đã khôi phục range gốc '+active.from+' → '+active.to+'. Chưa tự chạy job.','ok');
  }
  function resume() {
    if(!active||active.state==='running'||active.mode==='cutstack')return;var n=recoveryStart(), btn;
    if(n==null||n>active.to)return;
    var f=$('vdpFrom'),t=$('vdpTo');if(f){f.value=String(n);fire(f,'change');}if(t){t.value=String(active.to);fire(t,'change');}
    /* Combining only the resumed tail would create a misleading partial combined PDF. Disable it for Recovery only. */
    if(active.mode==='sheet'){
      var cb=$('vdpSheetCombine');if(cb&&cb.checked){cb.checked=false;fire(cb,'change');}
      var mode=$('vdpModeSheet');if(mode&&!mode.checked){mode.checked=true;fire(mode,'change');try{if(mode.click)mode.click();}catch(e0){}}
      btn=$('vdpSheetBuildBtn');
    } else {
      var cr=$('vdpCombinePdf');if(cr&&cr.checked){cr.checked=false;fire(cr,'change');}
      var mr=$('vdpModeRecord');if(mr&&!mr.checked){mr.checked=true;fire(mr,'change');try{if(mr.click)mr.click();}catch(e1){}}
      btn=(active.mode==='record-smart'&&$('v1421SmartBuild'))?$('v1421SmartBuild'):$('vdpBuildBtn');
    }
    if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status('V143.1 Recovery: tiếp tục từ '+n+' → '+active.to+'. Combine tự động tạm tắt để không tạo PDF gộp thiếu phần đầu; có thể Combine các PDF sau khi hoàn tất.','work');
    window.setTimeout(function(){click(btn);},80);
  }
  function clearCheckpoint() {
    active=null;clearActiveStorage();render();
  }
  function bindButton(id) {
    var b=$(id);if(!b||bound[id]===b)return false;bound[id]=b;
    var fn=function(){window.setTimeout(function(){snapshotStart(id);},0);};
    if(b.addEventListener)b.addEventListener('click',fn,false); else if(b.attachEvent)b.attachEvent('onclick',fn);
    return true;
  }
  function bindStatus() {
    var s=$('vdpStatus');
    if(!window.MutationObserver)return false;
    if(s&&statusObserver&&statusObserved===s)return true;
    if(statusObserver){try{statusObserver.disconnect();}catch(e0){}}
    statusObserver=null;statusObserved=s||null;
    if(!s)return false;
    try{
      statusObserver=new MutationObserver(function(){parseStatus();});
      statusObserver.observe(s,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class']});
      return true;
    }catch(e1){statusObserver=null;statusObserved=null;return false;}
  }
  function insertPanel() {
    if($('v143RecoveryPanel')){panelReady=true;return true;}
    var st=$('vdpStatus');if(!st||!st.parentNode)return false;
    var d=document.createElement('div');d.id='v143RecoveryPanel';d.className='v143-recovery';d.innerHTML=''
      +'<div class="v143-head"><div><b>PRODUCTION RECOVERY · CHECKPOINT SAFE</b><span>V143.1 startup-safe · không thay Bridge/Core/handler cũ</span></div><span id="v143StateBadge" class="v143-state idle">CHECKPOINT</span></div>'
      +'<div class="v143-kpis"><div><span>MODE</span><b id="v143Mode">CHƯA CÓ JOB</b></div><div><span>RANGE</span><b id="v143Range">—</b></div><div><span>CHECKPOINT</span><b id="v143Checkpoint">—</b></div><div><span>ETA / TIME</span><b id="v143Eta">—</b></div></div>'
      +'<div class="v143-progress"><i id="v143Bar"></i><strong id="v143Percent">0%</strong></div>'
      +'<div id="v143Reason" class="v143-reason">DPV sẽ tự ghi checkpoint khi batch bắt đầu.</div>'
      +'<div class="v143-actions"><button type="button" id="v143Resume" class="primary" disabled>Tiếp tục từ checkpoint</button><button type="button" id="v143RestoreRange" disabled>Khôi phục range gốc</button><button type="button" id="v143Clear">Xóa checkpoint</button></div>'
      +'<div class="v143-safety"><b>Quy tắc an toàn:</b> PDF record resume từ record đã hoàn tất cuối + 1. VDP Sheet chỉ resume ở <b>đầu tờ chưa xuất</b>. <b>CUT & STACK không resume giữa chừng</b> vì sẽ thay cấu trúc xấp.</div>'
      +'<details class="v143-history-box"><summary>Lịch sử Recovery gần đây</summary><div id="v143History" class="v143-history"></div></details>';
    st.parentNode.insertBefore(d,st.nextSibling);panelReady=true;
    $('v143Resume').onclick=resume;$('v143RestoreRange').onclick=restoreRangeOnly;$('v143Clear').onclick=clearCheckpoint;
    render();return true;
  }
  function version() {
    if(versionDone)return;versionDone=true;
    var v=q('.version-badge'), badge='V143.1 RECOVERY STARTUP SAFE · CORE V101 STABLE'; if(v)text(v,badge);
    try{document.title='DPV® V143.1 — Recovery Startup Safe · Core V101 Stable';}catch(e){}
    var beta=q('.beta-note');if(beta)beta.innerHTML='<strong>DPV® V143.1 Recovery Startup Safe · Core V101 Stable</strong><br>Checkpoint + ETA + Resume an toàn. Startup-safe: không theo dõi toàn bộ BODY, không can thiệp splash/load, không thay Core/Bridge/VDP ổn định.';
  }
  function scanBindings() {
    try{insertPanel();}catch(e0){}
    try{bindStatus();}catch(e1){}
    try{bindButton('vdpBuildBtn');}catch(e2){}
    try{bindButton('vdpSheetBuildBtn');}catch(e3){}
    try{bindButton('v1421SmartBuild');}catch(e4){}
    try{bindButton('v1422Build');}catch(e5){}
  }
  function init() {
    if(booted)return;booted=true;
    try{restoreStored();}catch(e0){}
    try{version();}catch(e1){}
    scanBindings();
    /* V143.1 STARTUP SAFE: a light periodic scan replaces the V143 body-wide
       MutationObserver. The old observer reacted to its own panel rendering and
       could create a MutationObserver feedback loop that starved the splash/load UI. */
    scanTimer=window.setInterval(function(){scanBindings();},1400);
    progressTimer=window.setInterval(function(){
      if(active&&active.state==='running'){try{parseStatus();}catch(e2){}try{if($('v143RecoveryPanel'))render();}catch(e3){}}
    },1000);
    window.DPVRecoveryV143={
      version:'143.1',startupSafe:true,getActive:function(){return active;},recoveryStart:recoveryStart,
      restoreRange:restoreRangeOnly,resume:resume,clear:clearCheckpoint,parseStatus:parseStatus,scan:scanBindings
    };
  }
  function bootAfterStableLoad(){window.setTimeout(init,850);}
  /* Do not execute Recovery initialization during DOMContentLoaded.
     Core V142.5 finishes its normal window load/splash path first. */
  if(document.readyState==='complete'){bootAfterStableLoad();}
  else if(window.addEventListener){window.addEventListener('load',bootAfterStableLoad,false);}
  else{window.attachEvent('onload',bootAfterStableLoad);}
}());
