(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function text(el,v){if(el){if("textContent" in el)el.textContent=v;else el.innerText=v;}}
  function sync(){
    var mode=$("outputMode"), p=$("outputPrintStart"), d=$("outputDieStart"), btn=$("buildBtn");
    if(!mode)return;
    var forced=($("finishCropMarks")&&$("finishCropMarks").checked)||($("duplexMode")&&$("duplexMode").checked);
    if(forced){mode.value="print_only"; mode.disabled=true;} else {mode.disabled=false;}
    if(p)p.disabled=false;
    if(d)d.disabled=(mode.value==="print_only"||forced);
    if(btn){
      if(mode.value==="print_only") text(btn,"Dàn Link & xuất FILE IN");
      else text(btn,"Dàn Link & xuất IN + KHUÔN");
    }
  }
  function init(){
    var ids=["outputMode","finishCropMarks","duplexMode"],i,e;
    for(i=0;i<ids.length;i++){e=$(ids[i]);if(e)e.addEventListener("change",sync);}
    sync();
    try{document.title="DPV® V148.9.2 — Output Mode · Custom Number Start · Auto Update";}catch(ex){}
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();
