
(function(){
  function add(){
    var btn=document.getElementById('diePreviewBtn');
    if(!btn||document.getElementById('v1476DiePreviewNote')) return !!btn;
    var note=document.createElement('div');
    note.id='v1476DiePreviewNote';
    note.style.marginTop='8px';
    note.style.padding='9px 11px';
    note.style.border='1px solid #bfe7d4';
    note.style.borderRadius='12px';
    note.style.background='#f4fff9';
    note.style.fontSize='12px';
    note.style.lineHeight='1.45';
    note.style.color='#376258';
    note.innerHTML='<b>DIE PREVIEW · V147.6 TRUE KHUON</b><br>Mở xem trước khuôn ưu tiên geometry <b>KHUON_BE thật</b>, không dùng Fast Preview từ artwork/shape cache. Build/Export không thay đổi.';
    var p=btn.parentNode; if(p&&p.parentNode) p.parentNode.insertBefore(note,p.nextSibling);
    return true;
  }
  var n=0,t=setInterval(function(){n++;if(add()||n>60)clearInterval(t);},500);
})();
