(function(){
  "use strict";
  function $(id){ return document.getElementById(id); }
  function txt(el,v){ if(!el)return; if('textContent' in el)el.textContent=v; else el.innerText=v; }
  function vstatus(m,k){
    if(window.DPVVDP101 && typeof window.DPVVDP101.status==='function') window.DPVVDP101.status(m,k||'');
  }
  function parse(raw){ try{return JSON.parse(String(raw||'{}'));}catch(e){return {ok:false,error:'Phản hồi dữ liệu không hợp lệ: '+e.message};} }

  var pending=false, watchdog=0;
  function resetButton(){
    pending=false;
    if(watchdog){window.clearTimeout(watchdog);watchdog=0;}
    var b=$('vdpChooseDataBtn');
    if(b){b.disabled=false;txt(b,'Chọn CSV / TXT');}
  }
  function armWatchdog(){
    if(watchdog)window.clearTimeout(watchdog);
    watchdog=window.setTimeout(function(){
      if(!pending)return;
      resetButton();
      vstatus('Không nhận được phản hồi từ cửa sổ chọn dữ liệu. Hãy thử lại.','error');
    },180000);
  }
  function callAsyncPicker(){
    try{
      if(window.DPVNative && typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke('ChooseVariableDataAsyncV120',[]).catch(function(e){resetButton();vstatus('Không mở được CSV/TXT: '+((e&&e.message)||String(e)),'error');});
        return true;
      }
      if(window.external && typeof window.external.ChooseVariableDataAsyncV120!=='undefined'){
        window.external.ChooseVariableDataAsyncV120();
        return true;
      }
    }catch(e){ resetButton(); vstatus('Windows Bridge lỗi khi mở CSV/TXT: '+((e&&e.message)||String(e)),'error'); return false; }
    resetButton();vstatus('DPV Bridge chưa sẵn sàng.','error');return false;
  }
  function callReload(path){
    try{
      if(window.DPVNative && typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke('ReadVariableDataFileV120',[path]).then(handlePayload).catch(function(e){vstatus('Đọc lại thất bại: '+((e&&e.message)||String(e)),'error');});
        return;
      }
      if(window.external && typeof window.external.ReadVariableDataFileV120!=='undefined'){
        handlePayload(window.external.ReadVariableDataFileV120(path));return;
      }
      vstatus('DPV Bridge chưa sẵn sàng.','error');
    }catch(e){vstatus('Đọc lại thất bại: '+((e&&e.message)||String(e)),'error');}
  }
  function handlePayload(payload){
    resetButton();
    var r=parse(payload);
    if(r.cancelled){vstatus('Đã hủy chọn dữ liệu.','');return;}
    if(!r.ok){vstatus(r.error||'Không đọc được CSV/TXT.','error');return;}
    if(!window.DPVVDP101 || typeof window.DPVVDP101.loadFileResult!=='function'){
      vstatus('VDP loader chưa sẵn sàng. Hãy đóng/mở lại cửa sổ Biến đổi dữ liệu.','error');return;
    }
    window.DPVVDP101.loadFileResult(payload);
  }
  function wrapReceiver(){
    if(window.__V120ReceiveWrapped)return;
    window.__V120ReceiveWrapped=true;
    var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){
      if(op==='vdpDataSelectedV120'){
        handlePayload(payload);
        return;
      }
      if(old) return old(op,payload);
    };
  }
  function bind(){
    var old=$('vdpChooseDataBtn');
    if(old && old.parentNode){
      var btn=old.cloneNode(true);
      btn.id='vdpChooseDataBtn';
      btn.className=(btn.className||'')+' dpv-v120-async-csv';
      old.parentNode.replaceChild(btn,old);
      btn.onclick=function(ev){
        ev=ev||window.event;
        try{if(ev.preventDefault)ev.preventDefault();if(ev.stopPropagation)ev.stopPropagation();ev.cancelBubble=true;}catch(x){}
        if(pending)return false;
        pending=true;btn.disabled=true;txt(btn,'Đang chọn...');
        vstatus('Đang mở cửa sổ chọn CSV/TXT…','work');
        armWatchdog();
        callAsyncPicker();
        return false;
      };
    }
    var reload=$('vdpReloadDataBtn');
    if(reload && reload.parentNode){
      var rb=reload.cloneNode(true);rb.id='vdpReloadDataBtn';reload.parentNode.replaceChild(rb,reload);
      rb.onclick=function(ev){
        ev=ev||window.event;try{if(ev.preventDefault)ev.preventDefault();ev.cancelBubble=true;}catch(x){}
        var st=(window.DPVVDP101&&window.DPVVDP101.getState)?window.DPVVDP101.getState():null;
        if(!st||!st.filePath){var b=$('vdpChooseDataBtn');if(b&&b.click)b.click();return false;}
        vstatus('Đang đọc lại CSV/TXT…','work');callReload(st.filePath);return false;
      };
    }
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;
    if(v)txt(v,'V120 CSV CALLBACK FIX · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;
    if(b)b.innerHTML='<strong>DPV® V120 CSV Callback Fix · Core V101 Stable</strong><br>Windows đọc CSV/TXT bằng callback sau khi hộp thoại đóng, không còn phụ thuộc giá trị trả về COM trong cùng click stack · đọc được file đang mở trong Excel bằng FileShare.ReadWrite.';
  }
  function start(){wrapReceiver();bind();mark();}
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);
  }else start();
})();
