/* DPV V142.4 — DUPLEX ORIENTATION SAFE ADD-ON
   Stable-base rule:
   - Does NOT replace Core V101, Bridge, ANP_duplexLayoutV60 or build handlers.
   - Uses the three duplex modes that already exist in the stable host.
   - Only adds a clearer UI selector and a safe recommended default.
*/
(function () {
  'use strict';
  var KEY = 'DPV_V1424_DUPLEX_ORIENTATION';
  var VALID = { abComplementary:1, turnSide:1, tumble180:1 };

  function byId(id) { return document.getElementById(id); }
  function q(sel) { return document.querySelector ? document.querySelector(sel) : null; }
  function text(el, s) { if (!el) { return; } if ('textContent' in el) { el.textContent = s; } else { el.innerText = s; } }
  function getStore() { try { return window.localStorage ? localStorage.getItem(KEY) : null; } catch (e) { return null; } }
  function setStore(v) { try { if (window.localStorage) { localStorage.setItem(KEY, v); } } catch (e) {} }
  function fireChange(el) {
    if (!el) { return; }
    try {
      if (document.createEvent) {
        var ev = document.createEvent('HTMLEvents');
        ev.initEvent('change', true, false);
        el.dispatchEvent(ev);
      } else if (el.fireEvent) { el.fireEvent('onchange'); }
    } catch (e) {}
  }
  function optionByValue(sel, value) {
    var i;
    if (!sel || !sel.options) { return null; }
    for (i = 0; i < sel.options.length; i++) { if (String(sel.options[i].value) === value) { return sel.options[i]; } }
    return null;
  }
  function modeInfo(mode) {
    if (mode === 'abComplementary') {
      return {
        title:'CHUẨN AB · GIỮ 0° NHƯ MẶT A',
        detail:'Phản vị trí trái ↔ phải. A 0° → B 0°. Các con xoay 90° được bù 90° ↔ 270° để đúng chiều lật cạnh.',
        cls:'recommended'
      };
    }
    if (mode === 'turnSide') {
      return {
        title:'GIỮ NGUYÊN MỌI GÓC A → B',
        detail:'Chỉ phản vị trí trái ↔ phải. A 0° → B 0°, A 90° → B 90°. Không xoay thêm bất kỳ góc nào.',
        cls:'exact'
      };
    }
    return {
      title:'ĐỐI ĐẦU 180° · LEGACY',
      detail:'A 0° → B 180°. Đây chính là kiểu làm vùng 0° ở mặt B bị lộn ngược như ảnh bạn gửi.',
      cls:'warning'
    };
  }
  function render() {
    var sel = byId('duplexFlip'), box = byId('dpvDuplexOrientationV1424'), badge = byId('dpvDuplexOrientationBadge'), desc = byId('dpvDuplexOrientationDesc');
    var i, buttons, mode, info;
    if (!sel || !box) { return; }
    mode = VALID[String(sel.value)] ? String(sel.value) : 'abComplementary';
    info = modeInfo(mode);
    if (badge) { badge.className = 'dpv-duplex-v1424-badge ' + info.cls; text(badge, info.title); }
    text(desc, info.detail);
    buttons = box.getElementsByTagName('button');
    for (i = 0; i < buttons.length; i++) {
      if (buttons[i].getAttribute('data-duplex-mode')) {
        buttons[i].className = 'button dpv-duplex-v1424-mode' + (buttons[i].getAttribute('data-duplex-mode') === mode ? ' active' : '');
      }
    }
  }
  function apply(mode, remember) {
    var sel = byId('duplexFlip');
    if (!sel || !VALID[mode]) { return; }
    sel.value = mode;
    if (remember) { setStore(mode); }
    fireChange(sel); // let the stable V141/V142 preview/config listener run itself
    render();
  }
  function build() {
    var sel = byId('duplexFlip'), field, box, saved, opt, buttons, i;
    if (!sel || byId('dpvDuplexOrientationV1424')) { return; }

    /* Clarify the legacy dropdown labels only; values and stable host behavior stay untouched. */
    opt = optionByValue(sel, 'abComplementary');
    if (opt) { text(opt, 'Chuẩn AB — phản X + giữ 0° (0→0, 90↔270)'); }
    opt = optionByValue(sel, 'turnSide');
    if (opt) { text(opt, 'Giữ nguyên góc A→B — phản X, không xoay thêm'); }
    opt = optionByValue(sel, 'tumble180');
    if (opt) { text(opt, 'Đối đầu 180° — legacy (0→180)'); }

    /* V142.4 requested production default: the 0° items on B stay 0° like A.
       This is only a UI default. The original 180° mode remains one click away. */
    saved = getStore();
    if (saved && VALID[saved]) { sel.value = saved; }
    else { sel.value = 'abComplementary'; }

    field = sel.parentNode;
    box = document.createElement('div');
    box.id = 'dpvDuplexOrientationV1424';
    box.className = 'dpv-duplex-v1424';
    box.innerHTML = '' +
      '<div class="dpv-duplex-v1424-head"><strong>HƯỚNG MẶT B · V142.4 SAFE</strong><span id="dpvDuplexOrientationBadge" class="dpv-duplex-v1424-badge"></span></div>' +
      '<div class="dpv-duplex-v1424-grid">' +
        '<button type="button" class="button dpv-duplex-v1424-mode" data-duplex-mode="abComplementary">Giữ 0° như mặt A<br><small>0→0 · 90↔270</small></button>' +
        '<button type="button" class="button dpv-duplex-v1424-mode" data-duplex-mode="turnSide">Giữ nguyên mọi góc<br><small>0→0 · 90→90</small></button>' +
        '<button type="button" class="button dpv-duplex-v1424-mode" data-duplex-mode="tumble180">Đối đầu 180° cũ<br><small>0→180</small></button>' +
      '</div>' +
      '<div id="dpvDuplexOrientationDesc" class="dpv-duplex-v1424-desc"></div>' +
      '<div class="dpv-duplex-v1424-note">Case trong ảnh của bạn: chọn <b>Giữ 0° như mặt A</b>. Các con 0° trong vùng khoanh đỏ sẽ không bị lộn ngược nữa.</div>';
    if (field && field.parentNode) {
      if (field.nextSibling) { field.parentNode.insertBefore(box, field.nextSibling); }
      else { field.parentNode.appendChild(box); }
    }

    buttons = box.getElementsByTagName('button');
    for (i = 0; i < buttons.length; i++) {
      if (buttons[i].getAttribute('data-duplex-mode')) {
        buttons[i].onclick = function () { apply(String(this.getAttribute('data-duplex-mode')), true); };
      }
    }
    sel.addEventListener ? sel.addEventListener('change', function () { if (VALID[String(sel.value)]) { setStore(String(sel.value)); } render(); }) : null;

    render();
  }
  function version() {
    var v = q('.version-badge');
    if (v) { v.innerHTML = 'V142.4 DUPLEX ORIENTATION SAFE · CORE V101 STABLE'; }
    try { document.title = 'DPV® V142.4 — Duplex Orientation Safe · Core V101 Stable'; } catch (e) {}
  }
  function init() { build(); version(); }
  if (document.readyState === 'loading') {
    if (document.addEventListener) { document.addEventListener('DOMContentLoaded', init, false); }
    else { window.attachEvent('onload', init); }
  } else { window.setTimeout(init, 0); }
}());
