(function(){
  "use strict";
  var VERSION="V149.3";
  var queue={items:[],current:null,seq:0,completed:0,failed:0,timer:0,paused:false,history:[],avg:{preview:30000,die:20000,build:120000},tick:0};
  var interceptReady=false;
  var QUEUE_IDS={hostPreviewBtn:"preview",diePreviewBtn:"die",buildBtn:"build"};
  function byId(id){return document.getElementById(id);}
  function qs(s,r){return (r||document).querySelector?(r||document).querySelector(s):null;}
  function qsa(s,r){return (r||document).querySelectorAll?(r||document).querySelectorAll(s):[];}
  function add(el,c){if(!el)return;if((" "+el.className+" ").indexOf(" "+c+" ")<0)el.className+=(el.className?" ":"")+c;}
  function rem(el,c){if(!el)return;el.className=(" "+el.className+" ").replace(" "+c+" "," ").replace(/^\s+|\s+$/g,"");}
  function esc(s){return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}
  function text(el){return el?(el.textContent||el.innerText||""):"";}
  function now(){var d=new Date(),p=function(n){return n<10?"0"+n:String(n);};return p(d.getHours())+":"+p(d.getMinutes())+":"+p(d.getSeconds());}
  function toast(msg){var t=byId("dpvToast");if(!t){return;}if("textContent" in t)t.textContent=msg;else t.innerText=msg;add(t,"show");setTimeout(function(){rem(t,"show");},2400);}
  function log(msg){var box=byId("log");if(!box)return;var r=document.createElement("div");r.className="log-line";r.innerText="["+now()+"] V149: "+msg;box.appendChild(r);box.scrollTop=box.scrollHeight;}
  function setStatus(msg,kind){var s=byId("status");if(s){s.className="status "+(kind||"");s.innerText=msg;}log(msg);}
  function setProgress(on){var p=byId("progressBar");if(p)p.className=on?"progress-bar busy":"progress-bar";}
  function safeConfig(){
    if(!window.DPVCoreV101||typeof window.DPVCoreV101.getConfig!=="function")throw new Error("Core V101 chưa sẵn sàng.");
    return window.DPVCoreV101.getConfig();
  }
  function bridge(){return window.DPVVDP101&&typeof window.DPVVDP101.bridgeCall==="function"?window.DPVVDP101.bridgeCall:null;}
  function hashString(s){var h=2166136261,i;for(i=0;i<s.length;i++){h^=s.charCodeAt(i);h+=(h<<1)+(h<<4)+(h<<7)+(h<<8)+(h<<24);}return (h>>>0).toString(16);}
  function sourceCount(c){return c&&c.sources&&c.sources.length?c.sources.length:0;}
  function createTask(kind){
    var c=safeConfig(), op, method, args, label;
    if(kind==="preview"){
      if(c.mode==="manual")throw new Error("Chế độ nhập kích thước chỉ dùng Tính nhanh/View khuôn, không đối chiếu Illustrator.");
      op="hostPreview";method="PreviewInIllustrator";args=[JSON.stringify(c),c.mode];label="Đối chiếu Illustrator";
    }else if(kind==="die"){
      op="diePreview";method=c.mode==="manual"?"OpenManualDiePreview":"OpenDiePreview";args=[JSON.stringify(c)];label="Mở xem trước khuôn";
    }else{
      if(c.mode==="manual")throw new Error("Hãy lấy file thiết kế hoặc chọn file nguồn trước khi xuất.");
      if(!c.outputPath)throw new Error("Hãy chọn thư mục xuất trước khi dàn.");
      op="build";method="Build";args=[JSON.stringify(c),c.mode];label=c.outputMode==="print_only"?"Dàn & xuất FILE IN":"Dàn FILE IN + KHUÔN BẾ";
    }
    var sig=kind+"|"+hashString(args.join("|"));
    return {id:++queue.seq,kind:kind,operation:op,method:method,args:args,label:label,signature:sig,createdAt:new Date().getTime(),sourceCount:sourceCount(c)};
  }
  function duplicate(sig){var i;if(queue.current&&queue.current.signature===sig)return true;for(i=0;i<queue.items.length;i++)if(queue.items[i].signature===sig)return true;return false;}
  function enqueue(kind){
    var t;try{t=createTask(kind);}catch(e){setStatus(e.message||String(e),"error");return;}
    if(duplicate(t.signature)){toast("Tác vụ giống hệt đã có trong hàng đợi.");return;}
    queue.items.push(t);log("Đã xếp hàng: "+t.label+" · "+t.sourceCount+" nguồn/artboard.");renderQueue();runNext();
  }
  function setQueueControlsBusy(on){
    var ids=["activeBtn","multiBtn","artboardsBtn","manualBtn","manualSizeBtn","outputBtn","ponBtn"],i,n;
    for(i=0;i<ids.length;i++){n=byId(ids[i]);if(n)n.disabled=!!on;}
    /* Các nút production vẫn mở để người dùng xếp thêm job. */
    for(i in QUEUE_IDS){if(QUEUE_IDS.hasOwnProperty(i)){n=byId(i);if(n)n.disabled=false;}}
  }
  function runNext(){
    if(queue.paused||queue.current||!queue.items.length)return;
    var fn=bridge();if(!fn){setStatus("Batch Bridge chưa sẵn sàng.","error");return;}
    queue.current=queue.items.shift();queue.current.startedAt=(new Date()).getTime();setQueueControlsBusy(true);setProgress(true);renderQueue();
    setStatus("Job Queue: đang chạy "+queue.current.label+" · Batch Bridge 1 lần gọi cho "+queue.current.sourceCount+" nguồn/artboard…","work");
    try{fn(queue.current.method,queue.current.args);}catch(e){finishCurrent(false,e.message||String(e));return;}
    if(queue.timer)clearTimeout(queue.timer);
    queue.timer=setTimeout(function(){if(queue.current){finishCurrent(false,"Tác vụ quá thời gian chờ. Hãy kiểm tra Illustrator/hộp thoại đang mở.");}},20*60*1000);
  }
  function saveQueueStats(){try{localStorage.setItem("dpv.v1492.queue.stats",JSON.stringify({avg:queue.avg,history:queue.history.slice(0,30)}));}catch(e){}}
  function loadQueueStats(){try{var o=JSON.parse(localStorage.getItem("dpv.v1492.queue.stats")||"{}");if(o&&o.avg){queue.avg.preview=Number(o.avg.preview||queue.avg.preview);queue.avg.die=Number(o.avg.die||queue.avg.die);queue.avg.build=Number(o.avg.build||queue.avg.build);}if(o&&o.history instanceof Array)queue.history=o.history.slice(0,30);}catch(e){}}
  function finishCurrent(ok,detail){
    if(!queue.current)return;
    if(queue.timer){clearTimeout(queue.timer);queue.timer=0;}
    var done=(new Date()).getTime(),started=Number(queue.current.startedAt||done),dur=Math.max(0,done-started),kind=queue.current.kind||"build",prev=Number(queue.avg[kind]||dur||1000);
    queue.avg[kind]=Math.round(prev*0.7+Math.max(1000,dur)*0.3);
    if(ok)queue.completed++;else queue.failed++;
    queue.history.unshift({id:queue.current.id,kind:kind,label:queue.current.label,status:ok?"done":"failed",detail:String(detail||""),durationMs:dur,at:done,sourceCount:Number(queue.current.sourceCount||0)});if(queue.history.length>30)queue.history.length=30;
    saveQueueStats();
    log((ok?"Hoàn tất: ":"Lỗi: ")+queue.current.label+(detail?" · "+detail:"")+" · "+Math.round(dur/1000)+"s");
    queue.current=null;setProgress(false);setQueueControlsBusy(false);renderQueue();setTimeout(runNext,80);
  }
  function cancelPending(){var n=queue.items.length,i,t,ts=(new Date()).getTime();for(i=0;i<queue.items.length;i++){t=queue.items[i];queue.history.unshift({id:t.id,kind:t.kind,label:t.label,status:"cancelled",detail:"Đã hủy khi đang chờ",durationMs:0,at:ts,sourceCount:Number(t.sourceCount||0)});}if(queue.history.length>30)queue.history.length=30;queue.items=[];saveQueueStats();renderQueue();toast(n?"Đã hủy "+n+" tác vụ đang chờ.":"Không có tác vụ chờ.");}
  function pauseQueue(on){queue.paused=(on===undefined)?!queue.paused:!!on;renderQueue();toast(queue.paused?"Đã tạm dừng nhận job tiếp theo. Job hiện tại vẫn chạy đến hết.":"Đã tiếp tục Job Queue.");if(!queue.paused)setTimeout(runNext,30);}
  function clearQueueHistory(){queue.history=[];saveQueueStats();renderQueue();toast("Đã xóa lịch sử Job Queue.");}
  function retryKind(kind){try{enqueue(kind);}catch(e){toast("Không thể Retry: "+(e.message||e));}}
  function fmtMs(ms){ms=Math.max(0,Number(ms||0));if(ms<1000)return ms+"ms";if(ms<60000)return Math.round(ms/1000)+"s";return Math.floor(ms/60000)+"m "+Math.round((ms%60000)/1000)+"s";}
  function estimate(){if(!queue.current)return null;var elapsed=Math.max(0,(new Date()).getTime()-Number(queue.current.startedAt||0)),avg=Math.max(1000,Number(queue.avg[queue.current.kind]||60000)),pct=Math.min(92,Math.max(3,Math.round((elapsed/avg)*90))),eta=Math.max(0,avg-elapsed);return {elapsed:elapsed,avg:avg,pct:pct,eta:eta};}
  function renderQueue(){
    var list=byId("dpvV149QueueList"),sum=byId("dpvV149QueueSummary"),i,h="",est=estimate(),p=byId("dpvV149QueueProgress"),pb=byId("dpvV149QueueProgressBar"),pause=byId("dpvV149QueuePause");
    if(sum)sum.innerText=(queue.current?"1 đang chạy":"0 đang chạy")+" · "+queue.items.length+" chờ · "+queue.completed+" xong"+(queue.failed?" · "+queue.failed+" lỗi":"")+(queue.paused?" · PAUSED":"");
    if(p){if(est&&queue.current)p.innerText="Ước tính "+est.pct+"% · đã chạy "+fmtMs(est.elapsed)+(est.eta>0?" · ETA ~"+fmtMs(est.eta):" · đang xử lý");else p.innerText=queue.paused?"Queue đang tạm dừng":"Sẵn sàng";}
    if(pb)pb.style.width=(est?est.pct:0)+"%";
    if(pause)pause.innerText=queue.paused?"Tiếp tục":"Tạm dừng";
    if(!list)return;
    if(queue.current)h+='<div class="dpv-v149-qrow running"><span class="dot"></span><div><strong>'+esc(queue.current.label)+'</strong><small>'+queue.current.sourceCount+' nguồn/artboard · Batch Bridge · '+(est?est.pct+'%':'RUN')+'</small></div><b>RUN</b></div>';
    for(i=0;i<queue.items.length;i++)h+='<div class="dpv-v149-qrow"><span class="dot"></span><div><strong>'+esc(queue.items[i].label)+'</strong><small>'+queue.items[i].sourceCount+' nguồn/artboard · #'+queue.items[i].id+'</small></div><b>WAIT</b></div>';
    if(queue.history.length){h+='<div class="dpv-v149-history-title">LỊCH SỬ GẦN ĐÂY</div>';for(i=0;i<Math.min(8,queue.history.length);i++){var x=queue.history[i],cls=x.status==="done"?"done":(x.status==="failed"?"failed":"cancelled"),st=x.status==="done"?"OK":(x.status==="failed"?"ERR":"CANCEL");h+='<div class="dpv-v149-qrow history '+cls+'"><span class="dot"></span><div><strong>'+esc(x.label)+'</strong><small>'+fmtMs(x.durationMs)+(x.detail?' · '+esc(x.detail).slice(0,120):'')+'</small></div><button type="button" class="dpv-v149-retry" data-retry="'+esc(x.kind)+'">'+st+(x.status==="failed"?' · Retry':'')+'</button></div>';}}
    if(!h)h='<div class="dpv-v149-qempty">Không có job đang chờ.</div>';
    list.innerHTML=h;var rs=qsa("[data-retry]",list);for(i=0;i<rs.length;i++)rs[i].onclick=function(){retryKind(this.getAttribute("data-retry"));};
  }
  function installQueueIntercept(){
    if(interceptReady)return;interceptReady=true;
    var id,b;
    for(id in QUEUE_IDS){if(!QUEUE_IDS.hasOwnProperty(id))continue;b=byId(id);if(!b)continue;(function(btn,kind){btn.addEventListener("click",function(e){e=e||window.event;if(e.preventDefault)e.preventDefault();if(e.stopPropagation)e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();enqueue(kind);return false;},true);})(b,QUEUE_IDS[id]);}
  }
  function wrapReceiver(){
    var old=window.VDPRO_receive;if(typeof old!=="function"||old.__v149wrapped)return;
    var wrapped=function(operation,payload){var parsed=null,ok=true,detail="";try{parsed=JSON.parse(String(payload||"{}"));ok=!!parsed.ok;detail=parsed.error||"";}catch(e){}
      try{old(operation,payload);}finally{if(queue.current&&operation===queue.current.operation){finishCurrent(ok,detail);}}
    };wrapped.__v149wrapped=true;window.VDPRO_receive=wrapped;
  }
  function observeTerminalErrors(){var s=byId("status");if(!s||!window.MutationObserver)return;var ob=new MutationObserver(function(){if(!queue.current)return;var t=String(text(s)||"").toLowerCase(),c=String(s.className||"").toLowerCase();if(c.indexOf("error")>=0&&(t.indexOf("lỗi")>=0||t.indexOf("không ")>=0||t.indexOf("error")>=0)){finishCurrent(false,text(s));}});ob.observe(s,{childList:true,subtree:true,attributes:true,characterData:true});}
  function makeQueueUi(){
    if(byId("dpvV149Queue"))return;var stack=qs(".result-column .action-stack");if(!stack)return;
    var box=document.createElement("div");box.id="dpvV149Queue";box.className="dpv-v149-queue";box.innerHTML='<div class="dpv-v149-qhead"><div><strong>JOB QUEUE PRO · BATCH BRIDGE</strong><small id="dpvV149QueueSummary">0 đang chạy · 0 chờ</small></div><div><button id="dpvV149QueuePause" type="button">Tạm dừng</button><button id="dpvV149QueueToggle" type="button">Chi tiết</button><button id="dpvV149QueueCancel" type="button">Hủy chờ</button><button id="dpvV149QueueClear" type="button">Xóa LS</button></div></div><div class="dpv-v149-qprogress"><div id="dpvV149QueueProgressBar"></div></div><div id="dpvV149QueueProgress" class="dpv-v149-qprogress-text">Sẵn sàng</div><div id="dpvV149QueueList" class="dpv-v149-qlist"></div>';
    if(stack.parentNode)stack.parentNode.insertBefore(box,stack.nextSibling);
    byId("dpvV149QueueToggle").onclick=function(){var l=byId("dpvV149QueueList");if(!l)return;if((" "+l.className+" ").indexOf(" open ")>=0)rem(l,"open");else add(l,"open");};
    byId("dpvV149QueueCancel").onclick=cancelPending;byId("dpvV149QueuePause").onclick=function(){pauseQueue();};byId("dpvV149QueueClear").onclick=clearQueueHistory;renderQueue();
  }
  function setStep(step){
    var body=document.body,classes=["dpv-v149-step-source","dpv-v149-step-layout","dpv-v149-step-output"],i,b;
    for(i=0;i<classes.length;i++)rem(body,classes[i]);if(step&&step!=="all")add(body,"dpv-v149-step-"+step);
    try{localStorage.setItem("dpv.v149.step",step||"all");}catch(e){}
    var bs=qsa("[data-v149-step]");for(i=0;i<bs.length;i++){b=bs[i];if(b.getAttribute("data-v149-step")===(step||"all"))add(b,"active");else rem(b,"active");}
  }
  function makeStepUi(){
    if(byId("dpvV149Steps"))return;var cols=qs(".workspace-columns"),ws=qs(".workspace");if(!cols||!ws)return;
    var bar=document.createElement("div");bar.id="dpvV149Steps";bar.className="dpv-v149-steps";bar.innerHTML='<div class="dpv-v149-stepcopy"><strong>QUY TRÌNH 3 BƯỚC</strong><small>Tập trung đúng khu vực cần làm · giảm rối giao diện</small></div><button data-v149-step="source"><b>1</b><span>Nguồn</span></button><button data-v149-step="layout"><b>2</b><span>Dàn & Khuôn</span></button><button data-v149-step="output"><b>3</b><span>Kiểm tra & Xuất</span></button><button data-v149-step="all"><b>∞</b><span>Tất cả</span></button>';
    ws.insertBefore(bar,cols);var bs=qsa("[data-v149-step]",bar),i;for(i=0;i<bs.length;i++)bs[i].onclick=function(){setStep(this.getAttribute("data-v149-step"));};
    var st="all";try{st=localStorage.getItem("dpv.v149.step")||"all";}catch(e){}setStep(st);
  }
  function getUpdateChannel(){try{return localStorage.getItem("dpv.update.channel.v149")==="beta"?"beta":"stable";}catch(e){return"stable";}}
  function setUpdateChannel(ch){ch=ch==="beta"?"beta":"stable";try{localStorage.setItem("dpv.update.channel.v149",ch);}catch(e){}if(window.DPVAutoUpdate&&window.DPVAutoUpdate.setChannel)window.DPVAutoUpdate.setChannel(ch);renderUpdateChannel();}
  function renderUpdateChannel(){var ch=getUpdateChannel(),s=byId("dpvV149ChannelState"),a=qsa("[data-v149-channel]"),i;if(s)s.innerText=ch==="beta"?"BETA · nhận bản thử nghiệm sớm":"STABLE · ưu tiên ổn định";for(i=0;i<a.length;i++){if(a[i].getAttribute("data-v149-channel")===ch)add(a[i],"active");else rem(a[i],"active");}}
  function makeUpdateChannelUi(){
    if(byId("dpvV149UpdateChannel"))return;var host=byId("dpvSettings")||document.body;var row=document.createElement("div");row.id="dpvV149UpdateChannel";row.className="dpv-v149-update-channel";row.innerHTML='<div><strong>Kênh cập nhật</strong><small id="dpvV149ChannelState"></small></div><div class="dpv-v149-channel-buttons"><button data-v149-channel="stable">Stable</button><button data-v149-channel="beta">Beta</button></div>';host.appendChild(row);var b=qsa("[data-v149-channel]",row),i;for(i=0;i<b.length;i++)b[i].onclick=function(){setUpdateChannel(this.getAttribute("data-v149-channel"));};renderUpdateChannel();
  }
  function sanitize(s){s=String(s==null?"":s);s=s.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,"<email-redacted>");s=s.replace(/[A-Za-z]:\\Users\\[^\\\r\n\"]+/g,"<windows-user-path>");s=s.replace(/\/Users\/[^\/\r\n\"]+/g,"<mac-user-path>");return s;}
  function diagnostics(){
    var cfg=null;try{cfg=safeConfig();}catch(e){}
    var cards=qsa("#sourceList .source-card"),src=[],i,c,w,h,badge,logs=qsa("#log .log-line"),logArr=[];
    for(i=0;i<cards.length;i++){c=cards[i];w=qs(".src-w",c);h=qs(".src-h",c);badge=qs(".source-badge",c);src.push({index:i+1,widthMm:w?w.value:"",heightMm:h?h.value:"",badge:sanitize(text(badge))});}
    for(i=Math.max(0,logs.length-200);i<logs.length;i++)logArr.push(sanitize(text(logs[i])));
    return {format:"DPV-DIAGNOSTICS-1",generatedAt:new Date().toISOString?new Date().toISOString():String(new Date()),appVersion:(window.DPV_AUTH_CONFIG&&window.DPV_AUTH_CONFIG.appVersion)||VERSION,title:document.title,platform:String(navigator.platform||""),userAgent:String(navigator.userAgent||""),updateChannel:getUpdateChannel(),connection:sanitize(text(byId("connectionText"))),status:sanitize(text(byId("status"))),queue:{running:queue.current?queue.current.label:null,pending:queue.items.length,completed:queue.completed,failed:queue.failed,paused:queue.paused,averagesMs:queue.avg,history:queue.history.slice(0,30)},nativeBatch:(window.DPVV1491&&window.DPVV1491.lastMetrics)?window.DPVV1491.lastMetrics():null,sources:src,settings:cfg?{mode:cfg.mode,paperW:cfg.paperW,paperH:cfg.paperH,margin:cfg.margin,header:cfg.header,gapX:cfg.gapX,gapY:cfg.gapY,linkBleed:cfg.linkBleed,allowRotate:cfg.allowRotate,trueShape:cfg.trueShape,uniformGap:cfg.uniformGap,outputMode:cfg.outputMode,duplexMode:cfg.duplexMode,finishCropMarks:cfg.finishCropMarks}:null,logs:logArr,privacy:"Email và đường dẫn user đã được ẩn tự động."};
  }
  function copyText(s){var ta=document.createElement("textarea");ta.value=s;ta.style.position="fixed";ta.style.left="-9999px";document.body.appendChild(ta);ta.select();var ok=false;try{ok=document.execCommand("copy");}catch(e){}document.body.removeChild(ta);return ok;}
  function utf8(s){s=unescape(encodeURIComponent(String(s==null?"":s)));var a=[],i;for(i=0;i<s.length;i++)a.push(s.charCodeAt(i)&255);return a;}
  function crc32(bytes){var c=0xffffffff,i,j;for(i=0;i<bytes.length;i++){c^=bytes[i];for(j=0;j<8;j++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;}
  function u16(a,n){a.push(n&255,(n>>>8)&255);}function u32(a,n){a.push(n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255);}
  function zipStore(files){var out=[],central=[],offset=0,i,f,name,data,crc,local=[];for(i=0;i<files.length;i++){f=files[i];name=utf8(f.name);data=utf8(f.text);crc=crc32(data);local=[];u32(local,0x04034b50);u16(local,20);u16(local,0x0800);u16(local,0);u16(local,0);u16(local,0);u32(local,crc);u32(local,data.length);u32(local,data.length);u16(local,name.length);u16(local,0);local=local.concat(name,data);out=out.concat(local);var c=[];u32(c,0x02014b50);u16(c,20);u16(c,20);u16(c,0x0800);u16(c,0);u16(c,0);u16(c,0);u32(c,crc);u32(c,data.length);u32(c,data.length);u16(c,name.length);u16(c,0);u16(c,0);u16(c,0);u16(c,0);u32(c,0);u32(c,offset);central=central.concat(c,name);offset+=local.length;}var centralOffset=out.length;out=out.concat(central);var e=[];u32(e,0x06054b50);u16(e,0);u16(e,0);u16(e,files.length);u16(e,files.length);u32(e,central.length);u32(e,centralOffset);u16(e,0);out=out.concat(e);return new Uint8Array(out);}
  function downloadBlob(blob,name){if(window.navigator&&window.navigator.msSaveBlob){window.navigator.msSaveBlob(blob,name);return true;}try{var a=document.createElement("a"),u=(window.URL||window.webkitURL).createObjectURL(blob);a.href=u;a.download=name;a.style.display="none";document.body.appendChild(a);a.click();setTimeout(function(){try{(window.URL||window.webkitURL).revokeObjectURL(u);}catch(e){}if(a.parentNode)a.parentNode.removeChild(a);},1000);return true;}catch(e){return false;}}
  function csvCell(v){v=String(v==null?"":v);return '"'+v.replace(/"/g,'""')+'"';}
  function exportDiagnostics(){var d=diagnostics(),raw=JSON.stringify(d,null,2),NL="\r\n",logs=(d.logs||[]).join(NL),csv="Index,WidthMm,HeightMm,Badge"+NL,i;for(i=0;i<d.sources.length;i++)csv+=csvCell(d.sources[i].index)+","+csvCell(d.sources[i].widthMm)+","+csvCell(d.sources[i].heightMm)+","+csvCell(d.sources[i].badge)+NL;var readme="DPV V149.3 DIAGNOSTICS PACKAGE"+NL+NL+"Khong chua artwork. Email va duong dan user duoc an tu dong."+NL+"Gui file ZIP nay khi can ho tro loi DPV."+NL;try{var bytes=zipStore([{name:"diagnostics.json",text:raw},{name:"bridge-log.txt",text:logs},{name:"sources.csv",text:csv},{name:"README.txt",text:readme}]),name="DPV_V149_2_DIAGNOSTICS_"+(new Date().getTime())+".zip",blob=new Blob([bytes],{type:"application/zip"});if(downloadBlob(blob,name)){toast("Đã xuất Diagnostics ZIP.");return;}}catch(e){}if(copyText(raw))toast("Không tạo được ZIP; Diagnostics JSON đã được sao chép.");else toast("Không xuất được Diagnostics.");}
  function makeDiagnosticsUi(){
    if(byId("dpvV149DiagExport"))return;var box=byId("dpvDiagBox");if(!box)return;var bar=document.createElement("div");bar.className="dpv-v149-diag-actions";bar.innerHTML='<button id="dpvV149DiagExport" class="button primary" type="button">Xuất Diagnostics ZIP</button><button id="dpvV149DiagCopy" class="button" type="button">Sao chép chẩn đoán</button><small>ZIP gồm diagnostics.json + bridge-log.txt + sources.csv · không kèm artwork · tự ẩn email/đường dẫn user.</small>';box.parentNode.insertBefore(bar,box);byId("dpvV149DiagExport").onclick=exportDiagnostics;byId("dpvV149DiagCopy").onclick=function(){var raw=JSON.stringify(diagnostics(),null,2);toast(copyText(raw)?"Đã sao chép Diagnostics.":"Không sao chép được.");};
  }
  function forceVersion(){try{document.title="DPV® V149.3 — Job Queue Pro · Diagnostics ZIP · Native Batch Cache";}catch(e){}var v=qs(".version-badge");if(v&&(!window.DPVAutoUpdate||String(v.innerHTML).indexOf("V149.0")<0))v.innerHTML="V149.3 · JOB QUEUE PRO";var beta=qs(".beta-note");if(beta)beta.innerHTML='<strong>DPV® V149.3 JOB QUEUE PRO + DIAGNOSTICS ZIP</strong><br>Pause/Resume queue · ETA ước tính từ lịch sử · Retry job lỗi · lịch sử job · Diagnostics ZIP không chứa artwork · Native Batch/Geometry Cache V149.1 giữ nguyên.';}
  function injectPerfBadge(){if(byId("dpvV149PerfBadge"))return;var conn=qs(".connection");if(!conn)return;var s=document.createElement("span");s.id="dpvV149PerfBadge";s.className="dpv-v149-perf-badge";s.innerHTML="⚡ Batch Bridge";s.title="Mỗi job Production gửi 1 payload tổng hợp cho toàn bộ nguồn/artboard và được tuần tự hóa để tránh Bridge chạy chồng.";conn.insertBefore(s,conn.firstChild);}
  function start(){loadQueueStats();makeStepUi();makeQueueUi();makeUpdateChannelUi();injectPerfBadge();installQueueIntercept();wrapReceiver();observeTerminalErrors();forceVersion();if(!queue.tick)queue.tick=setInterval(function(){if(queue.current||queue.paused)renderQueue();},1000);setTimeout(function(){makeDiagnosticsUi();forceVersion();},500);setTimeout(function(){wrapReceiver();installQueueIntercept();makeDiagnosticsUi();forceVersion();},1600);}
  window.DPVV149={queue:queue,enqueue:enqueue,cancelPending:cancelPending,pauseQueue:pauseQueue,clearQueueHistory:clearQueueHistory,retryKind:retryKind,runNext:runNext,diagnostics:diagnostics,exportDiagnostics:exportDiagnostics,setStep:setStep,getUpdateChannel:getUpdateChannel,setUpdateChannel:setUpdateChannel};
  if(document.readyState==="loading"){if(document.addEventListener)document.addEventListener("DOMContentLoaded",function(){setTimeout(start,80);},false);else window.attachEvent("onload",function(){setTimeout(start,80);});}else setTimeout(start,80);
})();
