/* ===== SOURCE: app_v101.js ===== */
(function () {
  "use strict";
  var sources = [], pendingArtboards = [], artboardDocumentName = "", artboardMode = false, manualSizeMode = false, busyState = false, connectWatchdog = 0;
  var vdp = { filePath:"", sourceFolder:"", fileName:"", headers:[], records:[], targets:[] };

  /* V101 STABLE BRIDGE LAYOUT CACHE
     Exact-gap V95 is intentionally expensive. Calculate it once in the fast UI
     JavaScript engine, then send only the final x/y/angle placements to Illustrator.
     Illustrator therefore does not run the polygon solver again for Preview/Build. */
  var layoutCacheV99 = { signature:"", compact:null };
  function layoutSignatureV99(c) {
    var p=[String(c.mode||""),c.paperW,c.paperH,c.margin,c.gapX,c.gapY,c.maxQty,c.allowRotate?1:0,
      c.trueShape?1:0,c.specialStagger?1:0,c.uniformGap?1:0,c.fastMode?1:0,c.angleStep,
      c.cornerSafe?1:0,c.cornerZone,c.demiMode?1:0,String(c.duplexMode?1:0)];
    var ss=c.sources||[], i,s,sh;
    for(i=0;i<ss.length;i++){
      s=ss[i]||{}; sh=s.shape||{};
      p.push(Number(s.width||0),Number(s.height||0),Number(s.quantity||0),String(sh.signature||""),
        sh.points&&sh.points.length?sh.points.length:0,sh.isCircle?1:0,sh.isRectangle?1:0,String(s.path||s.documentName||s.name||""));
    }
    return p.join("|");
  }
  function compactLayoutV99(layout,c) {
    if(!layout||!layout.items||!layout.items.length){return null;}
    var items=[], i,it;
    for(i=0;i<layout.items.length;i++){
      it=layout.items[i]||{};
      items.push({x:Number(it.x),y:Number(it.y),w:Number(it.w),h:Number(it.h),
        angle:it.angle!==undefined?Number(it.angle):(it.rotated?90:0),angleExplicit:it.angle!==undefined,rotated:it.rotated===true,
        offsetX:Number(it.offsetX||0),offsetY:Number(it.offsetY||0),
        sourceIndex:Number(it.sourceIndex||0),copyIndex:Number(it.copyIndex==null?i:it.copyIndex)});
    }
    return {version:101,mode:String(c.mode||"files"),items:items,count:items.length,
      binW:Number(layout.binW||0),binH:Number(layout.binH||0),method:String(layout.method||"cached-v99"),
      efficiency:Number(layout.efficiency||0),edgeRelaxX:Number(layout.edgeRelaxX||0),edgeRelaxY:Number(layout.edgeRelaxY||0),
      edgeOptimized:layout.edgeOptimized===true,cornerSafe:layout.cornerSafe===true,cornerClear:Number(layout.cornerClear||0),
      skippedCount:layout.skipped&&layout.skipped.length?layout.skipped.length:0,
      sourceCount:(c.sources||[]).length,sourceW:(c.sources&&c.sources.length?Number(c.sources[0].width||0):0),
      sourceH:(c.sources&&c.sources.length?Number(c.sources[0].height||0):0)};
  }
  function rememberLayoutV99(c,result){
    var layout=result&&result.layout;
    /* Artboard cache is safe only for one size group. File mode supports mixed sources. */
    if(c.mode==="artboards" && result && result.groupCount!==1){layoutCacheV99={signature:"",compact:null};return;}
    var compact=compactLayoutV99(layout,c);
    if(compact){layoutCacheV99={signature:layoutSignatureV99(c),compact:compact};}
  }
  function attachLayoutCacheV99(c){
    if(!c){return c;}
    var sig=layoutSignatureV99(c), result;
    try { delete c.precomputedLayoutV96; delete c.precomputedLayoutV97; } catch (e0) {}
    if(!layoutCacheV99.compact || layoutCacheV99.signature!==sig){
      result=VDPROEngine.preview(c);
      if(!result || !result.layout || !result.layout.items || !result.layout.items.length){
        throw new Error("Không tạo được Layout Cache V99. Hãy bấm Tính nhanh lại sau khi lấy KHUON_BE.");
      }
      rememberLayoutV99(c,result);
    }
    if(!layoutCacheV99.compact || layoutCacheV99.signature!==sig){
      throw new Error("Layout Cache V99 không khớp thông số hiện tại. Hãy bấm Tính nhanh lại.");
    }
    c.precomputedLayoutV99=layoutCacheV99.compact; c.precomputedLayoutV101=layoutCacheV99.compact;
    c.layoutCacheRequiredV99=true;
    return c;
  }

  var $ = function (id) { return document.getElementById(id); };
  function requiredEl(id) {
    var node = $(id);
    if (!node) { throw new Error("Thiếu control giao diện: #" + id + ". Hãy đóng hẳn DPV + Illustrator rồi cài lại V101 để xóa cache giao diện cũ."); }
    return node;
  }

  function now() { var d = new Date(); return ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2) + ":" + ("0" + d.getSeconds()).slice(-2); }
  function log(message) {
    var row = document.createElement("div"); row.className = "log-line"; row.innerText = "[" + now() + "] " + message;
    $("log").appendChild(row); $("log").scrollTop = $("log").scrollHeight;
  }
  function status(message, kind) {
    $("status").className = "status " + (kind || ""); $("status").innerText = message; log(message);
  }
  function setBusy(on, message) {
    busyState = on; var ids = ["connectBtn","activeBtn","multiBtn","artboardsBtn","manualBtn","manualSizeBtn","hostPreviewBtn","diePreviewBtn","buildBtn","vdpChooseDataBtn","vdpReloadDataBtn","vdpScanTargetsBtn","vdpClearTargetsBtn","vdpPreviewBtn","vdpRestoreBtn","vdpBuildBtn","vdpCombineExistingBtn"];
    for (var i = 0; i < ids.length; i++) { if ($(ids[i])) { $(ids[i]).disabled = on; } }
    if (!on && manualSizeMode) { $("hostPreviewBtn").disabled = true; $("diePreviewBtn").disabled = false; $("buildBtn").disabled = true; }
    $("progressBar").className = on ? "progress-bar busy" : "progress-bar";
    if (message) { status(message, on ? "work" : ""); }
  }
  function parse(raw) {
    try { return JSON.parse(String(raw || "")); }
    catch (e) { return { ok:false, error:"Bridge trả dữ liệu không hợp lệ: " + raw }; }
  }
  function html(value) {
    return String(value == null ? "" : value).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }
  function num(id) { return Number(requiredEl(id).value); }
  function check(id) { return requiredEl(id).checked === true; }
  function fmt(v) { return String(Math.round(Number(v) * 100) / 100); }
  function perfTime(ms) {
    ms = Number(ms || 0);
    if (ms < 1000) { return Math.round(ms) + " ms"; }
    if (ms < 60000) { return (Math.round(ms / 100) / 10) + " s"; }
    return Math.floor(ms / 60000) + "m " + Math.round((ms % 60000) / 1000) + "s";
  }
  function logPerformanceV48(r) {
    var p = r && r.performance, i, s, b, msg;
    if (!p || !p.stages) { log("PERF: Bridge chưa trả dữ liệu profiler."); return ""; }
    log("========== DPV PERFORMANCE PROFILER V5.0 ==========");
    log("TỔNG TRONG ILLUSTRATOR SCRIPT: " + perfTime(p.totalMs));
    if (p.nativeTotalMs != null) { log("TỔNG THỰC TẾ C#/COM → ILLUSTRATOR: " + perfTime(p.nativeTotalMs)); }
    if (p.nativeBridgeOverheadMs != null) { log("OVERHEAD Bridge/COM/nạp script: " + perfTime(p.nativeBridgeOverheadMs)); }
    for (i = 0; i < p.stages.length; i++) {
      s = p.stages[i];
      log("TIME " + s.name + ": " + perfTime(s.ms) + "  (" + (s.percent == null ? "-" : s.percent) + "%)");
    }
    if (p.buildStats) {
      var bs = p.buildStats;
      log("LINK BATCH V4.9: " + bs.total + " Link | tạo trực tiếp " + bs.primitiveLinks +
        " | clone group " + bs.groupClones + " | giảm khoảng " + bs.savedDuplicateOps + " lệnh duplicate");
    }
    if (p.bottlenecks && p.bottlenecks.length) {
      log("---------- 3 CÔNG ĐOẠN CHẬM NHẤT ----------");
      for (i = 0; i < p.bottlenecks.length; i++) {
        b = p.bottlenecks[i];
        log((i + 1) + ". " + b.name + " = " + perfTime(b.ms) + " (" + b.percent + "%)");
      }
      msg = p.bottlenecks[0].name + " · " + perfTime(p.bottlenecks[0].ms) + " · " + p.bottlenecks[0].percent + "%";
      return msg;
    }
    return "";
  }
  function macBridgeReady() { return window.DPVNative && typeof window.DPVNative.invoke === "function"; }
  function externalReady() {
    return macBridgeReady() || (window.external && typeof window.external.ConnectIllustrator !== "undefined");
  }
  function bridgeCall(method, args, done) {
    args = args || [];
    if (macBridgeReady()) {
      window.DPVNative.invoke(method, args).then(function (value) {
        if (done) { done(value); }
      }).catch(function (error) {
        setBusy(false); status((error && error.message) || String(error || "DPV® macOS Bridge báo lỗi."), "error");
      });
      return;
    }
    if (!externalReady() || typeof window.external[method] === "undefined") {
      setBusy(false); status("DPV® Bridge chưa sẵn sàng.", "error"); return;
    }
    try {
      // window.external is an IDispatch COM object in the Windows WebBrowser
      // control. Function.apply() is not supported reliably by that object and
      // raises "Invalid procedure call or argument". Invoke the dispatch member
      // directly, preserving its COM argument list.
      var value;
      if (args.length === 0) { value = window.external[method](); }
      else if (args.length === 1) { value = window.external[method](args[0]); }
      else if (args.length === 2) { value = window.external[method](args[0], args[1]); }
      else { throw new Error("DPV® Bridge không hỗ trợ quá 2 tham số."); }
      if (done) { done(value); }
    } catch (error) {
      setBusy(false);
      var bridgeMsg="Windows Bridge không gọi được " + method + ": " + ((error && error.message) || String(error));
      if(String(method||"").indexOf("VariableData")>=0 || method==="ScanVariableTargets"){vdpStatus(bridgeMsg,"error");}
      else{status(bridgeMsg,"error");}
    }
  }

  function clearConnectWatchdog() {
    if (connectWatchdog) { window.clearTimeout(connectWatchdog); connectWatchdog = 0; }
  }

  function startConnectWatchdog() {
    clearConnectWatchdog();
    connectWatchdog = window.setTimeout(function () {
      connectWatchdog = 0;
      if (!busyState) { return; }
      setBusy(false); setConnected(false);
      status("Illustrator không phản hồi sau 15 giây. Hãy đóng hộp thoại đang chờ trong Illustrator, mở xong Illustrator rồi bấm Kết nối lại; DPV và Illustrator phải chạy cùng quyền (không chạy một ứng dụng bằng Administrator).", "error");
    }, 15000);
  }

  function setConnected(ok, info) {
    $("connectionDot").className = "dot " + (ok ? "online" : "offline");
    $("connectionText").innerText = ok ? (info || "Đã kết nối Illustrator") : "Chưa kết nối Illustrator";
  }

  function refreshOutputActions() {
    $("hostPreviewBtn").disabled = busyState || manualSizeMode;
    $("diePreviewBtn").disabled = busyState;
    $("buildBtn").disabled = busyState || manualSizeMode;
    if (manualSizeMode) {
      $("hostPreviewBtn").title = $("buildBtn").title = "Hãy chọn file thiết kế nếu muốn đối chiếu hoặc xuất trong Illustrator.";
      $("diePreviewBtn").title = "Mở trực tiếp khuôn thủ công trong Illustrator, không lưu file.";
      $("diePreviewBtn").innerText = "View khuôn trực tiếp qua Illustrator";
    } else {
      $("hostPreviewBtn").title = $("diePreviewBtn").title = $("buildBtn").title = "";
      $("diePreviewBtn").innerText = "Mở xem trước khuôn";
    }
  }

  function syncSources() {
    var cards = document.querySelectorAll("#sourceList .source-card"), next = [], i, idx, src, q;
    for (i = 0; i < cards.length; i++) {
      idx = Number(cards[i].getAttribute("data-index")); src = sources[idx]; if (!src) { continue; }
      var wInput = cards[i].querySelector(".src-w"), hInput = cards[i].querySelector(".src-h");
      if (!wInput || !hInput) { throw new Error("Card nguồn in không hợp lệ. Hãy bấm Lấy file đang mở lại rồi Tính nhanh trên DPV."); }
      src.width = Number(wInput.value);
      src.height = Number(hInput.value);
      q = cards[i].querySelector(".src-q"); src.quantity = q ? Math.max(0, Math.floor(Number(q.value) || 0)) : 0;
      next.push(src);
    }
    sources = next;
  }

  function renderSources() {
    var box = $("sourceList"), out = "", i, s, badge;
    if (!sources.length) {
      manualSizeMode = false; refreshOutputActions();
      box.innerHTML = '<div class="empty">Chưa có nguồn in. Có thể lấy file từ Illustrator hoặc nhập kích thước tem để tính nhanh.</div>';
      localPreview(false); return;
    }
    for (i = 0; i < sources.length; i++) {
      s = sources[i];
      if (s.manualSize) { badge = '<span class="source-badge manual">' + (s.shape && s.shape.isCircle ? 'Hình tròn thủ công' : 'Kích thước thủ công') + '</span>'; }
      else if (s.shapeDeferred) { badge = '<span class="source-badge warn">Đọc nhanh · khuôn khi xuất</span>'; }
      else { badge = s.dieFallback ? '<span class="source-badge warn">Dùng artboard</span>' : '<span class="source-badge">Đã nhận shape khuôn</span>'; }
      out += '<div class="source-card" data-index="' + i + '"><div class="source-head">' +
        '<span class="source-name" title="' + html(s.path || s.name) + '">' + (i + 1) + '. ' + html(s.name) + '</span>' + badge +
        '<button class="remove-source" data-remove="' + i + '">×</button></div><div class="source-values">' +
        '<label>Rộng mm<input class="src-w" type="number" min="0.1" step="0.01" value="' + fmt(s.width) + '"' + (s.manualSize ? ' readonly' : '') + '></label>' +
        '<label>Cao mm<input class="src-h" type="number" min="0.1" step="0.01" value="' + fmt(s.height) + '"' + (s.manualSize ? ' readonly' : '') + '></label>' +
        (s.manualSize ? '<label>Chế độ<input type="text" readonly value="Xem tối đa"></label>' : artboardMode ? '<label>Chế độ<input type="text" readonly value="Tự đầy khổ"></label>' :
          '<label>SL<input class="src-q" type="number" min="0" step="1" value="' + Math.max(0, Number(s.quantity) || 0) + '"></label>') +
        '</div></div>';
    }
    box.innerHTML = out;
    var removes = document.querySelectorAll(".remove-source"), inputs = box.querySelectorAll("input");
    for (i = 0; i < removes.length; i++) {
      removes[i].addEventListener("click", function () {
        syncSources(); sources.splice(Number(this.getAttribute("data-remove")), 1);
        if (!sources.length) { manualSizeMode = false; }
        renderSources();
      });
    }
    for (i = 0; i < inputs.length; i++) { inputs[i].addEventListener("change", function () { syncSources(); localPreview(false); }); }
    refreshOutputActions(); localPreview(false);
  }

  function config() {
    syncSources();
    var c = {
      sources:sources, artboards:artboardMode ? sources : [], mode:artboardMode ? "artboards" : (manualSizeMode ? "manual" : "files"),
      dieHint:requiredEl("dieHint").value, jobName:artboardMode && artboardDocumentName ? artboardDocumentName :
        (sources.length === 1 ? sources[0].name : "GHEP_" + sources.length + "_MAU"),
      paperW:num("paperW"), paperH:num("paperH"), margin:num("margin"), header:num("header"),
      gapX:num("gapX"), gapY:num("gapY"), maxQty:Math.max(0, Math.floor(num("maxQty") || 0)),
      linkBleed:num("linkBleed"), allowRotate:check("allowRotate"), addTitle:check("addTitle"),
      trueShape:check("trueShape"), specialStagger:check("specialStagger"), uniformGap:check("uniformGap"), fastMode:check("fastMode"), angleStep:Number(requiredEl("angleStep").value),
      cornerSafe:check("cornerSafe"), cornerZone:Math.max(0, num("cornerZone") || 0),
      demiMode:check("demiMode"), demiExtend:num("demiExtend"),
      ponPath:requiredEl("ponPath").value, fitPon:check("fitPon"), autoPon:check("autoPon"),
      ponProcessBlack:check("ponProcessBlack"), cornerPonRed:check("cornerPonRed"),
      finishCropMarks:check("finishCropMarks"),
      finishMarkLength:Math.max(0.1, num("finishMarkLength") || 6),
      finishMarkGap:Math.max(0, num("finishMarkGap") || 0),
      duplexMode:check("duplexMode"), duplexFlip:String(requiredEl("duplexFlip").value || "tumble180"), dieAsLink:false,
      preservePrintColor:check("preservePrintColor"), outputPath:requiredEl("outputPath").value,
      outputMode:String(requiredEl("outputMode").value || "both"),
      outputPrintStart:String(requiredEl("outputPrintStart").value || "").replace(/\s+/g, ""),
      outputDieStart:String(requiredEl("outputDieStart").value || "").replace(/\s+/g, "")
    };
    if (!sources.length) { throw new Error("Chưa có file hoặc artboard cần dàn."); }
    if (c.outputMode !== "both" && c.outputMode !== "print_only") { c.outputMode = "both"; }
    if (c.outputPrintStart && !/^\d+(?:\.\d+)*$/.test(c.outputPrintStart)) { throw new Error("STT FILE IN không hợp lệ. Ví dụ đúng: 1.12 hoặc 12."); }
    if (c.outputMode === "both" && c.outputDieStart && !/^\d+(?:\.\d+)*$/.test(c.outputDieStart)) { throw new Error("STT KHUÔN không hợp lệ. Ví dụ đúng: 2.10 hoặc 10."); }
    if (c.finishCropMarks || c.duplexMode) { c.outputMode = "print_only"; }
    if (!(c.paperW > 0) || !(c.paperH > 0) || c.margin < 0 || c.paperW <= c.margin * 2 || c.paperH <= c.margin * 2) {
      throw new Error("Thông số khổ in hoặc lề không hợp lệ.");
    }
    if (c.duplexMode) {
      if (!c.finishCropMarks) { throw new Error("In 2 mặt chỉ dùng cùng chức năng PON cắt theo thành phẩm."); }
      if (!artboardMode || sources.length !== 2) { throw new Error("In 2 mặt cần chọn đúng 2 artboard: mặt trước rồi mặt sau."); }
      if (Math.abs(Number(sources[0].width) - Number(sources[1].width)) > 0.05 ||
          Math.abs(Number(sources[0].height) - Number(sources[1].height)) > 0.05) {
        throw new Error("Hai artboard in 2 mặt phải cùng kích thước thành phẩm.");
      }
    }
    return c;
  }

  function methodName(method) {
    if (String(method || "").indexOf("mixed-exact-max-v131|") === 0) { return "AUTO MAX MIXED · khe đều chính xác · xoay ngang/dọc tối đa"; }
    if (String(method || "").indexOf("regular-exact-v131|") === 0) { return "AUTO MAX MIXED · lưới thẳng thắng vì không ít con hơn"; }
    if (String(method || "").indexOf("true-shape-auto-stable-v101|") === 0) { return String(method).indexOf("regular-exact-v101")>=0 ? "AUTO STABLE · lưới thẳng đều · khe chính xác" : "AUTO STABLE · so le chỉ khi tăng số con · khe chính xác"; }
    if (String(method || "").indexOf("true-shape-auto-max-exact-v97|") === 0) { return "AUTO MAX · khe đều chính xác · số con tối đa"; }
    if (method === "demi-grid") { return "Bế 1 dao Demi – lưới thẳng"; }
    if (method === "true-shape-honeycomb") { return "True‑Shape tổ ong"; }
    if (method === "true-shape-profile-columns-v95") { return "Khuôn đặc biệt · Exact Gap FAST theo cột"; }
    if (method === "true-shape-profile-rows-v95") { return "Khuôn đặc biệt · Exact Gap FAST theo hàng"; }
    if (method === "true-shape-polygon") { return "True‑Shape polygon"; }
    if (method === "true-shape-staggered-exact") { return "Khuôn đặc biệt xoay · khe đều chính xác"; }
    if (method === "true-shape-interlocking-columns-exact") { return "Khuôn đặc biệt khóa nhau 90°/270° · khe đều chính xác"; }
    if (method === "true-shape-staggered") { return "True‑Shape khuôn đặc biệt – so le"; }
    if (method === "true-shape-interlocking-columns") { return "True‑Shape cột khóa nhau 90°/270°"; }
    if (String(method || "").indexOf("uniform-grid") === 0) { return "Lưới đều tuyệt đối · một hướng"; }
    if (method === "true-shape-mixed") { return "True‑Shape nhiều khuôn"; }
    if (method === "maxrects-mixed-sizes") { return "MaxRects nhiều kích thước"; }
    if (String(method || "").indexOf("corner-safe") >= 0) { return "Tối ưu chừa PON bốn góc"; }
    return "Cột/hàng xoay tối ưu";
  }

  function clearLayoutCanvas(message) {
    var canvas = $("layoutCanvas"), ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#f4f0de"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#716f65"; ctx.font = "13px Segoe UI, Arial"; ctx.textAlign = "center";
    ctx.fillText(message || "Chưa có bố cục", canvas.width / 2, canvas.height / 2);
    $("layoutCaption").innerText = message || "Chưa có bố cục";
  }

  function drawLayout(result, c) {
    var layout = result && result.layout, canvas = $("layoutCanvas"), ctx = canvas.getContext("2d");
    if (!layout || !layout.items || !layout.items.length) { clearLayoutCanvas("Chưa có bố cục để vẽ"); return; }
    var pad = 12, paperW = Number(c.paperW), paperH = Number(c.paperH);
    var scale = Math.min((canvas.width - pad * 2) / paperW, (canvas.height - pad * 2) / paperH);
    var sheetW = paperW * scale, sheetH = paperH * scale;
    var ox = (canvas.width - sheetW) / 2, oy = (canvas.height - sheetH) / 2;
    var colors = ["#ffbf00", "#08a878", "#ff5b24", "#13a8b8", "#74bd43", "#e59f00"];
    var items = layout.items, maxDraw = 2200, stride = Math.max(1, Math.ceil(items.length / maxDraw));
    var i, item, source, isCircle, x, y, w, h, color;
    ctx.clearRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = "#f4f0de"; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#fffef7"; ctx.fillRect(ox, oy, sheetW, sheetH);
    ctx.strokeStyle = "#17181c"; ctx.lineWidth = 1.2; ctx.strokeRect(ox + .5, oy + .5, sheetW - 1, sheetH - 1);
    ctx.save(); ctx.strokeStyle = "rgba(8,168,120,.72)"; ctx.lineWidth = 1;
    if (ctx.setLineDash) { ctx.setLineDash([4, 3]); }
    ctx.strokeRect(ox + c.margin * scale, oy + c.margin * scale,
      Math.max(0, (paperW - c.margin * 2) * scale), Math.max(0, (paperH - c.margin * 2) * scale));
    ctx.restore();
    if (c.cornerSafe && Number(c.cornerZone) > 0) {
      var zone = Math.min(Number(c.cornerZone), paperW / 2, paperH / 2) * scale;
      ctx.save(); ctx.fillStyle = "rgba(255,191,0,.13)"; ctx.strokeStyle = "rgba(255,191,0,.62)";
      if (ctx.setLineDash) { ctx.setLineDash([3, 3]); }
      ctx.fillRect(ox, oy, zone, zone); ctx.strokeRect(ox, oy, zone, zone);
      ctx.fillRect(ox + sheetW - zone, oy, zone, zone); ctx.strokeRect(ox + sheetW - zone, oy, zone, zone);
      ctx.fillRect(ox, oy + sheetH - zone, zone, zone); ctx.strokeRect(ox, oy + sheetH - zone, zone, zone);
      ctx.fillRect(ox + sheetW - zone, oy + sheetH - zone, zone, zone);
      ctx.strokeRect(ox + sheetW - zone, oy + sheetH - zone, zone, zone); ctx.restore();
    }
    for (i = 0; i < items.length; i += stride) {
      item = items[i]; source = c.sources[Math.max(0, Number(item.sourceIndex) || 0)] || c.sources[0] || {};
      isCircle = source.shape && source.shape.isCircle === true;
      color = colors[(Number(item.sourceIndex) || 0) % colors.length];
      x = ox + (Number(c.margin) + Number(item.x) + Number(item.offsetX || 0)) * scale;
      y = oy + (Number(c.margin) + Number(item.y) + Number(item.offsetY || 0)) * scale;
      w = Number(item.w) * scale; h = Number(item.h) * scale;
      ctx.beginPath();
      if (isCircle) { ctx.arc(x + w / 2, y + h / 2, Math.min(w, h) / 2, 0, Math.PI * 2, false); }
      else { ctx.rect(x, y, w, h); }
      ctx.fillStyle = color; ctx.globalAlpha = .16; ctx.fill(); ctx.globalAlpha = 1;
      ctx.strokeStyle = color; ctx.lineWidth = Math.max(.55, Math.min(1.2, scale * .13)); ctx.stroke();
    }
    $("layoutCaption").innerText = items.length + " con trên " + fmt(paperW) + "×" + fmt(paperH) + " mm" +
      (c.cornerSafe ? " · chừa PON " + fmt(c.cornerZone) + "mm" : "") +
      (stride > 1 ? " · sơ đồ rút gọn để giữ nhẹ" : "");
  }

  function showLocal(result, c) {
    if (result.mode === "artboards") {
      var details = [], firstCount = result.groups.length ? result.groups[0].countPerSheet : 0;
      for (var i = 0; i < result.groups.length; i++) {
        details.push("Nhóm " + result.groups[i].groupNumber + ": " + result.groups[i].width + "×" + result.groups[i].height + " = " + result.groups[i].countPerSheet + " con");
      }
      $("previewCount").innerText = result.groups.length === 1 ? firstCount : result.groupCount;
      $("previewMethod").innerText = result.duplex ?
        "1 FILE IN CATTP · 2 TRANG A/B · MẶT B BÙ GÓC THEO A" : result.cattp ?
        result.printFileCount + " FILE IN CATTP · KHÔNG XUẤT KHUÔN" :
        result.printFileCount + " FILE IN · " + result.dieFileCount + " FILE KHUÔN";
      $("previewDetails").innerText = details.join(" | "); $("efficiency").innerText = "Theo nhóm"; $("modeLabel").innerText = "Artboard";
    } else {
      $("previewCount").innerText = result.count;
      $("previewMethod").innerText = methodName(result.method);
      if (result.mode === "manual") {
        var manualSource = c.sources[0], shapeName = manualSource.shape && manualSource.shape.isCircle ? "Tròn Ø" : "Tem";
        $("previewDetails").innerText = shapeName + " " + fmt(manualSource.width) + (manualSource.shape && manualSource.shape.isCircle ? "" : "×" + fmt(manualSource.height)) +
          " mm · khổ " + fmt(c.paperW) + "×" + fmt(c.paperH) + " mm";
        $("modeLabel").innerText = "Thủ công";
      } else {
        $("previewDetails").innerText = result.rotated + " xoay · " + result.normal + " không xoay" + (result.skipped ? " · dư " + result.skipped : "");
        $("modeLabel").innerText = "File";
      }
      $("efficiency").innerText = (Math.round(result.efficiency * 1000) / 10) + "%";
    }
    $("engineState").innerText = "DPV® Desktop"; drawLayout(result, c);
  }

  function localPreview(showStatus) {
    try {
      var c = config(), result = VDPROEngine.preview(c); rememberLayoutV99(c, result); showLocal(result, c);
      if (showStatus) { status(result.mode === "manual" ? "Đã tính số con từ kích thước tem, không dùng Illustrator." : "Đã tính bố cục bên ngoài Illustrator.", "ok"); }
      return result;
    } catch (e) {
      $("previewCount").innerText = "0"; $("previewMethod").innerText = e.message;
      $("previewDetails").innerText = "Bổ sung nguồn hoặc kiểm tra lại thông số.";
      clearLayoutCanvas("Chưa có bố cục");
      if (showStatus) { status(e.message, "error"); }
      return null;
    }
  }

  function syncManualShapeFields() {
    var circle = $("manualShape").value === "circle";
    $("manualWidthLabel").innerText = circle ? "Đường kính (mm)" : "Rộng tem (mm)";
    $("manualHeightField").className = circle ? "field hidden" : "field";
  }

  function openManualSize() {
    if (manualSizeMode && sources.length && sources[0].manualSize) {
      $("manualName").value = sources[0].name || "Tem nhập thủ công";
      $("manualShape").value = sources[0].shape && sources[0].shape.isCircle ? "circle" : "rectangle";
      $("manualW").value = fmt(sources[0].width); $("manualH").value = fmt(sources[0].height);
    }
    syncManualShapeFields(); $("manualSizeBox").className = "manual-size-box";
    status("Nhập kích thước tem rồi bấm Tính và xem trước trên khổ.", "ok");
  }

  function applyManualSize() {
    var kind = $("manualShape").value, w = num("manualW"), h = kind === "circle" ? w : num("manualH");
    if (!(w > 0) || !(h > 0)) { status("Kích thước tem phải lớn hơn 0 mm.", "error"); return; }
    var shape;
    try { shape = VDPROEngine.manualShape(kind, w, h); }
    catch (e) { status(e.message, "error"); return; }
    $("maxQty").value = "0";
    if (kind === "circle") { $("trueShape").checked = true; $("demiMode").checked = false; }
    artboardMode = false; manualSizeMode = true;
    sources = [{ name:$("manualName").value || (kind === "circle" ? "Tem tròn" : "Tem chữ nhật"),
      width:w, height:h, quantity:0, manualSize:true, dieFallback:false, shape:shape }];
    $("manualSizeBox").className = "manual-size-box hidden"; renderSources(); refreshOutputActions();
    localPreview(true);
  }

  function connect() {
    if (!externalReady()) { status("DPV® Bridge chưa sẵn sàng.", "error"); return; }
    setBusy(true, "Đang kết nối Adobe Illustrator 2024–2026…"); startConnectWatchdog(); bridgeCall("ConnectIllustrator", [true]);
  }
  function getActive(manual) {
    if (!externalReady()) { return; } setBusy(true, manual ? "Đang đọc KHUON_BE đang chọn…" : "Đang đọc file Illustrator đang mở…");
    if (manual) { bridgeCall("GetManualDieSource"); } else { bridgeCall("GetActiveSource", [requiredEl("dieHint").value]); }
  }
  function chooseMultiple() {
    bridgeCall("ChooseSourceFiles", [], function (raw) {
      var files = parse(raw);
      if (!files.length) { return; } setBusy(true, "Illustrator đang đọc " + files.length + " file nguồn…");
      bridgeCall("InspectSourceFiles", [JSON.stringify(files), requiredEl("dieHint").value]);
    });
  }
  function listArtboards() { setBusy(true, "Đang đọc danh sách artboard từ Illustrator…"); bridgeCall("ListArtboards", [requiredEl("dieHint").value]); }
  function renderArtboards() {
    var out = "", i, a;
    for (i = 0; i < pendingArtboards.length; i++) {
      a = pendingArtboards[i];
      out += '<label class="artboard-option"><input class="ab-check" type="checkbox" data-index="' + i + '" checked>' +
        '<span><strong>' + html(a.displayIndex || (i + 1)) + '. ' + html(a.name) + '</strong><small>' + (a.dieFallback ? 'Dùng artboard' : 'Có KHUON_BE') + '</small></span>' +
        '<span class="artboard-size">' + fmt(a.width) + ' × ' + fmt(a.height) + ' mm</span></label>';
    }
    $("artboardList").innerHTML = out; $("artboardChooser").className = "artboard-box";
  }
  function useArtboards() {
    var checks = document.querySelectorAll(".ab-check"), selected = [], i, idx;
    for (i = 0; i < checks.length; i++) { if (checks[i].checked) { idx = Number(checks[i].getAttribute("data-index")); selected.push(pendingArtboards[idx]); } }
    if (!selected.length) { status("Bạn chưa chọn artboard nào.", "error"); return; }
    if (check("duplexMode") && selected.length !== 2) { status("In 2 mặt cần chọn đúng 2 artboard: mặt trước rồi mặt sau.", "error"); return; }
    artboardMode = true; manualSizeMode = false; sources = selected; $("artboardChooser").className = "artboard-box hidden"; renderSources();
    status("Đã nhận " + sources.length + " artboard; DPV® sẽ tự nhóm kích thước.", "ok");
  }

  function hostPreview() {
    if (manualSizeMode) { status("Chế độ nhập kích thước chỉ xem số con trong DPV®. Hãy chọn file thiết kế trước khi đối chiếu Illustrator.", "error"); return; }
    var c; try { c = attachLayoutCacheV99(config()); } catch (e) { status(e.message, "error"); return; }
    setBusy(true, "Đang đối chiếu bố cục với Illustrator · dùng Layout Cache V101 STABLE…");
    bridgeCall("PreviewInIllustrator", [JSON.stringify(c), c.mode]);
  }
  function diePreview() {
    var c; try { c = attachLayoutCacheV99(config()); } catch (e) { status(e.message, "error"); return; }
    setBusy(true, manualSizeMode ? "Illustrator đang dựng khuôn trực tiếp từ kích thước đã nhập…" : "Illustrator đang dựng preview V99 từ layout đã khóa · Illustrator KHÔNG chạy solver…");
    if (manualSizeMode) { bridgeCall("OpenManualDiePreview", [JSON.stringify(c)]); }
    else { bridgeCall("OpenDiePreview", [JSON.stringify(c)]); }
  }
  function build() {
    if (manualSizeMode) { status("Hãy lấy file thiết kế hoặc chọn file nguồn trước khi xuất FILE IN/KHUÔN.", "error"); return; }
    var c; try { c = attachLayoutCacheV99(config()); } catch (e) { status(e.message, "error"); return; }
    if (!c.outputPath) { status("Hãy chọn thư mục xuất trước khi dàn.", "error"); return; }
    setBusy(true, c.duplexMode ?
      "DPV® V65: dựng PDF A/B cùng vị trí, mặt B bù góc theo mặt A…" : c.finishCropMarks ?
      "DPV® V65: dựng FILE IN CATTP và PON biên bậc thang…" : c.outputMode === "print_only" ?
      "DPV® V148.9.2: dàn và chỉ xuất FILE IN…" :
      "DPV® V148.9.2: dàn FILE IN + KHUÔN BẾ…");
    bridgeCall("Build", [JSON.stringify(c), c.mode]);
  }


  function vdpStatus(message, kind) {
    if (!$('vdpStatus')) { return; }
    $('vdpStatus').className = 'status ' + (kind || ''); $('vdpStatus').innerText = message;
    log('VDP: ' + message);
  }

  function vdpNormalize(value) {
    return String(value == null ? '' : value).toLowerCase().replace(/^\s+|\s+$/g,'').replace(/[^a-z0-9à-ỹ]+/g,'');
  }

  function vdpDetectDelimiter(text) {
    var line = String(text || '').replace(/^\ufeff/, '').split(/\r?\n/)[0] || '', candidates = [',',';','\t'], best=',', bestCount=-1, i, j, count, q;
    for (i=0;i<candidates.length;i++) {
      count=0; q=false;
      for (j=0;j<line.length;j++) { if(line.charAt(j)==='"'){q=!q;} else if(!q && line.charAt(j)===candidates[i]){count++;} }
      if(count>bestCount){bestCount=count;best=candidates[i];}
    }
    return best;
  }

  function vdpParseDelimited(text) {
    text = String(text || '').replace(/^\ufeff/, '');
    var forcedDelimiter='', sepMatch=/^sep=(.)\r?\n/i.exec(text);
    if(sepMatch){forcedDelimiter=sepMatch[1];text=text.substring(sepMatch[0].length);}
    var delimiter = forcedDelimiter || vdpDetectDelimiter(text), rows=[], row=[], cell='', quote=false, i, ch, next;
    for(i=0;i<text.length;i++){
      ch=text.charAt(i); next=i+1<text.length?text.charAt(i+1):'';
      if(ch==='"') { if(quote && next==='"'){cell+='"';i++;} else {quote=!quote;} }
      else if(ch===delimiter && !quote){row.push(cell);cell='';}
      else if((ch==='\n' || ch==='\r') && !quote){ if(ch==='\r'&&next==='\n'){i++;} row.push(cell);cell=''; if(row.length>1 || String(row[0]||'').replace(/\s/g,'')){rows.push(row);} row=[]; }
      else {cell+=ch;}
    }
    if(cell!=='' || row.length){row.push(cell);rows.push(row);}
    if(!rows.length){return {headers:[],records:[],delimiter:delimiter};}
    var headers=[], used={}, h, base, n, r, obj, records=[];
    for(i=0;i<rows[0].length;i++){
      base=String(rows[0][i]||'').replace(/^\s+|\s+$/g,'') || ('FIELD_'+(i+1)); h=base; n=2;
      while(used[h]){h=base+'_'+n;n++;} used[h]=true; headers.push(h);
    }
    for(i=1;i<rows.length;i++){
      r=rows[i]; obj={}; for(h=0;h<headers.length;h++){obj[headers[h]]=r[h]!==undefined?r[h]:'';} records.push(obj);
    }
    return {headers:headers,records:records,delimiter:delimiter};
  }

  function vdpRenderData() {
    $('vdpRecordCount').value=String(vdp.records.length); $('vdpFieldCount').value=String(vdp.headers.length);
    $('vdpDataInfo').className='source-card'; $('vdpDataInfo').innerHTML=vdp.fileName ? '<strong>'+html(vdp.fileName)+'</strong><br><small>'+html(vdp.filePath)+'</small>' : 'Chưa chọn dữ liệu.';
    var head='', body='', i,j,maxRows=Math.min(vdp.records.length,12);
    if(vdp.headers.length){head='<tr>';for(i=0;i<vdp.headers.length;i++){head+='<th>'+html(vdp.headers[i])+'</th>';}head+='</tr>';}
    for(i=0;i<maxRows;i++){body+='<tr>';for(j=0;j<vdp.headers.length;j++){body+='<td title="'+html(vdp.records[i][vdp.headers[j]])+'">'+html(vdp.records[i][vdp.headers[j]])+'</td>';}body+='</tr>';}
    $('vdpDataHead').innerHTML=head; $('vdpDataBody').innerHTML=body;
    $('vdpFrom').value=vdp.records.length?'1':'1'; $('vdpTo').value=String(Math.max(1,vdp.records.length)); $('vdpRecordIndex').max=String(Math.max(1,vdp.records.length));
    var opts='<option value="">Số thứ tự record</option>'; for(i=0;i<vdp.headers.length;i++){opts+='<option value="'+html(vdp.headers[i])+'">'+html(vdp.headers[i])+'</option>';}$('vdpFileNameField').innerHTML=opts;
    vdpRenderMappings();
  }

  function vdpLoadFileResult(raw) {
    var r=parse(raw); if(!r.ok){vdpStatus(r.error||'Không đọc được file dữ liệu.','error');return;}
    var parsed=vdpParseDelimited(r.text||''); if(!parsed.headers.length){vdpStatus('File không có dòng tiêu đề/cột dữ liệu.','error');return;}
    vdp.filePath=r.path||''; vdp.sourceFolder=r.folder||''; vdp.fileName=r.name||''; vdp.headers=parsed.headers; vdp.records=parsed.records;
    vdpRenderData(); vdpStatus('Đã đọc '+vdp.records.length+' record · '+vdp.headers.length+' cột.','ok');
  }

  function vdpChooseData() { bridgeCall('ChooseVariableDataFile',[],function(raw){if(raw){vdpLoadFileResult(raw);}}); }

  function vdpActionOptions(selected) {
    var a=[['text','Text'],['image','Image relink'],['visibility','Ẩn / hiện'],['fillColor','Fill Color']], out='',i;
    for(i=0;i<a.length;i++){out+='<option value="'+a[i][0]+'"'+(a[i][0]===selected?' selected':'')+'>'+a[i][1]+'</option>';} return out;
  }
  function vdpFieldOptions(selected) {
    var out='<option value="">— Chọn cột dữ liệu —</option>',i; for(i=0;i<vdp.headers.length;i++){out+='<option value="'+html(vdp.headers[i])+'"'+(vdp.headers[i]===selected?' selected':'')+'>'+html(vdp.headers[i])+'</option>';} return out;
  }
  function vdpBestField(target) {
    var t=vdpNormalize(target.label), i, h; if(!t){return '';}
    for(i=0;i<vdp.headers.length;i++){h=vdpNormalize(vdp.headers[i]);if(h===t){return vdp.headers[i];}}
    for(i=0;i<vdp.headers.length;i++){h=vdpNormalize(vdp.headers[i]);if(h && (t.indexOf(h)>=0 || h.indexOf(t)>=0)){return vdp.headers[i];}}
    return '';
  }
  function vdpRemoveTarget(index) {
    vdpSyncMappings();
    if(index < 0 || index >= vdp.targets.length){return;}
    vdp.targets.splice(index,1);
    vdpRenderMappings(false);
    vdpStatus('Còn '+vdp.targets.length+' vị trí biến đổi.','ok');
  }
  function vdpRenderMappings(forceAuto) {
    var out='',i,t,selectedField,buttons; if(!vdp.targets.length){$('vdpMappings').innerHTML='<div class="empty compact-empty">Chưa có đối tượng để map.</div>';return;}
    for(i=0;i<vdp.targets.length;i++){
      t=vdp.targets[i]; selectedField=(forceAuto||!t.field)?vdpBestField(t):(t.field||''); if(selectedField){t.field=selectedField;}
      out+='<div class="vdp-map-row" data-vdp-index="'+i+'"><div class="vdp-map-head"><strong>'+(i+1)+'. '+html(t.label)+'</strong><span class="vdp-kind-badge">'+html(t.itemType)+'</span><button type="button" class="vdp-remove-map" data-remove-index="'+i+'" title="Xóa vị trí này">×</button></div>'+
        '<div class="vdp-map-controls"><select class="vdp-action">'+vdpActionOptions(t.action||'text')+'</select><select class="vdp-field">'+vdpFieldOptions(t.field||'')+'</select></div>'+
        '<div class="vdp-affix"><input class="vdp-prefix" type="text" placeholder="Tiền tố" value="'+html(t.prefix||'')+'"><input class="vdp-suffix" type="text" placeholder="Hậu tố" value="'+html(t.suffix||'')+'"></div></div>';
    }
    $('vdpMappings').innerHTML=out;
    buttons=$('vdpMappings').querySelectorAll('.vdp-remove-map');
    for(i=0;i<buttons.length;i++){buttons[i].addEventListener('click',function(){vdpRemoveTarget(Number(this.getAttribute('data-remove-index')));});}
  }
  function vdpSyncMappings() {
    var rows=$('vdpMappings').querySelectorAll('.vdp-map-row'),i,idx;
    for(i=0;i<rows.length;i++){idx=Number(rows[i].getAttribute('data-vdp-index'));if(!vdp.targets[idx]){continue;}vdp.targets[idx].action=rows[i].querySelector('.vdp-action').value;vdp.targets[idx].field=rows[i].querySelector('.vdp-field').value;vdp.targets[idx].prefix=rows[i].querySelector('.vdp-prefix').value;vdp.targets[idx].suffix=rows[i].querySelector('.vdp-suffix').value;}
  }
  function vdpMappingsConfig() {
    vdpSyncMappings(); var arr=[],i,t; for(i=0;i<vdp.targets.length;i++){t=vdp.targets[i];if(!t.field){continue;}arr.push({targetId:t.id,label:t.label,itemType:t.itemType,action:t.action,field:t.field,prefix:t.prefix||'',suffix:t.suffix||''});} return arr;
  }


  /* V114 READ-ONLY API: chỉ expose snapshot của Core V101 và VDP state cho lớp UI mới.
     Không thay đổi thuật toán dàn / Exact Gap / Hard Margin. */
  window.DPVCoreV101 = {
    getConfig:function(){
      var c=attachLayoutCacheV99(config());
      return c;
    },
    getLayout:function(){
      var c=attachLayoutCacheV99(config());
      return c.precomputedLayoutV101 || c.precomputedLayoutV99 || null;
    }
  };
  window.DPVVDP101 = {
    getState:function(){
      return {filePath:vdp.filePath||'',sourceFolder:vdp.sourceFolder||'',fileName:vdp.fileName||'',recordCount:vdp.records.length||0,mappings:vdpMappingsConfig()};
    },
    status:vdpStatus,
    bridgeCall:bridgeCall,
    loadFileResult:vdpLoadFileResult,
    getRecords:function(){ return vdp.records.slice(0); }
  };

  function vdpMergeTargets(nextTargets) {
    vdpSyncMappings();
    var seen={},i,t,added=0;
    for(i=0;i<vdp.targets.length;i++){seen[String(vdp.targets[i].id||'')]=true;}
    for(i=0;i<(nextTargets||[]).length;i++){t=nextTargets[i];if(!t || !t.id || seen[String(t.id)]){continue;}if(!t.field){t.field=vdpBestField(t);}seen[String(t.id)]=true;vdp.targets.push(t);added++;}
    return added;
  }
  function vdpScanTargets() { setBusy(true,'Đang thêm các vị trí Variable Data đang chọn trong Illustrator…'); bridgeCall('ScanVariableTargets',[]); }
  function vdpCurrentIndex() { var n=Math.floor(Number($('vdpRecordIndex').value)||1); n=Math.max(1,Math.min(Math.max(1,vdp.records.length),n));$('vdpRecordIndex').value=String(n);return n; }
  function vdpPreview() {
    if(!vdp.records.length){vdpStatus('Chưa có dữ liệu CSV/TXT.','error');return;} var maps=vdpMappingsConfig();if(!maps.length){vdpStatus('Chưa map cột dữ liệu vào đối tượng Illustrator.','error');return;}
    var idx=vdpCurrentIndex(); setBusy(true,'Đang preview Variable Data record '+idx+'…'); bridgeCall('PreviewVariableData',[JSON.stringify({record:vdp.records[idx-1],recordNumber:idx,mappings:maps,sourceFolder:vdp.sourceFolder})]);
  }
  function vdpRestore(){setBusy(true,'Đang khôi phục nội dung gốc…');bridgeCall('RestoreVariableData',[]);}
  function vdpBuild(){
    if(!vdp.records.length){vdpStatus('Chưa có dữ liệu CSV/TXT.','error');return;}
    var maps=vdpMappingsConfig(); if(!maps.length){vdpStatus('Chưa có mapping hợp lệ.','error');return;}
    var out=$('vdpOutputPath').value; if(!out){vdpStatus('Chưa chọn thư mục xuất.','error');return;}
    var exportIndividual=$('vdpExportIndividual').checked, combinePdf=$('vdpCombinePdf').checked;
    if(combinePdf && !exportIndividual){ exportIndividual=true; $('vdpExportIndividual').checked=true; }
    if(!exportIndividual){vdpStatus('V85 xuất VDP theo từng PDF record. Hãy bật “Xuất PDF riêng từng record”.','error');return;}
    var from=Math.max(1,Math.floor(Number($('vdpFrom').value)||1)),to=Math.min(vdp.records.length,Math.max(from,Math.floor(Number($('vdpTo').value)||vdp.records.length)));
    setBusy(true,'Đang render '+(to-from+1)+' PDF record'+(combinePdf?' · sau đó DPV tự Combine':'')+'…');
    bridgeCall('BuildVariableData',[JSON.stringify({dataPath:vdp.filePath,records:vdp.filePath?[]:vdp.records,mappings:maps,sourceFolder:vdp.sourceFolder,outputPath:out,from:from,to:to,fileNameField:$('vdpFileNameField').value,filePrefix:$('vdpFilePrefix').value||'VDP',exportIndividual:exportIndividual,combinePdf:combinePdf,combinedName:$('vdpCombinedName').value||'VDP_ALL'})]);
  }

  function vdpCombineExisting(){
    setBusy(true,'Chọn các PDF để DPV Combine trực tiếp…');
    bridgeCall('CombinePdfFilesDpv',[]);
  }

  window.VDPRO_receive = function (operation, payload) {
    if (operation === "connect") { clearConnectWatchdog(); }
    if (operation === "vdpBuildProgress") {
      var pr=parse(payload);
      if(pr && pr.ok){vdpStatus("Đang xuất record "+(pr.current||0)+"/"+(pr.total||0)+" · record dữ liệu "+(pr.recordNumber||"")+" · chế độ V79 Low-RAM…","ok");}
      return;
    }
    if (operation === "vdpCombineProgress") {
      var cp=parse(payload);
      if(cp && cp.ok){vdpStatus("Đang Combine trực tiếp trong DPV: "+(cp.current||0)+"/"+(cp.total||0)+" PDF · "+(cp.pages||0)+" trang…","ok");}
      return;
    }
    if (operation === "vdpCombineExisting" && !payload) { setBusy(false); vdpStatus("Đã hủy Combine PDF.",""); return; }
    setBusy(false); var r = parse(payload);
    if (!r.ok) {
      if (operation === "connect") { setConnected(false); }
      if (String(operation || "").indexOf("vdp") === 0) { vdpStatus(r.error || "Illustrator Bridge báo lỗi.", "error"); try { if ($("vdpStatus")) { $("vdpStatus").scrollIntoView(false); } } catch (eScroll) {} }
      else { status(r.error || "Illustrator Bridge báo lỗi.", "error"); }
      return;
    }
    if (operation === "connect") {
      setConnected(true, "Illustrator " + (r.version || "") + " đã kết nối"); status("Kết nối Illustrator thành công.", "ok"); return;
    }
    setConnected(true, "Illustrator đang kết nối");
    if (operation === "vdpCombineExisting") {
      vdpStatus("Combine trực tiếp hoàn tất "+(r.combinedCount||0)+" file → "+(r.combinedPages||0)+" trang. File: "+(r.combinedFile||""),"ok"); return;
    }
    if (operation === "vdpTargets") {
      var addedTargets = vdpMergeTargets(r.targets || []);
      vdpRenderMappings(false);
      vdpStatus("Đã thêm " + addedTargets + " vị trí. Tổng đang dùng: " + vdp.targets.length + " vị trí biến đổi.", "ok"); return;
    }
    if (operation === "vdpPreview") { vdpStatus("Đã preview record " + (r.recordNumber || "") + " với " + (r.applied || 0) + " kênh biến đổi.", "ok"); return; }
    if (operation === "vdpRestore") { vdpStatus("Đã khôi phục " + (r.restored || 0) + " đối tượng về nội dung gốc.", "ok"); return; }
    if (operation === "vdpBuild") {
      var msg="Hoàn tất "+(r.count||0)+" record với "+(r.mappingCount||0)+" vị trí biến đổi.";
      if(r.fastMode==="SAME_DOCUMENT_SNAPSHOT_V78"){msg+=" Gộp V78 snapshot cùng document.";} if(r.fastMode==="STREAM_LOW_RAM_V79"||r.fastMode==="PINNED_SOURCE_STREAM_V80"||r.fastMode==="TRUE_MULTIPAGE_STREAM_V84"){msg+=" Stream Low-RAM.";} if(r.fastMode==="RECORD_PDF_THEN_DPV_COMBINE_V86"){msg+=" V86: render PDF record rồi DPV tự Combine, không cần Acrobat.";}
      if(r.fidelityClone===true){msg+=" Fidelity AI: ON.";} if(r.autoSaved===true){msg+=" Đã tự Save AI trước khi chạy.";}
      if(r.units==="mm"){msg+=" Đơn vị output: mm.";}
      if(r.individualCount){msg+=" PDF riêng: "+r.individualCount+".";}
      if(r.combinedFile){msg+=" PDF Combine: "+r.combinedFile+" ("+(r.combinedPages||0)+" trang)"+(r.combineEngine?" · "+r.combineEngine:"")+".";}
      msg+=" Thư mục: "+(r.outputFolder||"");
      vdpStatus(msg,"ok"); return;
    }
    if (operation === "activeSource") {
      artboardMode = false; artboardDocumentName = ""; manualSizeMode = false; sources = [r.source]; renderSources();
      if (r.source && r.source.shapeDeferred) {
        status("Đã lấy file nhanh trong " + perfTime(r.source.readMs) + "; chưa quét toàn bộ artwork. Số con hiện tại là ước tính theo artboard; KHUON_BE thật sẽ được đọc khi xem hoặc xuất. Có thể dùng “Lấy khuôn đang chọn” để nhận chính xác ngay.", "ok");
      } else {
        status("Đã nhận file và KHUON_BE từ Illustrator trong " + perfTime(r.source && r.source.readMs) + ".", "ok");
      }
      return;
    }
    if (operation === "inspectSources") {
      artboardMode = false; artboardDocumentName = ""; manualSizeMode = false; sources = r.sources || []; renderSources(); status("Đã nhận " + sources.length + " file nguồn.", "ok"); return;
    }
    if (operation === "listArtboards") {
      pendingArtboards = r.artboards || []; artboardDocumentName = r.documentName || ""; renderArtboards(); status("Chọn các artboard cần dàn.", "ok"); return;
    }
    if (operation === "hostPreview") {
      if (r.groups) {
        $("previewMethod").innerText = r.duplex ?
          "Illustrator xác nhận: 1 PDF · 2 TRANG A/B · B XOAY ĐÚNG CHIỀU MÁY" : r.cattp ?
          "Illustrator xác nhận: " + r.printFileCount + " IN CATTP · KHÔNG KHUÔN" :
          "Illustrator xác nhận: " + r.printFileCount + " IN · " + r.dieFileCount + " KHUÔN";
      } else {
        $("previewCount").innerText = r.count; $("previewMethod").innerText = r.methodLabel || "Illustrator Preview";
      }
      $("engineState").innerText = "Đã đối chiếu AI"; status("Illustrator đã xác nhận bố cục.", "ok"); return;
    }
    if (operation === "diePreview") {
      status(r.manual ? "Đã mở trực tiếp " + r.count + " khuôn trong Illustrator; chưa lưu file." : "Đã mở bản xem trước khuôn trong Illustrator; chưa lưu file.", "ok"); return;
    }
    if (operation === "build") {
      var slowest = logPerformanceV48(r);
      if (r.printFileCount !== undefined) {
        status(r.duplex ?
          "Hoàn tất: đã tạo 1 FILE IN CATTP gồm 2 trang/artboard A–B; mặt B đã xoay đúng chiều máy trở giấy, chỉ có PON CATTP và không tạo FILE KHUÔN." + (slowest ? " Chậm nhất: " + slowest : "") : r.cattp ?
          "Hoàn tất: " + r.printFileCount + " FILE IN CATTP; PON cắt nằm chung file in, không tạo FILE KHUÔN." + (slowest ? " Chậm nhất: " + slowest : "") :
          (r.printFileCount === 0 ? "Hoàn tất: " + r.dieFileCount + " FILE KHUÔN BẾ." : r.dieFileCount === 0 ? "Hoàn tất: " + r.printFileCount + " FILE IN." : "Hoàn tất: " + r.printFileCount + " FILE IN và " + r.dieFileCount + " FILE KHUÔN BẾ.") + (slowest ? " Chậm nhất: " + slowest : ""), "ok");
      }
      else { status("Hoàn tất " + r.count + " con." + (slowest ? " Chậm nhất: " + slowest : "") + " Xem Nhật ký Bridge để thấy toàn bộ thời gian.", "ok"); }
    }
  };


  $("vdpOpenBtn").addEventListener("click", function(){ $("vdpPanel").className="vdp-overlay"; });
  $("vdpCloseBtn").addEventListener("click", function(){ $("vdpPanel").className="vdp-overlay hidden"; });
  $("vdpChooseDataBtn").addEventListener("click", vdpChooseData);
  $("vdpReloadDataBtn").addEventListener("click", function(){ if(!vdp.filePath){vdpChooseData();return;} bridgeCall("ReadVariableDataFile",[vdp.filePath],function(raw){if(raw){vdpLoadFileResult(raw);}}); });
  $("vdpScanTargetsBtn").addEventListener("click", vdpScanTargets);
  $("vdpClearTargetsBtn").addEventListener("click", function(){vdp.targets=[];vdpRenderMappings(false);vdpStatus("Đã xóa toàn bộ kênh biến đổi.","ok");});
  $("vdpAutoMapBtn").addEventListener("click", function(){ vdpSyncMappings(); vdpRenderMappings(true); vdpStatus("Đã thử tự map theo tên cột và tên đối tượng.","ok"); });
  $("vdpPrevBtn").addEventListener("click", function(){ $("vdpRecordIndex").value=String(Math.max(1,vdpCurrentIndex()-1)); vdpPreview(); });
  $("vdpNextBtn").addEventListener("click", function(){ $("vdpRecordIndex").value=String(Math.min(Math.max(1,vdp.records.length),vdpCurrentIndex()+1)); vdpPreview(); });
  $("vdpPreviewBtn").addEventListener("click", vdpPreview);
  $("vdpRestoreBtn").addEventListener("click", vdpRestore);
  $("vdpOutputBtn").addEventListener("click", function(){ bridgeCall("ChooseOutputFolder",[],function(p){if(p){$("vdpOutputPath").value=p;vdpStatus("Đã chọn thư mục xuất.","ok");}}); });
  $("vdpBuildBtn").addEventListener("click", vdpBuild);
    if($('vdpCombineExistingBtn')){$('vdpCombineExistingBtn').addEventListener('click',vdpCombineExisting);}

  $("connectBtn").addEventListener("click", connect);
  $("activeBtn").addEventListener("click", function () { getActive(false); });
  $("manualBtn").addEventListener("click", function () { getActive(true); });
  $("manualSizeBtn").addEventListener("click", openManualSize);
  $("closeManualSize").addEventListener("click", function () { $("manualSizeBox").className = "manual-size-box hidden"; });
  $("manualShape").addEventListener("change", syncManualShapeFields);
  $("applyManualSize").addEventListener("click", applyManualSize);
  $("multiBtn").addEventListener("click", chooseMultiple);
  $("artboardsBtn").addEventListener("click", listArtboards);
  $("closeArtboards").addEventListener("click", function () { $("artboardChooser").className = "artboard-box hidden"; });
  $("allArtboards").addEventListener("click", function () { var c=document.querySelectorAll(".ab-check"); for(var i=0;i<c.length;i++){c[i].checked=true;} });
  $("noneArtboards").addEventListener("click", function () { var c=document.querySelectorAll(".ab-check"); for(var i=0;i<c.length;i++){c[i].checked=false;} });
  $("useArtboards").addEventListener("click", useArtboards);
  $("localPreviewBtn").addEventListener("click", function () { localPreview(true); });
  $("hostPreviewBtn").addEventListener("click", hostPreview);
  $("diePreviewBtn").addEventListener("click", diePreview);
  $("buildBtn").addEventListener("click", build);
  $("outputBtn").addEventListener("click", function () { bridgeCall("ChooseOutputFolder", [], function(p){if(p){requiredEl("outputPath").value=p;status("Đã chọn thư mục xuất.","ok");}}); });
  $("ponBtn").addEventListener("click", function () { bridgeCall("ChoosePonFile", [], function(p){if(p){requiredEl("ponPath").value=p;status("Đã chọn file PON.","ok");}}); });
  $("clearPon").addEventListener("click", function () { requiredEl("ponPath").value=""; });
  $("clearLog").addEventListener("click", function () { $("log").innerHTML=""; });
  var demiPrevGapX = null, demiPrevGapY = null;
  function syncDemiModeV87(fromUser) {
    var demi = requiredEl("demiMode"), gx = requiredEl("gapX"), gy = requiredEl("gapY");
    var irrelevant = ["uniformGap","trueShape","specialStagger","cornerSafe","cornerZone","angleStep"];
    var i, node;
    if (demi.checked) {
      if (fromUser) { demiPrevGapX = gx.value; demiPrevGapY = gy.value; }
      gx.value = "0"; gy.value = "0"; gx.disabled = true; gy.disabled = true;
      for (i = 0; i < irrelevant.length; i++) { node = $(irrelevant[i]); if (node) { node.disabled = true; } }
    } else {
      gx.disabled = false; gy.disabled = false;
      if (fromUser && demiPrevGapX !== null) { gx.value = demiPrevGapX; gy.value = demiPrevGapY; }
      for (i = 0; i < irrelevant.length; i++) { node = $(irrelevant[i]); if (node) { node.disabled = false; } }
      syncUniformGapV83();
    }
  }
  $("demiMode").addEventListener("change", function () { syncDemiModeV87(true); localPreview(false); });
  function syncFinishCropFields() {
    var enabled = check("finishCropMarks");
    $("finishMarkLength").disabled = !enabled;
    $("finishMarkGap").disabled = !enabled;
    $("duplexMode").disabled = !enabled;
    if (!enabled) { $("duplexMode").checked = false; }
    $("duplexFlip").disabled = !enabled || !check("duplexMode");
  }
  $("finishCropMarks").addEventListener("change", function () { syncFinishCropFields(); localPreview(false); });
  $("duplexMode").addEventListener("change", function () { syncFinishCropFields(); renderSources(); localPreview(false); });


  function syncUniformGapV83(){
    /* V87: Demi là engine riêng. Không để Khe đều/True-Shape/Khuôn đặc biệt
       can thiệp UI khi Bế 1 dao đang bật. */
    if ($("demiMode") && $("demiMode").checked) { return; }
    var exactSpecial = $("uniformGap") && $("uniformGap").checked && $("specialStagger") && $("specialStagger").checked;
    if ($("specialStagger")) { $("specialStagger").disabled = false; }
    if ($("trueShape")) {
      $("trueShape").disabled = false;
      if (exactSpecial) { $("trueShape").checked = true; }
    }
  }
  if ($("uniformGap")) { $("uniformGap").addEventListener("change", function(){ syncUniformGapV83(); localPreview(false); }); }
  if ($("specialStagger")) { $("specialStagger").addEventListener("change", function(){ syncUniformGapV83(); localPreview(false); }); }
  syncUniformGapV83();
  syncDemiModeV87(false);
  var settingIds = ["paperW","paperH","margin","header","gapX","gapY","maxQty","linkBleed","allowRotate","uniformGap","trueShape","specialStagger","fastMode","cornerSafe","cornerZone","angleStep","demiExtend","cornerPonRed","finishMarkLength","finishMarkGap","duplexFlip"];
  for (var si = 0; si < settingIds.length; si++) {
    var settingNode = $(settingIds[si]);
    if (settingNode) { settingNode.addEventListener("change", function () { localPreview(false); }); }
  }

  syncFinishCropFields();
  renderSources();
  if (externalReady()) { window.setTimeout(function () { bridgeCall("ConnectIllustrator", [false]); }, 500); }
}());


/* ===== SOURCE: app_v102.js ===== */
(function () {
  function byId(id){ return document.getElementById(id); }
  function addClass(el, c){ if(!el)return; if((' '+el.className+' ').indexOf(' '+c+' ')<0) el.className += (el.className?' ':'')+c; }
  function removeClass(el, c){ if(!el)return; el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,''); }
  function safeStoreGet(k){ try{return window.localStorage?localStorage.getItem(k):null;}catch(e){return null;} }
  function safeStoreSet(k,v){ try{if(window.localStorage)localStorage.setItem(k,v);}catch(e){} }
  function textOf(el){ return el ? (el.textContent || el.innerText || '') : ''; }
  var toastTimer=null;
  function toast(msg){
    var t=byId('dpvToast'); if(!t)return; if('textContent' in t)t.textContent=msg; else t.innerText=msg;
    addClass(t,'show'); if(toastTimer)clearTimeout(toastTimer); toastTimer=setTimeout(function(){removeClass(t,'show');},2200);
  }
  function setTheme(theme){
    var dark=theme==='dark';
    if(dark)addClass(document.body,'dpv-dark'); else removeClass(document.body,'dpv-dark');
    var sw=byId('dpvThemeSwitch'); if(sw)sw.setAttribute('aria-pressed',dark?'true':'false');
    var light=byId('dpvThemeLightLabel'), d=byId('dpvThemeDarkLabel');
    if(light)light.style.fontWeight=dark?'650':'900'; if(d)d.style.fontWeight=dark?'900':'650';
    safeStoreSet('dpv.theme', dark?'dark':'light');
  }
  function getTheme(){ var v=safeStoreGet('dpv.theme'); return v==='dark'?'dark':'light'; }
  function insertShell(){
    if(byId('dpvSidebar'))return;
    var sidebar=document.createElement('aside'); sidebar.id='dpvSidebar'; sidebar.className='dpv-sidebar';
    sidebar.innerHTML=''
      +'<div class="dpv-side-brand"><img src="../../assets/icon/DPV-logo-128.png" alt="DPV"><div class="dpv-side-brand-copy"><strong>DPV<sup>®</sup></strong><small>PRINT WORKFLOW</small></div></div>'
      +'<nav class="dpv-nav">'
      +'<button class="dpv-nav-btn active" data-nav="main"><span class="dpv-nav-icon">▦</span>Dàn file</button>'
      +'<button class="dpv-nav-btn" data-nav="vdp"><span class="dpv-nav-icon">⛁</span>Biến đổi dữ liệu</button>'
      +'<button class="dpv-nav-btn" data-nav="combine"><span class="dpv-nav-icon">▤</span>Combine PDF</button>'
      +'<button class="dpv-nav-btn" data-nav="preset"><span class="dpv-nav-icon">▱</span>Thư viện preset</button>'
      +'<button class="dpv-nav-btn" data-nav="settings"><span class="dpv-nav-icon">⚙</span>Cài đặt</button>'
      +'</nav><div class="dpv-side-spacer"></div>'
      +'<div class="dpv-side-card"><strong><span class="dpv-side-dot"></span>Core V101 STABLE</strong>Engine dàn được khóa ổn định.<br>V102 chỉ nâng cấp giao diện.</div>'
      +'<div class="dpv-side-footer"><span class="dpv-avatar">DP</span><div class="dpv-side-user"><strong>DPV Desktop</strong><small>Windows + macOS Intel</small></div></div>';
    document.body.insertBefore(sidebar, document.body.firstChild);

    var top=document.querySelector ? document.querySelector('.topbar') : null;
    if(top){
      var search=document.createElement('div'); search.className='dpv-search-wrap'; search.innerHTML='<div class="dpv-search"><input id="dpvSearch" type="text" placeholder="Tìm nhanh chức năng, thông số..."><span class="dpv-search-key">Ctrl K</span></div>';
      var conn=top.querySelector ? top.querySelector('.connection') : null;
      if(conn)top.insertBefore(search,conn); else top.appendChild(search);
      if(conn){
        var theme=document.createElement('div'); theme.className='dpv-theme-toggle';
        theme.innerHTML='<span id="dpvThemeLightLabel" class="dpv-theme-label">☀ Light</span><button id="dpvThemeSwitch" class="dpv-theme-switch" type="button" aria-label="Đổi Light/Dark"><span class="dpv-theme-knob"></span></button><span id="dpvThemeDarkLabel" class="dpv-theme-label">Dark</span>';
        conn.appendChild(theme);
      }
    }

    var ws=document.querySelector ? document.querySelector('.workspace') : null;
    if(ws){
      var cols=document.createElement('div'); cols.className='workspace-columns';
      var kids=[],i; for(i=0;i<ws.children.length;i++){ if((' '+ws.children[i].className+' ').indexOf(' column ')>=0)kids.push(ws.children[i]); }
      for(i=0;i<kids.length;i++)cols.appendChild(kids[i]);
      var ov=document.createElement('div'); ov.className='dpv-overview'; ov.innerHTML=''
        +'<section class="dpv-hero"><div class="dpv-hero-kicker">DPV® WORKSPACE · Illustrator Automation</div><h2 id="dpvHeroTitle">Dàn file nhanh, chính xác & ổn định</h2><p id="dpvHeroText">True-Shape · Exact Gap · PON · Variable Data · PDF Combine</p><div class="dpv-hero-tags"><span class="dpv-chip">Core: V101 STABLE</span><span class="dpv-chip">UI: V103 LIVE PREVIEW</span><span id="dpvHeroSource" class="dpv-chip">Chưa có nguồn</span></div></section>'
        +'<div class="dpv-kpis"><div class="dpv-kpi"><label>SỐ CON DỰ KIẾN</label><strong id="dpvKpiCount">0</strong><small>Bố cục hiện tại</small></div><div class="dpv-kpi"><label>HIỆU SUẤT</label><strong id="dpvKpiEff">0%</strong><small id="dpvKpiEffHint">Đang chờ tính</small></div><div class="dpv-kpi"><label>ILLUSTRATOR</label><strong id="dpvKpiAi">Offline</strong><small id="dpvKpiAiHint">Bridge status</small></div></div>';
      ws.insertBefore(ov,ws.firstChild); ws.appendChild(cols);
    }
    var settings=document.createElement('div'); settings.id='dpvSettings'; settings.className='dpv-settings';
    settings.innerHTML='<h3>Cài đặt giao diện</h3><div class="dpv-settings-row"><span>Chế độ màu</span><button id="dpvSettingsTheme" class="button tiny">Đổi Light / Dark</button></div><div class="dpv-settings-row"><span>Engine dàn</span><strong>V101 STABLE · khóa</strong></div><div class="dpv-settings-row"><span>Giao diện</span><strong>V103 LIVE PREVIEW</strong></div>';
    document.body.appendChild(settings);
    var toastEl=document.createElement('div'); toastEl.id='dpvToast'; toastEl.className='dpv-toast'; document.body.appendChild(toastEl);
  }
  function setActiveNav(name){
    var btns=document.querySelectorAll?document.querySelectorAll('.dpv-nav-btn'):[]; var i;
    for(i=0;i<btns.length;i++){ if(btns[i].getAttribute('data-nav')===name)addClass(btns[i],'active'); else removeClass(btns[i],'active'); }
  }
  function openVdp(){ var b=byId('vdpOpenBtn'); if(b&&b.click)b.click(); setActiveNav('vdp'); }
  function bindNav(){
    var btns=document.querySelectorAll?document.querySelectorAll('.dpv-nav-btn'):[]; var i;
    for(i=0;i<btns.length;i++)btns[i].onclick=function(){
      var n=this.getAttribute('data-nav');
      if(n==='main'){ var p=byId('vdpPanel'); if(p)addClass(p,'hidden'); setActiveNav('main'); }
      else if(n==='vdp'){ openVdp(); }
      else if(n==='combine'){ openVdp(); setTimeout(function(){ var c=byId('vdpCombineExistingBtn'); if(c&&c.scrollIntoView)c.scrollIntoView(); toast('Combine PDF nằm trong Variable Data.'); },80); }
      else if(n==='preset'){ toast('Thư viện preset: giao diện đã sẵn sàng, engine preset chưa được thêm để giữ V101 ổn định.'); }
      else if(n==='settings'){ var s=byId('dpvSettings'); if(s){ if((' '+s.className+' ').indexOf(' open ')>=0)removeClass(s,'open'); else addClass(s,'open'); } setActiveNav('settings'); }
    };
    var close=byId('vdpCloseBtn'); if(close)close.addEventListener?close.addEventListener('click',function(){setActiveNav('main');}):null;
  }
  function bindTheme(){
    var sw=byId('dpvThemeSwitch'), st=byId('dpvSettingsTheme');
    function flip(){ setTheme(document.body.className.indexOf('dpv-dark')>=0?'light':'dark'); }
    if(sw)sw.onclick=flip; if(st)st.onclick=flip; setTheme(getTheme());
  }
  function bindSearch(){
    var inp=byId('dpvSearch'); if(!inp)return;
    document.onkeydown=function(e){ e=e||window.event; if((e.ctrlKey||e.metaKey)&&(e.keyCode===75)){ try{e.preventDefault();}catch(x){} inp.focus(); return false; } };
    inp.onkeydown=function(e){ e=e||window.event; if(e.keyCode!==13)return; var q=(inp.value||'').toLowerCase().replace(/^\s+|\s+$/g,''); if(!q)return;
      var nodes=document.querySelectorAll?document.querySelectorAll('label,strong,.button,.panel-title'):[]; var i,t;
      for(i=0;i<nodes.length;i++){ t=textOf(nodes[i]).toLowerCase(); if(t.indexOf(q)>=0){ try{nodes[i].scrollIntoView({block:'center'});}catch(x){nodes[i].scrollIntoView();} toast('Đã tìm: '+textOf(nodes[i]).replace(/^\s+|\s+$/g,'')); return; } }
      toast('Không tìm thấy “'+inp.value+'”');
    };
  }
  function syncKpis(){
    var pc=byId('previewCount'), eff=byId('efficiency'), cd=byId('connectionDot'), ct=byId('connectionText');
    var kc=byId('dpvKpiCount'), ke=byId('dpvKpiEff'), ka=byId('dpvKpiAi'), kh=byId('dpvKpiAiHint'), eh=byId('dpvKpiEffHint');
    if(kc&&pc)kc.innerHTML=textOf(pc)||'0'; if(ke&&eff)ke.innerHTML=textOf(eff)||'0%';
    var online=cd&&(' '+cd.className+' ').indexOf(' online ')>=0; if(ka)ka.innerHTML=online?'Online':'Offline'; if(kh)kh.innerHTML=online?'Illustrator đã kết nối':'Chờ kết nối';
    if(eh&&eff){ var n=parseFloat(textOf(eff)); eh.innerHTML=isNaN(n)?'Đang chờ tính':(n>=80?'Rất tốt':(n>=60?'Tốt':'Có thể tối ưu')); }
    var sl=document.querySelectorAll?document.querySelectorAll('.source-name'):[]; var hs=byId('dpvHeroSource'); if(hs)hs.innerHTML=sl&&sl.length?('Nguồn: '+textOf(sl[0])):'Chưa có nguồn';
  }
  function updateVersion(){ var v=document.querySelector?document.querySelector('.version-badge'):null; if(v)v.innerHTML='V103 LIVE PREVIEW · CORE V101 STABLE'; var beta=document.querySelector?document.querySelector('.beta-note'):null; if(beta)beta.innerHTML='<strong>DPV® V103 LIVE PREVIEW · CORE V101 STABLE</strong><br>Light/Dark hiện đại · sidebar dashboard mới · engine dàn V101 được giữ nguyên, không thay thuật toán.'; }
  function start(){ insertShell(); updateVersion(); bindTheme(); bindNav(); bindSearch(); syncKpis(); setInterval(syncKpis,1600); }
  if(document.readyState==='loading'){ if(document.addEventListener)document.addEventListener('DOMContentLoaded',start); else window.attachEvent('onload',start); } else start();
})();


/* ===== SOURCE: app_v103.js ===== */
(function () {
  var lastResult=null, lastConfig=null, exactView=true;
  var mainState={zoom:1,panX:0,panY:0,drag:false,lastX:0,lastY:0};
  var fullState={zoom:1,panX:0,panY:0,drag:false,lastX:0,lastY:0};
  function $(id){return document.getElementById(id);}
  function txt(el,s){if(!el)return; if('textContent' in el)el.textContent=s; else el.innerText=s;}
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function isDark(){return (' '+document.body.className+' ').indexOf(' dpv-dark ')>=0;}
  function ensureShell(){
    var canvas=$('layoutCanvas'); if(!canvas||$('layoutZoomMinus'))return;
    var parent=canvas.parentNode, vp=document.createElement('div'); vp.id='layoutViewport'; vp.className='layout-viewport';
    parent.insertBefore(vp,canvas); vp.appendChild(canvas);
    var sh=parent.querySelector?parent.querySelector('.subhead'):null;
    if(sh){
      var tb=document.createElement('div'); tb.className='layout-view-tools';
      tb.innerHTML='<button id="layoutZoomMinus" class="layout-tool" title="Thu nhỏ">−</button>'+
        '<span id="layoutZoomLabel" class="layout-zoom-label">100%</span>'+
        '<button id="layoutZoomPlus" class="layout-tool" title="Phóng to">+</button>'+
        '<button id="layoutZoomFit" class="layout-tool text">Vừa khổ</button>'+
        '<button id="layoutExactView" class="layout-tool text active" title="Vẽ trực tiếp contour KHUON_BE thật">Khuôn thật</button>'+
        '<button id="layoutFullscreen" class="layout-tool" title="Xem toàn màn hình">⛶</button>';
      sh.appendChild(tb);
    }
    var overlay=document.createElement('div'); overlay.id='layoutFullscreenOverlay'; overlay.className='layout-fullscreen hidden';
    overlay.innerHTML='<div class="layout-fullscreen-panel"><div class="layout-fullscreen-head"><div><strong>Xem trực tiếp sơ đồ dàn</strong><span id="layoutFullCaption"></span></div><div class="layout-view-tools"><button id="layoutFullMinus" class="layout-tool">−</button><span id="layoutFullZoomLabel" class="layout-zoom-label">100%</span><button id="layoutFullPlus" class="layout-tool">+</button><button id="layoutFullFit" class="layout-tool text">Vừa khổ</button><button id="layoutFullClose" class="layout-tool danger">×</button></div></div><div id="layoutFullViewport" class="layout-viewport fullscreen"><canvas id="layoutFullCanvas" width="1280" height="760"></canvas></div><div class="layout-hint">Cuộn chuột để zoom · Kéo chuột để di chuyển · Double-click để vừa khổ · Khuôn thật = contour KHUON_BE trực tiếp</div></div>';
    document.body.appendChild(overlay);
    bindView(vp,canvas,mainState,'layoutZoomLabel');
    bindView($('layoutFullViewport'),$('layoutFullCanvas'),fullState,'layoutFullZoomLabel');
    $('layoutZoomMinus').onclick=function(){zoomBy(mainState,canvas,-.2,'layoutZoomLabel');};
    $('layoutZoomPlus').onclick=function(){zoomBy(mainState,canvas,.2,'layoutZoomLabel');};
    $('layoutZoomFit').onclick=function(){fitView(mainState,canvas,'layoutZoomLabel');};
    $('layoutExactView').onclick=function(){exactView=!exactView; this.className='layout-tool text'+(exactView?' active':''); txt(this,exactView?'Khuôn thật':'Khung nhanh'); if(lastResult&&lastConfig)renderEnhanced(canvas,lastResult,lastConfig); if(!overlay.className.match(/hidden/)&&lastResult&&lastConfig)renderEnhanced($('layoutFullCanvas'),lastResult,lastConfig);};
    $('layoutFullscreen').onclick=function(){openFull();};
    $('layoutFullClose').onclick=function(){overlay.className='layout-fullscreen hidden';};
    $('layoutFullMinus').onclick=function(){zoomBy(fullState,$('layoutFullCanvas'),-.2,'layoutFullZoomLabel');};
    $('layoutFullPlus').onclick=function(){zoomBy(fullState,$('layoutFullCanvas'),.2,'layoutFullZoomLabel');};
    $('layoutFullFit').onclick=function(){fitView(fullState,$('layoutFullCanvas'),'layoutFullZoomLabel');};
  }
  function setTransform(st,canvas,labelId){
    canvas.style.transformOrigin='0 0';
    canvas.style.transform='translate('+st.panX+'px,'+st.panY+'px) scale('+st.zoom+')';
    txt($(labelId),Math.round(st.zoom*100)+'%');
  }
  function fitView(st,canvas,labelId){st.zoom=1;st.panX=0;st.panY=0;setTransform(st,canvas,labelId);}
  function zoomBy(st,canvas,delta,labelId,cx,cy){
    var old=st.zoom, nz=clamp(old+delta,.25,8); if(nz===old)return;
    if(cx===undefined){cx=canvas.clientWidth/2;cy=canvas.clientHeight/2;}
    st.panX=cx-(cx-st.panX)*(nz/old); st.panY=cy-(cy-st.panY)*(nz/old); st.zoom=nz; setTransform(st,canvas,labelId);
  }
  function bindView(vp,canvas,st,labelId){
    if(!vp||!canvas)return;
    function wheel(e){e=e||window.event; var d=0; if(e.deltaY!==undefined)d=e.deltaY; else if(e.wheelDelta!==undefined)d=-e.wheelDelta; var r=vp.getBoundingClientRect?vp.getBoundingClientRect():{left:0,top:0}; var cx=(e.clientX||0)-r.left,cy=(e.clientY||0)-r.top; zoomBy(st,canvas,d<0?.18:-.18,labelId,cx,cy); try{e.preventDefault();}catch(x){} return false;}
    if(vp.addEventListener){vp.addEventListener('wheel',wheel,{passive:false});vp.addEventListener('mousewheel',wheel,false);}else vp.onmousewheel=wheel;
    vp.onmousedown=function(e){e=e||window.event;st.drag=true;st.lastX=e.clientX;st.lastY=e.clientY;vp.className+=' dragging';return false;};
    document.addEventListener&&document.addEventListener('mousemove',function(e){if(!st.drag)return; st.panX+=e.clientX-st.lastX;st.panY+=e.clientY-st.lastY;st.lastX=e.clientX;st.lastY=e.clientY;setTransform(st,canvas,labelId);});
    document.addEventListener&&document.addEventListener('mouseup',function(){if(st.drag){st.drag=false;vp.className=vp.className.replace(/\sdragging/g,'');}});
    vp.ondblclick=function(){fitView(st,canvas,labelId);};
  }
  function openFull(){
    var o=$('layoutFullscreenOverlay'),c=$('layoutFullCanvas'); if(!o||!c)return; o.className='layout-fullscreen';
    var w=Math.max(900,(window.innerWidth||1400)-110),h=Math.max(560,(window.innerHeight||900)-150); c.width=w;c.height=h;
    fitView(fullState,c,'layoutFullZoomLabel'); if(lastResult&&lastConfig)renderEnhanced(c,lastResult,lastConfig); else copyCanvas($('layoutCanvas'),c);
    txt($('layoutFullCaption'),$('layoutCaption')?(' · '+($('layoutCaption').textContent||$('layoutCaption').innerText||'')):'');
  }
  function copyCanvas(src,dst){if(!src||!dst)return;var ctx=dst.getContext('2d');ctx.clearRect(0,0,dst.width,dst.height);ctx.drawImage(src,0,0,dst.width,dst.height);}
  function getVariant(shape,item){
    if(!shape||!shape.points||shape.points.length<3)return null;
    var a=item.angle!==undefined?Number(item.angle):(item.rotated===true?90:0);
    try{if(window.ANPTrueShape&&ANPTrueShape.rotateVariant)return ANPTrueShape.rotateVariant(shape.points,Number(shape.w||item.w),Number(shape.h||item.h),a);}catch(e){}
    return null;
  }
  function renderEnhanced(canvas,result,c){
    if(!canvas||!result||!c)return; var layout=result.layout;if(!layout||!layout.items||!layout.items.length)return;
    var ctx=canvas.getContext('2d'), pad=canvas=== $('layoutFullCanvas')?34:12, paperW=Number(c.paperW),paperH=Number(c.paperH); if(!(paperW>0&&paperH>0))return;
    var scale=Math.min((canvas.width-pad*2)/paperW,(canvas.height-pad*2)/paperH), sw=paperW*scale,sh=paperH*scale,ox=(canvas.width-sw)/2,oy=(canvas.height-sh)/2;
    var dark=isDark(), bg=dark?'#0a1725':'#f5f1e4', sheet=dark?'#0d2030':'#fffefa', border=dark?'#718298':'#172033', marginC=dark?'rgba(55,211,166,.8)':'rgba(8,168,120,.78)';
    ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle=bg;ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle=sheet;ctx.fillRect(ox,oy,sw,sh);ctx.strokeStyle=border;ctx.lineWidth=1.2;ctx.strokeRect(ox+.5,oy+.5,sw-1,sh-1);
    ctx.save();ctx.strokeStyle=marginC;ctx.lineWidth=1;if(ctx.setLineDash)ctx.setLineDash([5,4]);ctx.strokeRect(ox+Number(c.margin)*scale,oy+Number(c.margin)*scale,Math.max(0,(paperW-Number(c.margin)*2)*scale),Math.max(0,(paperH-Number(c.margin)*2)*scale));ctx.restore();
    var items=layout.items, maxDraw=canvas===$('layoutFullCanvas')?5000:2600,stride=Math.max(1,Math.ceil(items.length/maxDraw));
    var colors=dark?['#f6bf22','#28c69a','#ff7b59','#48b8d4','#8bcf65','#e7a932']:['#e5a900','#08a878','#e85a32','#1399af','#6cad3c','#d68d00'];
    for(var i=0;i<items.length;i+=stride){
      var it=items[i],si=Math.max(0,Number(it.sourceIndex)||0),src=(c.sources&&c.sources[si])||(c.sources&&c.sources[0])||{},col=colors[si%colors.length];
      var bx=ox+(Number(c.margin)+Number(it.x))*scale,by=oy+(Number(c.margin)+Number(it.y))*scale,variant=exactView?getVariant(src.shape,it):null;
      ctx.beginPath();
      if(variant&&variant.points&&variant.points.length>=3){
        for(var p=0;p<variant.points.length;p++){var px=bx+Number(variant.points[p].x)*scale,py=by+Number(variant.points[p].y)*scale;if(p===0)ctx.moveTo(px,py);else ctx.lineTo(px,py);}ctx.closePath();
      } else if(src.shape&&src.shape.isCircle===true){var ww=Number(it.w)*scale,hh=Number(it.h)*scale;ctx.arc(bx+ww/2,by+hh/2,Math.min(ww,hh)/2,0,Math.PI*2,false);
      } else {ctx.rect(bx+Number(it.offsetX||0)*scale,by+Number(it.offsetY||0)*scale,Number(it.w)*scale,Number(it.h)*scale);}
      ctx.fillStyle=col;ctx.globalAlpha=dark?.11:.12;ctx.fill();ctx.globalAlpha=1;ctx.strokeStyle=col;ctx.lineWidth=Math.max(.65,Math.min(1.5,scale*.14));ctx.stroke();
      if(canvas===$('layoutFullCanvas')&&fullState.zoom>=1.5&&items.length<250){ctx.fillStyle=dark?'#9fb1c5':'#53637a';ctx.font='10px Segoe UI, Arial';ctx.fillText(String(i+1),bx+3,by+12);}
    }
    if(canvas===$('layoutCanvas')){var cap=$('layoutCaption'); if(cap){var base=items.length+' con trên '+paperW+'×'+paperH+' mm';txt(cap,base+(exactView?' · view KHUON_BE thật':' · khung nhanh'));}}
  }
  function hookEngine(){
    if(!window.VDPROEngine||!VDPROEngine.preview||VDPROEngine.__v103Hook)return;
    var old=VDPROEngine.preview; VDPROEngine.preview=function(c){var r=old.apply(VDPROEngine,arguments); lastConfig=c;lastResult=r; setTimeout(function(){try{renderEnhanced($('layoutCanvas'),r,c);}catch(e){}},0);return r;}; VDPROEngine.__v103Hook=true;
  }
  function updateLabels(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V103 LIVE PREVIEW · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V103 LIVE PREVIEW · CORE V101 STABLE</strong><br>Zoom 25–800% · kéo để pan · full-screen · xem contour KHUON_BE trực tiếp · engine V101 không thay đổi.';
  }
  function start(){ensureShell();hookEngine();updateLabels();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();


/* ===== SOURCE: app_v105.js ===== */
(function(){
  "use strict";
  function byId(id){ return document.getElementById(id); }
  function setText(el,v){ if(!el)return; if('textContent' in el)el.textContent=v; else el.innerText=v; }
  function addLog(msg){
    var box=byId('log'); if(!box)return;
    var d=new Date(), z=function(n){return (n<10?'0':'')+n;};
    var row=document.createElement('div'); row.className='log-line';
    setText(row,'['+z(d.getHours())+':'+z(d.getMinutes())+':'+z(d.getSeconds())+'] '+msg);
    box.appendChild(row); box.scrollTop=box.scrollHeight;
  }
  function showStatus(msg,kind){
    var s=byId('status'); if(s){s.className='status '+(kind||'');setText(s,msg);} addLog(msg);
    var t=byId('dpvToast'); if(t){setText(t,msg); if((' '+t.className+' ').indexOf(' show ')<0)t.className+=' show'; setTimeout(function(){t.className=(' '+t.className+' ').replace(' show ',' ').replace(/^\s+|\s+$/g,'');},1800);}
  }
  function callNative(method,args,done,fail){
    args=args||[];
    try{
      if(window.DPVNative && typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke(method,args).then(function(v){done(v);}).catch(function(e){fail((e&&e.message)||String(e));});
        return;
      }
      if(window.external && typeof window.external[method] !== 'undefined'){
        var v;
        if(args.length===0)v=window.external[method]();
        else if(args.length===1)v=window.external[method](args[0]);
        else if(args.length===2)v=window.external[method](args[0],args[1]);
        else throw new Error('Quá nhiều tham số Bridge.');
        done(v); return;
      }
      fail('DPV Bridge chưa sẵn sàng.');
    }catch(e){fail((e&&e.message)||String(e));}
  }
  function bindPonPicker(){
    var old=byId('ponBtn'); if(!old||!old.parentNode)return;
    /* Replace the node to remove any older click/ripple handlers attached by cached UI layers. */
    var btn=old.cloneNode(true); btn.id='ponBtn'; btn.className=(btn.className||'')+' dpv-native-dialog-button';
    old.parentNode.replaceChild(btn,old);
    btn.onclick=function(ev){
      ev=ev||window.event; try{if(ev.preventDefault)ev.preventDefault();}catch(x){}
      if(btn.disabled)return false;
      btn.disabled=true; setText(btn,'Đang mở...');
      callNative('ChoosePonFile',[],function(path){
        btn.disabled=false; setText(btn,'Chọn PON');
        path=String(path||'');
        if(path){var p=byId('ponPath'); if(p){p.value=path; try{var e=document.createEvent('HTMLEvents');e.initEvent('change',true,false);p.dispatchEvent(e);}catch(x){}} showStatus('Đã chọn file PON.','ok');}
        else showStatus('Đã hủy chọn PON.','');
      },function(err){btn.disabled=false;setText(btn,'Chọn PON');showStatus('Không mở được hộp thoại PON: '+err,'error');});
      return false;
    };
  }
  function markVersion(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)setText(v,'V108 ICON · PON HOTFIX · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V108 ICON · PON HOTFIX · CORE V101 STABLE</strong><br>Sửa nút Chọn PON trên Windows + Mac Intel · không thay engine dàn V101.';
  }
  function start(){bindPonPicker();markVersion();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();


/* ===== SOURCE: app_v107.js ===== */
(function(){
  "use strict";
  function byId(id){return document.getElementById(id);}
  function text(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function status(msg,kind){
    var s=byId('status');if(s){s.className='status '+(kind||'');text(s,msg);}
    var log=byId('log');if(log){var r=document.createElement('div');r.className='log-line';text(r,msg);log.appendChild(r);log.scrollTop=log.scrollHeight;}
    var t=byId('dpvToast');if(t){text(t,msg);if((' '+t.className+' ').indexOf(' show ')<0)t.className+=' show';setTimeout(function(){t.className=(' '+t.className+' ').replace(' show ',' ').replace(/^\s+|\s+$/g,'');},2200);}
  }
  var pending=false;
  window.__DPVNativePonResult=function(path,err){
    var btn=byId('ponBtn');pending=false;if(btn){btn.disabled=false;text(btn,'Chọn PON');}
    if(err){status('Không mở được hộp thoại PON: '+String(err),'error');return;}
    path=String(path||'');
    if(!path){status('Đã hủy chọn PON.','');return;}
    var input=byId('ponPath');if(input){input.value=path;try{var ev=document.createEvent('HTMLEvents');ev.initEvent('change',true,false);input.dispatchEvent(ev);}catch(e){}}
    status('Đã chọn file PON: '+path,'ok');
  };
  function fallbackBridge(btn){
    try{
      if(window.DPVNative&&typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke('ChoosePonFile',[]).then(function(v){window.__DPVNativePonResult(v,'');}).catch(function(e){window.__DPVNativePonResult('',(e&&e.message)||String(e));});
        return true;
      }
      if(window.external&&typeof window.external.ChoosePonFile!=='undefined'){
        window.__DPVNativePonResult(window.external.ChoosePonFile(),'');return true;
      }
    }catch(e){window.__DPVNativePonResult('',(e&&e.message)||String(e));return true;}
    return false;
  }
  function bind(){
    var old=byId('ponBtn');if(!old||!old.parentNode)return;
    var btn=old.cloneNode(true);btn.id='ponBtn';btn.className=(btn.className||'')+' dpv-native-dialog-button';old.parentNode.replaceChild(btn,old);
    btn.onclick=function(ev){
      ev=ev||window.event;try{if(ev.preventDefault)ev.preventDefault();if(ev.stopPropagation)ev.stopPropagation();}catch(e){}
      if(pending||btn.disabled)return false;
      pending=true;btn.disabled=true;text(btn,'Đang mở...');
      try{
        if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.dpvPon){
          window.webkit.messageHandlers.dpvPon.postMessage('choose');return false;
        }
      }catch(e0){}
      if(!fallbackBridge(btn))window.__DPVNativePonResult('','DPV Native Bridge chưa sẵn sàng.');
      return false;
    };
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)text(v,'V108 ICON + NATIVE PON FIX · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V107 Native PON Fix · Core V101 Stable</strong><br>Mac dùng hộp thoại file native trực tiếp trong DPV.app, không còn sinh AppleScript Choose PON gây lỗi -2741.';
  }
  function start(){bind();mark();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();


/* ===== SOURCE: app_v111_brand.js ===== */
(function(){
  function done(){var s=document.getElementById('dpvSplash');if(!s)return;setTimeout(function(){s.className+=' dpv-splash-hide';setTimeout(function(){if(s&&s.parentNode)s.parentNode.removeChild(s);},420);},420);}
  if(document.readyState==='complete'){done();}else if(window.addEventListener){window.addEventListener('load',done,false);}else{window.attachEvent('onload',done);}
})();


/* ===== SOURCE: app_v113.js ===== */
(function(){"use strict";function t(e,v){if(!e)return;if('textContent'in e)e.textContent=v;else e.innerText=v;}function start(){var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)t(v,'V113 STABLE DIALOGS · CORE V101');var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V113 Stable Dialogs · Core V101</strong><br>Windows: native WinForms/Shell dialogs có chống click lặp cho PON, file nguồn, CSV/TXT, thư mục xuất và Combine PDF.';}if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();})();


/* ===== SOURCE: app_v114.js ===== */
(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function txt(el,v){if(!el)return;if('textContent'in el)el.textContent=v;else el.innerText=v;}
  function add(el,c){if(el&&(' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(el)el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function show(el,on){if(!el)return;if(on)rem(el,'hidden');else add(el,'hidden');}
  var sheetSnapshot=null;
  function getCore(){
    if(!window.DPVCoreV101||typeof window.DPVCoreV101.getConfig!=='function')throw new Error('Core V101 chưa sẵn sàng.');
    var c=window.DPVCoreV101.getConfig(),l=c&&(c.precomputedLayoutV101||c.precomputedLayoutV99);
    if(!l||!l.items||!l.items.length)throw new Error('Chưa có bố cục V101. Hãy đóng VDP → bấm Tính nhanh trên DPV → mở VDP lại.');
    return {config:c,layout:l};
  }
  function state(){if(!window.DPVVDP101||!window.DPVVDP101.getState)throw new Error('VDP Core chưa sẵn sàng.');return window.DPVVDP101.getState();}
  function status(m,k){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}
  function calcSummary(){
    try{
      var x=getCore(),s=state(),from=Math.max(1,Number($('vdpFrom').value)||1),to=Math.min(Number(s.recordCount||0),Math.max(from,Number($('vdpTo').value)||Number(s.recordCount||0))),n=Math.max(0,to-from+1),slots=x.layout.items.length,sheets=slots?Math.ceil(n/slots):0;
      sheetSnapshot=x;
      txt($('vdpSheetSlots'),String(slots));txt($('vdpSheetTotal'),String(sheets));txt($('vdpSheetRecords'),String(n));
      txt($('vdpSheetLayoutName'),(x.layout.method||'V101 Layout')+' · '+x.config.paperW+'×'+x.config.paperH+' mm · lề '+x.config.margin+' mm · gap '+x.config.gapX+'/'+x.config.gapY+' mm');
      status('Đã đồng bộ bố cục V101: '+slots+' con/tờ · '+sheets+' tờ cho '+n+' record.','ok');
      return x;
    }catch(e){sheetSnapshot=null;txt($('vdpSheetSlots'),'0');txt($('vdpSheetTotal'),'0');txt($('vdpSheetRecords'),'0');txt($('vdpSheetLayoutName'),e.message);status(e.message,'error');return null;}
  }
  function setMode(sheet){
    var rec=$('vdpRecordOutputBox'),sp=$('vdpSheetPanel'),rb=$('vdpBuildBtn'),sb=$('vdpSheetBuildBtn');
    show(rec,!sheet);show(sp,sheet);show(rb,!sheet);show(sb,sheet);
    if(sheet)calcSummary();
  }
  function makeUI(){
    var anchor=document.querySelector?document.querySelector('.vdp-output-options'):null;if(!anchor||$('vdpOutputMode'))return;
    var mode=document.createElement('div');mode.id='vdpOutputMode';mode.className='v114-mode';mode.innerHTML='<div class="v114-mode-title">Chế độ sản xuất VDP</div><div class="v114-segment"><label><input type="radio" name="vdpMode114" id="vdpModeRecord" checked><span>PDF từng record</span></label><label><input type="radio" name="vdpMode114" id="vdpModeSheet"><span>Dàn record trực tiếp lên khổ in</span></label></div>';
    anchor.parentNode.insertBefore(mode,anchor);
    var wrap=document.createElement('div');wrap.id='vdpRecordOutputBox';anchor.parentNode.insertBefore(wrap,anchor);wrap.appendChild(anchor);
    var cname=$('vdpCombinedName');if(cname&&cname.parentNode)wrap.appendChild(cname.parentNode);
    var sheet=document.createElement('div');sheet.id='vdpSheetPanel';sheet.className='v114-sheet hidden';sheet.innerHTML=''
      +'<div class="v114-sheet-head"><div><strong>VDP SHEET · Core V101 STABLE</strong><small id="vdpSheetLayoutName">Chưa đồng bộ bố cục.</small></div><button id="vdpSheetRefresh" type="button" class="button tiny">Đồng bộ bố cục</button></div>'
      +'<div class="v114-kpis"><div><span>Record chạy</span><strong id="vdpSheetRecords">0</strong></div><div><span>Con / tờ</span><strong id="vdpSheetSlots">0</strong></div><div><span>Số tờ</span><strong id="vdpSheetTotal">0</strong></div></div>'
      +'<div class="form-grid compact"><div class="field"><label>Thứ tự gán record</label><select id="vdpSheetOrder"><option value="row">Trái → phải, trên → dưới</option><option value="column">Trên → dưới, trái → phải</option><option value="snake">Ziczac theo hàng</option></select></div><div class="field"><label>Tờ cuối thiếu record</label><select id="vdpLastSheetMode"><option value="blank">Để trống vị trí còn lại</option><option value="center">Dồn các record còn lại vào giữa tờ</option></select></div><div class="field"><label>Tiền tố tên tờ</label><input id="vdpSheetPrefix" value="VDP_SHEET"></div><div class="field"><label>Tên PDF gộp các tờ</label><input id="vdpSheetCombinedName" value="VDP_ALL_SHEETS"></div></div>'
      +'<div class="vdp-output-options"><label class="vdp-check"><input id="vdpSheetKeepRecords" type="checkbox"> <span>Giữ PDF record trung gian (mặc định tắt để nhẹ ổ đĩa)</span></label><label class="vdp-check"><input id="vdpSheetCombine" type="checkbox" checked> <span>Gộp tất cả tờ thành 1 PDF nhiều trang</span></label><label class="vdp-check"><input id="vdpSheetUsePon" type="checkbox" checked> <span>Giữ PON / Auto PON / tiêu đề theo cấu hình Dàn file</span></label></div>'
      +'<div class="v114-note">Pipeline tối ưu: <b>Render record → PDF nhẹ → Place theo tọa độ V101 → xuất tờ</b>. Không clone toàn bộ artwork nhiều lần trong RAM. Exact Gap, lề cứng, xoay, True-Shape và bố cục đều lấy từ Core V101 đã Tính nhanh.</div>';
    wrap.parentNode.insertBefore(sheet,wrap.nextSibling);
    var oldBtn=$('vdpBuildBtn'),newBtn=document.createElement('button');newBtn.id='vdpSheetBuildBtn';newBtn.className='button success large vdp-build hidden';txt(newBtn,'Dàn dữ liệu lên khổ in & xuất PDF tờ');oldBtn.parentNode.insertBefore(newBtn,oldBtn.nextSibling);
    $('vdpModeRecord').onclick=function(){setMode(false);};$('vdpModeSheet').onclick=function(){setMode(true);};$('vdpSheetRefresh').onclick=calcSummary;
    $('vdpFrom').addEventListener('change',function(){if($('vdpModeSheet').checked)calcSummary();});$('vdpTo').addEventListener('change',function(){if($('vdpModeSheet').checked)calcSummary();});
    /* V122: do not bind undefined buildSheet here. bindBuildFix() below owns the button. */
  }
  function bindBuildFix(){
    // buildSheet được viết lại ở đây để giữ cú pháp ES5 đơn giản cho Windows WebBrowser.
    var b=$('vdpSheetBuildBtn');if(!b)return;
    b.onclick=function(){
      var st,x,out,from,to,cfg,sc;
      try{
        st=state();if(!st.filePath&&!(window.DPVVDP101&&window.DPVVDP101.getRecords&&window.DPVVDP101.getRecords().length))throw new Error('Chưa có dữ liệu CSV/TXT hoặc Dãy số tự động.');if(!(st.recordCount>0))throw new Error('Dữ liệu không có record.');if(!st.mappings||!st.mappings.length)throw new Error('Chưa map dữ liệu vào đối tượng Illustrator.');
        out=$('vdpOutputPath').value;if(!out)throw new Error('Chưa chọn thư mục xuất PDF.');x=calcSummary();if(!x)return;
        from=Math.max(1,Math.floor(Number($('vdpFrom').value)||1));to=Math.min(st.recordCount,Math.max(from,Math.floor(Number($('vdpTo').value)||st.recordCount)));
        sc={paperW:Number(x.config.paperW),paperH:Number(x.config.paperH),margin:Number(x.config.margin),header:Number(x.config.header),addTitle:x.config.addTitle===true,
          ponPath:String(x.config.ponPath||''),fitPon:x.config.fitPon===true,autoPon:x.config.autoPon===true,ponProcessBlack:x.config.ponProcessBlack===true,cornerPonRed:x.config.cornerPonRed===true};
        if($('vdpSheetUsePon')&&!$('vdpSheetUsePon').checked){sc.ponPath='';sc.autoPon=false;sc.addTitle=false;}
        cfg={dataPath:st.filePath,records:st.filePath?[]:((window.DPVVDP101&&window.DPVVDP101.getRecords)?window.DPVVDP101.getRecords():[]),mappings:st.mappings,sourceFolder:st.sourceFolder,outputPath:out,from:from,to:to,fileNameField:$('vdpFileNameField').value,filePrefix:$('vdpFilePrefix').value||'VDP',
          exportIndividual:$('vdpSheetKeepRecords').checked===true,combinePdf:false,sheetMode:true,sheetLayout:x.layout,sheetConfig:sc,sheetOrder:$('vdpSheetOrder').value,lastSheetMode:$('vdpLastSheetMode').value,
          keepRecordPdfs:$('vdpSheetKeepRecords').checked===true,combineSheets:$('vdpSheetCombine').checked===true,sheetPrefix:$('vdpSheetPrefix').value||'VDP_SHEET',sheetCombinedName:$('vdpSheetCombinedName').value||'VDP_ALL_SHEETS'};
        status('Bắt đầu VDP Sheet: '+x.layout.items.length+' con/tờ · dùng Core V101 đã khóa layout…','work');
        window.DPVVDP101.bridgeCall('BuildVariableData',[JSON.stringify(cfg)]);
      }catch(e){status(e.message||String(e),'error');}
    };
  }
  function wrapReceive(){
    if(!window.VDPRO_receive||window.__V114ReceiveWrapped)return;window.__V114ReceiveWrapped=true;var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){old(op,payload);try{var r=JSON.parse(String(payload||'{}'));if(op==='vdpBuildProgress'&&r.sheetMode){status('VDP Sheet · record '+r.current+'/'+r.total+(r.sheetCreated?' · vừa xuất tờ '+r.sheetDone+'/'+r.sheetTotal:''),'ok');}if(op==='vdpBuild'&&r.ok&&r.sheetMode){var m='Hoàn tất VDP Sheet: '+r.count+' record → '+r.sheetCount+' tờ';if(r.sheetCombinedFile)m+=' · PDF gộp: '+r.sheetCombinedFile;status(m,'ok');}}catch(e){} };
  }
  function mark(){var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V114 VDP SHEET · CORE V101 STABLE');var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V114 VDP SHEET · Core V101 Stable</strong><br>Dàn nhiều record trực tiếp lên khổ in bằng Layout Cache V101 · pipeline PDF nhẹ, low-RAM · giữ nguyên engine dàn ổn định.';}
  function start(){makeUI();bindBuildFix();wrapReceive();mark();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();


/* ===== SOURCE: app_v118.js ===== */
(function(){
  "use strict";
  function add(el,c){if(!el)return;if((" "+(el.className||"")+" ").indexOf(" "+c+" ")<0)el.className+=(el.className?" ":"")+c;}
  function rem(el,c){if(!el)return;el.className=(" "+(el.className||"")+" ").replace(" "+c+" "," ").replace(/^\s+|\s+$/g,"");}
  function qs(s){return document.querySelector?document.querySelector(s):null;}
  function vp(){var d=document.documentElement||{},b=document.body||{};return {w:d.clientWidth||b.clientWidth||window.innerWidth||1400,h:d.clientHeight||b.clientHeight||window.innerHeight||850};}
  var old=['dpv-layout-medium','dpv-layout-two','dpv-layout-stack','dpv-short-window','dpv-compact-sidebar','dpv-v117-wide','dpv-v117-stack','dpv-v117-compact','dpv-v117-tight','dpv-v117-mini','dpv-v117-tiny','dpv-v117-short','dpv-v118-wide','dpv-v118-stack','dpv-v118-compact','dpv-v118-tight','dpv-v118-mini','dpv-v118-tiny','dpv-v118-narrow','dpv-v118-short'];
  var timer=0,lastW=-1,lastH=-1;

  function clearLayout(b){for(var i=0;i<old.length;i++)rem(b,old[i]);}
  function isWindows(){var u=String(navigator.userAgent||'').toLowerCase();return u.indexOf('windows')>=0||u.indexOf('trident')>=0;}

  function apply(){
    var b=document.body, s=vp();
    clearLayout(b);
    if(isWindows()){add(b,'dpv-windows');add(b,'dpv-win-fast');}else{add(b,'dpv-mac');return;}

    /* Sidebar first. Re-read width only after its class has been applied. */
    if(s.w<1580)add(b,'dpv-v118-compact');
    var side=qs('.dpv-sidebar');
    var sideW=side?(side.offsetWidth||0):0;
    var usable=s.w-sideW-32;

    /* IE table mode only when there is genuinely enough CSS-pixel width. */
    if(usable>=1320)add(b,'dpv-v118-wide');
    else add(b,'dpv-v118-stack');

    if(s.w<1650)add(b,'dpv-v118-tight');
    if(s.w<1280)add(b,'dpv-v118-mini');
    if(s.w<980)add(b,'dpv-v118-tiny');
    if(usable<680)add(b,'dpv-v118-narrow');
    if(s.h<790)add(b,'dpv-v118-short');

    /* Measure actual topbar after wrap and size the scrollable workspace. */
    var top=qs('.topbar'), work=qs('.workspace');
    if(top&&work){
      var rect=top.getBoundingClientRect?top.getBoundingClientRect():null;
      var bottom=rect?rect.bottom:(top.offsetHeight||68);
      var available=s.h-bottom;
      if(available<260)available=260;
      work.style.height=available+'px';
    }
  }

  function mark(){
    var v=qs('.version-badge');if(v)v.innerHTML='V118 IE TABLE FIX · CORE V101 STABLE';
    var n=qs('.beta-note');if(n)n.innerHTML='<strong>DPV® V118 IE Table Fix · Core V101 Stable</strong><br>Windows bỏ flex 3 cột gây co sập khi maximize/restore; màn hình rộng dùng table-layout ổn định, màn hình hẹp tự xếp dọc và cuộn. Không thay engine dàn, PON, VDP hay Bridge Illustrator.';
  }

  function run(force){var s=vp();if(force||s.w!==lastW||s.h!==lastH){lastW=s.w;lastH=s.h;apply();mark();setTimeout(apply,80);setTimeout(apply,260);}}
  function resize(){if(timer)clearTimeout(timer);timer=setTimeout(function(){run(true);},45);}
  function start(){run(true);if(window.addEventListener){window.addEventListener('resize',resize,false);window.addEventListener('load',function(){run(true);},false);}else if(window.attachEvent){window.attachEvent('onresize',resize);window.attachEvent('onload',function(){run(true);});}setTimeout(function(){run(true);},400);setTimeout(function(){run(true);},1100);setInterval(function(){run(false);},1200);}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();


/* ===== SOURCE: app_v119.js ===== */
(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function txt(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function vstatus(m,k){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}
  function nativeCall(method,args,done,fail){
    args=args||[];
    try{
      if(window.DPVNative&&typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke(method,args).then(done).catch(function(e){fail((e&&e.message)||String(e));});return;
      }
      if(window.external&&typeof window.external[method]!=='undefined'){
        var v;if(args.length===0)v=window.external[method]();else if(args.length===1)v=window.external[method](args[0]);else throw new Error('Bridge V119 chỉ hỗ trợ tối đa 1 tham số ở dialog này.');done(v);return;
      }
      fail('DPV Bridge chưa sẵn sàng.');
    }catch(e){fail((e&&e.message)||String(e));}
  }
  var pending=false;
  function bind(){
    var old=$('vdpChooseDataBtn');if(!old||!old.parentNode)return;
    var btn=old.cloneNode(true);btn.id='vdpChooseDataBtn';btn.className=(btn.className||'')+' dpv-v119-native-csv';old.parentNode.replaceChild(btn,old);
    btn.onclick=function(ev){
      ev=ev||window.event;try{if(ev.preventDefault)ev.preventDefault();if(ev.stopPropagation)ev.stopPropagation();}catch(x){}
      if(pending)return false;pending=true;btn.disabled=true;txt(btn,'Đang chọn...');vstatus('Đang mở cửa sổ chọn CSV/TXT…','work');
      nativeCall('ChooseVariableDataPathV119',[],function(path){
        path=String(path||'');
        if(!path){pending=false;btn.disabled=false;txt(btn,'Chọn CSV / TXT');vstatus('Đã hủy chọn dữ liệu.','');return;}
        vstatus('Đã chọn file. Đang đọc dữ liệu…','work');
        nativeCall('ReadVariableDataFileV119',[path],function(raw){
          pending=false;btn.disabled=false;txt(btn,'Chọn CSV / TXT');
          if(window.DPVVDP101&&typeof window.DPVVDP101.loadFileResult==='function')window.DPVVDP101.loadFileResult(raw);
          else vstatus('VDP loader chưa sẵn sàng.','error');
        },function(err){pending=false;btn.disabled=false;txt(btn,'Chọn CSV / TXT');vstatus('Không đọc được CSV/TXT: '+err,'error');});
      },function(err){pending=false;btn.disabled=false;txt(btn,'Chọn CSV / TXT');vstatus('Không mở được hộp thoại CSV/TXT: '+err,'error');});
      return false;
    };

    var reload=$('vdpReloadDataBtn');if(reload&&reload.parentNode){
      var rb=reload.cloneNode(true);rb.id='vdpReloadDataBtn';reload.parentNode.replaceChild(rb,reload);
      rb.onclick=function(){
        var st=(window.DPVVDP101&&window.DPVVDP101.getState)?window.DPVVDP101.getState():null;
        if(!st||!st.filePath){if(btn&&btn.click)btn.click();return false;}
        vstatus('Đang đọc lại CSV/TXT…','work');
        nativeCall('ReadVariableDataFileV119',[st.filePath],function(raw){if(window.DPVVDP101&&window.DPVVDP101.loadFileResult)window.DPVVDP101.loadFileResult(raw);},function(err){vstatus('Đọc lại thất bại: '+err,'error');});
        return false;
      };
    }
  }
  function mark(){var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V119 CSV NATIVE FIX · CORE V101 STABLE');var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V119 CSV Native Fix · Core V101 Stable</strong><br>Windows tách chọn file và đọc CSV/TXT thành 2 bước native ổn định · hỗ trợ UTF-8, UTF-16, ANSI Vietnamese, CSV/TXT/TSV và Excel sep= · không thay engine dàn.';}
  function start(){bind();mark();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();


/* ===== SOURCE: app_v120.js ===== */
(function(){
  "use strict";
  function $(id){ return document.getElementById(id); }
  function txt(el,v){ if(!el)return; if('textContent' in el)el.textContent=v; else el.innerText=v; }
  function vstatus(m,k){
    if(window.DPVVDP101 && typeof window.DPVVDP101.status==='function') window.DPVVDP101.status(m,k||'');
  }
  function parse(raw){ try{return JSON.parse(String(raw||'{}'));}catch(e){return {ok:false,error:'Phản hồi dữ liệu không hợp lệ: '+e.message};} }

  var pending=false, watchdog=0;
  function resetButton(){
    pending=false;
    if(watchdog){window.clearTimeout(watchdog);watchdog=0;}
    var b=$('vdpChooseDataBtn');
    if(b){b.disabled=false;txt(b,'Chọn CSV / TXT');}
  }
  function armWatchdog(){
    if(watchdog)window.clearTimeout(watchdog);
    watchdog=window.setTimeout(function(){
      if(!pending)return;
      resetButton();
      vstatus('Không nhận được phản hồi từ cửa sổ chọn dữ liệu. Hãy thử lại.','error');
    },180000);
  }
  function callAsyncPicker(){
    try{
      if(window.DPVNative && typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke('ChooseVariableDataAsyncV120',[]).catch(function(e){resetButton();vstatus('Không mở được CSV/TXT: '+((e&&e.message)||String(e)),'error');});
        return true;
      }
      if(window.external && typeof window.external.ChooseVariableDataAsyncV120!=='undefined'){
        window.external.ChooseVariableDataAsyncV120();
        return true;
      }
    }catch(e){ resetButton(); vstatus('Windows Bridge lỗi khi mở CSV/TXT: '+((e&&e.message)||String(e)),'error'); return false; }
    resetButton();vstatus('DPV Bridge chưa sẵn sàng.','error');return false;
  }
  function callReload(path){
    try{
      if(window.DPVNative && typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke('ReadVariableDataFileV120',[path]).then(handlePayload).catch(function(e){vstatus('Đọc lại thất bại: '+((e&&e.message)||String(e)),'error');});
        return;
      }
      if(window.external && typeof window.external.ReadVariableDataFileV120!=='undefined'){
        handlePayload(window.external.ReadVariableDataFileV120(path));return;
      }
      vstatus('DPV Bridge chưa sẵn sàng.','error');
    }catch(e){vstatus('Đọc lại thất bại: '+((e&&e.message)||String(e)),'error');}
  }
  function handlePayload(payload){
    resetButton();
    var r=parse(payload);
    if(r.cancelled){vstatus('Đã hủy chọn dữ liệu.','');return;}
    if(!r.ok){vstatus(r.error||'Không đọc được CSV/TXT.','error');return;}
    if(!window.DPVVDP101 || typeof window.DPVVDP101.loadFileResult!=='function'){
      vstatus('VDP loader chưa sẵn sàng. Hãy đóng/mở lại cửa sổ Biến đổi dữ liệu.','error');return;
    }
    window.DPVVDP101.loadFileResult(payload);
  }
  function wrapReceiver(){
    if(window.__V120ReceiveWrapped)return;
    window.__V120ReceiveWrapped=true;
    var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){
      if(op==='vdpDataSelectedV120'){
        handlePayload(payload);
        return;
      }
      if(old) return old(op,payload);
    };
  }
  function bind(){
    var old=$('vdpChooseDataBtn');
    if(old && old.parentNode){
      var btn=old.cloneNode(true);
      btn.id='vdpChooseDataBtn';
      btn.className=(btn.className||'')+' dpv-v120-async-csv';
      old.parentNode.replaceChild(btn,old);
      btn.onclick=function(ev){
        ev=ev||window.event;
        try{if(ev.preventDefault)ev.preventDefault();if(ev.stopPropagation)ev.stopPropagation();ev.cancelBubble=true;}catch(x){}
        if(pending)return false;
        pending=true;btn.disabled=true;txt(btn,'Đang chọn...');
        vstatus('Đang mở cửa sổ chọn CSV/TXT…','work');
        armWatchdog();
        callAsyncPicker();
        return false;
      };
    }
    var reload=$('vdpReloadDataBtn');
    if(reload && reload.parentNode){
      var rb=reload.cloneNode(true);rb.id='vdpReloadDataBtn';reload.parentNode.replaceChild(rb,reload);
      rb.onclick=function(ev){
        ev=ev||window.event;try{if(ev.preventDefault)ev.preventDefault();ev.cancelBubble=true;}catch(x){}
        var st=(window.DPVVDP101&&window.DPVVDP101.getState)?window.DPVVDP101.getState():null;
        if(!st||!st.filePath){var b=$('vdpChooseDataBtn');if(b&&b.click)b.click();return false;}
        vstatus('Đang đọc lại CSV/TXT…','work');callReload(st.filePath);return false;
      };
    }
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;
    if(v)txt(v,'V120 CSV CALLBACK FIX · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;
    if(b)b.innerHTML='<strong>DPV® V120 CSV Callback Fix · Core V101 Stable</strong><br>Windows đọc CSV/TXT bằng callback sau khi hộp thoại đóng, không còn phụ thuộc giá trị trả về COM trong cùng click stack · đọc được file đang mở trong Excel bằng FileShare.ReadWrite.';
  }
  function start(){wrapReceiver();bind();mark();}
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);
  }else start();
})();


/* ===== SOURCE: app_v121.js ===== */
(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function fixDataInfo(){
    var el=$('vdpDataInfo');
    if(!el)return;
    /* vdpDataInfo used to reuse class source-card. That caused Core V101
       syncSources() to mistake CSV info for an imposition source card. */
    if((' '+el.className+' ').indexOf(' source-card ')>=0){
      el.className=(' '+el.className+' ').replace(' source-card ',' vdp-data-info-card ').replace(/^\s+|\s+$/g,'');
    }
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;
    if(v)v.innerHTML='V121 VDP SOURCE SCOPE FIX · CORE V101 STABLE';
  }
  function start(){fixDataInfo();mark();setInterval(fixDataInfo,350);}
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);
  }else start();
})();

/* ===== SOURCE: app_v122.js ===== */
(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function status(msg,kind){
    if(window.DPVVDP101&&typeof window.DPVVDP101.status==='function')window.DPVVDP101.status(msg,kind||'');
  }
  function getCore(){
    if(!window.DPVCoreV101||typeof window.DPVCoreV101.getConfig!=='function')throw new Error('Core V101 chưa sẵn sàng.');
    var c=window.DPVCoreV101.getConfig();
    var l=c&&(c.precomputedLayoutV101||c.precomputedLayoutV99);
    if(!l||!l.items||!l.items.length)throw new Error('Chưa có bố cục V101. Đóng VDP → Tính nhanh trên DPV → mở VDP lại.');
    return {config:c,layout:l};
  }
  function getState(){
    if(!window.DPVVDP101||typeof window.DPVVDP101.getState!=='function')throw new Error('VDP Core chưa sẵn sàng.');
    return window.DPVVDP101.getState();
  }
  function build(){
    var btn=$('vdpSheetBuildBtn');
    try{
      var st=getState();
      if(!st.filePath&&!(window.DPVVDP101&&window.DPVVDP101.getRecords&&window.DPVVDP101.getRecords().length))throw new Error('Chưa có dữ liệu CSV/TXT hoặc Dãy số tự động.');
      if(!(Number(st.recordCount)>0))throw new Error('Dữ liệu không có record.');
      if(!st.mappings||!st.mappings.length)throw new Error('Chưa map dữ liệu vào đối tượng Illustrator.');
      var out=$('vdpOutputPath')?$('vdpOutputPath').value:'';
      if(!out)throw new Error('Chưa chọn thư mục xuất PDF.');
      var x=getCore();
      var from=Math.max(1,Math.floor(Number($('vdpFrom').value)||1));
      var to=Math.min(Number(st.recordCount),Math.max(from,Math.floor(Number($('vdpTo').value)||Number(st.recordCount))));
      var sc={
        paperW:Number(x.config.paperW),paperH:Number(x.config.paperH),margin:Number(x.config.margin),header:Number(x.config.header),
        addTitle:x.config.addTitle===true,ponPath:String(x.config.ponPath||''),fitPon:x.config.fitPon===true,autoPon:x.config.autoPon===true,
        ponProcessBlack:x.config.ponProcessBlack===true,cornerPonRed:x.config.cornerPonRed===true
      };
      if($('vdpSheetUsePon')&&!$('vdpSheetUsePon').checked){sc.ponPath='';sc.autoPon=false;sc.addTitle=false;}
      var cfg={
        dataPath:st.filePath,records:st.filePath?[]:((window.DPVVDP101&&window.DPVVDP101.getRecords)?window.DPVVDP101.getRecords():[]),mappings:st.mappings,sourceFolder:st.sourceFolder,outputPath:out,from:from,to:to,
        fileNameField:$('vdpFileNameField').value,filePrefix:$('vdpFilePrefix').value||'VDP',
        exportIndividual:$('vdpSheetKeepRecords').checked===true,combinePdf:false,sheetMode:true,sheetLayout:x.layout,sheetConfig:sc,
        sheetOrder:$('vdpSheetOrder').value,lastSheetMode:$('vdpLastSheetMode').value,keepRecordPdfs:$('vdpSheetKeepRecords').checked===true,
        combineSheets:$('vdpSheetCombine').checked===true,sheetPrefix:$('vdpSheetPrefix').value||'VDP_SHEET',
        sheetCombinedName:$('vdpSheetCombinedName').value||'VDP_ALL_SHEETS'
      };
      if(btn){btn.disabled=true;btn.setAttribute('data-v122-running','1');}
      status('V122: Đang gửi '+(to-from+1)+' record sang Illustrator · '+x.layout.items.length+' con/tờ…','work');
      if(!window.DPVVDP101||typeof window.DPVVDP101.bridgeCall!=='function')throw new Error('Windows Bridge chưa sẵn sàng.');
      window.DPVVDP101.bridgeCall('BuildVariableData',[JSON.stringify(cfg)]);
    }catch(e){
      if(btn){btn.disabled=false;btn.removeAttribute('data-v122-running');}
      status('Không chạy được VDP Sheet: '+(e&&e.message?e.message:String(e)),'error');
    }
    return false;
  }
  function bind(){
    var b=$('vdpSheetBuildBtn');
    if(!b)return false;
    b.onclick=build;
    b.setAttribute('data-v122-bound','1');
    return true;
  }
  function wrapReceive(){
    if(window.__V122ReceiveWrapped||typeof window.VDPRO_receive!=='function')return;
    window.__V122ReceiveWrapped=true;
    var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){
      old(op,payload);
      try{
        var r=JSON.parse(String(payload||'{}'));
        var b=$('vdpSheetBuildBtn');
        if(op==='vdpBuildProgress'&&r.sheetMode){
          status('VDP Sheet · record '+r.current+'/'+r.total+(r.sheetCreated?' · đã xuất tờ '+r.sheetDone+'/'+r.sheetTotal:''),'work');
        }
        if(op==='vdpBuild'){
          if(b){b.disabled=false;b.removeAttribute('data-v122-running');}
          if(!r.ok)status('VDP Sheet lỗi: '+String(r.error||r.message||'Không rõ lỗi Illustrator.'),'error');
          else if(r.sheetMode){
            var m='Hoàn tất: '+String(r.count||0)+' record → '+String(r.sheetCount||0)+' tờ.';
            if(r.sheetCombinedFile)m+=' PDF gộp: '+r.sheetCombinedFile;
            status(m,'ok');
          }
        }
      }catch(e){}
    };
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;
    if(v)v.innerHTML='V122 VDP SHEET BUTTON FIX · CORE V101 STABLE';
  }
  function start(){
    mark();wrapReceive();
    var n=0,t=setInterval(function(){n++;bind();wrapReceive();if(n>20)clearInterval(t);},150);
    setTimeout(function(){if(bind())status('VDP Sheet V122 sẵn sàng. Nút Dàn & xuất đã được gắn handler ổn định.','ok');},450);
  }
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);
  }else start();
})();


/* ===== SOURCE: app_v123.js ===== */
(function(){"use strict";function t(e,v){if(!e)return;if("textContent" in e)e.textContent=v;else e.innerText=v;}function s(){var v=document.querySelector?document.querySelector(".version-badge"):null;if(v)t(v,"V123 VDP SHEET COMBINE STABLE · CORE V101");var b=document.querySelector?document.querySelector(".beta-note"):null;if(b)b.innerHTML="<strong>DPV® V123 VDP Sheet Combine Stable · Core V101</strong><br>Xuất PDF từng tờ trước → đóng batch → Combine sau, nhẹ RAM và tránh lỗi artboard/tờ không khớp.";}if(document.readyState==="loading"){if(document.addEventListener)document.addEventListener("DOMContentLoaded",s);else window.attachEvent("onload",s);}else s();})();

/* ===== SOURCE: app_v124.js ===== */
(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function text(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function status(m,k){if(window.DPVVDP101&&typeof window.DPVVDP101.status==='function')window.DPVVDP101.status(m,k||'');}
  function getCore(){
    if(!window.DPVCoreV101||typeof window.DPVCoreV101.getConfig!=='function')throw new Error('Core V101 chưa sẵn sàng.');
    var c=window.DPVCoreV101.getConfig(),l=c&&(c.precomputedLayoutV101||c.precomputedLayoutV99);
    if(!l||!l.items||!l.items.length)throw new Error('Chưa có bố cục V101. Đóng VDP → Tính nhanh trên DPV → mở VDP lại.');
    return {config:c,layout:l};
  }
  function getState(){if(!window.DPVVDP101||typeof window.DPVVDP101.getState!=='function')throw new Error('VDP Core chưa sẵn sàng.');return window.DPVVDP101.getState();}
  function addInfo(){
    var panel=$('vdpSheetPanel'),head=panel&&panel.querySelector?panel.querySelector('.v114-sheet-head'):null;
    if(!panel||!head||$('vdpSheetSyncV124'))return;
    var d=document.createElement('div');d.id='vdpSheetSyncV124';d.className='v124-sync-info';
    d.innerHTML='<strong>Đồng bộ Dàn file:</strong> đang chờ bố cục V101.';
    head.parentNode.insertBefore(d,head.nextSibling);
    var cb=$('vdpSheetUsePon');
    if(cb&&cb.parentNode){var sp=cb.parentNode.getElementsByTagName('span');if(sp&&sp.length)text(sp[0],'Giữ PON / Auto PON / tiêu đề theo Dàn file (Bleed + CATTP luôn đồng bộ)');}
  }
  function syncInfo(){
    addInfo();var d=$('vdpSheetSyncV124');if(!d)return;
    try{
      var x=getCore(),c=x.config,p=[];
      p.push('Layout '+x.layout.items.length+' con/tờ');
      p.push('Bleed '+String(Number(c.linkBleed||0))+' mm');
      p.push(c.finishCropMarks===true?'CATTP BẬT · '+String(Number(c.finishMarkLength||6))+'mm / gap '+String(Number(c.finishMarkGap||0))+'mm':'CATTP TẮT');if(c.duplexMode===true)p.push('2 MẶT A/B · '+String(c.duplexFlip||'tumble180'));
      if(c.ponPath)p.push('PON file'); else if(c.autoPon===true)p.push('Auto PON'); else p.push('PON tắt');
      d.innerHTML='<strong>Đồng bộ Dàn file:</strong> '+p.join(' · ');
    }catch(e){d.innerHTML='<strong>Đồng bộ Dàn file:</strong> '+String(e.message||e);}
  }
  function build(){
    var btn=$('vdpSheetBuildBtn');
    try{
      var st=getState();if(!st.filePath&&!(window.DPVVDP101&&window.DPVVDP101.getRecords&&window.DPVVDP101.getRecords().length))throw new Error('Chưa có dữ liệu CSV/TXT hoặc Dãy số tự động.');if(!(Number(st.recordCount)>0))throw new Error('Dữ liệu không có record.');if(!st.mappings||!st.mappings.length)throw new Error('Chưa map dữ liệu vào đối tượng Illustrator.');
      var out=$('vdpOutputPath')?$('vdpOutputPath').value:'';if(!out)throw new Error('Chưa chọn thư mục xuất PDF.');
      var x=getCore(),c=x.config,from=Math.max(1,Math.floor(Number($('vdpFrom').value)||1)),to=Math.min(Number(st.recordCount),Math.max(from,Math.floor(Number($('vdpTo').value)||Number(st.recordCount))));
      var sourceW=Number(x.layout.sourceW||((c.sources&&c.sources.length)?c.sources[0].width:0)||0),sourceH=Number(x.layout.sourceH||((c.sources&&c.sources.length)?c.sources[0].height:0)||0);
      var sc={
        paperW:Number(c.paperW),paperH:Number(c.paperH),margin:Number(c.margin),header:Number(c.header),gapX:Number(c.gapX),gapY:Number(c.gapY),
        sourceW:sourceW,sourceH:sourceH,linkBleed:Math.max(0,Number(c.linkBleed||0)),addTitle:c.addTitle===true,
        ponPath:String(c.ponPath||''),fitPon:c.fitPon===true,autoPon:c.autoPon===true,ponProcessBlack:c.ponProcessBlack===true,cornerPonRed:c.cornerPonRed===true,
        finishCropMarks:c.finishCropMarks===true,finishMarkLength:Math.max(.1,Number(c.finishMarkLength||6)),finishMarkGap:Math.max(0,Number(c.finishMarkGap||0)),
        cornerSafe:c.cornerSafe===true,cornerZone:Math.max(0,Number(c.cornerZone||0)),preservePrintColor:c.preservePrintColor!==false,
        duplexMode:c.duplexMode===true,duplexFlip:String(c.duplexFlip||'tumble180')
      };
      /* PON/title may be manually hidden in VDP, but production bleed and CATTP
         ALWAYS follow the Dàn file configuration as requested. */
      if($('vdpSheetUsePon')&&!$('vdpSheetUsePon').checked){sc.ponPath='';sc.autoPon=false;sc.addTitle=false;}
      var cfg={
        dataPath:st.filePath,records:st.filePath?[]:((window.DPVVDP101&&window.DPVVDP101.getRecords)?window.DPVVDP101.getRecords():[]),mappings:st.mappings,sourceFolder:st.sourceFolder,outputPath:out,from:from,to:to,
        fileNameField:$('vdpFileNameField').value,filePrefix:$('vdpFilePrefix').value||'VDP',exportIndividual:$('vdpSheetKeepRecords').checked===true,combinePdf:false,
        sheetMode:true,sheetLayout:x.layout,sheetConfig:sc,sheetOrder:$('vdpSheetOrder').value,lastSheetMode:$('vdpLastSheetMode').value,
        keepRecordPdfs:$('vdpSheetKeepRecords').checked===true,combineSheets:$('vdpSheetCombine').checked===true,sheetPrefix:$('vdpSheetPrefix').value||'VDP_SHEET',sheetCombinedName:$('vdpSheetCombinedName').value||'VDP_ALL_SHEETS'
      };
      if(btn){btn.disabled=true;btn.setAttribute('data-v124-running','1');}
      status('V125: Layout V101 · Bleed '+sc.linkBleed+' mm · CATTP '+(sc.finishCropMarks?'BẬT':'TẮT')+(sc.duplexMode?' · A/B 2 mặt':'')+' · '+(to-from+1)+' record…','work');
      window.DPVVDP101.bridgeCall('BuildVariableData',[JSON.stringify(cfg)]);
    }catch(e){if(btn){btn.disabled=false;btn.removeAttribute('data-v124-running');}status('Không chạy được VDP Sheet: '+String(e&&e.message?e.message:e),'error');}
    return false;
  }
  function bind(){var b=$('vdpSheetBuildBtn');if(!b)return false;b.onclick=build;b.setAttribute('data-v124-bound','1');return true;}
  function wrapReceive(){
    if(window.__V124ReceiveWrapped||typeof window.VDPRO_receive!=='function')return;window.__V124ReceiveWrapped=true;var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){old(op,payload);try{var r=JSON.parse(String(payload||'{}')),b=$('vdpSheetBuildBtn');if(op==='vdpBuild'){if(b){b.disabled=false;b.removeAttribute('data-v124-running');}if(!r.ok)status('VDP Sheet lỗi: '+String(r.error||r.message||'Không rõ lỗi Illustrator.'),'error');else if(r.sheetMode){var m='Hoàn tất VDP Sheet: '+String(r.count||0)+' record → '+String(r.sheetCount||0)+' tờ';if(r.sheetCombinedFile)m+=' · PDF gộp: '+r.sheetCombinedFile;status(m,'ok');}}}catch(e){} };
  }
  function mark(){var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)text(v,'V125 VDP PRODUCTION FIDELITY · CORE V101');var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V125 VDP Production Fidelity · Core V101</strong><br>VDP Sheet giữ đúng khổ giấy khi Combine · Bleed dùng MediaBox và cùng công thức padding của Dàn file · PON/CATTP/2 mặt A-B đồng bộ từ cấu hình Dàn file.';}
  function start(){addInfo();syncInfo();mark();wrapReceive();var n=0,t=setInterval(function(){n++;bind();wrapReceive();if(n%5===0)syncInfo();if(n>30)clearInterval(t);},150);var r=$('vdpSheetRefresh');if(r&&r.addEventListener)r.addEventListener('click',function(){setTimeout(syncInfo,80);},false);var m=$('vdpModeSheet');if(m&&m.addEventListener)m.addEventListener('click',function(){setTimeout(syncInfo,80);},false);}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();


/* ===== SOURCE: app_v125.js ===== */
(function(){"use strict";function t(e,v){if(!e)return;if("textContent" in e)e.textContent=v;else e.innerText=v;}function m(){var v=document.querySelector?document.querySelector(".version-badge"):null;if(v)t(v,"V125 VDP PRODUCTION FIDELITY · CORE V101");}if(document.readyState==="loading"){if(document.addEventListener)document.addEventListener("DOMContentLoaded",m);else window.attachEvent("onload",m);}else m();})();

/* ===== SOURCE: app_v127.js ===== */
(function(){
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge'); if(v)v.innerHTML='V127 AI STAY OPEN · CORE V101 STABLE';
    var b=q('.beta-note'); if(b)b.innerHTML='<strong>DPV® V127 AI Stay Open · Core V101 Stable</strong><br>VDP giữ Illustrator sống sau khi xuất · luôn mở/kích hoạt lại file AI nguồn · không thay thuật toán dàn V101.';
  }
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);}else mark();
})();


/* ===== SOURCE: app_v128.js ===== */
(function(){
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge'); if(v)v.innerHTML='V128 DUPLEX PHYSICAL MIRROR · CORE V101 STABLE';
    var b=q('.beta-note'); if(b)b.innerHTML='<strong>DPV® V128 Duplex Physical Mirror · Core V101 Stable</strong><br>Mặt B phản vị trí vật lý A trái ↔ B phải trong cả Dàn file và VDP Sheet · giữ AI Stay Open V127 · không thay solver V101.';
  }
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);}else mark();
})();


/* ===== SOURCE: app_v129.js ===== */
(function(){
  "use strict";
  function byId(id){ return document.getElementById(id); }
  function add(el,c){ if(!el)return; if((' '+el.className+' ').indexOf(' '+c+' ')<0) el.className += (el.className?' ':'')+c; }
  function rem(el,c){ if(!el)return; el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,''); }

  function makeQrUi(){
    if(byId('dpvQrCard')) return true;
    var sidebar=byId('dpvSidebar');
    if(!sidebar) return false;
    var core=sidebar.querySelector ? sidebar.querySelector('.dpv-side-card') : null;
    var card=document.createElement('section');
    card.id='dpvQrCard';
    card.className='dpv-qr-card';
    card.innerHTML=''
      +'<div class="dpv-qr-head">'
      +'<span class="dpv-qr-scan-icon">QR</span>'
      +'<strong class="dpv-qr-title">Quét QR</strong>'
      +'<span class="dpv-qr-subtitle">Quét để biết thêm thông tin</span>'
      +'</div>'
      +'<div id="dpvQrImageWrap" class="dpv-qr-image-wrap" title="Bấm để phóng to mã QR">'
      +'<img class="dpv-qr-image" src="../../assets/qr/DPV_Zalo_QR.png" alt="QR Zalo DPV">'
      +'</div>'
      +'<button id="dpvQrOpen" class="dpv-qr-action" type="button">Phóng to mã QR</button>'
      +'<div class="dpv-qr-caption">Zalo hỗ trợ · Thông tin nhanh</div>';
    if(core) sidebar.insertBefore(card,core); else sidebar.appendChild(card);

    var modal=document.createElement('div');
    modal.id='dpvQrModal';
    modal.className='dpv-qr-modal';
    modal.innerHTML=''
      +'<div class="dpv-qr-modal-card">'
      +'<h3 class="dpv-qr-modal-title">Quét QR để biết thêm thông tin</h3>'
      +'<div class="dpv-qr-modal-sub">Mở camera điện thoại hoặc Zalo để quét mã</div>'
      +'<img class="dpv-qr-modal-image" src="../../assets/qr/DPV_Zalo_QR.png" alt="QR Zalo DPV phóng to">'
      +'<br><button id="dpvQrClose" class="dpv-qr-modal-close" type="button">Đóng</button>'
      +'</div>';
    document.body.appendChild(modal);

    function openQr(){ add(modal,'open'); }
    function closeQr(){ rem(modal,'open'); }
    var openBtn=byId('dpvQrOpen'), imgBtn=byId('dpvQrImageWrap'), closeBtn=byId('dpvQrClose');
    if(openBtn) openBtn.onclick=openQr;
    if(imgBtn) imgBtn.onclick=openQr;
    if(closeBtn) closeBtn.onclick=closeQr;
    modal.onclick=function(e){ e=e||window.event; if((e.target||e.srcElement)===modal) closeQr(); };
    if(document.addEventListener){
      document.addEventListener('keydown',function(e){ if((e||window.event).keyCode===27) closeQr(); },false);
    }else if(document.attachEvent){
      document.attachEvent('onkeydown',function(){ if(window.event && window.event.keyCode===27) closeQr(); });
    }
    return true;
  }

  function markVersion(){
    var v=document.querySelector ? document.querySelector('.version-badge') : null;
    if(v) v.innerHTML='V129 QR INFO · CORE V101 STABLE';
    var beta=document.querySelector ? document.querySelector('.beta-note') : null;
    if(beta) beta.innerHTML='<strong>DPV® V129 QR Info · Core V101 Stable</strong><br>Thêm QR Zalo hỗ trợ ở sidebar + chế độ phóng to để quét dễ hơn · không thay engine dàn, PON, VDP, Duplex hay Bridge Illustrator.';
    var core=document.querySelector ? document.querySelector('.dpv-side-card') : null;
    if(core) core.innerHTML='<strong><span class="dpv-side-dot"></span>Core V101 STABLE</strong>Engine dàn được khóa ổn định.<br>V129 chỉ thêm giao diện QR hỗ trợ.';
  }

  function start(){
    var tries=0;
    function boot(){
      tries++;
      if(makeQrUi()){ markVersion(); return; }
      if(tries<30) setTimeout(boot,80);
    }
    boot();
  }
  if(document.readyState==='loading'){
    if(document.addEventListener) document.addEventListener('DOMContentLoaded',start,false);
    else window.attachEvent('onload',start);
  }else start();
})();


/* ===== SOURCE: app_v130.js ===== */
(function(){
  "use strict";
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge'); if(v){v.innerHTML='V130 MANUAL PREVIEW FIX · CORE V101 STABLE';}
    var b=q('.beta-note'); if(b){b.innerHTML='<strong>DPV® V130 Manual Preview Fix · Core V101 Stable</strong><br>Nhập kích thước → Tính nhanh V101 → View khuôn qua Illustrator dùng đúng Layout Cache, không chạy solver lần hai.';}
  }
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);}else{mark();}
})();


/* ===== SOURCE: app_v131.js ===== */
(function(){
  "use strict";
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge');
    if(v){v.innerHTML='V131 MIXED ROTATION MAX · CORE V101 SAFE';}
    var b=q('.beta-note');
    if(b){b.innerHTML='<strong>DPV® V131 Mixed Rotation Max</strong><br>Exact Gap vẫn chính xác · tự thử lưới thẳng + phối ngang/dọc · chỉ dùng bố cục trộn khi thực sự tăng số con · giữ lề cứng/PON/VDP/Duplex.';}
  }
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);
  }else{mark();}
})();


/* ===== SOURCE: app_v132.js ===== */
(function(){
  "use strict";
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge'); if(v){v.innerHTML='V132 MIXED ROTATION SAFE · CORE V101';}
    var b=q('.beta-note'); if(b){b.innerHTML='<strong>DPV® V132 Mixed Rotation Safe</strong><br>Auto Max ngang/dọc có kiểm tra va chạm thật + Gap X/Y trước khi nhận bố cục · Live Preview xoay đúng 0/90 · giữ Core V101/PON/VDP/Duplex.';}
  }
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);}else{mark();}
})();


/* ===== SOURCE: app_v133.js ===== */
(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function txt(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function add(el,c){if(el&&(' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(el)el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function status(m,k){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}
  var seq={active:false,records:[],field:'SO_NHAY',start:1,end:100,step:1,pad:false,width:4,prefix:'',suffix:''};
  var MAX=50000;
  function escCsv(v){v=String(v==null?'':v);return /[",\r\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}
  function absDigits(n){var s=String(Math.abs(Math.floor(Number(n)||0)));return s.length;}
  function padNum(n,w){var neg=Number(n)<0,s=String(Math.abs(Math.floor(Number(n)||0)));while(s.length<w)s='0'+s;return (neg?'-':'')+s;}
  function formatted(n){var core=seq.pad?padNum(n,Math.max(1,seq.width)):String(n);return seq.prefix+core+seq.suffix;}
  function read(){
    seq.field=String($('v133Field').value||'SO_NHAY').replace(/^\s+|\s+$/g,'')||'SO_NHAY';
    seq.start=Math.floor(Number($('v133Start').value)||0); seq.end=Math.floor(Number($('v133End').value)||0);
    seq.step=Math.max(1,Math.floor(Math.abs(Number($('v133Step').value)||1)));
    seq.pad=$('v133Pad').checked===true; seq.width=Math.max(1,Math.min(12,Math.floor(Number($('v133Width').value)||1)));
    seq.prefix=String($('v133Prefix').value||'');seq.suffix=String($('v133Suffix').value||'');
  }
  function count(){read();return Math.floor(Math.abs(seq.end-seq.start)/seq.step)+1;}
  function updatePreview(){
    read();var n=count(),dir=seq.end>=seq.start?1:-1,a=[],i,v=seq.start,lim=Math.min(4,n);
    $('v133Width').disabled=!seq.pad;
    for(i=0;i<lim;i++){a.push(formatted(v));v+=dir*seq.step;}
    var last=formatted(seq.start+dir*seq.step*(n-1));
    $('v133Sample').innerHTML='<b>'+n.toLocaleString()+' record</b> · '+a.join(' · ')+(n>lim?' · … · '+last:'');
  }
  function generate(){
    try{
      read();var n=count();if(n<1)throw new Error('Khoảng số không hợp lệ.');if(n>MAX)throw new Error('Tối đa '+MAX.toLocaleString()+' record/lần để Illustrator chạy ổn định. Hãy chia thành nhiều batch nếu cần.');
      var dir=seq.end>=seq.start?1:-1,lines=[escCsv(seq.field)],records=[],i,v=seq.start,val;
      for(i=0;i<n;i++){val=formatted(v);lines.push(escCsv(val));records.push((function(k,x){var o={};o[k]=x;return o;})(seq.field,val));v+=dir*seq.step;}
      seq.active=true;seq.records=records;
      if(!window.DPVVDP101||typeof window.DPVVDP101.loadFileResult!=='function')throw new Error('VDP Core chưa sẵn sàng.');
      window.DPVVDP101.loadFileResult(JSON.stringify({ok:true,path:'',folder:'',name:'Dãy số tự động · '+seq.field,text:lines.join('\r\n')}));
      status('Đã tạo '+n+' record số tự động · '+formatted(seq.start)+' → '+formatted(seq.end)+'. Không cần CSV/TXT.','ok');
      setMode('seq');
    }catch(e){status('Không tạo được dãy số: '+String(e&&e.message?e.message:e),'error');}
  }
  function setMode(mode){
    var seqMode=mode==='seq';
    if(!seqMode)seq.active=false;
    var a=$('v133CsvMode'),b=$('v133SeqMode'),box=$('v133SeqBox'),toolbar=$('vdpChooseDataBtn')&&$('vdpChooseDataBtn').parentNode;
    if(a){if(seqMode)rem(a,'active');else add(a,'active');}if(b){if(seqMode)add(b,'active');else rem(b,'active');}
    if(box){if(seqMode)rem(box,'v133-hidden');else add(box,'v133-hidden');}
    if(toolbar){if(seqMode)add(toolbar,'v133-hidden');else rem(toolbar,'v133-hidden');}
  }
  function makeUI(){
    if($('v133SourceSwitch'))return;
    var card=$('vdpChooseDataBtn');card=card&&card.parentNode&&card.parentNode.parentNode;if(!card)return;
    var sw=document.createElement('div');sw.id='v133SourceSwitch';sw.className='v133-source-switch';sw.innerHTML='<button id="v133CsvMode" type="button" class="active">CSV / TXT</button><button id="v133SeqMode" type="button">Dãy số tự động</button>';
    var first=card.querySelector?card.querySelector('.toolbar'):null;if(first)card.insertBefore(sw,first);else card.insertBefore(sw,card.firstChild);
    var box=document.createElement('div');box.id='v133SeqBox';box.className='v133-seq-box v133-hidden';box.innerHTML=''
      +'<div class="v133-seq-title"><strong>NHẢY SỐ KHÔNG CẦN CSV</strong><span class="v133-seq-badge">NUMBER SEQUENCE</span></div>'
      +'<div class="v133-seq-grid">'
      +'<div class="field"><label>Bắt đầu</label><input id="v133Start" type="number" value="1" step="1"></div>'
      +'<div class="field"><label>Kết thúc</label><input id="v133End" type="number" value="100" step="1"></div>'
      +'<div class="field"><label>Bước nhảy</label><input id="v133Step" type="number" value="1" min="1" step="1"></div>'
      +'<div class="field"><label>Tên cột để map</label><input id="v133Field" type="text" value="SO_NHAY"></div>'
      +'<div class="field"><label>Tiền tố (tuỳ chọn)</label><input id="v133Prefix" type="text" placeholder="VD: A-"></div>'
      +'<div class="field"><label>Hậu tố (tuỳ chọn)</label><input id="v133Suffix" type="text" placeholder="VD: -B"></div>'
      +'<label class="v133-seq-zero"><input id="v133Pad" type="checkbox"> Thêm số 0 phía trước <span>· độ dài</span><input id="v133Width" type="number" min="1" max="12" value="4" disabled> <span>chữ số</span></label>'
      +'</div><div id="v133Sample" class="v133-seq-preview"></div>'
      +'<div class="v133-seq-actions"><button id="v133Generate" type="button" class="button accent">Tạo dãy số & dùng ngay</button></div>'
      +'<div class="v133-seq-help">Ví dụ: 1 → 500, bật số 0 trước và đặt 4 chữ số → <b>0001, 0002, …, 0500</b>. Có thể thêm tiền tố/hậu tố như <b>SP-0001-A</b>. Sau khi tạo, map cột <b>SO_NHAY</b> vào Text và Preview/Xuất như CSV bình thường.</div>';
    sw.parentNode.insertBefore(box,sw.nextSibling);
    $('v133CsvMode').onclick=function(){setMode('csv');};$('v133SeqMode').onclick=function(){setMode('seq');updatePreview();};$('v133Generate').onclick=generate;
    var ids=['v133Start','v133End','v133Step','v133Field','v133Prefix','v133Suffix','v133Pad','v133Width'],i,el;
    for(i=0;i<ids.length;i++){el=$(ids[i]);if(el){el.onchange=updatePreview;el.onkeyup=updatePreview;}}
    updatePreview();
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V133 NUMBER SEQUENCE · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V133 Number Sequence · Core V101 Stable</strong><br>VDP thêm nguồn Dãy số tự động: Start / End / Step / số 0 phía trước / tiền tố / hậu tố · không cần CSV/TXT · dùng được cả PDF record và VDP Sheet.';
  }
  function expose(){window.DPVNumberSeqV133={isActive:function(){return seq.active===true;},getRecords:function(){return seq.records.slice(0);},getConfig:function(){return seq;}};}
  function start(){makeUI();mark();expose();var c=$('vdpChooseDataBtn');if(c&&c.addEventListener)c.addEventListener('click',function(){seq.active=false;},false);}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();


/* ===== SOURCE: app_v135.js ===== */
(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function txt(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function add(el,c){if(el&&(' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(el)el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function status(m,k){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}
  function parse(raw){try{return JSON.parse(String(raw||'{}'));}catch(e){return null;}}
  function cloneRecord(o){var n={},k;for(k in o){if(Object.prototype.hasOwnProperty.call(o,k))n[k]=o[k];}return n;}
  function headersOf(records){var out=[],seen={},i,k;for(i=0;i<records.length;i++){for(k in records[i]){if(Object.prototype.hasOwnProperty.call(records[i],k)&&!seen[k]){seen[k]=true;out.push(k);}}}return out;}
  function escCsv(v){v=String(v==null?'':v);return /[",\r\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v;}
  function toCsv(headers,records){var lines=[],i,j,row;lines.push(headers.map(escCsv).join(','));for(i=0;i<records.length;i++){row=[];for(j=0;j<headers.length;j++)row.push(escCsv(records[i][headers[j]]));lines.push(row.join(','));}return lines.join('\r\n');}
  function padNum(n,w){var neg=Number(n)<0,s=String(Math.abs(Math.floor(Number(n)||0)));while(s.length<w)s='0'+s;return (neg?'-':'')+s;}

  var mode='csv', base={valid:false,path:'',folder:'',name:'',headers:[],records:[]}, oldLoad=null, oldGen=null, restoring=false;

  function readSeq(){
    var start=Math.floor(Number($('v133Start')&&$('v133Start').value)||0),step=Math.max(1,Math.floor(Math.abs(Number($('v133Step')&&$('v133Step').value)||1))),field=String(($('v133Field')&&$('v133Field').value)||'SO_NHAY').replace(/^\s+|\s+$/g,'')||'SO_NHAY';
    return {start:start,step:step,field:field,pad:$('v133Pad')&&$('v133Pad').checked===true,width:Math.max(1,Math.min(12,Math.floor(Number($('v133Width')&&$('v133Width').value)||1))),prefix:String(($('v133Prefix')&&$('v133Prefix').value)||''),suffix:String(($('v133Suffix')&&$('v133Suffix').value)||'')};
  }
  function formatNum(n,c){var core=c.pad?padNum(n,c.width):String(n);return c.prefix+core+c.suffix;}
  function captureBase(){
    if(restoring||!window.DPVVDP101||!window.DPVVDP101.getState||!window.DPVVDP101.getRecords)return false;
    var st=window.DPVVDP101.getState(), rec=window.DPVVDP101.getRecords();
    if(!st||!st.filePath||!rec||!rec.length)return false;
    base.valid=true;base.path=st.filePath;base.folder=st.sourceFolder||'';base.name=st.fileName||'CSV/TXT';base.records=[];
    var i;for(i=0;i<rec.length;i++)base.records.push(cloneRecord(rec[i]));base.headers=headersOf(base.records);return true;
  }
  function restoreBase(){
    if(!base.valid||!oldLoad)return false;
    restoring=true;
    try{oldLoad(JSON.stringify({ok:true,path:base.path,folder:base.folder,name:base.name,text:toCsv(base.headers,base.records)}));}
    finally{restoring=false;}
    return true;
  }
  function hybridInfo(){
    var info=$('v135HybridInfo');if(!info)return;
    var c=readSeq(),n=base.valid?base.records.length:0,last=n?formatNum(c.start+(n-1)*c.step,c):'—';
    info.innerHTML=base.valid?'<b>'+n+' dòng CSV</b> + cột <b>'+c.field+'</b> · '+formatNum(c.start,c)+' → '+last:'Chưa có CSV/TXT nền. Hãy chọn CSV/TXT trước, sau đó DPV sẽ gắn 1 số tự động cho mỗi record.';
    if($('v133End')){$('v133End').disabled=(mode==='hybrid');if(mode==='hybrid'&&n)$('v133End').value=String(c.start+(n-1)*c.step);}
  }
  function applyHybrid(auto){
    try{
      if(!base.valid){ if(!captureBase())throw new Error('Chưa có CSV/TXT nền. Hãy bấm “Chọn CSV / TXT” trước.'); }
      var c=readSeq(), rec=[],i,o,val,headers=base.headers.slice(0),found=false;
      for(i=0;i<headers.length;i++){if(headers[i]===c.field){found=true;break;}}if(!found)headers.push(c.field);
      for(i=0;i<base.records.length;i++){o=cloneRecord(base.records[i]);val=formatNum(c.start+i*c.step,c);o[c.field]=val;rec.push(o);}
      restoring=true;
      try{oldLoad(JSON.stringify({ok:true,path:'',folder:base.folder,name:'CSV + Dãy số · '+base.name+' + '+c.field,text:toCsv(headers,rec)}));}
      finally{restoring=false;}
      if(window.DPVNumberSeqV133&&window.DPVNumberSeqV133.getConfig){/* keep old API untouched */}
      hybridInfo();
      status((auto?'Đã cập nhật':'Đã ghép')+' '+rec.length+' record CSV + dãy số '+c.field+' · '+formatNum(c.start,c)+' → '+formatNum(c.start+(rec.length-1)*c.step,c)+'. Có thể map đồng thời cột CSV và '+c.field+'.','ok');
    }catch(e){status('Không ghép được CSV + dãy số: '+String(e&&e.message?e.message:e),'error');}
  }
  function setVisual(m){
    mode=m;var a=$('v133CsvMode'),b=$('v133SeqMode'),h=$('v135HybridMode'),box=$('v133SeqBox'),tool=$('vdpChooseDataBtn')&&$('vdpChooseDataBtn').parentNode,g=$('v133Generate');
    if(a){rem(a,'active');}if(b){rem(b,'active');}if(h){rem(h,'active');}
    if(m==='csv'){if(a)add(a,'active');if(box)add(box,'v133-hidden');if(tool)rem(tool,'v133-hidden');if(g)txt(g,'Tạo dãy số & dùng ngay');if(base.valid)restoreBase();}
    else if(m==='seq'){if(b)add(b,'active');if(box)rem(box,'v133-hidden');if(tool)add(tool,'v133-hidden');if(g)txt(g,'Tạo dãy số & dùng ngay');}
    else{if(h)add(h,'active');if(box)rem(box,'v133-hidden');if(tool)rem(tool,'v133-hidden');if(g)txt(g,'Ghép dãy số vào CSV hiện tại');captureBase();}
    var hybrid=$('v135HybridInfo');if(hybrid){if(m==='hybrid')rem(hybrid,'v135-hidden');else add(hybrid,'v135-hidden');}
    if($('v133End'))$('v133End').disabled=(m==='hybrid');hybridInfo();
  }
  function wrapLoader(){
    if(!window.DPVVDP101||window.__V135LoaderWrapped)return;window.__V135LoaderWrapped=true;oldLoad=window.DPVVDP101.loadFileResult;
    window.DPVVDP101.loadFileResult=function(raw){
      oldLoad(raw);if(restoring)return;
      var r=parse(raw);
      if(r&&r.ok&&r.path){captureBase();if(mode==='hybrid')window.setTimeout(function(){applyHybrid(true);},0);}
    };
  }
  function makeUI(){
    var sw=$('v133SourceSwitch');if(!sw||$('v135HybridMode'))return false;
    var btn=document.createElement('button');btn.id='v135HybridMode';btn.type='button';btn.innerHTML='CSV + Dãy số';sw.appendChild(btn);
    var box=$('v133SeqBox');if(box){var info=document.createElement('div');info.id='v135HybridInfo';info.className='v135-hybrid-info v135-hidden';box.insertBefore(info,box.firstChild);}
    var csv=$('v133CsvMode'),seq=$('v133SeqMode'),gen=$('v133Generate');
    var oldCsv=csv&&csv.onclick,oldSeq=seq&&seq.onclick;oldGen=gen&&gen.onclick;
    if(csv)csv.onclick=function(){if(oldCsv)oldCsv();setVisual('csv');};
    if(seq)seq.onclick=function(){if(oldSeq)oldSeq();setVisual('seq');};
    btn.onclick=function(){if(oldSeq)oldSeq();setVisual('hybrid');};
    if(gen)gen.onclick=function(){if(mode==='hybrid')applyHybrid(false);else if(oldGen)oldGen();};
    var ids=['v133Start','v133Step','v133Field','v133Prefix','v133Suffix','v133Pad','v133Width'],i,el,prevChange,prevKey;
    for(i=0;i<ids.length;i++){
      el=$(ids[i]);if(!el)continue;prevChange=el.onchange;prevKey=el.onkeyup;
      el.onchange=(function(pc){return function(){if(pc)pc.call(this);if(mode==='hybrid')hybridInfo();};})(prevChange);
      el.onkeyup=(function(pk){return function(){if(pk)pk.call(this);if(mode==='hybrid')hybridInfo();};})(prevKey);
    }
    return true;
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V135 HYBRID DATA · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V135 Hybrid Data · Core V101 Stable</strong><br>VDP cho phép dùng đồng thời CSV/TXT + Dãy số tự động trong cùng record: map tên/địa chỉ từ CSV và SO_NHAY/serial tự động vào các vị trí khác nhau.';
  }
  function expose(){window.DPVHybridV135={getMode:function(){return mode;},hasBase:function(){return base.valid;},apply:function(){applyHybrid(false);},baseCount:function(){return base.records.length||0;}};}
  function start(){wrapLoader();makeUI();captureBase();mark();expose();setVisual('csv');}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();


/* ===== SOURCE: app_v136.js ===== */
(function(){
  function q(s){try{return document.querySelector(s);}catch(e){return null;}}
  function mark(){
    var v=q('.version-badge');
    if(v)v.innerHTML='V136 FONT FIDELITY · CORE V101 STABLE';
    var b=q('.beta-note');
    if(b)b.innerHTML='<strong>DPV® V136 Font Fidelity</strong><br>VDP Text/Number Sequence giữ nguyên font, style, size, leading, tracking và paragraph alignment của TextFrame layout khi Preview/Xuất PDF/VDP Sheet.';
  }
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);
    else window.attachEvent('onload',mark);
  }else mark();
})();


/* ===== SOURCE: app_v137.js ===== */
(function(){
  function $(id){return document.getElementById(id);}
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)v.innerHTML='V137 EXACT TEXT TEMPLATE · CORE V101 STABLE';
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V137 Exact Text Template</strong><br>VDP giữ style RIÊNG từng TextFrame/target: font, style, size, leading, tracking, paragraph. Artboard A chữ lớn và B chữ nhỏ không còn bị lẫn định dạng.';
  }
  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',mark);}else{mark();}
})();


/* ===== SOURCE: app_v138.js ===== */
(function(){
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;
    if(v)v.innerHTML='V138 NO-STROKE FIDELITY · CORE V101 STABLE';
    var b=document.querySelector?document.querySelector('.beta-note'):null;
    if(b)b.innerHTML='<strong>DPV® V138 No-Stroke Fidelity</strong><br>VDP giữ đúng font/size của từng TextFrame và KHÔNG tự bật stroke khi chữ gốc chỉ có Fill. Nếu layout gốc Stroke=None thì số nhảy/CSV xuất ra vẫn Stroke=None.';
  }
  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',mark);}else{mark();}
})();


/* ===== SOURCE: app_v139.js ===== */
(function(){
  "use strict";
  var VERSION='V140 PERFORMANCE FOUNDATION';
  var STORE_PRESETS='dpv.pro.presets.v139';
  var STORE_RECENT='dpv.pro.lastSettings.v139';
  var STORE_JOBS='dpv.pro.jobs.v139';
  var STORE_PERF='dpv.pro.performance.v139';
  var MAX_JOBS=24;
  var jobState={active:null,lastMain:'',lastVdp:''};

  function byId(id){return document.getElementById(id);}
  function qs(s){return document.querySelector?document.querySelector(s):null;}
  function qsa(s){return document.querySelectorAll?document.querySelectorAll(s):[];}
  function txt(el){return el?(el.textContent||el.innerText||''):'';}
  function trim(s){return String(s==null?'':s).replace(/^\s+|\s+$/g,'');}
  function add(el,c){if(!el)return;if((' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(!el)return;el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function num(id,def){var e=byId(id),v=e?parseFloat(e.value):NaN;return isNaN(v)?def:v;}
  function checked(id){var e=byId(id);return !!(e&&e.checked);}
  function val(id){var e=byId(id);return e?String(e.value||''):'';}
  function count(sel){var a=qsa(sel);return a?a.length:0;}
  function nowLabel(){var d=new Date();function p(n){return n<10?'0'+n:String(n);}return p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());}
  function nowFull(){var d=new Date();function p(n){return n<10?'0'+n:String(n);}return p(d.getDate())+'/'+p(d.getMonth()+1)+' '+p(d.getHours())+':'+p(d.getMinutes());}
  function storeGet(k,def){try{var s=window.localStorage?localStorage.getItem(k):null;return s?JSON.parse(s):def;}catch(e){return def;}}
  function storeSet(k,v){try{if(window.localStorage)localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){return false;}}
  function fire(el,type){if(!el)return;try{var ev=document.createEvent('HTMLEvents');ev.initEvent(type,true,false);el.dispatchEvent(ev);}catch(e){try{el.fireEvent('on'+type);}catch(x){}}}
  function click(id){var e=byId(id);if(e&&e.click)e.click();}
  function showToast(msg){var t=byId('dpvToast');if(t){if('textContent'in t)t.textContent=msg;else t.innerText=msg;add(t,'show');setTimeout(function(){rem(t,'show');},2200);}}

  var settingIds=['paperW','paperH','margin','header','gapX','gapY','maxQty','linkBleed','dieHint','angleStep','cornerZone','demiExtend','finishMarkLength','finishMarkGap','duplexFlip'];
  var checkIds=['allowRotate','uniformGap','trueShape','specialStagger','fastMode','addTitle','cornerSafe','demiMode','preservePrintColor','autoPon','fitPon','ponProcessBlack','cornerPonRed','finishCropMarks','duplexMode'];
  function captureSettings(){
    var o={version:140,created:new Date().getTime(),values:{},checks:{}};var i,e;
    for(i=0;i<settingIds.length;i++){e=byId(settingIds[i]);if(e)o.values[settingIds[i]]=String(e.value||'');}
    for(i=0;i<checkIds.length;i++){e=byId(checkIds[i]);if(e)o.checks[checkIds[i]]=!!e.checked;}
    return o;
  }
  function applySettings(o){
    if(!o)return;var k,e;
    for(k in o.values){if(o.values.hasOwnProperty(k)){e=byId(k);if(e){e.value=o.values[k];fire(e,'input');fire(e,'change');}}}
    for(k in o.checks){if(o.checks.hasOwnProperty(k)){e=byId(k);if(e){e.checked=!!o.checks[k];fire(e,'change');}}}
    setTimeout(function(){click('localPreviewBtn');},80);
  }
  function saveRecent(){storeSet(STORE_RECENT,captureSettings());}

  function isOnline(){var d=byId('connectionDot');return !!(d&&(' '+d.className+' ').indexOf(' online ')>=0);}
  function sourceCount(){var n=count('#sourceList .source-card');if(n)return n;var l=byId('sourceList');if(!l)return 0;return count('#sourceList [data-index]');}
  function previewCount(){var v=parseInt(trim(txt(byId('previewCount'))),10);return isNaN(v)?0:v;}
  function vdpRecordCount(){var e=byId('vdpRecordCount'),n=e?parseInt(e.value,10):0;return isNaN(n)?0:n;}
  function vdpMappingCount(){return count('#vdpMappings .vdp-map-row');}
  function vdpMappedFields(){var rows=qsa('#vdpMappings .vdp-map-row'),ok=0,i,s;for(i=0;i<rows.length;i++){s=rows[i].querySelector?rows[i].querySelector('.vdp-field'):null;if(s&&trim(s.value))ok++;}return ok;}

  function runPreflight(){
    var a=[],pw=num('paperW',0),ph=num('paperH',0),m=num('margin',0),head=num('header',0),gx=num('gapX',0),gy=num('gapY',0),bleed=num('linkBleed',0),sc=sourceCount(),pc=previewCount(),out=trim(val('outputPath')),pon=trim(val('ponPath'));
    function item(level,title,detail){a.push({level:level,title:title,detail:detail});}
    item(isOnline()?'ok':'error','Kết nối Illustrator',isOnline()?'Illustrator đang Online.':'Chưa kết nối Illustrator; không thể Preview/Build sản xuất.');
    item(sc>0?'ok':'error','Nguồn in',sc>0?('Đã có '+sc+' nguồn/artboard cần dàn.'):'Chưa có nguồn in hoặc kích thước thủ công.');
    item(pw>0&&ph>0?'ok':'error','Khổ in',pw>0&&ph>0?(pw+' × '+ph+' mm'):'Rộng/Cao khổ phải lớn hơn 0.');
    item(m>=0&&pw>2*m&&ph>2*m?'ok':'error','Lề cứng',m>=0&&pw>2*m&&ph>2*m?('Lề '+m+' mm nằm trong khổ.'):'Lề đang lớn hơn vùng in khả dụng.');
    item(head>=0&&head<ph-2*m?'ok':'error','Vùng tiêu đề',head>=0&&head<ph-2*m?('Vùng tên file '+head+' mm.'):'Vùng tiêu đề không còn đủ chiều cao làm việc.');
    item(gx>=0&&gy>=0?'ok':'error','Khoảng cách',gx>=0&&gy>=0?('Gap ngang '+gx+' mm · dọc '+gy+' mm.'):'Gap không được âm.');
    item(bleed>=0?'ok':'error','Bleed',bleed>=0?('Bleed trong Link '+bleed+' mm.'):'Bleed không được âm.');
    item(pc>0?'ok':'warn','Layout đã tính',pc>0?('Layout hiện tại '+pc+' con/tờ.'):'Chưa Tính nhanh; nên khóa layout trước khi xuất.');
    item(out?'ok':'error','Thư mục đầu ra',out?out:'Chưa chọn thư mục xuất.');
    if(!checked('autoPon'))item(pon?'ok':'warn','PON',pon?'Đã chọn PON file.':'Auto PON đang tắt nhưng chưa chọn file PON.'); else item('ok','PON','Auto PON đang bật.');
    if(checked('duplexMode'))item(sc===2?'ok':'error','In 2 mặt A/B',sc===2?'Đúng 2 nguồn/artboard A/B.':('Đang có '+sc+' nguồn; Duplex yêu cầu đúng 2 artboard.'));
    if(checked('finishCropMarks'))item(num('finishMarkLength',0)>0?'ok':'error','CATTP',num('finishMarkLength',0)>0?('Dài '+num('finishMarkLength',0)+' mm · cách '+num('finishMarkGap',0)+' mm.'):'Chiều dài PON cắt phải > 0.');
    var vr=vdpRecordCount(),vm=vdpMappingCount(),vf=vdpMappedFields();
    if(vr>0||vm>0){
      item(vr>0?'ok':'error','VDP dữ liệu',vr>0?(vr+' record đã nạp.'):'Chưa có record VDP.');
      item(vm>0&&vf===vm?'ok':(vm>0?'warn':'error'),'VDP mapping',vm>0?(vf+'/'+vm+' kênh đã chọn cột dữ liệu.'):'Chưa có kênh biến đổi.');
      item(trim(val('vdpOutputPath'))?'ok':'warn','VDP đầu ra',trim(val('vdpOutputPath'))?trim(val('vdpOutputPath')):'Chưa chọn thư mục VDP.');
    }
    var s={ok:0,warn:0,error:0,items:a};var i;for(i=0;i<a.length;i++)s[a[i].level]++;
    return s;
  }
  function preflightMessage(s){if(s.error)return s.error+' lỗi cần sửa · '+s.warn+' cảnh báo';if(s.warn)return 'Sẵn sàng có '+s.warn+' cảnh báo';return 'Sẵn sàng sản xuất · tất cả kiểm tra đạt';}
  function updateSafety(s){
    var box=byId('dpvSafetyStrip'),lab=byId('dpvSafetyLabel');if(!box||!lab)return;s=s||runPreflight();
    rem(box,'ok');rem(box,'warn');rem(box,'error');add(box,s.error?'error':(s.warn?'warn':'ok'));lab.innerHTML=esc(preflightMessage(s));
  }
  function renderPreflight(){
    var s=runPreflight(),sum=byId('dpvPreflightSummary'),list=byId('dpvPreflightList');if(!sum||!list)return;
    sum.innerHTML='<div class="dpv-pro-stat ok"><label>ĐẠT</label><strong>'+s.ok+'</strong></div><div class="dpv-pro-stat warn"><label>CẢNH BÁO</label><strong>'+s.warn+'</strong></div><div class="dpv-pro-stat error"><label>LỖI</label><strong>'+s.error+'</strong></div><div class="dpv-pro-stat"><label>LAYOUT</label><strong>'+previewCount()+'</strong></div>';
    var h='',i,x,ic;for(i=0;i<s.items.length;i++){x=s.items[i];ic=x.level==='ok'?'✓':(x.level==='warn'?'!':'×');h+='<div class="dpv-check-row '+x.level+'"><span class="dpv-check-icon">'+ic+'</span><div class="dpv-check-copy"><strong>'+esc(x.title)+'</strong><small>'+esc(x.detail)+'</small></div></div>';}
    list.innerHTML=h;updateSafety(s);
  }

  function getPresets(){var p=storeGet(STORE_PRESETS,[]);return p&&p.length!=null?p:[];}
  function renderPresets(){
    var list=byId('dpvPresetList');if(!list)return;var p=getPresets(),h='',i;if(!p.length){list.innerHTML='<div class="dpv-check-row"><div class="dpv-check-copy"><strong>Chưa có preset</strong><small>Lưu bộ thông số dàn đang dùng để gọi lại trong 1 click. File nguồn/PON/output không được lưu để tránh đường dẫn cũ.</small></div></div>';return;}
    for(i=0;i<p.length;i++)h+='<div class="dpv-preset-row" data-preset-index="'+i+'"><div class="dpv-preset-main"><strong>'+esc(p[i].name)+'</strong><small>'+esc(p[i].note||'Thông số dàn DPV')+'</small></div><div class="dpv-preset-actions"><button data-preset-apply="'+i+'">Áp dụng</button><button data-preset-delete="'+i+'">Xóa</button></div></div>';
    list.innerHTML=h;var btns=qsa('[data-preset-apply]'),j;for(j=0;j<btns.length;j++)btns[j].onclick=function(){var idx=parseInt(this.getAttribute('data-preset-apply'),10),arr=getPresets();if(arr[idx]){applySettings(arr[idx].data);showToast('Đã áp dụng preset: '+arr[idx].name);closePro();}};
    btns=qsa('[data-preset-delete]');for(j=0;j<btns.length;j++)btns[j].onclick=function(){var idx=parseInt(this.getAttribute('data-preset-delete'),10),arr=getPresets();if(idx>=0&&idx<arr.length){arr.splice(idx,1);storeSet(STORE_PRESETS,arr);renderPresets();}};
  }
  function savePreset(){var n=trim(val('dpvPresetName'));if(!n){showToast('Nhập tên preset trước.');return;}var p=getPresets(),i;for(i=p.length-1;i>=0;i--)if(String(p[i].name).toLowerCase()===n.toLowerCase())p.splice(i,1);p.unshift({name:n,note:'Khổ '+val('paperW')+'×'+val('paperH')+' · Gap '+val('gapX')+'/'+val('gapY')+' · Lề '+val('margin'),data:captureSettings()});if(p.length>20)p.length=20;storeSet(STORE_PRESETS,p);byId('dpvPresetName').value='';renderPresets();showToast('Đã lưu preset '+n);}

  function getJobs(){var a=storeGet(STORE_JOBS,[]);return a&&a.length!=null?a:[];}
  function saveJobs(a){if(a.length>MAX_JOBS)a.length=MAX_JOBS;storeSet(STORE_JOBS,a);}
  function addJob(type,label){var a=getJobs(),ts=new Date().getTime(),j={id:ts,type:type,label:label,start:nowFull(),tsStart:ts,state:'running',detail:'Đã gửi lệnh.'};a.unshift(j);saveJobs(a);jobState.active=j;jobState.lastMain=trim(txt(byId('status')));jobState.lastVdp=trim(txt(byId('vdpStatus')));renderJobs();}
  function finishJob(state,detail){if(!jobState.active)return;var a=getJobs(),i,now=new Date().getTime();for(i=0;i<a.length;i++)if(a[i].id===jobState.active.id){a[i].state=state;a[i].detail=detail||a[i].detail;a[i].end=nowFull();a[i].tsEnd=now;a[i].durationMs=Math.max(0,now-(a[i].tsStart||a[i].id||now));break;}saveJobs(a);jobState.active=null;renderJobs();}
  function classifyStatus(s,el){var t=String(s||'').toLowerCase(),cn=el?String(el.className||'').toLowerCase():'';if(!t)return'';if(cn.indexOf('error')>=0||t.indexOf('lỗi')>=0||t.indexOf('error')>=0||t.indexOf('failed')>=0||t.indexOf('không thể')>=0||t.indexOf('không đọc')>=0||t.indexOf('chưa chọn')>=0||t.indexOf('chưa có')>=0)return'error';if(t.indexOf('hoàn tất')>=0||t.indexOf('đã xuất')>=0||t.indexOf('đã tính')>=0||t.indexOf('đã xác nhận')>=0||t.indexOf('đã mở')>=0||t.indexOf('complete')>=0||t.indexOf('thành công')>=0)return'done';return'info';}
  function renderJobs(){
    var live=byId('dpvLiveJob'),list=byId('dpvJobList');if(!live||!list)return;var a=getJobs(),h='',i,j;
    if(jobState.active)live.innerHTML='<strong>'+esc(jobState.active.label)+'</strong><small>'+esc(jobState.active.detail||'Đang chờ phản hồi từ engine...')+'</small><div class="dpv-live-bar"><i></i></div>';else live.innerHTML='<strong>Không có tác vụ đang chạy</strong><small>DPV sẽ ghi lịch sử Tính nhanh, Preview, Build, VDP và Combine tại đây.</small>';
    if(!a.length){list.innerHTML='<div class="dpv-check-row"><div class="dpv-check-copy"><strong>Chưa có lịch sử</strong><small>Thực hiện một tác vụ để bắt đầu ghi nhật ký.</small></div></div>';return;}
    for(i=0;i<a.length;i++){j=a[i];h+='<div class="dpv-job-row"><div class="dpv-job-main"><strong>'+esc(j.label)+'</strong><small>'+esc(j.start+(j.end?' → '+j.end:'')+(j.durationMs!=null?' · '+(j.durationMs<1000?j.durationMs+' ms':(Math.round(j.durationMs/100)/10)+' s'):'')+' · '+(j.detail||''))+'</small></div><span class="dpv-job-state '+esc(j.state||'info')+'">'+esc(j.state==='running'?'ĐANG CHẠY':(j.state==='done'?'HOÀN TẤT':(j.state==='error'?'LỖI':'THÔNG TIN')))+'</span></div>';}
    list.innerHTML=h;
  }
  function monitorStatuses(){
    var m=trim(txt(byId('status'))),v=trim(txt(byId('vdpStatus'))),s,cl;
    if(m&&m!==jobState.lastMain){jobState.lastMain=m;if(jobState.active){jobState.active.detail=m;cl=classifyStatus(m,byId('status'));if(cl==='done'||cl==='error')finishJob(cl,m);else renderJobs();}}
    if(v&&v!==jobState.lastVdp){jobState.lastVdp=v;if(jobState.active){jobState.active.detail=v;cl=classifyStatus(v,byId('vdpStatus'));if(cl==='done'||cl==='error')finishJob(cl,v);else renderJobs();}}
  }
  function bindStatusMonitor(){
    var els=[byId('status'),byId('vdpStatus')],i,el;
    if(window.MutationObserver){for(i=0;i<els.length;i++){el=els[i];if(el){(function(node){var ob=new MutationObserver(function(){monitorStatuses();});ob.observe(node,{childList:true,characterData:true,subtree:true,attributes:true,attributeFilter:['class']});})(el);}}}
    else if(document.addEventListener){for(i=0;i<els.length;i++){el=els[i];if(el)el.addEventListener('DOMSubtreeModified',monitorStatuses,false);}}
    else if(document.attachEvent){for(i=0;i<els.length;i++){el=els[i];if(el)el.attachEvent('onpropertychange',monitorStatuses);}}
    monitorStatuses();
  }
  function bindJobButton(id,type,label,save){var e=byId(id);if(!e)return;var fn=function(){if(save)saveRecent();addJob(type,label);};if(e.addEventListener)e.addEventListener('click',fn,false);else if(e.attachEvent)e.attachEvent('onclick',fn);}

  function diagData(){
    var perf=getPerf();return[
      ['Phiên bản UI',VERSION],['Core layout','V101 STABLE + Mixed Rotation Safe'],['Illustrator',isOnline()?trim(txt(byId('connectionText'))):'Offline'],['Nguồn in',String(sourceCount())],['Layout',String(previewCount())+' con/tờ'],['Khổ',val('paperW')+' × '+val('paperH')+' mm'],['Gap',val('gapX')+' / '+val('gapY')+' mm'],['Output',trim(val('outputPath'))||'Chưa chọn'],['VDP record',String(vdpRecordCount())],['VDP mapping',String(vdpMappingCount())],['UI performance',perf],['Theme',document.body.className.indexOf('dpv-dark')>=0?'Dark':'Light'],['Viewport',(document.documentElement.clientWidth||0)+' × '+(document.documentElement.clientHeight||0)],['User agent',navigator.userAgent||'']
    ];
  }
  function renderDiag(){var tb=byId('dpvDiagTable'),box=byId('dpvDiagBox');if(!tb||!box)return;var d=diagData(),h='',t='',i;for(i=0;i<d.length;i++){h+='<tr><td>'+esc(d[i][0])+'</td><td class="dpv-diag-value">'+esc(d[i][1])+'</td></tr>';t+=d[i][0]+': '+d[i][1]+'\r\n';}tb.innerHTML=h;box.value=t;renderPerf();}

  function detectWindowsLegacy(){var ua=(navigator.userAgent||'').toLowerCase();return ua.indexOf('trident')>=0||ua.indexOf('msie')>=0||ua.indexOf('windows')>=0;}
  function getPerf(){var p=storeGet(STORE_PERF,null);if(typeof p==='string')return p;if(p&&p.mode)return p.mode;return detectWindowsLegacy()?'fast':'balanced';}
  function setPerf(mode){if(mode!=='fast'&&mode!=='balanced'&&mode!=='beauty')mode='balanced';rem(document.body,'dpv-perf-fast');rem(document.body,'dpv-perf-balanced');rem(document.body,'dpv-perf-beauty');add(document.body,'dpv-perf-'+mode);storeSet(STORE_PERF,{mode:mode});renderPerf();}
  function renderPerf(){var b=qsa('.dpv-perf-choice'),p=getPerf(),i;for(i=0;i<b.length;i++){if(b[i].getAttribute('data-perf')===p)add(b[i],'active');else rem(b[i],'active');}}

  function setNavActive(name){var b=qsa('.dpv-nav-btn'),i;for(i=0;i<b.length;i++){if(b[i].getAttribute('data-nav')===name)add(b[i],'active');else rem(b[i],'active');}}
  function openPro(tab){var o=byId('dpvProOverlay');if(!o)return;add(o,'open');switchTab(tab||'preflight');if(tab==='preflight')renderPreflight();if(tab==='preset')renderPresets();if(tab==='jobs')renderJobs();if(tab==='system')renderDiag();setNavActive(tab==='preset'?'preset':tab);}
  function closePro(){var o=byId('dpvProOverlay');if(o)rem(o,'open');setNavActive('main');}
  function switchTab(tab){var ts=qsa('.dpv-pro-tab'),ps=qsa('.dpv-pro-page'),i;for(i=0;i<ts.length;i++){if(ts[i].getAttribute('data-pro-tab')===tab)add(ts[i],'active');else rem(ts[i],'active');}for(i=0;i<ps.length;i++){if(ps[i].getAttribute('data-pro-page')===tab)add(ps[i],'active');else rem(ps[i],'active');}}

  function insertProUI(){
    if(byId('dpvProOverlay'))return;
    var side=byId('dpvSidebar'),nav=side&&side.querySelector?side.querySelector('.dpv-nav'):null,settingsBtn=nav&&nav.querySelector?nav.querySelector('[data-nav="settings"]'):null,b;
    if(nav){
      b=document.createElement('button');b.className='dpv-nav-btn';b.setAttribute('data-nav','preflight');b.innerHTML='<span class="dpv-nav-icon">✓</span>Preflight';nav.insertBefore(b,settingsBtn||null);
      b=document.createElement('button');b.className='dpv-nav-btn';b.setAttribute('data-nav','jobs');b.innerHTML='<span class="dpv-nav-icon">◌</span>Trung tâm Job';nav.insertBefore(b,settingsBtn||null);
    }
    var res=qs('.result-column'),status=byId('status');if(res&&status){var strip=document.createElement('div');strip.id='dpvSafetyStrip';strip.className='dpv-safety-strip';strip.innerHTML='<div class="dpv-safety-left"><span class="dpv-safety-dot"></span><span id="dpvSafetyLabel" class="dpv-safety-label">Preflight chưa chạy</span></div><button id="dpvSafetyBtn" class="button tiny dpv-safety-btn">Kiểm tra</button>';res.insertBefore(strip,status);}
    var o=document.createElement('div');o.id='dpvProOverlay';o.className='dpv-pro-overlay';o.innerHTML=''
      +'<div class="dpv-pro-window"><div class="dpv-pro-head"><div class="dpv-pro-head-left"><span class="dpv-pro-badge">PRO</span><div><h2 class="dpv-pro-title">DPV Pro Center</h2><p class="dpv-pro-sub">Preflight · Preset · Job History · System Diagnostics · UI Performance</p></div></div><button id="dpvProClose" class="dpv-pro-close">×</button></div>'
      +'<div class="dpv-pro-tabs"><button class="dpv-pro-tab active" data-pro-tab="preflight">Preflight</button><button class="dpv-pro-tab" data-pro-tab="preset">Preset</button><button class="dpv-pro-tab" data-pro-tab="jobs">Job Center</button><button class="dpv-pro-tab" data-pro-tab="system">System</button></div>'
      +'<div class="dpv-pro-body">'
      +'<section class="dpv-pro-page active" data-pro-page="preflight"><div id="dpvPreflightSummary" class="dpv-pro-summary"></div><div class="dpv-pro-grid"><div class="dpv-pro-card"><h3>Preflight sản xuất</h3><p>Kiểm tra trạng thái nguồn, khổ/lề/gap, layout, PON/CATTP, Duplex và VDP trước khi xuất. Đây là kiểm tra không phá file và không thay Core V101.</p><div id="dpvPreflightList" class="dpv-preflight-list"></div><div class="dpv-pro-toolbar"><button id="dpvPreflightRun" class="button primary">Chạy lại</button><button id="dpvPreflightCalc" class="button">Tính nhanh bố cục</button><button id="dpvPreflightOutput" class="button">Chọn đầu ra</button></div></div><div class="dpv-pro-card"><h3>Quy tắc an toàn</h3><p><strong>Không tự sửa file Illustrator.</strong> Preflight chỉ báo lỗi/cảnh báo. Các chức năng Build/VDP vẫn dùng nguyên pipeline đã ổn định.</p><p>Khuyến nghị trước job lớn: Preflight → Tính nhanh → Preview 1 record → chạy batch.</p></div></div></section>'
      +'<section class="dpv-pro-page" data-pro-page="preset"><div class="dpv-pro-grid"><div class="dpv-pro-card"><h3>Thư viện preset dàn</h3><p>Lưu khổ, lề, gap, bleed, rotate, Exact Gap, PON/CATTP, Duplex và các thông số sản xuất. Không lưu đường dẫn file để tránh mở nhầm job cũ.</p><div class="dpv-pro-toolbar"><input id="dpvPresetName" class="dpv-pro-name" type="text" placeholder="Tên preset, ví dụ Tem 54x81 - 320x390"><button id="dpvPresetSave" class="button primary">Lưu hiện tại</button><button id="dpvPresetRestore" class="button">Khôi phục lần gần nhất</button></div><div id="dpvPresetList" class="dpv-preset-list"></div></div></div></section>'
      +'<section class="dpv-pro-page" data-pro-page="jobs"><div class="dpv-pro-grid"><div class="dpv-pro-card"><h3>Tác vụ hiện tại</h3><div id="dpvLiveJob" class="dpv-live-job"></div></div><div class="dpv-pro-card"><h3>Lịch sử thao tác</h3><p>Ghi nhẹ trên máy: Tính nhanh, Preview, Build, VDP, Combine. Không đọc/ghi artwork.</p><div class="dpv-pro-toolbar"><button id="dpvJobsClear" class="button">Xóa lịch sử</button></div><div id="dpvJobList" class="dpv-job-list"></div></div></div></section>'
      +'<section class="dpv-pro-page" data-pro-page="system"><div class="dpv-pro-grid"><div class="dpv-pro-card"><h3>Hiệu năng giao diện</h3><p>Chỉ thay hiệu ứng UI, không thay thuật toán dàn hoặc chất lượng PDF.</p><div class="dpv-perf-selector"><button class="dpv-perf-choice" data-perf="fast">Nhanh · ít hiệu ứng</button><button class="dpv-perf-choice" data-perf="balanced">Cân bằng</button><button class="dpv-perf-choice" data-perf="beauty">Đẹp · nhiều hiệu ứng</button></div><div class="dpv-pro-toolbar"><button id="dpvProTheme" class="button">Đổi Light / Dark</button></div></div><div class="dpv-pro-card"><h3>Diagnostics</h3><table class="dpv-diag-table"><tbody id="dpvDiagTable"></tbody></table><textarea id="dpvDiagBox" class="dpv-diag-box" readonly></textarea></div></div></section>'
      +'</div></div>';
    document.body.appendChild(o);

    var menu=document.createElement('div');menu.id='dpvCommandMenu';menu.className='dpv-command-menu';var sw=qs('.dpv-search-wrap');if(sw)sw.appendChild(menu);
    var set=byId('dpvSettings');if(set){var row=document.createElement('div');row.className='dpv-settings-row';row.innerHTML='<span>Pro Center</span><button id="dpvOpenProSettings" class="button tiny">Mở hệ thống</button>';set.appendChild(row);}
  }

  var commands=[
    {name:'Dàn file',keys:'dan file main',run:function(){var p=byId('vdpPanel');if(p)add(p,'hidden');setNavActive('main');}},
    {name:'Biến đổi dữ liệu VDP',keys:'vdp bien doi du lieu',run:function(){click('vdpOpenBtn');setNavActive('vdp');}},
    {name:'Tính nhanh trên DPV',keys:'tinh nhanh layout preview',run:function(){click('localPreviewBtn');}},
    {name:'Đối chiếu bằng Illustrator',keys:'illustrator preview doi chieu',run:function(){click('hostPreviewBtn');}},
    {name:'View khuôn trực tiếp qua Illustrator',keys:'view khuon die preview',run:function(){click('diePreviewBtn');}},
    {name:'Dàn Link & xuất IN/KHUÔN',keys:'build xuat in khuon dan link',run:function(){click('buildBtn');}},
    {name:'Chọn PON',keys:'pon file',run:function(){click('ponBtn');}},
    {name:'Chọn thư mục đầu ra',keys:'output thu muc xuat',run:function(){click('outputBtn');}},
    {name:'Preflight sản xuất',keys:'preflight kiem tra loi',run:function(){openPro('preflight');}},
    {name:'Thư viện preset',keys:'preset thu vien thong so',run:function(){openPro('preset');}},
    {name:'Trung tâm Job',keys:'job history lich su',run:function(){openPro('jobs');}},
    {name:'Diagnostics & hiệu năng',keys:'system diagnostics hieu nang',run:function(){openPro('system');}},
    {name:'Đổi Light / Dark',keys:'theme dark light giao dien',run:function(){var b=byId('dpvThemeSwitch');if(b)click('dpvThemeSwitch');}}
  ];
  function filteredCommands(q){q=trim(q).toLowerCase();var a=[],i,c,s;for(i=0;i<commands.length;i++){c=commands[i];s=(c.name+' '+c.keys).toLowerCase();if(!q||s.indexOf(q)>=0)a.push(c);}return a;}
  function renderCommands(){var inp=byId('dpvSearch'),m=byId('dpvCommandMenu');if(!inp||!m)return;var a=filteredCommands(inp.value),h='',i;for(i=0;i<a.length&&i<9;i++)h+='<button class="dpv-command-item'+(i===0?' selected':'')+'" data-command-index="'+commands.indexOf(a[i])+'"><span>'+esc(a[i].name)+'</span><small>Enter</small></button>';m.innerHTML=h;if(a.length)add(m,'open');else rem(m,'open');var b=qsa('.dpv-command-item'),j;for(j=0;j<b.length;j++)b[j].onclick=function(){var idx=parseInt(this.getAttribute('data-command-index'),10);rem(m,'open');inp.value='';if(commands[idx])commands[idx].run();};}
  function bindCommandPalette(){var inp=byId('dpvSearch'),m=byId('dpvCommandMenu');if(!inp||!m)return;inp.placeholder='Tìm lệnh: VDP, Preflight, PON, Preset...';inp.onfocus=function(){renderCommands();};inp.oninput=function(){renderCommands();};inp.onkeydown=function(e){e=e||window.event;if(e.keyCode===27){rem(m,'open');inp.blur();return;}if(e.keyCode===13){var a=filteredCommands(inp.value);if(a.length){rem(m,'open');inp.value='';a[0].run();try{e.preventDefault();}catch(x){}return false;}}};inp.onblur=function(){setTimeout(function(){rem(m,'open');},180);};}

  function bindUI(){
    var tabs=qsa('.dpv-pro-tab'),i;for(i=0;i<tabs.length;i++)tabs[i].onclick=function(){var t=this.getAttribute('data-pro-tab');switchTab(t);if(t==='preflight')renderPreflight();if(t==='preset')renderPresets();if(t==='jobs')renderJobs();if(t==='system')renderDiag();};
    if(byId('dpvProClose'))byId('dpvProClose').onclick=closePro;if(byId('dpvSafetyBtn'))byId('dpvSafetyBtn').onclick=function(){openPro('preflight');};
    if(byId('dpvPreflightRun'))byId('dpvPreflightRun').onclick=renderPreflight;if(byId('dpvPreflightCalc'))byId('dpvPreflightCalc').onclick=function(){click('localPreviewBtn');setTimeout(renderPreflight,220);};if(byId('dpvPreflightOutput'))byId('dpvPreflightOutput').onclick=function(){click('outputBtn');};
    if(byId('dpvPresetSave'))byId('dpvPresetSave').onclick=savePreset;if(byId('dpvPresetRestore'))byId('dpvPresetRestore').onclick=function(){var r=storeGet(STORE_RECENT,null);if(r){applySettings(r);showToast('Đã khôi phục thông số gần nhất.');closePro();}else showToast('Chưa có thông số gần nhất.');};
    if(byId('dpvJobsClear'))byId('dpvJobsClear').onclick=function(){storeSet(STORE_JOBS,[]);jobState.active=null;renderJobs();};
    var perf=qsa('.dpv-perf-choice');for(i=0;i<perf.length;i++)perf[i].onclick=function(){setPerf(this.getAttribute('data-perf'));renderDiag();};
    if(byId('dpvProTheme'))byId('dpvProTheme').onclick=function(){click('dpvThemeSwitch');setTimeout(renderDiag,80);};if(byId('dpvOpenProSettings'))byId('dpvOpenProSettings').onclick=function(){var s=byId('dpvSettings');if(s)rem(s,'open');openPro('system');};
    var presetNav=qs('.dpv-nav-btn[data-nav="preset"]'),preNav=qs('.dpv-nav-btn[data-nav="preflight"]'),jobNav=qs('.dpv-nav-btn[data-nav="jobs"]');if(presetNav)presetNav.onclick=function(){openPro('preset');};if(preNav)preNav.onclick=function(){openPro('preflight');};if(jobNav)jobNav.onclick=function(){openPro('jobs');};
    var ov=byId('dpvProOverlay');if(ov)ov.onclick=function(e){e=e||window.event;if((e.target||e.srcElement)===ov)closePro();};
    bindCommandPalette();
    bindJobButton('localPreviewBtn','layout','Tính nhanh bố cục',true);bindJobButton('hostPreviewBtn','preview','Đối chiếu Illustrator',false);bindJobButton('diePreviewBtn','die','View khuôn Illustrator',false);bindJobButton('buildBtn','build','Dàn Link & xuất IN/KHUÔN',true);bindJobButton('vdpBuildBtn','vdp','VDP / VDP Sheet',false);bindJobButton('vdpCombineExistingBtn','combine','Combine PDF',false);
  }

  function updateVersion(){var v=qs('.version-badge');if(v)v.innerHTML='V140 PERFORMANCE · CORE V101 STABLE';var b=qs('.beta-note');if(b)b.innerHTML='<strong>DPV® V140 Performance Foundation · Core V101 Stable</strong><br>Release Bundle · Job Monitor event-driven · Diagnostics · Ctrl+K Command Palette. Không thay engine dàn, VDP, PON, Duplex hay Bridge Illustrator.';var card=qs('.dpv-side-card');if(card)card.innerHTML='<strong><span class="dpv-side-dot"></span>Core V101 STABLE</strong>Engine sản xuất được giữ nguyên.<br>V140 tối ưu runtime + UI.';}
  function start(){insertProUI();add(document.body,'dpv-pro-polish');setPerf(getPerf());updateVersion();bindUI();bindStatusMonitor();renderPreflight();renderPresets();renderJobs();renderDiag();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',function(){setTimeout(start,30);},false);else window.attachEvent('onload',function(){setTimeout(start,30);});}else setTimeout(start,30);
})();


/* ===== SOURCE: app_v140.js ===== */
(function(){
  "use strict";
  var VERSION='V140 PERFORMANCE FOUNDATION';
  var STORE_ADV='dpv.ui.advanced.v140';
  var previewZoom=1;

  function byId(id){return document.getElementById(id);}
  function qs(s,root){return (root||document).querySelector?(root||document).querySelector(s):null;}
  function qsa(s,root){return (root||document).querySelectorAll?(root||document).querySelectorAll(s):[];}
  function add(el,c){if(!el)return;if((' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(!el)return;el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function storeGet(k,d){try{var v=window.localStorage?localStorage.getItem(k):null;return v==null?d:JSON.parse(v);}catch(e){return d;}}
  function storeSet(k,v){try{if(window.localStorage)localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
  function text(el){return el?(el.textContent||el.innerText||''):'';}
  function setText(el,s){if(!el)return;if('textContent' in el)el.textContent=s;else el.innerText=s;}

  function updateVersionLabels(){
    var v=qs('.version-badge');if(v)v.innerHTML='V140 PERFORMANCE · CORE V101 STABLE';
    var b=qs('.beta-note');if(b)b.innerHTML='<strong>DPV® V140 Performance Foundation · Core V101 Stable</strong><br>Release Bundle · Event-driven Job Monitor · UI typography mới · Advanced compact · Preview phóng lớn. Không thay engine dàn, VDP, PON, Duplex hay Bridge Illustrator.';
    var side=qs('.dpv-side-card');if(side)side.innerHTML='<strong><span class="dpv-side-dot"></span>Core V101 STABLE</strong>Engine sản xuất giữ nguyên.<br>V140 tối ưu runtime + giao diện.';
  }

  function setAdvancedVisible(on){
    var col=qs('.settings-column');if(!col)return;
    if(on)rem(col,'dpv-v140-compact');else add(col,'dpv-v140-compact');
    var b=byId('dpvAdvancedToggle');if(b){b.setAttribute('aria-expanded',on?'true':'false');b.innerHTML=on?'Thu gọn nâng cao':'Nâng cao <span>9</span>';}
    storeSet(STORE_ADV,!!on);
  }
  function enhanceSettings(){
    var col=qs('.settings-column');if(!col||byId('dpvAdvancedToggle'))return;
    var ids=['specialStagger','fastMode','addTitle','cornerSafe','demiMode','preservePrintColor'];
    var i,e,p;
    for(i=0;i<ids.length;i++){e=byId(ids[i]);if(e&&e.parentNode){p=e.parentNode;add(p,'dpv-v140-advanced');}}
    var grids=qsa('.form-grid.compact',col);if(grids.length)add(grids[0],'dpv-v140-advanced-grid');
    var title=qs('.panel-title',col);if(title){
      var b=document.createElement('button');b.id='dpvAdvancedToggle';b.className='dpv-v140-advanced-toggle';b.type='button';b.innerHTML='Nâng cao <span>9</span>';
      b.onclick=function(){setAdvancedVisible((' '+col.className+' ').indexOf(' dpv-v140-compact ')>=0);};title.appendChild(b);
    }
    setAdvancedVisible(storeGet(STORE_ADV,false)===true);
  }

  function copyPreview(){
    var src=byId('layoutCanvas'),dst=byId('dpvV140PreviewCanvas');if(!src||!dst)return;
    try{dst.width=src.width;dst.height=src.height;var c=dst.getContext('2d');c.clearRect(0,0,dst.width,dst.height);c.drawImage(src,0,0);applyPreviewZoom();}catch(e){}
    var cap=byId('dpvV140PreviewCaption'),old=byId('layoutCaption');if(cap&&old)setText(cap,text(old));
  }
  function applyPreviewZoom(){var c=byId('dpvV140PreviewCanvas');if(!c)return;c.style.width=Math.round(c.width*previewZoom)+'px';c.style.height=Math.round(c.height*previewZoom)+'px';var z=byId('dpvV140ZoomLabel');if(z)setText(z,Math.round(previewZoom*100)+'%');}
  function openPreview(){var o=byId('dpvV140PreviewOverlay');if(!o)return;previewZoom=1.35;copyPreview();add(o,'open');}
  function closePreview(){rem(byId('dpvV140PreviewOverlay'),'open');}
  function enhanceCanvas(){
    var box=qs('.sheet-preview');if(!box||byId('dpvV140PreviewOpen'))return;
    var sh=qs('.subhead',box);if(sh){var wrap=document.createElement('span');wrap.className='dpv-v140-preview-actions';wrap.innerHTML='<button id="dpvV140PreviewOpen" type="button" class="button tiny">Mở lớn</button>';sh.appendChild(wrap);byId('dpvV140PreviewOpen').onclick=openPreview;}
    var o=document.createElement('div');o.id='dpvV140PreviewOverlay';o.className='dpv-v140-preview-overlay';o.innerHTML='<div class="dpv-v140-preview-window"><div class="dpv-v140-preview-head"><div><strong>Sơ đồ dàn · Preview lớn</strong><small id="dpvV140PreviewCaption">Bố cục hiện tại</small></div><div class="dpv-v140-preview-tools"><button id="dpvV140ZoomOut" class="button tiny">−</button><span id="dpvV140ZoomLabel">135%</span><button id="dpvV140ZoomIn" class="button tiny">+</button><button id="dpvV140RefreshPreview" class="button tiny">Làm mới</button><button id="dpvV140PreviewClose" class="button tiny">Đóng</button></div></div><div class="dpv-v140-preview-stage"><canvas id="dpvV140PreviewCanvas"></canvas></div></div>';
    document.body.appendChild(o);
    byId('dpvV140PreviewClose').onclick=closePreview;byId('dpvV140RefreshPreview').onclick=copyPreview;
    byId('dpvV140ZoomIn').onclick=function(){previewZoom=Math.min(2.5,previewZoom+.15);applyPreviewZoom();};
    byId('dpvV140ZoomOut').onclick=function(){previewZoom=Math.max(.55,previewZoom-.15);applyPreviewZoom();};
    o.onclick=function(ev){ev=ev||window.event;if((ev.target||ev.srcElement)===o)closePreview();};
  }

  function runtimeMs(){
    try{var t=window.performance&&performance.timing;if(t&&t.navigationStart){var e=t.domContentLoadedEventEnd||t.domInteractive||new Date().getTime();return Math.max(0,e-t.navigationStart);}}catch(e){}
    return 0;
  }
  function enhanceSystem(){
    var page=qs('[data-pro-page="system"]');if(!page||byId('dpvV140Runtime'))return;
    var grid=qs('.dpv-pro-grid',page);if(!grid)return;
    var card=document.createElement('div');card.id='dpvV140Runtime';card.className='dpv-pro-card dpv-v140-runtime-card';
    card.innerHTML='<h3>V140 Runtime</h3><p>Kiểm tra lớp giao diện mới. Chỉ đo frontend, không can thiệp Illustrator/Core.</p><div class="dpv-v140-runtime-grid"><div><span>CSS request</span><strong id="dpvV140CssCount">–</strong></div><div><span>JS request</span><strong id="dpvV140JsCount">–</strong></div><div><span>DOMContentLoaded</span><strong id="dpvV140Boot">–</strong></div><div><span>Job monitor</span><strong>EVENT</strong></div></div><p class="dpv-v140-runtime-note">Source lịch sử vẫn nằm trong package để debug; runtime chỉ nạp release bundle V140.</p>';
    grid.appendChild(card);
    var css=byId('dpvV140CssCount'),js=byId('dpvV140JsCount'),boot=byId('dpvV140Boot');
    if(css)setText(css,String(document.styleSheets?document.styleSheets.length:0));
    if(js)setText(js,String(qsa('script[src]').length));
    var ms=runtimeMs();if(boot)setText(boot,ms?ms+' ms':'N/A');
  }

  function bindEscape(){
    var old=document.onkeydown;document.onkeydown=function(e){e=e||window.event;if(e.keyCode===27){closePreview();}if(typeof old==='function')return old.call(document,e);};
  }
  function start(){add(document.body,'dpv-v140');updateVersionLabels();enhanceSettings();enhanceCanvas();setTimeout(enhanceSystem,100);bindEscape();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',function(){setTimeout(start,70);},false);else window.attachEvent('onload',function(){setTimeout(start,70);});}else setTimeout(start,70);
})();
