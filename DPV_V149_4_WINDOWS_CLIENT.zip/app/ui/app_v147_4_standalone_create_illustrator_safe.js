
(function(){
  'use strict';
  var pending=false;
  function $(id){return document.getElementById(id);}
  function status(msg,kind){
    var el=$('v1474StandaloneStatus');
    if(el){el.textContent=msg;el.className='v1474-status '+(kind||'');}
    try{ if(window.DPVVDP101&&window.DPVVDP101.status) window.DPVVDP101.status(msg,kind||''); }catch(e){}
  }
  function num(id,d){var e=$(id),v=Number(e&&e.value);return isNaN(v)?d:v;}
  function value(id,d){var e=$(id);return e?e.value:d;}
  function ensureExtra(){
    var card=$('v147QrStudioCard'); if(!card) return false;
    if(!$('v1474StandaloneStatus')){
      var box=document.createElement('div');box.id='v1474StandaloneStatus';box.className='v1474-status';box.textContent='V147.4: Standalone Bridge sẵn sàng.';
      var actions=card.querySelector('.v147-actions'); if(actions) actions.parentNode.insertBefore(box,actions.nextSibling); else card.appendChild(box);
    }
    if(!$('v1474SizeControls')){
      var grid=card.querySelector('.v147-grid');
      var x=document.createElement('div');x.id='v1474SizeControls';x.className='v1474-extra';
      x.innerHTML='<div class="v1474-extra-title">KÍCH THƯỚC KHI TẠO RA ARTBOARD</div><div class="v1474-extra-grid">'
        +'<label><span>Rộng mã (mm)</span><input id="v1474WidthMm" type="number" min="5" step="0.1" value="50"></label>'
        +'<label><span>Cao mã (mm)</span><input id="v1474HeightMm" type="number" min="5" step="0.1" value="20"></label>'
        +'<label><span>Số cột batch</span><input id="v1474Columns" type="number" min="1" step="1" value="4"></label>'
        +'<label><span>Gap batch (mm)</span><input id="v1474GapMm" type="number" min="0" step="0.1" value="5"></label>'
        +'</div><div class="v1474-extra-note">Nếu chọn <b>Vào đối tượng đang chọn</b>, kích thước mã lấy trực tiếp theo bounds của shape trong Illustrator. Các ô trên chỉ dùng khi chọn <b>Tạo ra giữa artboard</b>.</div>';
      if(grid&&grid.parentNode) grid.parentNode.insertBefore(x,grid.nextSibling); else card.appendChild(x);
    }
    return true;
  }
  function syncDefaults(){
    var t=value('v147CodeType','qr'),w=$('v1474WidthMm'),h=$('v1474HeightMm'); if(!w||!h)return;
    if(t==='qr'){ if(w.getAttribute('data-user')!=='1')w.value='30'; if(h.getAttribute('data-user')!=='1')h.value='30'; }
    else { if(w.getAttribute('data-user')!=='1')w.value='50'; if(h.getAttribute('data-user')!=='1')h.value='20'; }
  }
  function cfg(){
    var mode=value('v147CreateMode','single'),raw= mode==='batch'?value('v147BatchContent',''):value('v147SingleContent',''),vals;
    if(mode==='batch') vals=String(raw||'').split(/\r?\n/).map(function(s){return s.replace(/^\s+|\s+$/g,'');}).filter(function(s){return !!s;});
    else vals=[String(raw||'').replace(/^\s+|\s+$/g,'')].filter(function(s){return !!s;});
    return {standaloneV1474:true,codeType:value('v147CodeType','qr'),targetMode:value('v147TargetMode','selection'),values:vals,
      fontName:value('v147FontName','Arial'),fontSize:num('v147FontSize',9),showText:Number(value('v147ShowText','1')),
      textMode:value('v147TextMode','outline'),fontWeight:'regular',tracking:0,textGapMm:1.2,barHeightPercent:100,barWidthPercent:100,quietZone:10,
      widthMm:num('v1474WidthMm',50),heightMm:num('v1474HeightMm',20),columns:num('v1474Columns',4),gapMm:num('v1474GapMm',5)};
  }
  function send(preview){
    var c=cfg(); if(!c.values.length){status('Chưa nhập nội dung QR/Barcode.','error');return;}
    if(!window.DPVVDP101||typeof window.DPVVDP101.bridgeCall!=='function'){status('Bridge Illustrator chưa sẵn sàng.','error');return;}
    pending=true;status((preview?'Đang Preview':'Đang tạo')+' '+c.values.length+' mã trong Illustrator…','work');
    try{window.DPVVDP101.bridgeCall('PreviewVariableData',[JSON.stringify(c)]);}catch(e){pending=false;status('Không gửi được lệnh: '+(e.message||String(e)),'error');}
  }
  function bind(){
    if(!ensureExtra())return false;
    var p=$('v147PreviewAiBtn'),c=$('v147CreateBtn'),b=$('v147BatchBtn'),t=$('v147CodeType');
    if(p&&!p.__v1474){p.__v1474=true;p.onclick=function(e){if(e)e.preventDefault();send(true);return false;};}
    if(c&&!c.__v1474){c.__v1474=true;c.onclick=function(e){if(e)e.preventDefault();send(false);return false;};}
    if(b&&!b.__v1474){b.__v1474=true;b.onclick=function(e){if(e)e.preventDefault();var m=$('v147CreateMode');if(m)m.value='batch';send(false);return false;};}
    if(t&&!t.__v1474){t.__v1474=true;t.addEventListener('change',syncDefaults,false);syncDefaults();}
    ['v1474WidthMm','v1474HeightMm'].forEach(function(id){var e=$(id);if(e&&!e.__v1474){e.__v1474=true;e.addEventListener('input',function(){this.setAttribute('data-user','1');},false);}});
    return true;
  }
  function wrapReceive(){
    if(window.__V1474ReceiveWrapped||typeof window.VDPRO_receive!=='function')return false;
    window.__V1474ReceiveWrapped=true;var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){
      if(op==='vdpPreview'&&pending){
        var r={};try{r=JSON.parse(String(payload||'{}'));}catch(e){}
        if(r&&r.standaloneV1474){pending=false;if(r.ok===false)status('Standalone lỗi: '+String(r.error||'Không rõ lỗi Illustrator.'),'error');else status('Đã tạo '+String(r.created||0)+' mã '+String(r.codeType||'')+' trong Illustrator · '+String(r.documentName||''),'ok');return;}
      }
      return old.apply(window,arguments);
    };return true;
  }
  var n=0,iv=setInterval(function(){n++;bind();wrapReceive();if(n>100)clearInterval(iv);},350);
  document.addEventListener('click',function(){setTimeout(function(){bind();wrapReceive();},20);},false);
})();
