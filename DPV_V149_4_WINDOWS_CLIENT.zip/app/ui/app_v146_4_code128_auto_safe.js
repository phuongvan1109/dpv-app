
(function(){
  function tick(){
    var boxes = document.querySelectorAll('*');
    var done = false;
    for(var i=0;i<boxes.length;i++){
      var el = boxes[i];
      if(el && el.textContent && /Code 128/.test(el.textContent) && !el.getAttribute('data-v1464-auto')){
        el.setAttribute('data-v1464-auto','1');
        var note = document.createElement('div');
        note.style.marginTop='8px';
        note.style.padding='8px 10px';
        note.style.border='1px solid #cfe4da';
        note.style.borderRadius='10px';
        note.style.background='#f7fffb';
        note.style.fontSize='12px';
        note.style.color='#355a50';
        note.innerHTML='<b>V146.4 SAFE · Code128 AUTO A/B/C</b><br>Chuỗi số chẵn dài sẽ tự tối ưu sang <b>Code128-C</b>. Chuỗi chữ/số hỗn hợp sẽ tự đi <b>B/C</b> gần kiểu Barcode Studio.';
        el.appendChild(note);
        done = true;
      }
    }
    return done;
  }
  var t=0, iv=setInterval(function(){ t++; if(tick()||t>40) clearInterval(iv); }, 600);
})();
