/* DPV V148.4 MULTI ARTBOARD CACHE HARDENED — visible release marker only. */
(function(){
  function apply(){
    try { document.title='DPV® V148.4 — Multi Artboard Cache Hardened · Core V101 Stable'; } catch(e){}
    try { var v=document.querySelector?document.querySelector('.version-badge'):null; if(v){v.innerHTML='V148.4 MULTI ARTBOARD CACHE HARDENED · CORE V101 STABLE';} } catch(e2){}
  }
  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',apply);}else{apply();}
})();
