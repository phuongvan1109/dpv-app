(function(){
  function q(s){try{return document.querySelector(s);}catch(e){return null;}}
  function mark(){
    var v=q('.version-badge');
    if(v)v.innerHTML='V136 FONT FIDELITY · CORE V101 STABLE';
    var b=q('.beta-note');
    if(b)b.innerHTML='<strong>DPV® V136 Font Fidelity</strong><br>VDP Text/Number Sequence giữ nguyên font, style, size, leading, tracking và paragraph alignment của TextFrame layout khi Preview/Xuất PDF/VDP Sheet.';
  }
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);
    else window.attachEvent('onload',mark);
  }else mark();
})();
