(function(){
  "use strict";
  var cfg=window.DPV_AUTH_CONFIG||{};
  var server=String(cfg.serverUrl||"").replace(/\/$/,"");
  var current=String(cfg.appVersion||"V148.5");
  var dismissed=false,lastInfo=null,lastState="idle";
  function parse(s){try{return JSON.parse(String(s||"{}"));}catch(e){return {ok:false,error:"Phản hồi cập nhật không hợp lệ."};}}
  function q(id){return document.getElementById(id);}
  function qs(sel){return document.querySelector?document.querySelector(sel):null;}
  function qp(name){var a=String(location.search||"").replace(/^\?/,"").split("&"),i,p;for(i=0;i<a.length;i++){p=a[i].split("=");if(decodeURIComponent(p[0]||"")===name)return decodeURIComponent(p.slice(1).join("=")||"");}return "";}
  function platform(){var p=qp("dpvPlatform");if(p)return p;try{if(window.external&&typeof window.external.GetDpvAuthDeviceInfo!=="undefined"){var r=parse(window.external.GetDpvAuthDeviceInfo());if(r&&r.platform)return String(r.platform);}}catch(e){}var n=String(navigator.platform||"").toLowerCase();return n.indexOf("mac")>=0?"mac-intel":"windows-x64";}
  function setBadge(state,latest){
    lastState=state||"idle";
    var b=qs('.version-badge');if(!b)return;
    b.style.display='inline-flex';b.style.alignItems='center';b.style.gap='5px';b.style.cursor='pointer';b.style.whiteSpace='nowrap';
    b.title='Phiên bản hiện tại: '+current+' · Bấm để kiểm tra cập nhật';
    if(state==='available'){b.innerHTML=current+' · <strong>CÓ '+String(latest||'BẢN MỚI')+'</strong>';b.style.background='#fff0c2';b.style.borderColor='#efbd3c';b.style.color='#7a4b00';}
    else if(state==='latest'){b.innerHTML=current+' · <strong>MỚI NHẤT</strong>';b.style.background='#eafaf5';b.style.borderColor='#9edfc9';b.style.color='#08755d';}
    else if(state==='checking'){b.innerHTML=current+' · Đang kiểm tra…';b.style.background='#eef4ff';b.style.borderColor='#b9c9eb';b.style.color='#36557e';}
    else if(state==='offline'){b.innerHTML=current+' · Cập nhật';b.style.background='#f4f5f7';b.style.borderColor='#d6dae1';b.style.color='#596273';}
    else {b.innerHTML=current+' · Kiểm tra cập nhật';}
    b.onclick=function(){check(true);};
  }
  function request(done){
    if(!server||server.indexOf('YOUR-WORKER')>=0){done({ok:false,error:'Chưa cấu hình Update Server.'});return;}
    var path='/api/auth/update?platform='+encodeURIComponent(platform())+'&current='+encodeURIComponent(current);
    try{if(window.external&&typeof window.external.DpvAuthRequest!=="undefined"){done(parse(window.external.DpvAuthRequest(JSON.stringify({serverUrl:server,method:'GET',path:path,body:{},token:''}))));return;}}catch(e){done({ok:false,error:String(e.message||e)});return;}
    var x=new XMLHttpRequest();try{x.open('GET',server+path,true);}catch(e2){done({ok:false,error:e2.message});return;}x.onreadystatechange=function(){if(x.readyState===4)done(parse(x.responseText));};x.onerror=function(){done({ok:false,error:'Không kiểm tra được cập nhật.'});};x.send();
  }
  function injectCss(){if(q('dpvUpdateStyle'))return;var s=document.createElement('style');s.id='dpvUpdateStyle';s.textContent='#dpvUpdateOverlay{position:fixed;inset:0;background:rgba(13,18,28,.68);z-index:2147483000;display:flex;align-items:center;justify-content:center;padding:24px;font-family:Arial,sans-serif}#dpvUpdateOverlay.hidden{display:none}#dpvUpdateCard{width:min(540px,94vw);background:#fff;border-radius:22px;padding:24px;box-shadow:0 28px 80px #0007;color:#182131}#dpvUpdateCard h2{margin:0 0 6px;font-size:22px}#dpvUpdateCurrent{font-size:13px;color:#667085;margin-top:7px}#dpvUpdateVersion{font-weight:800;color:#0a8d71;margin:5px 0 12px;font-size:17px}#dpvUpdateNotes{white-space:pre-wrap;background:#f5f7fb;border-radius:12px;padding:12px;max-height:220px;overflow:auto;line-height:1.45}#dpvUpdateActions{display:flex;gap:10px;justify-content:flex-end;margin-top:18px}#dpvUpdateActions button{border:0;border-radius:10px;padding:10px 16px;font-weight:800;cursor:pointer}#dpvUpdateLater{background:#edf1f6;color:#243044}#dpvUpdateNow{background:#0aa37f;color:#fff}#dpvUpdateMsg{font-size:13px;margin-top:10px;color:#667085}.dpv-update-mandatory{color:#b42318;font-weight:800}';document.head.appendChild(s);}
  function ensureUi(){injectCss();var ov=q('dpvUpdateOverlay');if(ov)return ov;ov=document.createElement('div');ov.id='dpvUpdateOverlay';ov.className='hidden';ov.innerHTML='<div id="dpvUpdateCard"><h2>Có phiên bản DPV mới</h2><div id="dpvUpdateCurrent"></div><div id="dpvUpdateVersion"></div><div id="dpvUpdateMandatory"></div><div id="dpvUpdateNotes"></div><div id="dpvUpdateMsg"></div><div id="dpvUpdateActions"><button id="dpvUpdateLater" type="button">Để sau</button><button id="dpvUpdateNow" type="button">Cập nhật ngay</button></div></div>';document.body.appendChild(ov);q('dpvUpdateLater').onclick=function(){dismissed=true;ov.className='hidden';};q('dpvUpdateNow').onclick=runUpdate;return ov;}
  function show(info){lastInfo=info;setBadge('available',info.latestVersion);var ov=ensureUi();q('dpvUpdateCurrent').innerText='Phiên bản hiện tại: '+current;q('dpvUpdateVersion').innerText='Cập nhật lên: '+String(info.latestVersion||'');q('dpvUpdateNotes').innerText=String(info.notes||'Bản cập nhật DPV mới đã sẵn sàng.');q('dpvUpdateMandatory').innerHTML=info.mandatory?'<span class="dpv-update-mandatory">Bản cập nhật bắt buộc để tiếp tục sử dụng.</span>':'';q('dpvUpdateLater').style.display=info.mandatory?'none':'inline-block';q('dpvUpdateMsg').innerText='';ov.className='';}
  function openExternal(url){try{if(window.external&&typeof window.external.OpenExternalUrl!=="undefined"){window.external.OpenExternalUrl(url);return true;}}catch(e){}try{var w=window.open(url,'_blank');if(w)return true;}catch(e2){}return false;}
  function runUpdate(){var i=lastInfo||{};if(!i.downloadUrl){q('dpvUpdateMsg').innerText='Chủ app chưa gắn link tải cho phiên bản này.';return;}q('dpvUpdateNow').disabled=true;q('dpvUpdateMsg').innerText='Đang chuẩn bị cập nhật '+current+' → '+String(i.latestVersion||'bản mới')+'…';
    try{if(window.external&&typeof window.external.StartDpvAutoUpdate!=="undefined"){var r=parse(window.external.StartDpvAutoUpdate(String(i.downloadUrl),String(i.sha256||'')));if(r.ok){q('dpvUpdateMsg').innerText=r.message||'Đang tải bản cập nhật. DPV sẽ tự đóng và mở trình cài đặt.';return;}q('dpvUpdateMsg').innerText=r.error||'Không bắt đầu được Auto Update.';q('dpvUpdateNow').disabled=false;return;}}catch(e){q('dpvUpdateMsg').innerText=String(e.message||e);q('dpvUpdateNow').disabled=false;return;}
    if(openExternal(String(i.downloadUrl))){q('dpvUpdateMsg').innerText='Đã mở bộ cài '+String(i.latestVersion||'mới')+'. Sau khi tải xong chỉ cần chạy bộ cài; không cần cấu hình lại tài khoản.';}else{q('dpvUpdateMsg').innerText='Không mở được link cập nhật.';}q('dpvUpdateNow').disabled=false;
  }
  function check(force){if(dismissed&&!force)return;if(force)setBadge('checking');request(function(r){if(r&&r.ok){if(r.updateAvailable){setBadge('available',r.latestVersion);if(force||!dismissed)show(r);}else{setBadge('latest');if(force){var ov=q('dpvUpdateOverlay');if(ov)ov.className='hidden';}}}else{setBadge('offline');}});}
  function start(){setBadge('idle');window.setTimeout(function(){check(false);},1700);window.setInterval(function(){check(false);},6*60*60*1000);}
  window.DPVAutoUpdate={check:function(){check(true);},version:current,state:function(){return lastState;}};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
