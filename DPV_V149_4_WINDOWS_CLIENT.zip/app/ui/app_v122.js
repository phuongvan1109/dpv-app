(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function status(msg,kind){
    if(window.DPVVDP101&&typeof window.DPVVDP101.status==='function')window.DPVVDP101.status(msg,kind||'');
  }
  function getCore(){
    if(!window.DPVCoreV101||typeof window.DPVCoreV101.getConfig!=='function')throw new Error('Core V101 chưa sẵn sàng.');
    var c=window.DPVCoreV101.getConfig();
    var l=c&&(c.precomputedLayoutV101||c.precomputedLayoutV99);
    if(!l||!l.items||!l.items.length)throw new Error('Chưa có bố cục V101. Đóng VDP → Tính nhanh trên DPV → mở VDP lại.');
    return {config:c,layout:l};
  }
  function getState(){
    if(!window.DPVVDP101||typeof window.DPVVDP101.getState!=='function')throw new Error('VDP Core chưa sẵn sàng.');
    return window.DPVVDP101.getState();
  }
  function build(){
    var btn=$('vdpSheetBuildBtn');
    try{
      var st=getState();
      if(!st.filePath&&!(window.DPVVDP101&&window.DPVVDP101.getRecords&&window.DPVVDP101.getRecords().length))throw new Error('Chưa có dữ liệu CSV/TXT hoặc Dãy số tự động.');
      if(!(Number(st.recordCount)>0))throw new Error('Dữ liệu không có record.');
      if(!st.mappings||!st.mappings.length)throw new Error('Chưa map dữ liệu vào đối tượng Illustrator.');
      var out=$('vdpOutputPath')?$('vdpOutputPath').value:'';
      if(!out)throw new Error('Chưa chọn thư mục xuất PDF.');
      var x=getCore();
      var from=Math.max(1,Math.floor(Number($('vdpFrom').value)||1));
      var to=Math.min(Number(st.recordCount),Math.max(from,Math.floor(Number($('vdpTo').value)||Number(st.recordCount))));
      var sc={
        paperW:Number(x.config.paperW),paperH:Number(x.config.paperH),margin:Number(x.config.margin),header:Number(x.config.header),
        addTitle:x.config.addTitle===true,ponPath:String(x.config.ponPath||''),fitPon:x.config.fitPon===true,autoPon:x.config.autoPon===true,
        ponProcessBlack:x.config.ponProcessBlack===true,cornerPonRed:x.config.cornerPonRed===true
      };
      if($('vdpSheetUsePon')&&!$('vdpSheetUsePon').checked){sc.ponPath='';sc.autoPon=false;sc.addTitle=false;}
      var cfg={
        dataPath:st.filePath,records:st.filePath?[]:((window.DPVVDP101&&window.DPVVDP101.getRecords)?window.DPVVDP101.getRecords():[]),mappings:st.mappings,sourceFolder:st.sourceFolder,outputPath:out,from:from,to:to,
        fileNameField:$('vdpFileNameField').value,filePrefix:$('vdpFilePrefix').value||'VDP',
        exportIndividual:$('vdpSheetKeepRecords').checked===true,combinePdf:false,sheetMode:true,sheetLayout:x.layout,sheetConfig:sc,
        sheetOrder:$('vdpSheetOrder').value,lastSheetMode:$('vdpLastSheetMode').value,keepRecordPdfs:$('vdpSheetKeepRecords').checked===true,
        combineSheets:$('vdpSheetCombine').checked===true,sheetPrefix:$('vdpSheetPrefix').value||'VDP_SHEET',
        sheetCombinedName:$('vdpSheetCombinedName').value||'VDP_ALL_SHEETS'
      };
      if(btn){btn.disabled=true;btn.setAttribute('data-v122-running','1');}
      status('V122: Đang gửi '+(to-from+1)+' record sang Illustrator · '+x.layout.items.length+' con/tờ…','work');
      if(!window.DPVVDP101||typeof window.DPVVDP101.bridgeCall!=='function')throw new Error('Windows Bridge chưa sẵn sàng.');
      window.DPVVDP101.bridgeCall('BuildVariableData',[JSON.stringify(cfg)]);
    }catch(e){
      if(btn){btn.disabled=false;btn.removeAttribute('data-v122-running');}
      status('Không chạy được VDP Sheet: '+(e&&e.message?e.message:String(e)),'error');
    }
    return false;
  }
  function bind(){
    var b=$('vdpSheetBuildBtn');
    if(!b)return false;
    b.onclick=build;
    b.setAttribute('data-v122-bound','1');
    return true;
  }
  function wrapReceive(){
    if(window.__V122ReceiveWrapped||typeof window.VDPRO_receive!=='function')return;
    window.__V122ReceiveWrapped=true;
    var old=window.VDPRO_receive;
    window.VDPRO_receive=function(op,payload){
      old(op,payload);
      try{
        var r=JSON.parse(String(payload||'{}'));
        var b=$('vdpSheetBuildBtn');
        if(op==='vdpBuildProgress'&&r.sheetMode){
          status('VDP Sheet · record '+r.current+'/'+r.total+(r.sheetCreated?' · đã xuất tờ '+r.sheetDone+'/'+r.sheetTotal:''),'work');
        }
        if(op==='vdpBuild'){
          if(b){b.disabled=false;b.removeAttribute('data-v122-running');}
          if(!r.ok)status('VDP Sheet lỗi: '+String(r.error||r.message||'Không rõ lỗi Illustrator.'),'error');
          else if(r.sheetMode){
            var m='Hoàn tất: '+String(r.count||0)+' record → '+String(r.sheetCount||0)+' tờ.';
            if(r.sheetCombinedFile)m+=' PDF gộp: '+r.sheetCombinedFile;
            status(m,'ok');
          }
        }
      }catch(e){}
    };
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;
    if(v)v.innerHTML='V122 VDP SHEET BUTTON FIX · CORE V101 STABLE';
  }
  function start(){
    mark();wrapReceive();
    var n=0,t=setInterval(function(){n++;bind();wrapReceive();if(n>20)clearInterval(t);},150);
    setTimeout(function(){if(bind())status('VDP Sheet V122 sẵn sàng. Nút Dàn & xuất đã được gắn handler ổn định.','ok');},450);
  }
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);
  }else start();
})();
