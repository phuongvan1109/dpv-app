(function(){
  function byId(id){return document.getElementById(id);}
  function add(el,c){if(!el)return;if((' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(!el)return;el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function txt(el){return el?(el.textContent||el.innerText||''):'';}
  function raf(fn){return (window.requestAnimationFrame||function(cb){return setTimeout(cb,16);})(fn);}
  function boot(){
    add(document.body,'dpv-motion-boot');
    setTimeout(function(){rem(document.body,'dpv-motion-boot');add(document.body,'dpv-motion-ready');},45);
    setTimeout(function(){add(document.body,'dpv-motion-settled');},700);
  }
  function ripple(el,e){
    if(!el||el.disabled)return;
    var r=el.getBoundingClientRect?el.getBoundingClientRect():null;if(!r)return;
    var s=Math.max(r.width,r.height)*2.1,sp=document.createElement('span');sp.className='dpv-ripple';
    var x=(e&&e.clientX?e.clientX:r.left+r.width/2)-r.left-s/2;
    var y=(e&&e.clientY?e.clientY:r.top+r.height/2)-r.top-s/2;
    sp.style.width=s+'px';sp.style.height=s+'px';sp.style.left=x+'px';sp.style.top=y+'px';el.appendChild(sp);
    setTimeout(function(){try{if(sp.parentNode)sp.parentNode.removeChild(sp);}catch(x){}},650);
  }
  function bindButtons(){
    if(!document.addEventListener)return;
    document.addEventListener('mousedown',function(e){
      e=e||window.event;var t=e.target||e.srcElement;
      while(t&&t!==document.body&&(' '+(t.className||'')+' ').indexOf(' button ')<0&&(' '+(t.className||'')+' ').indexOf(' icon-button ')<0&&(' '+(t.className||'')+' ').indexOf(' layout-tool ')<0)t=t.parentNode;
      if(!t||t===document.body)return;add(t,'dpv-pressing');ripple(t,e);setTimeout(function(){rem(t,'dpv-pressing');},180);
    },false);
    document.addEventListener('mouseup',function(){var a=document.querySelectorAll?document.querySelectorAll('.dpv-pressing'):[],i;for(i=0;i<a.length;i++)rem(a[i],'dpv-pressing');},false);
  }
  function bindThemeMotion(){
    var sw=byId('dpvThemeSwitch'),st=byId('dpvSettingsTheme');
    function pre(){add(document.body,'dpv-theme-anim');setTimeout(function(){rem(document.body,'dpv-theme-anim');},430);}
    if(sw&&sw.addEventListener)sw.addEventListener('click',pre,true);
    if(st&&st.addEventListener)st.addEventListener('click',pre,true);
  }
  function bindNavMotion(){
    var ns=document.querySelectorAll?document.querySelectorAll('.dpv-nav-btn'):[],i;
    function pulse(){add(document.body,'dpv-nav-transition');setTimeout(function(){rem(document.body,'dpv-nav-transition');},320);}
    for(i=0;i<ns.length;i++){if(ns[i].addEventListener)ns[i].addEventListener('click',pulse,true);}
  }
  function pop(el){if(!el)return;rem(el,'dpv-number-pop');void el.offsetWidth;add(el,'dpv-number-pop');setTimeout(function(){rem(el,'dpv-number-pop');},430);}
  function watchNumbers(){
    var ids=['previewCount','dpvKpiCount','efficiency','dpvKpiEff'],i;
    if(window.MutationObserver){
      for(i=0;i<ids.length;i++)(function(el){if(!el)return;var old=txt(el);new MutationObserver(function(){var n=txt(el);if(n!==old){old=n;pop(el);}}).observe(el,{childList:true,subtree:true,characterData:true});})(byId(ids[i]));
    }
  }
  function markVersion(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)v.innerHTML='V104 FLUID MOTION · CORE V101 STABLE';
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V104 FLUID MOTION UI · CORE V101 STABLE</strong><br>Motion layer mượt · Light/Dark chuyển cảnh mềm · hover/press/ripple · preview tương tác · không sửa engine dàn V101.';
    var chips=document.querySelectorAll?document.querySelectorAll('.dpv-chip'):[],i;for(i=0;i<chips.length;i++){if(txt(chips[i]).indexOf('UI:')===0)chips[i].innerHTML='UI: V104 FLUID MOTION';}
    var s=document.querySelector?document.querySelector('#dpvSettings .dpv-settings-row:last-child strong'):null;if(s)s.innerHTML='V104 FLUID MOTION';var sc=document.querySelector?document.querySelector('.dpv-side-card'):null;if(sc)sc.innerHTML='<strong><span class="dpv-side-dot"></span>Core V101 STABLE</strong>Engine dàn được khóa ổn định.<br>V104 chỉ nâng cấp chuyển động giao diện.';
  }
  function start(){boot();bindButtons();bindThemeMotion();bindNavMotion();watchNumbers();markVersion();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();
