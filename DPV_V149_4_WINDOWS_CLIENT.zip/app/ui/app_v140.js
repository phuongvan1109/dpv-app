(function(){
  "use strict";
  var VERSION='V140 PERFORMANCE FOUNDATION';
  var STORE_ADV='dpv.ui.advanced.v140';
  var previewZoom=1;

  function byId(id){return document.getElementById(id);}
  function qs(s,root){return (root||document).querySelector?(root||document).querySelector(s):null;}
  function qsa(s,root){return (root||document).querySelectorAll?(root||document).querySelectorAll(s):[];}
  function add(el,c){if(!el)return;if((' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function rem(el,c){if(!el)return;el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function storeGet(k,d){try{var v=window.localStorage?localStorage.getItem(k):null;return v==null?d:JSON.parse(v);}catch(e){return d;}}
  function storeSet(k,v){try{if(window.localStorage)localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
  function text(el){return el?(el.textContent||el.innerText||''):'';}
  function setText(el,s){if(!el)return;if('textContent' in el)el.textContent=s;else el.innerText=s;}

  function updateVersionLabels(){
    var v=qs('.version-badge');if(v)v.innerHTML='V140 PERFORMANCE · CORE V101 STABLE';
    var b=qs('.beta-note');if(b)b.innerHTML='<strong>DPV® V140 Performance Foundation · Core V101 Stable</strong><br>Release Bundle · Event-driven Job Monitor · UI typography mới · Advanced compact · Preview phóng lớn. Không thay engine dàn, VDP, PON, Duplex hay Bridge Illustrator.';
    var side=qs('.dpv-side-card');if(side)side.innerHTML='<strong><span class="dpv-side-dot"></span>Core V101 STABLE</strong>Engine sản xuất giữ nguyên.<br>V140 tối ưu runtime + giao diện.';
  }

  function setAdvancedVisible(on){
    var col=qs('.settings-column');if(!col)return;
    if(on)rem(col,'dpv-v140-compact');else add(col,'dpv-v140-compact');
    var b=byId('dpvAdvancedToggle');if(b){b.setAttribute('aria-expanded',on?'true':'false');b.innerHTML=on?'Thu gọn nâng cao':'Nâng cao <span>9</span>';}
    storeSet(STORE_ADV,!!on);
  }
  function enhanceSettings(){
    var col=qs('.settings-column');if(!col||byId('dpvAdvancedToggle'))return;
    var ids=['specialStagger','fastMode','addTitle','cornerSafe','demiMode','preservePrintColor'];
    var i,e,p;
    for(i=0;i<ids.length;i++){e=byId(ids[i]);if(e&&e.parentNode){p=e.parentNode;add(p,'dpv-v140-advanced');}}
    var grids=qsa('.form-grid.compact',col);if(grids.length)add(grids[0],'dpv-v140-advanced-grid');
    var title=qs('.panel-title',col);if(title){
      var b=document.createElement('button');b.id='dpvAdvancedToggle';b.className='dpv-v140-advanced-toggle';b.type='button';b.innerHTML='Nâng cao <span>9</span>';
      b.onclick=function(){setAdvancedVisible((' '+col.className+' ').indexOf(' dpv-v140-compact ')>=0);};title.appendChild(b);
    }
    setAdvancedVisible(storeGet(STORE_ADV,false)===true);
  }

  function copyPreview(){
    var src=byId('layoutCanvas'),dst=byId('dpvV140PreviewCanvas');if(!src||!dst)return;
    try{dst.width=src.width;dst.height=src.height;var c=dst.getContext('2d');c.clearRect(0,0,dst.width,dst.height);c.drawImage(src,0,0);applyPreviewZoom();}catch(e){}
    var cap=byId('dpvV140PreviewCaption'),old=byId('layoutCaption');if(cap&&old)setText(cap,text(old));
  }
  function applyPreviewZoom(){var c=byId('dpvV140PreviewCanvas');if(!c)return;c.style.width=Math.round(c.width*previewZoom)+'px';c.style.height=Math.round(c.height*previewZoom)+'px';var z=byId('dpvV140ZoomLabel');if(z)setText(z,Math.round(previewZoom*100)+'%');}
  function openPreview(){var o=byId('dpvV140PreviewOverlay');if(!o)return;previewZoom=1.35;copyPreview();add(o,'open');}
  function closePreview(){rem(byId('dpvV140PreviewOverlay'),'open');}
  function enhanceCanvas(){
    var box=qs('.sheet-preview');if(!box||byId('dpvV140PreviewOpen'))return;
    var sh=qs('.subhead',box);if(sh){var wrap=document.createElement('span');wrap.className='dpv-v140-preview-actions';wrap.innerHTML='<button id="dpvV140PreviewOpen" type="button" class="button tiny">Mở lớn</button>';sh.appendChild(wrap);byId('dpvV140PreviewOpen').onclick=openPreview;}
    var o=document.createElement('div');o.id='dpvV140PreviewOverlay';o.className='dpv-v140-preview-overlay';o.innerHTML='<div class="dpv-v140-preview-window"><div class="dpv-v140-preview-head"><div><strong>Sơ đồ dàn · Preview lớn</strong><small id="dpvV140PreviewCaption">Bố cục hiện tại</small></div><div class="dpv-v140-preview-tools"><button id="dpvV140ZoomOut" class="button tiny">−</button><span id="dpvV140ZoomLabel">135%</span><button id="dpvV140ZoomIn" class="button tiny">+</button><button id="dpvV140RefreshPreview" class="button tiny">Làm mới</button><button id="dpvV140PreviewClose" class="button tiny">Đóng</button></div></div><div class="dpv-v140-preview-stage"><canvas id="dpvV140PreviewCanvas"></canvas></div></div>';
    document.body.appendChild(o);
    byId('dpvV140PreviewClose').onclick=closePreview;byId('dpvV140RefreshPreview').onclick=copyPreview;
    byId('dpvV140ZoomIn').onclick=function(){previewZoom=Math.min(2.5,previewZoom+.15);applyPreviewZoom();};
    byId('dpvV140ZoomOut').onclick=function(){previewZoom=Math.max(.55,previewZoom-.15);applyPreviewZoom();};
    o.onclick=function(ev){ev=ev||window.event;if((ev.target||ev.srcElement)===o)closePreview();};
  }

  function runtimeMs(){
    try{var t=window.performance&&performance.timing;if(t&&t.navigationStart){var e=t.domContentLoadedEventEnd||t.domInteractive||new Date().getTime();return Math.max(0,e-t.navigationStart);}}catch(e){}
    return 0;
  }
  function enhanceSystem(){
    var page=qs('[data-pro-page="system"]');if(!page||byId('dpvV140Runtime'))return;
    var grid=qs('.dpv-pro-grid',page);if(!grid)return;
    var card=document.createElement('div');card.id='dpvV140Runtime';card.className='dpv-pro-card dpv-v140-runtime-card';
    card.innerHTML='<h3>V140 Runtime</h3><p>Kiểm tra lớp giao diện mới. Chỉ đo frontend, không can thiệp Illustrator/Core.</p><div class="dpv-v140-runtime-grid"><div><span>CSS request</span><strong id="dpvV140CssCount">–</strong></div><div><span>JS request</span><strong id="dpvV140JsCount">–</strong></div><div><span>DOMContentLoaded</span><strong id="dpvV140Boot">–</strong></div><div><span>Job monitor</span><strong>EVENT</strong></div></div><p class="dpv-v140-runtime-note">Source lịch sử vẫn nằm trong package để debug; runtime chỉ nạp release bundle V140.</p>';
    grid.appendChild(card);
    var css=byId('dpvV140CssCount'),js=byId('dpvV140JsCount'),boot=byId('dpvV140Boot');
    if(css)setText(css,String(document.styleSheets?document.styleSheets.length:0));
    if(js)setText(js,String(qsa('script[src]').length));
    var ms=runtimeMs();if(boot)setText(boot,ms?ms+' ms':'N/A');
  }

  function bindEscape(){
    var old=document.onkeydown;document.onkeydown=function(e){e=e||window.event;if(e.keyCode===27){closePreview();}if(typeof old==='function')return old.call(document,e);};
  }
  function start(){add(document.body,'dpv-v140');updateVersionLabels();enhanceSettings();enhanceCanvas();setTimeout(enhanceSystem,100);bindEscape();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',function(){setTimeout(start,70);},false);else window.attachEvent('onload',function(){setTimeout(start,70);});}else setTimeout(start,70);
})();
