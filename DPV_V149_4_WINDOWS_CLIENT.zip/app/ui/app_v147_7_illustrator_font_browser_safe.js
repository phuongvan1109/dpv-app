
/* DPV V147.7 ILLUSTRATOR-STYLE FONT BROWSER SAFE
   UI-only. Uses the font list already synchronized from Illustrator V147.5.
   Selected font is written back to v1475FontSelect (PostScript name), so barcode engine remains unchanged.
*/
(function(){
  'use strict';
  var master=[], families=[], browser=null, query='', selectedPS='', openedFamily='';
  function $(id){return document.getElementById(id);} 
  function txt(v){return String(v==null?'':v);} 
  function low(v){return txt(v).toLowerCase();}
  function esc(s){return txt(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function cssFont(family){return '"'+txt(family).replace(/"/g,'\\"')+'", sans-serif';}
  function dispatch(el,name){try{var e=document.createEvent('HTMLEvents');e.initEvent(name,true,false);el.dispatchEvent(e);}catch(x){try{if(el.fireEvent)el.fireEvent('on'+name);}catch(y){}}}
  function snapshot(){
    var sel=$('v1475FontSelect'),i,o,a=[],seen={};
    if(!sel||sel.options.length<3)return false;
    for(i=1;i<sel.options.length;i++){
      o=sel.options[i];
      var ps=txt(o.value),fam=txt(o.getAttribute('data-family')||o.text||ps),sty=txt(o.getAttribute('data-style')||'Regular');
      if(!ps||seen[ps])continue;seen[ps]=1;
      a.push({name:ps,family:fam,style:sty,search:low(fam+' '+sty+' '+ps)});
    }
    if(a.length>master.length){master=a;group();return true;}
    return master.length>0;
  }
  function group(){
    var map={},order=[],i,f,k;
    for(i=0;i<master.length;i++){
      f=master[i];k=low(f.family);
      if(!map[k]){map[k]={family:f.family,styles:[]};order.push(k);}
      map[k].styles.push(f);
    }
    order.sort(function(a,b){var aa=low(map[a].family),bb=low(map[b].family);return aa<bb?-1:aa>bb?1:0;});
    families=[];
    for(i=0;i<order.length;i++){
      var g=map[order[i]];
      g.styles.sort(function(a,b){var aa=low(a.style),bb=low(b.style);return aa<bb?-1:aa>bb?1:0;});
      families.push(g);
    }
  }
  function selectPS(ps,family,style){
    var sel=$('v1475FontSelect'),i,found=false;
    if(!sel)return;
    for(i=1;i<sel.options.length;i++){
      if(txt(sel.options[i].value)===ps){sel.selectedIndex=i;found=true;break;}
    }
    if(!found){
      var o=document.createElement('option');o.value=ps;o.text=family+(style?' · '+style:'');o.setAttribute('data-family',family);o.setAttribute('data-style',style||'');sel.add(o);sel.selectedIndex=sel.options.length-1;
    }
    selectedPS=ps;openedFamily=family;dispatch(sel,'change');
    var search=$('v1475FontSearch');if(search)search.value=family;
    render();
  }
  function familyMatches(g,q){
    if(!q)return true;
    if(low(g.family).indexOf(q)>=0)return true;
    for(var i=0;i<g.styles.length;i++)if(g.styles[i].search.indexOf(q)>=0)return true;
    return false;
  }
  function render(){
    if(!browser)return;
    var list=browser.querySelector('.v1477-list'),cnt=browser.querySelector('.v1477-count'),selected=browser.querySelector('.v1477-selectedbar'),q=low(query).replace(/^\s+|\s+$/g,''),html='',shown=0,i,j,g,f,open;
    for(i=0;i<families.length;i++){
      g=families[i];if(!familyMatches(g,q))continue;shown++;open=(openedFamily===g.family)||(q&&low(g.family).indexOf(q)>=0);
      html+='<div class="v1477-family'+(open?' open':'')+(selectedPS&&g.styles.some(function(x){return x.name===selectedPS;})?' selected':'')+'" data-family="'+esc(g.family)+'">';
      html+='<div class="v1477-family-head"><div class="v1477-arrow">'+(open?'▾':'›')+'</div><div class="v1477-family-name">'+esc(g.family)+' <span style="color:#879790">('+g.styles.length+')</span></div><div class="v1477-sample" style="font-family:'+esc(cssFont(g.family))+'">Sample</div><div class="v1477-style-count">'+g.styles.length+'</div></div>';
      html+='<div class="v1477-styles">';
      for(j=0;j<g.styles.length;j++){
        f=g.styles[j];
        if(q&&f.search.indexOf(q)<0&&low(g.family).indexOf(q)<0)continue;
        html+='<div class="v1477-style'+(f.name===selectedPS?' chosen':'')+'" data-ps="'+esc(f.name)+'" data-family="'+esc(f.family)+'" data-style="'+esc(f.style)+'"><div></div><div class="v1477-style-name">'+esc(f.style||'Regular')+'</div><div class="v1477-sample" style="font-family:'+esc(cssFont(f.family))+'">Sample</div><div class="v1477-ps" title="'+esc(f.name)+'">'+esc(f.name)+'</div></div>';
      }
      html+='</div></div>';
    }
    if(!html)html='<div class="v1477-empty">Không tìm thấy font phù hợp với “'+esc(query)+'”.</div>';
    list.innerHTML=html;if(cnt)cnt.textContent=shown+' family · '+master.length+' font';
    if(selected){
      var sf=null;for(i=0;i<master.length;i++)if(master[i].name===selectedPS){sf=master[i];break;}
      selected.innerHTML=sf?'<span>Đang chọn:</span> <b>'+esc(sf.family)+'</b><span>· '+esc(sf.style)+'</span><span style="margin-left:auto">'+esc(sf.name)+'</span>':'<span>Chưa chọn font.</span>';
    }
    bindRows();
  }
  function bindRows(){
    var heads=browser.querySelectorAll('.v1477-family-head'),styles=browser.querySelectorAll('.v1477-style'),i;
    for(i=0;i<heads.length;i++)heads[i].onclick=function(){var p=this.parentNode,f=p.getAttribute('data-family');openedFamily=openedFamily===f?'':f;render();};
    for(i=0;i<styles.length;i++)styles[i].onclick=function(e){if(e)e.stopPropagation();selectPS(this.getAttribute('data-ps'),this.getAttribute('data-family'),this.getAttribute('data-style'));};
  }
  function openBrowser(){
    if(!browser)return;snapshot();
    browser.style.display='block';
    var search=$('v1475FontSearch');query=search?search.value:'';
    var sel=$('v1475FontSelect');selectedPS=sel?txt(sel.value):selectedPS;
    render();
  }
  function closeBrowser(){if(browser)browser.style.display='none';}
  function build(){
    var panel=document.querySelector('.v1475-font-panel')||$('v1475FontSelect')&&$('v1475FontSelect').parentNode&&$('v1475FontSelect').parentNode.parentNode;
    var sel=$('v1475FontSelect'),search=$('v1475FontSearch');if(!panel||!sel||!search)return false;
    if($('v1477FontBrowser')){browser=$('v1477FontBrowser');snapshot();return true;}
    var btn=document.createElement('button');btn.id='v1477OpenFontBrowser';btn.type='button';btn.textContent='▦ Mở thư viện font kiểu Illustrator';
    sel.parentNode.insertBefore(btn,sel.nextSibling);
    browser=document.createElement('div');browser.id='v1477FontBrowser';browser.style.display='none';
    browser.innerHTML='<div class="v1477-toolbar"><strong>FONT LIBRARY · ILLUSTRATOR</strong><span class="v1477-count">Đang đọc font…</span><button type="button" class="v1477-close">Đóng</button></div><div class="v1477-list"></div><div class="v1477-selectedbar"><span>Chưa chọn font.</span></div>';
    btn.parentNode.insertBefore(browser,btn.nextSibling);
    btn.onclick=function(e){if(e)e.preventDefault();openBrowser();};browser.querySelector('.v1477-close').onclick=function(){closeBrowser();};
    if(search.addEventListener){search.addEventListener('input',function(){query=this.value||'';if(browser.style.display!=='none'){snapshot();render();}},false);search.addEventListener('focus',function(){openBrowser();},false);}else if(search.attachEvent){search.attachEvent('onkeyup',function(){query=search.value||'';openBrowser();});}
    if(sel.addEventListener)sel.addEventListener('change',function(){selectedPS=sel.value||'';if(browser.style.display!=='none')render();},false);
    snapshot();return true;
  }
  var tries=0,t=setInterval(function(){tries++;if(build()){snapshot();}if(tries>360)clearInterval(t);},350);
  if(document.addEventListener)document.addEventListener('click',function(){setTimeout(function(){build();snapshot();},40);},false);
})();
