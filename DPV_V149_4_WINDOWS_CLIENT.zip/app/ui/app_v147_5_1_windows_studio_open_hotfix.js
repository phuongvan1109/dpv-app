/* DPV V147.5.1 WINDOWS STUDIO OPEN HOTFIX
   IE/WebBrowser-safe final opener for the V147.1 dedicated QR/Barcode page.
   UI-only, no Bridge/Core/QR/Barcode engine changes.
*/
(function(){
  'use strict';
  function $(id){return document.getElementById(id);}
  function addClass(el,c){if(!el)return;if((' '+el.className+' ').indexOf(' '+c+' ')<0)el.className+=(el.className?' ':'')+c;}
  function remClass(el,c){if(!el)return;el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function ensureOverlayGeometry(ov){
    if(!ov)return;
    var s=ov.style;
    s.position='fixed';s.top='0px';s.right='0px';s.bottom='0px';s.left='0px';
    s.width='100%';s.height='100%';s.zIndex='10050';s.boxSizing='border-box';
  }
  function ensureMount(){
    var ov=$('v1471StudioOverlay'),mount=$('v1471StudioMount'),card=$('v147QrStudioCard');
    if(!ov){
      ov=document.createElement('div');ov.id='v1471StudioOverlay';ov.className='v1471-overlay v1471-hidden';
      ov.innerHTML='<div class="v1471-window"><header class="v1471-header"><div class="v1471-title-wrap"><div class="v1471-kicker">DPV® STANDALONE TOOLS</div><h2>QR / Barcode Studio</h2><p>Tạo QR Code · Code128 AUTO · EAN‑13 riêng, không cần mở Biến đổi dữ liệu VDP.</p></div><div class="v1471-head-actions"><span class="v1471-badge">V147.5.1 WIN SAFE</span><button id="v1471CloseBtn" class="v1471-close" type="button">×</button></div></header><div class="v1471-body"><div id="v1471StudioMount" class="v1471-mount"></div></div></div>';
      document.body.appendChild(ov);mount=$('v1471StudioMount');
    }
    ensureOverlayGeometry(ov);
    if(card&&mount&&card.parentNode!==mount){mount.appendChild(card);addClass(card,'v1471-contained-card');}
    var close=$('v1471CloseBtn');if(close&&!close.__v14751){close.__v14751=true;close.onclick=closeStudio;}
    return ov;
  }
  function setNav(){
    var btns=document.querySelectorAll?document.querySelectorAll('.dpv-nav-btn'):[],i;
    for(i=0;i<btns.length;i++){if(btns[i].getAttribute('data-nav')==='qrstudio')addClass(btns[i],'active');else remClass(btns[i],'active');}
  }
  function openStudio(e){
    if(e){try{e.preventDefault();}catch(x){}try{e.cancelBubble=true;}catch(y){} }
    var ov=ensureMount();if(!ov)return false;
    ensureOverlayGeometry(ov);remClass(ov,'v1471-hidden');ov.style.display='block';
    addClass(document.body,'v1471-studio-open');setNav();
    try{var body=ov.querySelector?ov.querySelector('.v1471-body'):null;if(body)body.scrollTop=0;}catch(z){}
    return false;
  }
  function closeStudio(e){
    if(e){try{e.preventDefault();}catch(x){} }
    var ov=$('v1471StudioOverlay');if(ov){addClass(ov,'v1471-hidden');ov.style.display='none';}
    remClass(document.body,'v1471-studio-open');return false;
  }
  function bindButton(btn){
    if(!btn||btn.__v14751)return;btn.__v14751=true;
    btn.onclick=openStudio;
    if(btn.addEventListener)btn.addEventListener('click',openStudio,false);
    else if(btn.attachEvent)btn.attachEvent('onclick',openStudio);
  }
  function repair(){
    var ov=ensureMount();if(ov&&(' '+ov.className+' ').indexOf(' v1471-hidden ')>=0)ov.style.display='none';
    bindButton($('v1471StudioNav'));bindButton($('v1471TopBtn'));
    var nav=document.querySelector?document.querySelector('.dpv-nav'):null;
    if(nav&&!$('v1471StudioNav')){
      var b=document.createElement('button');b.id='v1471StudioNav';b.className='dpv-nav-btn v1471-nav-btn';b.setAttribute('data-nav','qrstudio');
      b.innerHTML='<span class="dpv-nav-icon">▦</span>QR / Barcode Studio';
      var vdp=nav.querySelector?nav.querySelector('.dpv-nav-btn[data-nav="vdp"]'):null;
      if(vdp&&vdp.nextSibling)nav.insertBefore(b,vdp.nextSibling);else nav.appendChild(b);bindButton(b);
    }
    return !!$('v1471StudioNav');
  }
  window.DPV_V14751_OPEN_STUDIO=openStudio;
  var tries=0,t=setInterval(function(){tries++;repair();if(tries>60)clearInterval(t);},300);
  if(document.addEventListener)document.addEventListener('keydown',function(e){e=e||window.event;if(e.keyCode===27)closeStudio(e);},false);
})();
