/* DPV V146.2 QR PIPELINE HOTFIX — additive UI only.
   Fixes false V141 unsupported-action rows, adds code validation and a direct Preview button.
*/
(function(){
  'use strict';
  var VERSION='V146.2';
  function $(id){return document.getElementById(id);}
  function trim(v){return String(v==null?'':v).replace(/^\s+|\s+$/g,'');}
  function utf8len(s){s=String(s==null?'':s);var n=0,i,c;for(i=0;i<s.length;i++){c=s.charCodeAt(i);if(c<0x80)n++;else if(c<0x800)n+=2;else if(c>=0xD800&&c<=0xDBFF&&i+1<s.length){i++;n+=4;}else n+=3;}return n;}
  function eanCheck(s12){var i,sum=0;for(i=0;i<12;i++)sum+=Number(s12.charAt(i))*(i%2?3:1);return String((10-(sum%10))%10);}
  function state(){try{return window.DPVVDP101&&window.DPVVDP101.getState?window.DPVVDP101.getState():null;}catch(e){return null;}}
  function records(){try{return window.DPVVDP101&&window.DPVVDP101.getRecords?window.DPVVDP101.getRecords():[];}catch(e){return [];}}
  function status(m,k){try{if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}catch(e){}}
  function getCurrent(){var r=records(),el=$('vdpRecordIndex'),n=Math.max(1,Math.floor(Number(el&&el.value)||1));if(n>r.length)n=r.length||1;return {records:r,index:n,record:r[n-1]||{}};}
  function codeMappings(){var st=state()||{},a=st.mappings||[],out=[],i;for(i=0;i<a.length;i++)if(a[i].action==='qrVector'||a[i].action==='code128Vector'||a[i].action==='ean13Vector')out.push(a[i]);return out;}
  function validate(){
    var cur=getCurrent(),maps=codeMappings(),all=cur.records,errors=[],warns=[],i,j,m,v,s,bad=0,max=0,first=0;
    for(i=0;i<maps.length;i++){
      m=maps[i];bad=0;max=0;first=0;
      for(j=0;j<all.length;j++){
        v=all[j]&&all[j][m.field]!==undefined?all[j][m.field]:'';s=String(m.prefix||'')+String(v==null?'':v)+String(m.suffix||'');
        if(m.action==='qrVector'){
          var bytes=utf8len(s);if(bytes>max)max=bytes;if(!trim(s)||bytes>858){bad++;if(!first)first=j+1;}
        }else if(m.action==='code128Vector'){
          if(!s||/[^\x20-\x7E]/.test(s)){bad++;if(!first)first=j+1;}
        }else if(m.action==='ean13Vector'){
          if(!/^\d{12,13}$/.test(s)||(s.length===13&&s.charAt(12)!==eanCheck(s.substr(0,12)))){bad++;if(!first)first=j+1;}
        }
      }
      if(bad)errors.push((m.label||m.field)+': '+bad+' record lỗi'+(first?' · đầu tiên #'+first:'')+'.');
      else if(m.action==='qrVector')warns.push((m.label||m.field)+': QR đạt · dài nhất '+max+' byte.');
      else warns.push((m.label||m.field)+': '+(m.action==='code128Vector'?'Code 128':'EAN-13')+' đạt.');
    }
    return {errors:errors,warns:warns,count:maps.length,current:cur};
  }
  function fixPreflight(){
    var list=$('v141List'),sum=$('v141Summary'),badge=$('v141Badge'),rows,i,small,detail,icon,changed=false,ok=0,warn=0,err=0,divs;
    if(!list)return;
    rows=list.querySelectorAll('.v141-check');
    for(i=0;i<rows.length;i++){
      small=rows[i].querySelector('small');detail=small?(small.textContent||small.innerText||''):'';
      if(rows[i].classList.contains('error')&&/^Action không được hỗ trợ: (qrVector|code128Vector|ean13Vector)$/.test(detail)){
        rows[i].classList.remove('error');rows[i].classList.add('ok');icon=rows[i].querySelector('.v141-icon');if(icon)icon.textContent='✓';
        if(small)small.textContent='Action mã vector được '+VERSION+' hỗ trợ.';changed=true;
      }
    }
    if(changed&&sum){rows=list.querySelectorAll('.v141-check');for(i=0;i<rows.length;i++){if(rows[i].classList.contains('error'))err++;else if(rows[i].classList.contains('warn'))warn++;else if(rows[i].classList.contains('ok'))ok++;}divs=sum.querySelectorAll('div strong');if(divs.length>=3){divs[0].textContent=String(ok);divs[1].textContent=String(warn);divs[2].textContent=String(err);}if(badge){badge.textContent=err?(err+' LỖI'):(warn?(warn+' CẢNH BÁO'):'SẴN SÀNG');}}
  }
  function renderCard(){
    var base=$('v146QrBarcodeCard'),root=$('vdpMappings'),card=$('v1462CodeHotfixCard'),v=validate(),h='',i;
    if(!root||!root.parentNode)return false;
    if(!card){card=document.createElement('div');card.id='v1462CodeHotfixCard';card.style.cssText='margin:8px 0;padding:10px 11px;border:1px solid #b9e8d8;border-radius:10px;background:#f4fffb;font-size:11px;line-height:1.45;color:#1d3342';card.innerHTML='<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><strong>QR / BARCODE PIPELINE HOTFIX</strong><span style="font-weight:700;color:#07956e">V146.2 SAFE</span></div><div id="v1462CodeState" style="margin-top:6px"></div><button id="v1462PreviewCodeBtn" type="button" class="button primary" style="margin-top:8px;width:100%">Preview mã record hiện tại trong Illustrator</button><div style="opacity:.7;margin-top:6px">QR hỗ trợ đến Version 20-L · khoảng 858 byte UTF-8. Nút này chỉ Preview các mapping QR/Code128/EAN-13; không thay pipeline VDP cũ.</div>';if(base&&base.parentNode===root.parentNode)root.parentNode.insertBefore(card,base.nextSibling);else root.parentNode.insertBefore(card,root.nextSibling);$('v1462PreviewCodeBtn').onclick=previewCodes;}
    var st=$('v1462CodeState');if(st){if(!v.count)h='<span style="opacity:.72">Chưa có mapping QR / Barcode.</span>';else if(v.errors.length){h='<b style="color:#c44836">'+v.errors.length+' lỗi dữ liệu mã</b><br>'+v.errors.join('<br>');}else{h='<b style="color:#07875f">'+v.count+' mapping mã sẵn sàng</b>';for(i=0;i<v.warns.length;i++)h+='<br>'+v.warns[i];}st.innerHTML=h;}
    var old=base&&base.querySelector('.v146-code-note');if(old)old.innerHTML='Cách dùng: chọn shape/khung giữ chỗ → <b>+ Thêm vị trí đang chọn trong AI</b> → chọn cột → chọn QR/Code128/EAN-13 → bấm <b>Preview mã record hiện tại</b>. QR V146.2 hỗ trợ URL dài tới khoảng 858 byte.';
    return true;
  }
  function previewCodes(){
    var v=validate(),cur=v.current,st=state()||{},maps=codeMappings();
    if(!maps.length){status('V146.2: chưa có mapping QR/Barcode.','error');return;}
    if(v.errors.length){status('V146.2: dữ liệu mã chưa hợp lệ: '+v.errors[0],'error');return;}
    if(!window.DPVVDP101||typeof window.DPVVDP101.bridgeCall!=='function'){status('V146.2: Bridge chưa sẵn sàng.','error');return;}
    status('V146.2: đang Preview '+maps.length+' mã ở record '+cur.index+'…','ok');
    window.DPVVDP101.bridgeCall('PreviewVariableData',[JSON.stringify({record:cur.record,recordNumber:cur.index,mappings:maps,sourceFolder:st.sourceFolder||''})]);
  }
  function hook(){var root=$('vdpMappings');if(!root)return false;renderCard();fixPreflight();if(!root.__v1462HotfixObserver){var mo=new MutationObserver(function(){window.setTimeout(function(){renderCard();fixPreflight();},0);});mo.observe(root,{childList:true,subtree:true});root.__v1462HotfixObserver=mo;root.addEventListener('change',function(){window.setTimeout(renderCard,0);},false);}var list=$('v141List');if(list&&!list.__v1462PreflightObserver){var pm=new MutationObserver(function(){window.setTimeout(fixPreflight,0);});pm.observe(list,{childList:true,subtree:true});list.__v1462PreflightObserver=pm;}return true;}
  var tries=0,t=setInterval(function(){tries++;if(hook()||tries>80)clearInterval(t);},400);
  document.addEventListener('click',function(){window.setTimeout(function(){hook();renderCard();fixPreflight();},30);},false);
})();
