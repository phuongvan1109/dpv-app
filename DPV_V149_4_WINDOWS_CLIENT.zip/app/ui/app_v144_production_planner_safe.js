/* DPV V144 — PRODUCTION PLANNER SAFE ADD-ON
   Additive-only rules:
   - Does NOT override Core V101, VDPROEngine.preview, Bridge, VDP, Cut & Stack, Duplex or Recovery handlers.
   - Reads existing preview/settings only.
   - Writes only its own localStorage keys.
   - Existing DPV settings are changed only after an explicit user click on "Áp dụng" for a saved snapshot.
*/
(function () {
  'use strict';
  var STORE = 'dpv.v144.productionPlanner.safe';
  var SNAP = 'dpv.v144.layoutSnapshots.safe';
  var booted = false, observers = [], bound = false, recalcTimer = null;

  function $(id){return document.getElementById(id);}
  function q(sel,root){return (root||document).querySelector?(root||document).querySelector(sel):null;}
  function trim(s){return String(s==null?'':s).replace(/^\s+|\s+$/g,'');}
  function txt(el){return el?trim(('textContent' in el?el.textContent:el.innerText)||''):'';}
  function setText(id,s){var e=$(id);if(!e)return;if('textContent' in e)e.textContent=s;else e.innerText=s;}
  function num(id,d){var e=$(id),n=e?Number(e.value):NaN;return isFinite(n)?n:d;}
  function intText(id,d){var n=parseInt(txt($(id)).replace(/[^0-9\-]/g,''),10);return isNaN(n)?d:n;}
  function checked(id){var e=$(id);return !!(e&&e.checked);}
  function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function fire(el,type){if(!el)return;try{var ev=document.createEvent('HTMLEvents');ev.initEvent(type,true,false);el.dispatchEvent(ev);}catch(e){try{el.fireEvent('on'+type);}catch(x){}}}
  function storeGet(key,def){try{var r=window.localStorage?localStorage.getItem(key):null;return r?JSON.parse(r):def;}catch(e){return def;}}
  function storeSet(key,val){try{if(window.localStorage){localStorage.setItem(key,JSON.stringify(val));return true;}}catch(e){}return false;}
  function fmtInt(n){n=Math.round(Number(n)||0);return String(n).replace(/\B(?=(\d{3})+(?!\d))/g,'.');}
  function fmt1(n){n=Number(n);if(!isFinite(n))return '—';return (Math.round(n*10)/10).toFixed(1).replace('.',',');}
  function fmt2(n){n=Number(n);if(!isFinite(n))return '—';return (Math.round(n*100)/100).toFixed(2).replace('.',',');}
  function money(n){n=Number(n);if(!isFinite(n))return '—';return fmtInt(Math.round(n));}
  function efficiencyNumber(){var s=txt($('efficiency')).replace(',','.');var m=s.match(/([0-9]+(?:\.[0-9]+)?)/);return m?Math.max(0,Math.min(100,Number(m[1]))):NaN;}
  function currentCount(){return Math.max(0,intText('previewCount',0));}
  function settings(){
    return {
      paperW:num('paperW',0),paperH:num('paperH',0),margin:num('margin',0),header:num('header',0),gapX:num('gapX',0),gapY:num('gapY',0),maxQty:num('maxQty',0),linkBleed:num('linkBleed',0),
      allowRotate:checked('allowRotate'),uniformGap:checked('uniformGap'),trueShape:checked('trueShape'),specialStagger:checked('specialStagger'),fastMode:checked('fastMode'),cornerSafe:checked('cornerSafe'),cornerZone:num('cornerZone',0),
      angleStep:$('angleStep')?String($('angleStep').value||'15'):'15',demiMode:checked('demiMode'),duplexMode:checked('duplexMode'),finishCropMarks:checked('finishCropMarks')
    };
  }
  function readInputs(){
    var saved=storeGet(STORE,{}), qn=Math.max(0,Math.floor(num('v144TargetQty',saved.targetQty||1000))), waste=Math.max(0,num('v144WastePct',saved.wastePct==null?3:saved.wastePct));
    var sheetCost=Math.max(0,num('v144SheetCost',saved.sheetCost||0)), printCost=Math.max(0,num('v144PrintCost',saved.printCost||0)), setup=Math.max(0,num('v144SetupCost',saved.setupCost||0));
    return {targetQty:qn,wastePct:waste,sheetCost:sheetCost,printCost:printCost,setupCost:setup};
  }
  function calc(count,eff,inp){
    var qty=inp.targetQty, req=qty*(1+inp.wastePct/100), base=count>0?Math.ceil(qty/count):0, sheets=count>0?Math.ceil(req/count):0, produced=sheets*count;
    var over=Math.max(0,produced-qty), paperW=num('paperW',0),paperH=num('paperH',0),areaSheet=(paperW*paperH)/1000000, totalArea=areaSheet*sheets;
    var wasteArea=isFinite(eff)?totalArea*(1-eff/100):NaN, totalCost=sheets*(inp.sheetCost+inp.printCost)+inp.setupCost, unit=qty>0?totalCost/qty:0;
    var plusOne=count>0?Math.ceil(req/(count+1)):0, save=count>0?Math.max(0,sheets-plusOne):0;
    return {base:base,sheets:sheets,produced:produced,over:over,totalArea:totalArea,wasteArea:wasteArea,totalCost:totalCost,unit:unit,savePlusOne:save,printSides:sheets*(checked('duplexMode')?2:1)};
  }
  function saveInputs(){var i=readInputs();storeSet(STORE,i);return i;}
  function currentSnapshot(){
    var c=currentCount(),eff=efficiencyNumber(),s=settings();
    return {count:c,eff:isFinite(eff)?eff:null,method:txt($('previewMethod')),details:txt($('previewDetails')),mode:txt($('modeLabel')),capturedAt:(new Date()).getTime(),settings:s};
  }
  function snapshots(){var a=storeGet(SNAP,{});return a&&typeof a==='object'?a:{};}
  function saveSnapshot(key){
    var s=currentSnapshot();if(!(s.count>0)){message('Chưa có layout. Hãy bấm “Tính nhanh trên DPV®” trước khi lưu Snapshot.','warn');return;}
    var a=snapshots();a[key]=s;storeSet(SNAP,a);renderSnapshots();message('Đã lưu Snapshot '+key+': '+s.count+' con/tờ.','ok');
  }
  function clearSnapshots(){storeSet(SNAP,{});renderSnapshots();message('Đã xóa Snapshot A/B/C.','ok');}
  function setVal(id,v){var e=$(id);if(!e||v==null)return;e.value=String(v);}
  function setCheck(id,v){var e=$(id);if(!e||v==null)return;e.checked=!!v;}
  function applySnapshot(key){
    var a=snapshots(),x=a[key];if(!x||!x.settings){message('Snapshot '+key+' chưa có dữ liệu.','warn');return;}
    var s=x.settings;
    setVal('paperW',s.paperW);setVal('paperH',s.paperH);setVal('margin',s.margin);setVal('header',s.header);setVal('gapX',s.gapX);setVal('gapY',s.gapY);setVal('maxQty',s.maxQty);setVal('linkBleed',s.linkBleed);setVal('cornerZone',s.cornerZone);setVal('angleStep',s.angleStep);
    setCheck('allowRotate',s.allowRotate);setCheck('uniformGap',s.uniformGap);setCheck('trueShape',s.trueShape);setCheck('specialStagger',s.specialStagger);setCheck('fastMode',s.fastMode);setCheck('cornerSafe',s.cornerSafe);setCheck('demiMode',s.demiMode);
    message('Đã áp dụng thông số Snapshot '+key+'. DPV chưa tự Build; hãy kiểm tra Preview rồi mới xuất.','ok');
    window.setTimeout(function(){var b=$('localPreviewBtn');try{if(b&&b.click)b.click();}catch(e){}},80);
  }
  function bestKey(a,inp){
    var keys=['A','B','C'],best=null,i,x,scoreSheets,scoreEff;
    for(i=0;i<keys.length;i++){
      x=a[keys[i]];if(!x||!(x.count>0))continue;scoreSheets=inp.targetQty>0?Math.ceil(inp.targetQty*(1+inp.wastePct/100)/x.count):999999999;scoreEff=x.eff==null?-1:x.eff;
      if(!best||scoreSheets<best.sheets||(scoreSheets===best.sheets&&x.count>best.count)||(scoreSheets===best.sheets&&x.count===best.count&&scoreEff>best.eff)){best={key:keys[i],sheets:scoreSheets,count:x.count,eff:scoreEff};}
    }
    return best?best.key:null;
  }
  function renderSnapshots(){
    var host=$('v144SnapshotRows');if(!host)return;var a=snapshots(),inp=readInputs(),best=bestKey(a,inp),keys=['A','B','C'],h='',i,k,x,sh,eff;
    for(i=0;i<keys.length;i++){
      k=keys[i];x=a[k];
      if(!x){h+='<div class="v144-snap empty"><b>'+k+'</b><span>Chưa lưu</span><button type="button" data-v144-save="'+k+'">Lưu '+k+'</button></div>';continue;}
      sh=inp.targetQty>0?Math.ceil(inp.targetQty*(1+inp.wastePct/100)/Math.max(1,x.count)):0;eff=x.eff==null?'—':fmt1(x.eff)+'%';
      h+='<div class="v144-snap'+(best===k?' best':'')+'"><b>'+k+(best===k?'<em>BEST</em>':'')+'</b><span><strong>'+fmtInt(x.count)+'</strong> con/tờ · '+eff+' · '+fmtInt(sh)+' tờ</span><small>'+esc(x.method||'Layout')+'</small><div><button type="button" data-v144-save="'+k+'">Ghi đè</button><button type="button" data-v144-apply="'+k+'">Áp dụng</button></div></div>';
    }
    host.innerHTML=h;
    bindDynamicSnapshotButtons();
  }
  function bindDynamicSnapshotButtons(){
    var host=$('v144SnapshotRows'),btns,i,b,k;if(!host)return;btns=host.getElementsByTagName('button');
    for(i=0;i<btns.length;i++){b=btns[i];k=b.getAttribute('data-v144-save');if(k){b.onclick=(function(x){return function(){saveSnapshot(x);};}(k));continue;}k=b.getAttribute('data-v144-apply');if(k)b.onclick=(function(x){return function(){applySnapshot(x);};}(k));}
  }
  function message(s,type){var e=$('v144Message');if(!e)return;e.className='v144-message '+(type||'');setText('v144Message',s);}
  function recalc(){
    if(!$('v144Planner'))return;var inp=saveInputs(),count=currentCount(),eff=efficiencyNumber(),c=calc(count,eff,inp);
    setText('v144KpiCount',count>0?fmtInt(count):'—');setText('v144KpiSheets',count>0?fmtInt(c.sheets):'—');setText('v144KpiProduced',count>0?fmtInt(c.produced):'—');setText('v144KpiOver',count>0?fmtInt(c.over):'—');
    setText('v144BaseSheets',count>0?fmtInt(c.base):'—');setText('v144PrintSides',count>0?fmtInt(c.printSides):'—');setText('v144TotalArea',count>0?fmt2(c.totalArea)+' m²':'—');setText('v144WasteArea',count>0&&isFinite(c.wasteArea)?fmt2(c.wasteArea)+' m²':'—');
    setText('v144TotalCost',count>0?money(c.totalCost):'—');setText('v144UnitCost',count>0&&inp.targetQty>0?fmt2(c.unit):'—');setText('v144PlusOne',count>0?(c.savePlusOne>0?'Giảm '+fmtInt(c.savePlusOne)+' tờ':'Không đổi'):'—');
    setText('v144CurrentEff',isFinite(eff)?fmt1(eff)+'%':'—');
    var waste=isFinite(eff)?Math.max(0,100-eff):NaN;setText('v144MaterialWaste',isFinite(waste)?fmt1(waste)+'%':'—');
    var msg='';if(!(count>0))msg='Chưa có layout: bấm “Tính nhanh trên DPV®”.';else if(inp.targetQty<=0)msg='Nhập số lượng thành phẩm cần sản xuất.';else msg='Với '+fmtInt(inp.targetQty)+' thành phẩm + '+fmt1(inp.wastePct)+'% hao hụt: cần '+fmtInt(c.sheets)+' tờ, ra '+fmtInt(c.produced)+' con.';
    message(msg,count>0?'ok':'');renderSnapshots();
  }
  function schedule(){if(recalcTimer)window.clearTimeout(recalcTimer);recalcTimer=window.setTimeout(recalc,80);}
  function copyText(s){
    try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(s).then(function(){message('Đã copy tóm tắt sản xuất.','ok');},function(){fallbackCopy(s);});return;}}catch(e){}
    fallbackCopy(s);
  }
  function fallbackCopy(s){var ta=document.createElement('textarea');ta.value=s;ta.style.position='fixed';ta.style.left='-9999px';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');message('Đã copy tóm tắt sản xuất.','ok');}catch(e){message('Không copy tự động được.','warn');}document.body.removeChild(ta);}
  function summary(){
    var inp=readInputs(),count=currentCount(),eff=efficiencyNumber(),c=calc(count,eff,inp),s=settings();
    var lines=['DPV V144 - PRODUCTION SUMMARY','',
      'Layout: '+(count>0?count:'—')+' con/tờ','Phương án: '+txt($('previewMethod')),'Hiệu suất: '+(isFinite(eff)?fmt1(eff)+'%':'—'),
      'Khổ: '+fmt1(s.paperW)+' x '+fmt1(s.paperH)+' mm | Lề '+fmt1(s.margin)+' mm | Gap '+fmt1(s.gapX)+' / '+fmt1(s.gapY)+' mm',
      'Số lượng cần: '+fmtInt(inp.targetQty),'Hao hụt dự kiến: '+fmt1(inp.wastePct)+'%','Tờ lý thuyết: '+fmtInt(c.base),'Tờ có bù hao: '+fmtInt(c.sheets),'Sản lượng: '+fmtInt(c.produced),'Dư: '+fmtInt(c.over),
      'Diện tích vật liệu: '+fmt2(c.totalArea)+' m²','Diện tích hao theo layout: '+(isFinite(c.wasteArea)?fmt2(c.wasteArea)+' m²':'—'),
      'Tổng chi phí nhập: '+money(c.totalCost),'Chi phí / thành phẩm: '+fmt2(c.unit),'Nếu tăng +1 con/tờ: '+(c.savePlusOne>0?'giảm '+fmtInt(c.savePlusOne)+' tờ':'không giảm số tờ')
    ];
    copyText(lines.join('\n'));
  }
  function insertPanel(){
    if($('v144Planner'))return true;var col=q('.result-column');if(!col)return false;var action=q('.action-stack',col);if(!action||!action.parentNode)return false;
    var d=document.createElement('div');d.id='v144Planner';d.className='v144-planner';d.innerHTML=''
      +'<div class="v144-head"><div><b>PRODUCTION PLANNER · V144 SAFE</b><span>Tính số tờ, hao hụt, chi phí và so sánh layout — không can thiệp Core/Bridge</span></div><span class="v144-safe">ADDITIVE</span></div>'
      +'<div class="v144-inputs"><label>Số lượng thành phẩm cần<input id="v144TargetQty" type="number" min="0" step="1"></label><label>Hao hụt dự kiến (%)<input id="v144WastePct" type="number" min="0" step="0.1"></label><label>Giá vật liệu / tờ<input id="v144SheetCost" type="number" min="0" step="1"></label><label>Chi phí in / tờ<input id="v144PrintCost" type="number" min="0" step="1"></label><label>Chi phí cố định<input id="v144SetupCost" type="number" min="0" step="1"></label></div>'
      +'<div class="v144-kpis"><div><span>CON / TỜ</span><b id="v144KpiCount">—</b></div><div><span>TỜ CẦN</span><b id="v144KpiSheets">—</b></div><div><span>SẢN LƯỢNG</span><b id="v144KpiProduced">—</b></div><div><span>DƯ</span><b id="v144KpiOver">—</b></div></div>'
      +'<div class="v144-details"><div><span>Tờ lý thuyết</span><b id="v144BaseSheets">—</b></div><div><span>Số mặt in</span><b id="v144PrintSides">—</b></div><div><span>Hiệu suất layout</span><b id="v144CurrentEff">—</b></div><div><span>Hao vật liệu</span><b id="v144MaterialWaste">—</b></div><div><span>Tổng diện tích</span><b id="v144TotalArea">—</b></div><div><span>Diện tích hao</span><b id="v144WasteArea">—</b></div><div><span>Tổng chi phí</span><b id="v144TotalCost">—</b></div><div><span>Chi phí / con</span><b id="v144UnitCost">—</b></div><div><span>Nếu +1 con/tờ</span><b id="v144PlusOne">—</b></div></div>'
      +'<div class="v144-compare"><div class="v144-subhead"><b>SO SÁNH LAYOUT · SNAPSHOT A/B/C</b><span>Lưu layout hiện tại → đổi setting → Tính nhanh → lưu phương án khác</span></div><div id="v144SnapshotRows"></div><div class="v144-actions"><button type="button" id="v144ClearSnapshots">Xóa A/B/C</button><button type="button" id="v144CopySummary" class="primary">Copy tóm tắt sản xuất</button></div></div>'
      +'<div id="v144Message" class="v144-message">Sẵn sàng.</div>';
    action.parentNode.insertBefore(d,action);
    var saved=storeGet(STORE,{targetQty:1000,wastePct:3,sheetCost:0,printCost:0,setupCost:0});
    $('v144TargetQty').value=String(saved.targetQty==null?1000:saved.targetQty);$('v144WastePct').value=String(saved.wastePct==null?3:saved.wastePct);$('v144SheetCost').value=String(saved.sheetCost||0);$('v144PrintCost').value=String(saved.printCost||0);$('v144SetupCost').value=String(saved.setupCost||0);
    var ids=['v144TargetQty','v144WastePct','v144SheetCost','v144PrintCost','v144SetupCost'],i,e;
    for(i=0;i<ids.length;i++){e=$(ids[i]);if(e.addEventListener){e.addEventListener('input',schedule,false);e.addEventListener('change',schedule,false);}else if(e.attachEvent)e.attachEvent('onchange',schedule);}
    $('v144ClearSnapshots').onclick=clearSnapshots;$('v144CopySummary').onclick=summary;
    renderSnapshots();recalc();return true;
  }
  function observePreview(){
    if(bound)return;var ids=['previewCount','efficiency','previewMethod','previewDetails','modeLabel'],i,e;
    if(window.MutationObserver){for(i=0;i<ids.length;i++){e=$(ids[i]);if(!e)continue;try{var o=new MutationObserver(schedule);o.observe(e,{childList:true,subtree:true,characterData:true});observers.push(o);}catch(x){}}}
    var inputIds=['paperW','paperH','margin','header','gapX','gapY','maxQty','linkBleed','allowRotate','uniformGap','trueShape','specialStagger','fastMode','cornerSafe','cornerZone','angleStep','demiMode','duplexMode'],j,el;
    for(j=0;j<inputIds.length;j++){el=$(inputIds[j]);if(!el)continue;if(el.addEventListener)el.addEventListener('change',schedule,false);else if(el.attachEvent)el.attachEvent('onchange',schedule);}
    bound=true;
  }
  function init(){if(booted)return;booted=true;if(!insertPanel()){window.setTimeout(function(){booted=false;init();},700);return;}observePreview();window.DPVProductionPlannerV144={version:'144',safe:true,recalc:recalc,saveSnapshot:saveSnapshot,applySnapshot:applySnapshot,summary:summary};}
  function boot(){window.setTimeout(init,1250);}
  if(document.readyState==='complete')boot();else if(window.addEventListener)window.addEventListener('load',boot,false);else window.attachEvent('onload',boot);
}());
