(function(){
  "use strict";
  function $(id){return document.getElementById(id);}
  function txt(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function vstatus(m,k){if(window.DPVVDP101&&window.DPVVDP101.status)window.DPVVDP101.status(m,k||'');}
  function nativeCall(method,args,done,fail){
    args=args||[];
    try{
      if(window.DPVNative&&typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke(method,args).then(done).catch(function(e){fail((e&&e.message)||String(e));});return;
      }
      if(window.external&&typeof window.external[method]!=='undefined'){
        var v;if(args.length===0)v=window.external[method]();else if(args.length===1)v=window.external[method](args[0]);else throw new Error('Bridge V119 chỉ hỗ trợ tối đa 1 tham số ở dialog này.');done(v);return;
      }
      fail('DPV Bridge chưa sẵn sàng.');
    }catch(e){fail((e&&e.message)||String(e));}
  }
  var pending=false;
  function bind(){
    var old=$('vdpChooseDataBtn');if(!old||!old.parentNode)return;
    var btn=old.cloneNode(true);btn.id='vdpChooseDataBtn';btn.className=(btn.className||'')+' dpv-v119-native-csv';old.parentNode.replaceChild(btn,old);
    btn.onclick=function(ev){
      ev=ev||window.event;try{if(ev.preventDefault)ev.preventDefault();if(ev.stopPropagation)ev.stopPropagation();}catch(x){}
      if(pending)return false;pending=true;btn.disabled=true;txt(btn,'Đang chọn...');vstatus('Đang mở cửa sổ chọn CSV/TXT…','work');
      nativeCall('ChooseVariableDataPathV119',[],function(path){
        path=String(path||'');
        if(!path){pending=false;btn.disabled=false;txt(btn,'Chọn CSV / TXT');vstatus('Đã hủy chọn dữ liệu.','');return;}
        vstatus('Đã chọn file. Đang đọc dữ liệu…','work');
        nativeCall('ReadVariableDataFileV119',[path],function(raw){
          pending=false;btn.disabled=false;txt(btn,'Chọn CSV / TXT');
          if(window.DPVVDP101&&typeof window.DPVVDP101.loadFileResult==='function')window.DPVVDP101.loadFileResult(raw);
          else vstatus('VDP loader chưa sẵn sàng.','error');
        },function(err){pending=false;btn.disabled=false;txt(btn,'Chọn CSV / TXT');vstatus('Không đọc được CSV/TXT: '+err,'error');});
      },function(err){pending=false;btn.disabled=false;txt(btn,'Chọn CSV / TXT');vstatus('Không mở được hộp thoại CSV/TXT: '+err,'error');});
      return false;
    };

    var reload=$('vdpReloadDataBtn');if(reload&&reload.parentNode){
      var rb=reload.cloneNode(true);rb.id='vdpReloadDataBtn';reload.parentNode.replaceChild(rb,reload);
      rb.onclick=function(){
        var st=(window.DPVVDP101&&window.DPVVDP101.getState)?window.DPVVDP101.getState():null;
        if(!st||!st.filePath){if(btn&&btn.click)btn.click();return false;}
        vstatus('Đang đọc lại CSV/TXT…','work');
        nativeCall('ReadVariableDataFileV119',[st.filePath],function(raw){if(window.DPVVDP101&&window.DPVVDP101.loadFileResult)window.DPVVDP101.loadFileResult(raw);},function(err){vstatus('Đọc lại thất bại: '+err,'error');});
        return false;
      };
    }
  }
  function mark(){var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)txt(v,'V119 CSV NATIVE FIX · CORE V101 STABLE');var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V119 CSV Native Fix · Core V101 Stable</strong><br>Windows tách chọn file và đọc CSV/TXT thành 2 bước native ổn định · hỗ trợ UTF-8, UTF-16, ANSI Vietnamese, CSV/TXT/TSV và Excel sep= · không thay engine dàn.';}
  function start(){bind();mark();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start,false);else window.attachEvent('onload',start);}else start();
})();
