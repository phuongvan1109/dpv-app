/* DPV V147.7.1 FAST FONT BROWSER + COMMIT FIX
   UI-only hotfix for V147.7.
   Goals:
   - avoid rendering 2000+ font rows at once
   - click family commits a usable default style immediately
   - click exact style commits PostScript name immediately
   - keep legacy select small/hidden so old V147.5/V147.7 scripts stay cheap
*/
(function(){
  'use strict';

  var master=[], families=[], famMap={}, selectedPS='', openedKey='', ready=false;
  var lastSelectCount=0, renderTimer=null, pollTimer=null;
  var MAX_IDLE=36, MAX_SEARCH=72;

  function $(id){ return document.getElementById(id); }
  function str(v){ return String(v==null?'':v); }
  function lower(v){ return str(v).toLowerCase(); }
  function esc(s){ return str(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function dispatch(el,name){
    if(!el) return;
    try{ var e=document.createEvent('HTMLEvents'); e.initEvent(name,true,false); el.dispatchEvent(e); }
    catch(x){ try{ if(el.fireEvent) el.fireEvent('on'+name); }catch(y){} }
  }

  function captureFonts(force){
    var sel=$('v1475FontSelect'), i,o,a=[],seen={}, ps,fam,sty,search;
    if(!sel || sel.options.length<2) return false;
    if(!force && sel.options.length<=5 && master.length) return true;
    if(!force && sel.options.length===lastSelectCount && master.length>20) return true;

    for(i=0;i<sel.options.length;i++){
      o=sel.options[i]; ps=str(o.value);
      if(!ps || seen[ps]) continue;
      fam=str(o.getAttribute('data-family') || o.text || o.textContent || ps);
      sty=str(o.getAttribute('data-style') || 'Regular');
      search=lower(fam+' '+sty+' '+ps);
      seen[ps]=1;
      a.push({name:ps,family:fam,style:sty,search:search});
    }
    if(a.length>10){
      master=a; lastSelectCount=sel.options.length; groupFonts(); ready=true;
      collapseLegacySelect();
      updateSelectedUi();
      return true;
    }
    return master.length>0;
  }

  function groupFonts(){
    var i,f,key,g,keys=[];
    famMap={}; families=[];
    for(i=0;i<master.length;i++){
      f=master[i]; key=lower(f.family);
      if(!famMap[key]){ famMap[key]={key:key,family:f.family,styles:[],search:lower(f.family)}; keys.push(key); }
      famMap[key].styles.push(f);
    }
    keys.sort(function(a,b){ var aa=lower(famMap[a].family),bb=lower(famMap[b].family); return aa<bb?-1:aa>bb?1:0; });
    for(i=0;i<keys.length;i++){
      g=famMap[keys[i]];
      g.styles.sort(function(a,b){ var aa=lower(a.style),bb=lower(b.style); return aa<bb?-1:aa>bb?1:0; });
      g.search = lower(g.family+' '+g.styles.map(function(x){return x.style+' '+x.name;}).join(' '));
      families.push(g);
    }
  }

  function preferredStyle(g){
    var prefs=['regular','roman','book','normal','medium'],i,j,s;
    if(!g || !g.styles.length) return null;
    for(i=0;i<prefs.length;i++){
      for(j=0;j<g.styles.length;j++){
        s=lower(g.styles[j].style);
        if(s===prefs[i] || s.indexOf(prefs[i])>=0) return g.styles[j];
      }
    }
    return g.styles[0];
  }

  function collapseLegacySelect(){
    var sel=$('v1475FontSelect'), chosen=null, i,o, head;
    if(!sel) return;
    selectedPS = selectedPS || str(sel.value);
    if(selectedPS){
      for(i=0;i<master.length;i++){ if(master[i].name===selectedPS){ chosen=master[i]; break; } }
    }
    while(sel.options.length) sel.remove(0);
    head=document.createElement('option'); head.value=''; head.text='— Font Illustrator —'; sel.add(head);
    if(chosen){
      o=document.createElement('option'); o.value=chosen.name; o.text=chosen.family+' · '+chosen.style;
      o.setAttribute('data-family',chosen.family); o.setAttribute('data-style',chosen.style); o.setAttribute('data-search',chosen.search);
      sel.add(o); sel.selectedIndex=1;
    }
    sel.style.display='none';
  }

  function ensureCommittedOption(font){
    var sel=$('v1475FontSelect'), o;
    if(!sel || !font) return;
    while(sel.options.length) sel.remove(0);
    o=document.createElement('option'); o.value=''; o.text='— Font Illustrator —'; sel.add(o);
    o=document.createElement('option'); o.value=font.name; o.text=font.family+' · '+font.style;
    o.setAttribute('data-family',font.family); o.setAttribute('data-style',font.style); o.setAttribute('data-search',font.search);
    sel.add(o); sel.selectedIndex=1; sel.style.display='none';
  }

  function commitFont(font){
    var legacy=$('v147FontName'), status=$('v1475FontStatus'), hiddenSearch=$('v1475FontSearch');
    if(!font) return;
    selectedPS=font.name;
    ensureCommittedOption(font);
    if(legacy){ legacy.value=font.name; dispatch(legacy,'input'); dispatch(legacy,'change'); }
    if(hiddenSearch) hiddenSearch.value='';
    dispatch($('v1475FontSelect'),'change');
    if(status) status.textContent='Đang chọn: '+font.family+' · '+font.style+' · '+font.name;
    updateSelectedUi(font);
    closeBrowser();
  }

  function selectedFont(){
    var i;
    for(i=0;i<master.length;i++) if(master[i].name===selectedPS) return master[i];
    return null;
  }

  function updateSelectedUi(font){
    var btn=$('v14771SelectedBtn'), label=$('v14771SelectedText');
    font=font || selectedFont();
    if(label) label.innerHTML=font?'<b>'+esc(font.family)+'</b><span>'+esc(font.style)+'</span><small>'+esc(font.name)+'</small>':'<b>Chọn font Illustrator</b><span>Click để mở thư viện</span>';
    if(btn && font){ btn.style.fontFamily='"'+font.family.replace(/"/g,'\\"')+'", sans-serif'; }
  }

  function matchFamilies(q){
    var out=[],i,g;
    q=lower(q).replace(/^\s+|\s+$/g,'');
    for(i=0;i<families.length;i++){
      g=families[i];
      if(!q || g.search.indexOf(q)>=0) out.push(g);
      if(out.length >= (q?MAX_SEARCH:MAX_IDLE)) break;
    }
    return out;
  }

  function render(){
    var panel=$('v14771Browser'), list=$('v14771List'), count=$('v14771Count'), inp=$('v14771Search');
    var q=inp?inp.value:'', groups=matchFamilies(q), html='',i,j,g,f,open,sel,maxStyles;
    if(!panel || !list) return;
    if(!ready){ list.innerHTML='<div class="v14771-empty">Đang đọc danh sách font từ Illustrator…</div>'; if(count)count.textContent=''; return; }
    sel=selectedFont();
    for(i=0;i<groups.length;i++){
      g=groups[i]; open=(openedKey===g.key);
      html+='<div class="v14771-family'+(sel&&lower(sel.family)===g.key?' selected':'')+'" data-key="'+esc(g.key)+'">';
      html+='<div class="v14771-row v14771-family-row">';
      html+='<button type="button" class="v14771-expand" data-act="toggle" title="Xem style">'+(open?'▾':'›')+'</button>';
      html+='<div class="v14771-family-name" data-act="choose-family">'+esc(g.family)+' <small>('+g.styles.length+')</small></div>';
      html+='<div class="v14771-sample" data-act="choose-family" style="font-family:\''+esc(g.family.replace(/'/g,"\\'"))+'\', sans-serif">Sample</div>';
      html+='<button type="button" class="v14771-use" data-act="choose-family">Chọn</button>';
      html+='</div>';
      if(open){
        html+='<div class="v14771-styles">'; maxStyles=Math.min(g.styles.length,32);
        for(j=0;j<maxStyles;j++){
          f=g.styles[j];
          html+='<div class="v14771-style'+(f.name===selectedPS?' chosen':'')+'" data-ps="'+esc(f.name)+'">';
          html+='<div class="v14771-style-name">'+esc(f.style||'Regular')+'</div>';
          html+='<div class="v14771-sample" style="font-family:\''+esc(f.family.replace(/'/g,"\\'"))+'\', sans-serif">Sample</div>';
          html+='<div class="v14771-ps">'+esc(f.name)+'</div>';
          html+='</div>';
        }
        if(g.styles.length>maxStyles) html+='<div class="v14771-more">+'+(g.styles.length-maxStyles)+' style khác — gõ tên style để lọc.</div>';
        html+='</div>';
      }
      html+='</div>';
    }
    if(!html) html='<div class="v14771-empty">Không tìm thấy font khớp “'+esc(q)+'”.</div>';
    list.innerHTML=html;
    if(count) count.textContent=(q?groups.length+' kết quả đầu':'Hiển thị '+groups.length+' family đầu')+' · '+families.length+' family / '+master.length+' font';
  }

  function scheduleRender(){ if(renderTimer) clearTimeout(renderTimer); renderTimer=setTimeout(render,90); }
  function openBrowser(){ var p=$('v14771Browser'); if(!p) return; p.style.display='block'; render(); var inp=$('v14771Search'); if(inp){ try{ inp.focus(); }catch(e){} } }
  function closeBrowser(){ var p=$('v14771Browser'); if(p) p.style.display='none'; openedKey=''; var inp=$('v14771Search'); if(inp) inp.value=''; }

  function findFamilyByKey(key){ return famMap[key]||null; }
  function findFontByPs(ps){ var i; for(i=0;i<master.length;i++) if(master[i].name===ps) return master[i]; return null; }

  function handleListClick(e){
    e=e||window.event; var t=e.target||e.srcElement, styleNode=null, familyNode=null, act,key,g,f;
    if(!t) return;
    while(t && t!==$('v14771List')){
      if(t.className && String(t.className).indexOf('v14771-style')>=0){ styleNode=t; break; }
      if(t.getAttribute && t.getAttribute('data-act')){ act=t.getAttribute('data-act'); break; }
      t=t.parentNode;
    }
    if(styleNode){ f=findFontByPs(styleNode.getAttribute('data-ps')); if(f) commitFont(f); return; }
    t=e.target||e.srcElement;
    while(t && t!==$('v14771List')){ if(t.className && String(t.className).indexOf('v14771-family')>=0){ familyNode=t; break; } t=t.parentNode; }
    if(!familyNode) return;
    key=familyNode.getAttribute('data-key'); g=findFamilyByKey(key); if(!g) return;
    if(act==='toggle'){ openedKey=(openedKey===key?'':key); render(); return; }
    /* Illustrator-like usability: clicking family/sample/Choose commits preferred style immediately. */
    f=preferredStyle(g); if(f) commitFont(f);
  }

  function buildUi(){
    var fontline=document.querySelector('.v1475-fontline'), nativeSearch=$('v1475FontSearch'), nativeSel=$('v1475FontSelect'), oldBtn=$('v1477OpenFontBrowser'), oldBrowser=$('v1477FontBrowser');
    var wrap,btn,browser,input,close,list;
    if(!fontline || !nativeSearch || !nativeSel) return false;

    /* Neutralize old 2000-option live filters. Keep an empty hidden input for legacy scripts. */
    nativeSearch.value=''; nativeSearch.style.display='none'; nativeSearch.__v14752=true;
    nativeSel.style.display='none';
    if(oldBtn) oldBtn.style.display='none';
    if(oldBrowser) oldBrowser.style.display='none';

    if($('v14771Picker')){ captureFonts(false); return true; }

    wrap=document.createElement('div'); wrap.id='v14771Picker'; wrap.className='v14771-picker';
    btn=document.createElement('button'); btn.type='button'; btn.id='v14771SelectedBtn'; btn.className='v14771-selected';
    btn.innerHTML='<span id="v14771SelectedText"><b>Chọn font Illustrator</b><span>Click để mở thư viện</span></span><i>⌄</i>';
    wrap.appendChild(btn);

    browser=document.createElement('div'); browser.id='v14771Browser'; browser.className='v14771-browser'; browser.style.display='none';
    browser.innerHTML=''
      +'<div class="v14771-toolbar"><input id="v14771Search" type="text" placeholder="Tìm font hoặc style…"><span id="v14771Count"></span><button type="button" id="v14771Close">Đóng</button></div>'
      +'<div id="v14771List" class="v14771-list"></div>';
    wrap.appendChild(browser);
    fontline.insertBefore(wrap, fontline.firstChild);

    btn.onclick=function(ev){ if(ev&&ev.preventDefault)ev.preventDefault(); if(browser.style.display==='none')openBrowser(); else closeBrowser(); return false; };
    input=$('v14771Search'); if(input){
      if(input.addEventListener){ input.addEventListener('input',scheduleRender,false); input.addEventListener('keyup',function(ev){ev=ev||window.event;if(ev.keyCode===27)closeBrowser();},false); }
      else if(input.attachEvent) input.attachEvent('onkeyup',scheduleRender);
    }
    close=$('v14771Close'); if(close) close.onclick=function(){closeBrowser();};
    list=$('v14771List'); if(list){ if(list.addEventListener) list.addEventListener('click',handleListClick,false); else if(list.attachEvent) list.attachEvent('onclick',handleListClick); }

    captureFonts(true); updateSelectedUi();
    return true;
  }

  function monitorFonts(){
    var sel=$('v1475FontSelect'); if(!sel) return;
    /* A reload from Illustrator repopulates the legacy select with hundreds/thousands of options. Capture once then collapse again. */
    if(sel.options.length>20){ captureFonts(true); }
  }

  var tries=0, init=setInterval(function(){
    tries++;
    if(buildUi()){
      if(!pollTimer) pollTimer=setInterval(monitorFonts,1200);
      if(ready && tries>12) clearInterval(init);
    }
    if(tries>80) clearInterval(init);
  },300);
})();
