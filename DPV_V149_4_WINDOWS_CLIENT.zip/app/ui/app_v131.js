(function(){
  "use strict";
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge');
    if(v){v.innerHTML='V131 MIXED ROTATION MAX · CORE V101 SAFE';}
    var b=q('.beta-note');
    if(b){b.innerHTML='<strong>DPV® V131 Mixed Rotation Max</strong><br>Exact Gap vẫn chính xác · tự thử lưới thẳng + phối ngang/dọc · chỉ dùng bố cục trộn khi thực sự tăng số con · giữ lề cứng/PON/VDP/Duplex.';}
  }
  if(document.readyState==='loading'){
    if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);
  }else{mark();}
})();
