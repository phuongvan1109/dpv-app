(function(){
  "use strict";
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge'); if(v){v.innerHTML='V130 MANUAL PREVIEW FIX · CORE V101 STABLE';}
    var b=q('.beta-note'); if(b){b.innerHTML='<strong>DPV® V130 Manual Preview Fix · Core V101 Stable</strong><br>Nhập kích thước → Tính nhanh V101 → View khuôn qua Illustrator dùng đúng Layout Cache, không chạy solver lần hai.';}
  }
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);}else{mark();}
})();
