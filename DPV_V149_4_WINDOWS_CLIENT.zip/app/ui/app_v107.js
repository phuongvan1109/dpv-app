(function(){
  "use strict";
  function byId(id){return document.getElementById(id);}
  function text(el,v){if(!el)return;if('textContent' in el)el.textContent=v;else el.innerText=v;}
  function status(msg,kind){
    var s=byId('status');if(s){s.className='status '+(kind||'');text(s,msg);}
    var log=byId('log');if(log){var r=document.createElement('div');r.className='log-line';text(r,msg);log.appendChild(r);log.scrollTop=log.scrollHeight;}
    var t=byId('dpvToast');if(t){text(t,msg);if((' '+t.className+' ').indexOf(' show ')<0)t.className+=' show';setTimeout(function(){t.className=(' '+t.className+' ').replace(' show ',' ').replace(/^\s+|\s+$/g,'');},2200);}
  }
  var pending=false;
  window.__DPVNativePonResult=function(path,err){
    var btn=byId('ponBtn');pending=false;if(btn){btn.disabled=false;text(btn,'Chọn PON');}
    if(err){status('Không mở được hộp thoại PON: '+String(err),'error');return;}
    path=String(path||'');
    if(!path){status('Đã hủy chọn PON.','');return;}
    var input=byId('ponPath');if(input){input.value=path;try{var ev=document.createEvent('HTMLEvents');ev.initEvent('change',true,false);input.dispatchEvent(ev);}catch(e){}}
    status('Đã chọn file PON: '+path,'ok');
  };
  function fallbackBridge(btn){
    try{
      if(window.DPVNative&&typeof window.DPVNative.invoke==='function'){
        window.DPVNative.invoke('ChoosePonFile',[]).then(function(v){window.__DPVNativePonResult(v,'');}).catch(function(e){window.__DPVNativePonResult('',(e&&e.message)||String(e));});
        return true;
      }
      if(window.external&&typeof window.external.ChoosePonFile!=='undefined'){
        window.__DPVNativePonResult(window.external.ChoosePonFile(),'');return true;
      }
    }catch(e){window.__DPVNativePonResult('',(e&&e.message)||String(e));return true;}
    return false;
  }
  function bind(){
    var old=byId('ponBtn');if(!old||!old.parentNode)return;
    var btn=old.cloneNode(true);btn.id='ponBtn';btn.className=(btn.className||'')+' dpv-native-dialog-button';old.parentNode.replaceChild(btn,old);
    btn.onclick=function(ev){
      ev=ev||window.event;try{if(ev.preventDefault)ev.preventDefault();if(ev.stopPropagation)ev.stopPropagation();}catch(e){}
      if(pending||btn.disabled)return false;
      pending=true;btn.disabled=true;text(btn,'Đang mở...');
      try{
        if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.dpvPon){
          window.webkit.messageHandlers.dpvPon.postMessage('choose');return false;
        }
      }catch(e0){}
      if(!fallbackBridge(btn))window.__DPVNativePonResult('','DPV Native Bridge chưa sẵn sàng.');
      return false;
    };
  }
  function mark(){
    var v=document.querySelector?document.querySelector('.version-badge'):null;if(v)text(v,'V108 ICON + NATIVE PON FIX · CORE V101 STABLE');
    var b=document.querySelector?document.querySelector('.beta-note'):null;if(b)b.innerHTML='<strong>DPV® V107 Native PON Fix · Core V101 Stable</strong><br>Mac dùng hộp thoại file native trực tiếp trong DPV.app, không còn sinh AppleScript Choose PON gây lỗi -2741.';
  }
  function start(){bind();mark();}
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',start);else window.attachEvent('onload',start);}else start();
})();
