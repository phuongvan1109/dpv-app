(function(){
  "use strict";
  function q(s){return document.querySelector?document.querySelector(s):null;}
  function mark(){
    var v=q('.version-badge'); if(v){v.innerHTML='V132 MIXED ROTATION SAFE · CORE V101';}
    var b=q('.beta-note'); if(b){b.innerHTML='<strong>DPV® V132 Mixed Rotation Safe</strong><br>Auto Max ngang/dọc có kiểm tra va chạm thật + Gap X/Y trước khi nhận bố cục · Live Preview xoay đúng 0/90 · giữ Core V101/PON/VDP/Duplex.';}
  }
  if(document.readyState==='loading'){if(document.addEventListener)document.addEventListener('DOMContentLoaded',mark,false);else window.attachEvent('onload',mark);}else{mark();}
})();
