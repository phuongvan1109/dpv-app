(function(){
  "use strict";
  function add(el,c){ if(!el)return; if((" "+(el.className||"")+" ").indexOf(" "+c+" ")<0) el.className += (el.className?" ":"")+c; }
  function rem(el,c){ if(!el)return; el.className=(" "+(el.className||"")+" ").replace(" "+c+" "," ").replace(/^\s+|\s+$/g,""); }
  function qs(s){ return document.querySelector ? document.querySelector(s) : null; }
  function viewport(){
    var de=document.documentElement||{};
    return {w:de.clientWidth||window.innerWidth||1400,h:de.clientHeight||window.innerHeight||850};
  }
  var timer=0,lastW=-1,lastH=-1;

  function removeLegacyLayoutClasses(b){
    var names=['dpv-layout-medium','dpv-layout-two','dpv-layout-stack','dpv-short-window','dpv-compact-sidebar','dpv-v117-wide','dpv-v117-stack','dpv-v117-compact','dpv-v117-tight','dpv-v117-mini','dpv-v117-tiny','dpv-v117-short'];
    for(var i=0;i<names.length;i++) rem(b,names[i]);
  }

  function applyLayout(){
    var b=document.body, vp=viewport();
    removeLegacyLayoutClasses(b);

    var ua=String(navigator.userAgent||'').toLowerCase();
    if(ua.indexOf('windows')>=0 || ua.indexOf('trident')>=0){ add(b,'dpv-windows'); add(b,'dpv-win-fast'); }
    else add(b,'dpv-mac');

    if(vp.w<1500) add(b,'dpv-v117-compact');
    var side=qs('.dpv-sidebar');
    var sideW=side ? (side.offsetWidth||0) : 0;
    var usable=vp.w-sideW-32;

    /* A single safe fallback is more reliable in IE11 than a fragile middle mode. */
    if(usable>=1180) add(b,'dpv-v117-wide');
    else add(b,'dpv-v117-stack');

    if(vp.w<1580) add(b,'dpv-v117-tight');
    if(vp.w<1240) add(b,'dpv-v117-mini');
    if(vp.w<980) add(b,'dpv-v117-tiny');
    if(vp.h<800) add(b,'dpv-v117-short');

    var top=qs('.topbar'), ws=qs('.workspace');
    if(top && ws){
      var topH=top.offsetHeight||68;
      var available=vp.h-topH;
      if(available<260) available=260;
      ws.style.height=available+'px';
    }
  }

  function mark(){
    var v=qs('.version-badge');
    if(v) v.innerHTML='V117 STABLE RESIZE · CORE V101 STABLE';
    var beta=qs('.beta-note');
    if(beta) beta.innerHTML='<strong>DPV® V117 Stable Resize · Core V101 Stable</strong><br>Windows dùng 1 vùng cuộn duy nhất để không mất nội dung khi maximize / restore / resize · tự chuyển 3 cột sang xếp dọc khi vùng hiển thị không đủ · không thay engine dàn, PON, VDP hay Bridge.';
  }

  function run(force){
    var vp=viewport();
    if(force || vp.w!==lastW || vp.h!==lastH){
      lastW=vp.w; lastH=vp.h;
      applyLayout(); mark();
      /* WebBrowser may report the final size a moment after maximize/restore. */
      setTimeout(applyLayout,70);
      setTimeout(applyLayout,220);
    }
  }
  function resized(){ if(timer)clearTimeout(timer); timer=setTimeout(function(){run(true);},30); }
  function start(){
    run(true);
    if(window.addEventListener){ window.addEventListener('resize',resized,false); window.addEventListener('load',function(){run(true);},false); }
    else if(window.attachEvent){ window.attachEvent('onresize',resized); window.attachEvent('onload',function(){run(true);}); }
    setTimeout(function(){run(true);},350);
    setTimeout(function(){run(true);},1000);
    /* Covers rare WinForms maximize/restore cases where IE11 misses resize. */
    setInterval(function(){run(false);},1500);
  }
  if(document.readyState==='loading'){
    if(document.addEventListener) document.addEventListener('DOMContentLoaded',start,false);
    else window.attachEvent('onload',start);
  } else start();
})();
