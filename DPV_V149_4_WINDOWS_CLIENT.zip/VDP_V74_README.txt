DPV V74 — LINKSAFE FAST VARIABLE DATA / FAST COMBINED PDF

- Sửa lỗi file PDF gộp bị trắng/mất link với artwork dùng ảnh linked (PlacedItem).
- Work document giờ relink lại theo đường dẫn tuyệt đối sau khi clone.
- Document PDF gộp giờ relink rồi embed ảnh linked để tránh mất hình khi save PDF.
- Vẫn giữ tốc độ nhanh của V73: clone 1 lần, không import PDF tạm, save PDF gộp 1 lần.

Khuyến nghị:
- Nếu artwork có nhiều ảnh linked, hãy dùng V74 thay cho V73.
- Nếu chỉ cần PDF gộp, có thể tắt xuất PDF riêng để nhanh nhất.
