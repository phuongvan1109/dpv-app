DPV V147.5.2 – WINDOWS FONT PICKER HOTFIX

Fixes the QR/Barcode Studio font picker on Windows WebBrowser/IE shell.
The previous UI attempted to filter <option> items with display:none, which is unreliable on this shell.
V147.5.2 rebuilds the dropdown with matching Illustrator fonts on each search.
No Barcode/QR/Bridge/Core engine changes.
