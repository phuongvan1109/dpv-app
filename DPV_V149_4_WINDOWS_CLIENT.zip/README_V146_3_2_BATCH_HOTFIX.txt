V146.3.2 HOTFIX
Root cause fixed: record batch dispatcher previously returned applied=0 for vector-code-only records.
The new append-only ANP_vdpApplyRecordV71 wrapper isolates code mappings and applies them directly.
Old jobs without QR/Barcode use the frozen V146.3.1 path unchanged.
