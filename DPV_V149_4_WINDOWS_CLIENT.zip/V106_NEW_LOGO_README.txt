DPV® V106 — NEW LOGO / ICON UPDATE

- Thay icon ứng dụng Windows và Mac Intel bằng hình cô gái đeo kính ôm chú chó DPV do người dùng cung cấp.
- Thay favicon + logo trong sidebar/giao diện DPV bằng cùng hình mới.
- Windows: icon đa kích thước 16–256 px trong DPV.ico + PNG 16–1024 px.
- Mac Intel: DPV.icns + PNG 1024 px mới.
- Giữ nguyên PON Hotfix V105, Fluid Motion, Live Preview và Core V101 STABLE.
- Không thay thuật toán dàn, Exact Gap, True-Shape, Demi, VDP hoặc PDF Combine.
