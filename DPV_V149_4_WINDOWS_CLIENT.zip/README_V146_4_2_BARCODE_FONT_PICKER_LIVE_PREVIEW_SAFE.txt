DPV V146.4.2 – BARCODE FONT PICKER + LIVE STYLE PREVIEW SAFE

Built from V146.4.1 stable base.
Adds:
- quick font picker + exact Illustrator Family/PostScript font name field
- font size in pt, tracking, Regular/Bold, left/center/right alignment for Code128
- Text sống / Outline mode
- UI preview of current record human-readable barcode text
- direct “Preview thật trong Illustrator” before batch

Code128 AUTO A/B/C from V146.4 remains active.
EAN-13 keeps standard number layout; font/size/tracking/live-outline still apply.
QR, Core V101, VDP Sheet, Cut & Stack, Duplex, Recovery, Planner and presets are not intentionally modified.
