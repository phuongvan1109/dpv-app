DPV V109 — COCOA NATIVE PON PANEL HOTFIX

MAC INTEL
- Sửa dứt điểm lỗi Chọn PON báo AppleScript/JXA syntax error -2741.
- Bỏ Standard Additions chooseFile().
- Dùng trực tiếp Cocoa NSOpenPanel trong DPV.app.
- Hỗ trợ AI / EPS / PDF / SVG, Cancel an toàn, đường dẫn Unicode/tiếng Việt/khoảng trắng.
- Không sửa Core V101 STABLE, không thay thuật toán dàn.

WINDOWS
- Giữ nguyên cơ chế chọn PON WinForms ổn định của V108.

ICON
- Giữ icon cô gái + chó DPV của V108.
