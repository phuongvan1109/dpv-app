DPV V97 — AUTO MAX EXACT GAP

MỤC TIÊU
- Chỉ cần bật 1 chế độ: Tối ưu tự động: khoảng cách đều chính xác + số con tối đa.
- Không còn dừng ở solver Exact Gap FAST đầu tiên.
- DPV thử Profile hàng/cột, khóa nhau 90/270, 0/180 và so le chính xác, rồi chọn layout có số con lớn nhất.
- Tăng số pha khóa thử từ 4 lên 15 pha đối xứng để không bỏ lỡ kiểu khóa khuôn lệch tâm.
- Vẫn giữ Layout Cache / Low-Lag của V96.

LƯU Ý HÌNH HỌC
Nếu một số lượng (ví dụ 28) thực sự không thể fit trong khổ với khe contour >= 2.000 mm, DPV sẽ trả số exact tối đa thấp hơn. V97 không gian lận bằng cách giảm khe.
