DPV V116 RESIZE HOTFIX
- Sửa lỗi giao diện còn mất nội dung khi phóng to / thu nhỏ cửa sổ trên Windows.
- Tự đo lại vùng làm việc thực tế và chuyển 3 cột / 2 hàng / xếp dọc phù hợp.
- Cho topbar tự xuống dòng an toàn, workspace tự tính lại chiều cao.
- Giảm lag khi resize nhờ tắt thêm transition nặng trên Windows.
- Không thay đổi engine dàn, PON, Variable Data hay Bridge Illustrator.
