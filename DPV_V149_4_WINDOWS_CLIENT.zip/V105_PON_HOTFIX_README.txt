DPV V105 — PON PICKER HOTFIX

- Sửa nút Chọn PON không phản hồi sau V104 Fluid Motion.
- Tách các nút mở hộp thoại hệ thống khỏi hiệu ứng ripple/mousedown để tránh WebBrowser/WKWebView nuốt click.
- Nút PON được bind lại bằng bridge độc lập, hoạt động trên Windows và Mac Intel.
- Không thay đổi Core V101 STABLE, thuật toán dàn, Exact Gap, lề, True-Shape, Demi, VDP.
