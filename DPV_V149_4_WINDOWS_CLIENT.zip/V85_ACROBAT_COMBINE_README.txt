DPV V85 — ACROBAT POST-COMBINE

CÁCH KHUYẾN NGHỊ CHO 100+ RECORD
1. Bật “Xuất PDF riêng từng record”.
2. Nếu muốn 1 file nhiều trang, bật “Sau khi xuất PDF riêng → Combine bằng Adobe Acrobat”.
3. DPV render từng record trong Illustrator như V79/V80 Stream Low-RAM.
4. Sau khi record cuối hoàn tất, Illustrator không dựng document merge. Desktop Bridge gọi Adobe Acrobat để gộp PDF theo đúng thứ tự record.
5. Các PDF record vẫn được giữ lại để kiểm tra hoặc chạy lại Combine.

NÚT COMBINE PDF CÓ SẴN
- Bấm “Combine các PDF có sẵn bằng Acrobat”.
- Chọn nhiều PDF.
- Chọn tên file đích.
- DPV dùng Acrobat PDDoc InsertPages, không mở/dàn artwork trong Illustrator.

LƯU Ý
- Cần Adobe Acrobat Standard/Pro. Reader chỉ đọc PDF và không hỗ trợ chức năng chỉnh sửa/gộp này qua COM.
- Nếu Acrobat không có, phần xuất PDF record vẫn hoàn tất; Combine sẽ báo lỗi riêng.
