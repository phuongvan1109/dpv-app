DPV V146.4.1 – BARCODE TEXT VISIBILITY + FONT SAFE

Built from V146.4 stable base.
Fixes human-readable text under barcode being invisible / hidden against white barcode background.
Font name, font size (pt), tracking, and live/outline mode are supported more reliably for Code128 and EAN-13.
Code128 AUTO A/B/C remains active.
