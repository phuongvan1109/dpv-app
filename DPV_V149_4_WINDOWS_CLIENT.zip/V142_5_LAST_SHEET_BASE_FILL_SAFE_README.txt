DPV V142.5 — LAST-SHEET BASE FILL SAFE

MỤC TIÊU
- Tờ cuối thiếu record vẫn giữ đúng layout/vị trí như mọi tờ trước.
- Record thật luôn đi từ VT1 trở đi theo Thứ tự gán record hiện tại.
- Mỗi vị trí thiếu vẫn đặt FILE GỐC vào đúng slot, nhưng work-copy được restore về trạng thái gốc trước khi xuất filler PDF nên KHÔNG áp dữ liệu biến đổi.
- CUT & STACK tự ép lastSheetMode=basefill, không dồn giữa và không bỏ trống artwork.

AN TOÀN / ADDITIVE
- Không sửa body hàm V141.2/V142.x hiện hữu. Host chỉ APPEND wrapper V142.5 ở cuối file.
- Core V101 / packer / multipacker / trueshape / CSV Bridge / SMART / Duplex / Cut & Stack cũ giữ nguyên.
- Các mode legacy "Để trống" và "Dồn giữa" vẫn còn cho VDP Sheet thường; V142.5 đặt Base Fill làm mặc định.

VÍ DỤ 8 VỊ TRÍ/TỜ, CÒN 5 RECORD
VT1..VT5 = record thật + dữ liệu biến đổi
VT6..VT8 = file gốc / NO DATA
Không dồn VT1..VT5 vào giữa tờ.
