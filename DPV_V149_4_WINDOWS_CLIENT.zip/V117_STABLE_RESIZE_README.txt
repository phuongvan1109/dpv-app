DPV V117 STABLE RESIZE
- Windows: bỏ nested scroll trong 3 cột; chỉ workspace cuộn.
- Maximize / restore / resize không làm mất panel.
- Nếu chiều rộng CSS không đủ (kể cả DPI 125/150%), tự xếp 3 panel theo chiều dọc.
- Topbar ẩn thành phần phụ trước khi bị tràn.
- Không thay Core V101, PON, VDP, Illustrator Bridge.
