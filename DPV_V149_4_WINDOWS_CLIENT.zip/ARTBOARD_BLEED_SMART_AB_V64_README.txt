DPV® V64 — ARTBOARD / BLEED / AB THÔNG MINH

1. CHỌN ARTBOARD
- Kích thước thành phẩm luôn lấy trực tiếp từ artboardRect của Illustrator.
- Artwork, bleed và KHUON_BE nằm tràn ngoài artboard không làm sai kích thước tem.
- Ví dụ artboard 105x148 mm luôn được nhận là 105x148 mm, không còn thành 109x152 mm.

2. BLEED FILE IN
- Link in được cắt theo artboard cộng đúng giá trị “Bleed trong Link”.
- Mặt A và mặt B dùng cùng một quy tắc crop nên vùng tràn hai mặt bằng nhau.
- Bleed chỉ thuộc nội dung in; không làm thay đổi kích thước thành phẩm và số con.

3. QUY TẮC AB HAI MẶT
- Mặt B giữ nguyên vị trí từng con của mặt A.
- Góc mặt B là góc bù của mặt A: 0°→0°, 90°→270°, 270°→90°.
- Không phản toàn tờ theo trục Y và không cộng 180° cho mọi con.

4. TỐI ƯU KHUÔN ĐẶC BIỆT
- Chế độ Siêu nhẹ nhận khuôn đối xứng như vòm, chữ D và chỉ thử các góc có ý nghĩa.
- Giảm mạnh số phép thử hình học nhưng vẫn giữ đủ 0°/90°/180°/270° để dàn so le.
- Tắt “Siêu nhẹ” khi cần dò đầy đủ mọi góc theo bước góc đã chọn.

PHIÊN BẢN
- Windows: DPV® Desktop Beta 0.1.19 V64.
- macOS Universal: DPV® Beta 0.2.4 V64, Intel + Apple Silicon.
