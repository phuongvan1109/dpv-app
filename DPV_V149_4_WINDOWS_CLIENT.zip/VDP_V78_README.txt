DPV V78 — AUTO-SAVE FIDELITY FIX

Lỗi đã sửa:
V76/V77 yêu cầu sourceDoc.saved === true. Sau khi Preview rồi Restore, Illustrator vẫn coi file là Modified nên bấm Chạy có thể thất bại dù nội dung nhìn đã trở lại bình thường.

V78:
1. Restore nội dung gốc.
2. Nếu file .AI đang Modified, tự Save.
3. Copy nguyên file AI sang work-copy tạm.
4. Chạy VDP trên work-copy.
5. Xóa work-copy sau khi hoàn tất.

Không cần Ctrl+S lại sau mỗi lần Preview. File vẫn phải có đường dẫn .AI ít nhất một lần (Save As .AI nếu là file mới).
