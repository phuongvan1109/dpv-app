DPV® V65 — LẤY FILE ĐANG MỞ KHÔNG QUÉT TOÀN BỘ ARTWORK

VẤN ĐỀ ĐÃ SỬA
- V64 quét pageItems, group, compound path và Bézier của cả file ngay khi bấm “Lấy file đang mở”.
- File nhiều chi tiết khiến Illustrator Not Responding và toàn máy bị lag.

CƠ CHẾ V65
1. Lấy tên tài liệu, artboard đang hoạt động, kích thước và đường dẫn trước.
2. Chỉ thử tối đa 32 vector trong layer có tên KHUON_BE/DIE/CUT.
3. File nhỏ mới kiểm tra nhanh stroke có tên/màu khuôn.
4. File lớn chưa nhận được khuôn sẽ trả artboard ngay, không quét toàn bộ artwork.
5. KHUON_BE thật vẫn được quét khi xem trước hoặc xuất, nên không làm giảm độ chính xác của PDF/KHUÔN.
6. Kết quả metadata được cache theo tài liệu, artboard và số lượng đối tượng.

KHI THẺ NGUỒN HIỆN “ĐỌC NHANH · KHUÔN KHI XUẤT”
- Số con trong sơ đồ nhanh là ước tính theo artboard.
- Khi bấm xem/xuất, DPV® sẽ đọc contour thật.
- Muốn xem số con True-Shape chính xác ngay: chọn contour khuôn trong Illustrator rồi bấm “Lấy khuôn đang chọn”.
