DPV V147.6 – TRUE DIE PREVIEW SAFE

Preview-only hotfix built from V147.5.2.
The final FILE KHUON export path is not changed.
Fix: OpenDiePreview no longer prefers fast cached shape when real KHUON_BE geometry exists; it falls through to the real serialized Bezier die geometry.
This prevents artwork/text outlines (for example giant W contours) from appearing in die preview while exported die remains correct.
