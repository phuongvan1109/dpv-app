DPV V143.1 — RECOVERY STARTUP SAFE HOTFIX

BASE: V142.5 LAST-SHEET BASE FILL SAFE (byte-for-byte stable runtime, except index loader additions).

ROOT CAUSE FIXED
- V143 used a MutationObserver on document.body with subtree=true.
- The observer called initOnce() after every DOM mutation.
- initOnce()/renderHistory() changed the V143 panel DOM again.
- That could trigger a self-sustaining MutationObserver feedback loop and starve the UI event loop while the splash screen was still visible.

V143.1 CHANGES
- Removes the body-wide MutationObserver completely.
- Recovery module starts only 850 ms AFTER the normal window load event, allowing V142.5 splash/startup to complete first.
- Uses a lightweight 1400 ms element scan only to attach to dynamically-created VDP controls.
- Status MutationObserver is scoped only to #vdpStatus and reconnects safely if the VDP panel is recreated.
- No Core/Bridge/VDP/Cut&Stack/Duplex/host change.

STABLE RULE
V142.5 is the immutable base. V143.1 adds only:
  app_v143_1_recovery_startup_safe.js
  style_v143_1_recovery_startup_safe.css
plus one CSS loader and one JS loader in index.html.
