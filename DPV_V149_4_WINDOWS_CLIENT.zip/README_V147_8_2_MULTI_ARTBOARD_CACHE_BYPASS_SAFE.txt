DPV V147.8.2 — MULTI ARTBOARD CACHE BYPASS SAFE

Fixes a logic bug in V99/V101 UI cache when Multi Artboard contains more than one size group.

Root cause:
- local preview grouped artboards by size (e.g. 80x20 and 80x15)
- rememberLayoutV99 deliberately cleared the global cache when groupCount != 1
- hostPreview / diePreview / Build then immediately required that same cache and threw “Layout Cache V99 không khớp…”

Fix:
- Artboard mode no longer requires global V99/V101 layout cache
- native artboard pipeline ANP_v12Preview / ANP_v12Build / ANP_v14DiePreview computes each size group independently, as originally designed
- File mode cache behavior is unchanged
- Multi-group preview count now shows per-group counts, e.g. 58 / 75 instead of the misleading group count 2

Built from V147.8.1.
