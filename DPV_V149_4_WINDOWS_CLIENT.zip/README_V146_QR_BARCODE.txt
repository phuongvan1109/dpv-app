DPV V146 — QR & BARCODE VECTOR SAFE

CÁCH DÙNG
1. Mở file Illustrator và chọn một shape/khung giữ chỗ đúng kích thước mã cần tạo.
2. Mở Biến đổi dữ liệu VDP.
3. Chọn CSV/TXT và bấm + Thêm vị trí đang chọn trong AI.
4. Chọn cột dữ liệu.
5. Ở Action chọn:
   - QR Code · Vector
   - Barcode Code 128 · Vector
6. Preview record trong Illustrator để kiểm tra.
7. Chạy VDP / VDP Sheet / Cut & Stack như workflow hiện tại.

QR CODE
- Vector CMYK 100K, có quiet zone 4 module.
- Hỗ trợ UTF-8.
- V146 hỗ trợ QR Version 1–6, mức sửa lỗi L, tối đa an toàn khoảng 132 byte UTF-8/record.

CODE 128
- Code 128-B, tự tính checksum.
- Hỗ trợ ASCII ký tự 32–126.
- Vector bar 100K, có quiet zone.

AN TOÀN
- V145 là stable base.
- UI mới chỉ thêm action vào dropdown mapping.
- Host addon chỉ xử lý khi action là qrVector/code128Vector; action cũ delegate nguyên hàm VDP V145.
- Core V101 / CSV Bridge / Cut & Stack / Duplex / Recovery / Planner / Job Preset không đổi.
