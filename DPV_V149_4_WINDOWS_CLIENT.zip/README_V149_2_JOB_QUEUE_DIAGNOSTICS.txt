DPV V149.2
- Job Queue Pro: Pause/Resume next jobs, cancel pending, history, retry failed jobs.
- ETA/progress is explicitly an estimate based on rolling historical duration per job type.
- Diagnostics ZIP: diagnostics.json, bridge-log.txt, sources.csv, README.txt. No artwork included.
- Native Batch Bridge + Geometry Cache V149.1 remains active.
