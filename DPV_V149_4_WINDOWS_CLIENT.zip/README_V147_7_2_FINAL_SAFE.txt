DPV V147.7.2 - STANDALONE BRIDGE + FONT COMMIT FINAL SAFE

Patched directly from the user's uploaded V147.7.1 package.

Fixes:
1. QR/Barcode Standalone create response is handled by one final cross-platform state.
2. EAN-13 invalid 12/13 digit/checksum data is reported immediately instead of hanging on "Dang tao".
3. Exact Illustrator PostScript font name is the canonical font state.
4. New lightweight font browser renders max 30 results; it does not build 2000 live preview rows.
5. Font-list Bridge responses are consumed by the final picker to avoid older modules rebuilding 2000 options.
6. Works for both Mac Intel and Windows package trees.

Stable production Core/VDP/layout algorithms are not modified by this UI hotfix.
