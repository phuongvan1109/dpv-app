DPV V147 – QR/BARCODE STANDALONE STUDIO SAFE

Built from V146.4.3 stable base.
Additive-only module for creating QR / Barcode independently, without using Variable Data mapping flow.
Features added in UI:
- QR Code standalone
- Barcode Code128 AUTO standalone
- Barcode EAN-13 standalone
- single-create mode
- batch create from pasted lines
- create into selected object or centered on artboard
- barcode font / pt size / text mode controls
