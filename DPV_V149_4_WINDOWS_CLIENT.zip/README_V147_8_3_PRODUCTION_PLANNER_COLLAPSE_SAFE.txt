DPV V147.8.3 — PRODUCTION PLANNER COLLAPSE SAFE

Built from V147.8.2. UI-only additive patch.
- Production Planner starts collapsed by default.
- Collapsed header still shows target quantity, waste %, pieces/sheet and sheets needed.
- Click header or Open/Collapse button to toggle.
- Expanded/collapsed state is remembered locally.
- Production Planner calculation logic, Core, Bridge and layout engines are unchanged.
