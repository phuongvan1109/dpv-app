@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul

set "DPV_SOURCE=%~dp0"
set "DPV_TARGET=%LOCALAPPDATA%\DPV"
set "DPV_EXE=%DPV_TARGET%\DPV.exe"
set "DPV_CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%DPV_CSC%" set "DPV_CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"

echo.
echo ================================================
echo       DPV V148.1 CLOUDFLARE FREE - WINDOWS
echo       V147.8.x CORE + CLOUDFLARE ACCOUNT LICENSE
echo ================================================
echo.

if not exist "%DPV_SOURCE%src\VDPRO.cs" (
  echo LOI: Khong tim thay src\VDPRO.cs.
  echo.
  echo Ban dang chay installer ben trong file ZIP hoac thu muc chua giai nen day du.
  echo Hay chon Extract All... roi chay lai CAI_DPV_WINDOWS.bat trong thu muc da giai nen.
  echo.
  pause
  exit /b 1
)

if not exist "%DPV_CSC%" (
  echo LOI: Khong tim thay .NET Framework 4.x compiler.
  echo Hay bat .NET Framework 4.8 trong Windows Features roi chay lai.
  pause
  exit /b 1
)

echo [1/4] Dong DPV cu...
taskkill /IM DPV.exe /F >nul 2>&1
taskkill /IM VDPRO.exe /F >nul 2>&1

if not exist "%DPV_TARGET%" mkdir "%DPV_TARGET%"

echo [2/4] Sao chep file...
xcopy "%DPV_SOURCE%app" "%DPV_TARGET%\app\" /E /I /Y /Q >nul
if errorlevel 1 goto COPY_ERROR
xcopy "%DPV_SOURCE%assets" "%DPV_TARGET%\assets\" /E /I /Y /Q >nul
if errorlevel 1 goto COPY_ERROR
xcopy "%DPV_SOURCE%bridge" "%DPV_TARGET%\bridge\" /E /I /Y /Q >nul
if errorlevel 1 goto COPY_ERROR
xcopy "%DPV_SOURCE%src" "%DPV_TARGET%\src\" /E /I /Y /Q >nul
if errorlevel 1 goto COPY_ERROR

for %%F in (README_VI.txt VERSION.txt VDP_SAMPLE.csv uninstall_windows.bat) do (
  if exist "%DPV_SOURCE%%%F" copy /Y "%DPV_SOURCE%%%F" "%DPV_TARGET%\%%F" >nul
)

if not exist "%DPV_TARGET%\src\VDPRO.cs" goto COPY_ERROR

echo [3/4] Tao DPV.exe...
"%DPV_CSC%" /nologo /codepage:65001 /target:winexe /platform:x64 /optimize+ ^
  /out:"%DPV_EXE%" ^
  /win32icon:"%DPV_TARGET%\assets\icon\DPV.ico" ^
  /reference:System.dll ^
  /reference:System.Core.dll ^
  /reference:System.Drawing.dll ^
  /reference:System.Windows.Forms.dll ^
  /reference:System.Web.Extensions.dll ^
  "%DPV_TARGET%\src\VDPRO.cs"
if errorlevel 1 goto COMPILE_ERROR

echo [4/4] Tao shortcut Desktop...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell;$n='DPV'+[char]174;$p=Join-Path ([Environment]::GetFolderPath('Desktop')) ($n+'.lnk');$s=$w.CreateShortcut($p);$s.TargetPath='%DPV_EXE%';$s.WorkingDirectory='%DPV_TARGET%';$s.IconLocation='%DPV_EXE%,0';$s.Description=$n;$s.Save()" >nul 2>&1

echo.
echo ================================================
echo CAI DAT HOAN TAT.
echo DPV se duoc mo ngay bay gio.
echo ================================================
echo.
start "" "%DPV_EXE%"
pause
exit /b 0

:COPY_ERROR
echo.
echo LOI SAO CHEP FILE.
echo Hay giai nen ZIP vao thu muc ngan, vi du D:\DPV_V142_1_SAFE, roi chay lai.
pause
exit /b 1

:COMPILE_ERROR
echo.
echo LOI TAO DPV.exe.
echo Chup man hinh phan loi nay gui de kiem tra.
pause
exit /b 1
