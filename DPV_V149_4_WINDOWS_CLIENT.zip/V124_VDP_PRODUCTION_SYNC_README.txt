DPV V124 VDP PRODUCTION SYNC
- VDP Sheet dùng đúng Layout Cache V101 của màn Dàn file.
- Tự kế thừa Bleed trong Link (tràn nền) từ Dàn file.
- Nếu PON cắt theo thành phẩm (CATTP) bật ở Dàn file, mỗi tờ VDP tự dựng CATTP theo chính các vị trí record có mặt trên tờ đó.
- Kế thừa chiều dài/gap PON CATTP, PON file/Auto PON, màu PON góc, tiêu đề và preserve color.
- Record PDF tạm mở rộng ArtBox theo bleed rồi đặt lệch -bleed để mép thành phẩm vẫn trùng tọa độ V101.
- Tờ cuối thiếu record chỉ dựng PON CATTP cho các vị trí thực sự có record.
