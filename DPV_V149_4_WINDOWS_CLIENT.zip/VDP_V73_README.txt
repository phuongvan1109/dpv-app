DPV V74 — LINKSAFE FAST VARIABLE DATA / FAST COMBINED PDF

MỤC TIÊU V74
Tăng tốc khi gộp rất nhiều record thành một PDF nhiều trang.

CƠ CHẾ MỚI
1) Tài liệu làm việc chỉ được clone 1 lần cho toàn bộ batch.
2) Mỗi record: khôi phục trạng thái gốc -> áp dữ liệu -> copy artwork trực tiếp vào tài liệu PDF gộp.
3) Không còn tạo hàng trăm PDF tạm rồi mở/import từng trang PDF như V72.
4) Chỉ save PDF gộp đúng 1 lần ở cuối batch.
5) Khi chạy batch, app.redraw() được bỏ qua để giảm thời gian Illustrator render màn hình.

CÁCH DÙNG
- Nếu chỉ cần 1 PDF gộp nhanh nhất: bỏ tick “Xuất PDF riêng từng record”, giữ tick “Gộp nhanh tất cả record vào 1 PDF nhiều trang”.
- Nếu cần cả PDF riêng + PDF gộp: bật cả hai. V73 vẫn nhanh hơn V72 ở phần gộp vì không import lại PDF.
- Với dữ liệu rất lớn, nên chia batch để mỗi PDF gộp không vượt 950 trang/artboard.

LƯU Ý
- Ảnh biến đổi vẫn dùng Linked/PlacedItem.
- File AI gốc không bị save đè; V73 làm việc trên bản clone.


V74 FIX
- Sửa lỗi artwork có ảnh link/placed item bị ô trắng khi xuất PDF gộp nhanh.
- Khi copy sang document gộp, DPV sẽ relink theo đường dẫn tuyệt đối và embed ảnh link vào document gộp để PDF không mất hình.
