DPV® V108 — ICON REFRESH + NATIVE PON FIX

- Icon ứng dụng Windows và Mac Intel dùng đúng hình cô gái đeo kính ôm chú chó DPV do người dùng cung cấp.
- Windows: DPV.exe + shortcut Desktop dùng DPV.ico đa kích thước mới.
- Mac Intel: Finder/Dock dùng DPV-v108.icns mới để buộc làm mới icon cache; vẫn giữ DPV.icns tương thích.
- Logo/sidebar/favicon trong giao diện dùng cùng artwork.
- Giữ Native PON Fix V107 trên Mac (không dùng AppleScript choose file gây lỗi -2741).
- Core V101 STABLE và toàn bộ thuật toán dàn không thay đổi.
