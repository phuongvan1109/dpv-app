DPV V148.8 — LICENSE EXPIRY DISPLAY + REGISTER

1) Ngày hết hạn do chủ app đặt trong trang /admin, ô Hết hạn.
2) Sau khi đăng nhập, DPV hiện HSD ngay cạnh email:
   - HSD: Không giới hạn
   - HSD: 30/09/2026 · còn 16 ngày
   - Còn <= 7 ngày sẽ cảnh báo màu vàng.
3) Khi chủ app đổi hạn dùng, DPV tự cập nhật ở lần validate tiếp theo (mặc định 10 phút), không cần đăng nhập lại.
4) Khi quá hạn, server chặn đăng nhập/validate như trước.
5) Đăng ký email/mật khẩu đang hoạt động: email hợp lệ, mật khẩu tối thiểu 8 ký tự.
   Tài khoản mới mặc định pending và phải được chủ app duyệt.
