DPV V87 — SỬA BẾ 1 DAO DEMI

1. Bật “Bế 1 dao Demi – lưới thẳng”.
2. DPV tự đặt Gap X/Y = 0 và tạm khóa True-Shape/Khuôn đặc biệt/Khe đều/chừa góc.
3. “Cho phép xoay” vẫn dùng được: DPV thử 0° và 90° rồi chọn hướng có nhiều con hơn.
4. Tắt Demi để trở lại dàn thường; gap cũ được phục hồi.

V87 cũng đổi tên file JS để tránh Windows WebBrowser nạp cache app/engine cũ, nguyên nhân có thể gây lỗi “Unable to get property value of undefined or null reference”.
