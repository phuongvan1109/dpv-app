DPV V147.7.7 – FULL FONT LIBRARY SAFE

Built from V147.7.6 Bridge Version Lock baseline.
Fix: Illustrator font enumeration no longer stops at 2000 styles.
- The host iterates ALL app.textFonts.
- UI still renders only a small result window, so searching/browsing stays light.
- A new cache key avoids reusing the old truncated 2000-font cache.
- Press the refresh (↻) button once after installing to build the new FULL cache.
- Core/VDP/layout/barcode engines are not changed by this patch.
