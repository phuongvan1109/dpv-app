DPV V147.7.4 – STANDALONE DIRECT ENGINE FINAL SAFE

Root fix:
- Standalone QR / Code128 / EAN-13 no longer calls the VDP mapping dispatcher ANP_vdpApplyOneV71.
- Direct drawing engine is isolated from VDP wrappers and persistent targetengine state.
- Old V147 create buttons are hidden; new unique button IDs prevent old document-level click handlers from sending duplicate requests.
- Mac and Windows use the existing stable PreviewVariableData transport only as transport; the drawing engine itself is standalone.
