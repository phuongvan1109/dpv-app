DPV V147.7.1 - FAST FONT BROWSER + COMMIT HOTFIX

Built from V147.7 stable base.
Fixes:
- clicking a font family now commits its preferred Regular/Book/Roman style immediately
- clicking an exact style commits its PostScript name immediately
- avoids rendering 2000+ font rows at once
- renders only a small result window and only expands styles for one family
- legacy 2000-option select/search are neutralized to reduce Windows WebBrowser lag
No QR/Barcode engine, Bridge, Core, VDP, Cut & Stack, Duplex or Multi-Artboard logic is changed.
