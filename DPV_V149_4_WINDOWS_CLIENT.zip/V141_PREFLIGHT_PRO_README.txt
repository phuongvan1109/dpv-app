DPV® V141 PREFLIGHT PRO · CORE V101 STABLE
Build 2026-09-06

MỤC TIÊU V141
- Bắt lỗi dữ liệu VDP trước khi batch chạy, giảm tình trạng chạy hàng trăm record rồi mới dừng.
- Không rewrite Core V101 và không thay pipeline V140.1 Work-Copy Rebind.

NÂNG CẤP CHÍNH
1. Preflight VDP cục bộ tự cập nhật:
   - Record / phạm vi Từ–Đến.
   - Mapping thiếu cột, target ID trống, target bị map lặp.
   - TextFrame / PlacedItem không đúng loại cho Text hoặc Image.
   - Text rỗng, ảnh rỗng, Fill Color sai định dạng.
   - Thư mục xuất và layout VDP Sheet.
2. Kiểm tên PDF trước khi chạy:
   - Phát hiện tên trùng sau đúng quy tắc sanitize của engine.
   - Cảnh báo ký tự Windows/macOS không hợp lệ và tên > 90 ký tự.
   - Cảnh báo ô tên file trống.
3. Kiểm tra sâu bằng Illustrator nhưng KHÔNG sửa artwork:
   - Target đang tồn tại trong file AI nguồn.
   - Đúng loại TextFrame / PlacedItem.
   - File ảnh Linked thực sự tồn tại (đường dẫn đầy đủ hoặc tương đối thư mục CSV/TXT).
   - Fill Color hợp lệ.
4. Nút “Đi tới record lỗi đầu” để sửa/Preview nhanh.
5. Preflight sâu dùng lại kênh PreviewVariableData hiện có nên tương thích Windows + Mac Intel, không cần đổi native bridge binary.

GIỮ NGUYÊN
- Core V101 / Exact Gap / Mixed Rotation / True Shape / solver dàn.
- PON / CATTP / Duplex / Bleed.
- CSV / Dãy số / CSV + Dãy số.
- Font Fidelity V136/V137 / No-Stroke V138.
- V140.1 Work-Copy UUID Rebind khi batch VDP.

LƯU Ý
- Kiểm tra cục bộ tự chạy khi dữ liệu/mapping thay đổi.
- “Kiểm tra sâu Illustrator” là read-only: không Preview record, không đổi text/image/fill trong artwork.
- Preflight báo lỗi để bạn sửa trước; V141 không tự ý bỏ record lỗi hoặc sửa dữ liệu.
