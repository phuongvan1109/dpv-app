DPV V147.8.1 – DIE CONTOUR GUARD SAFE

Built directly from V147.8 VDP TEXT TRACKING SAFE.

Fix:
- Prevent internal red artwork/text/logo outlines from being inferred as KHUON_BE.
- Priority: directly named die > closed stroke-only red/spot contour > inherited named contour > legacy fallback.
- Filled red artwork such as QC PASS / letter Q is excluded whenever a valid stroke-only die contour exists.
- Existing VDP text tracking from V147.8 is preserved.

Production scope:
- Core packer/layout unchanged.
- VDP/QR/Barcode/Cut & Stack/Duplex unchanged.
- Only die inference in Illustrator host is overridden append-only.
