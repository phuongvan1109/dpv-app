DPV V115 — RESPONSIVE FAST UI / CORE V101 STABLE

WINDOWS
- Responsive shell: compact sidebar below 1370 px; 2-row layout below 1120 px; full vertical stack below 930 px.
- Workspace becomes scrollable on short windows instead of clipping content.
- VDP panels also wrap/stack on small windows.
- Windows Fast UI disables expensive ripple/pulse/large shadows and removes the visual-only motion script from startup.
- KPI polling reduced from 700 ms to 1600 ms on Windows.
- Minimum WinForms window lowered to 900 x 620; DPI autoscale enabled.

SAFETY
- Core V101 JS engines, True-Shape, Illustrator host.jsx/host_bundle.jsx, PON logic, VDP Sheet and dialog functions are unchanged.
