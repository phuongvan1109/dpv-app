DPV® V148.1 — CLOUDFLARE FREE ACCOUNT / DEVICE LICENSE
=======================================================

MỤC TIÊU
- Không cần VPS, không cần server chạy 24/24 trên máy của bạn.
- Cloudflare Worker + D1 làm máy chủ tài khoản/license online.
- Windows và Mac dùng chung 1 database.
- Tài khoản mới mặc định PENDING: chủ app phải duyệt ACTIVE mới dùng được.
- Admin xem email, thiết bị, phiên bản DPV, lần login, nhật ký đăng ký/login.
- Có khóa tài khoản, giới hạn số máy, ngày hết hạn, thu hồi/kích hoạt lại máy.
- Email/password hoạt động ngay sau khi deploy. Google Login là bước tùy chọn.

CẦN CHUẨN BỊ (MIỄN PHÍ)
1) Tài khoản Cloudflare.
2) Node.js 20+ trên máy dùng để deploy lần đầu.
3) Không cần mua domain: dùng URL *.workers.dev miễn phí.

CÀI NHANH WINDOWS
1) Mở thư mục DPV_CLOUDFLARE_FREE.
2) Chạy SETUP_FIRST_TIME_WINDOWS.bat.
3) Trình duyệt mở Cloudflare -> đăng nhập/cho phép Wrangler.
4) Khi hỏi ADMIN_PASSWORD, nhập mật khẩu trang quản trị của bạn.
5) Script tự tạo D1, schema, secrets, deploy Worker và cố gắng tự gắn URL vào cả bản Windows + Mac.
6) URL được lưu trong WORKER_URL.txt.
7) Trang quản trị: <WORKER_URL>/admin ; username mặc định: admin.
8) Cài DPV Windows bằng CAI_DPV_V148_1_WINDOWS.bat.

CÀI NHANH MAC
1) chmod +x SETUP_FIRST_TIME_MAC.command (nếu macOS bỏ quyền execute).
2) Chạy SETUP_FIRST_TIME_MAC.command.
3) Làm theo hướng dẫn tương tự Windows.
4) Sau đó cài DPV bằng INSTALL_DPV_V148_1_MAC_INTEL.command.

GOOGLE/GMAIL LOGIN (TÙY CHỌN)
- Email/password không cần Google Cloud.
- Để bật nút Google:
  1) Xem WORKER_URL.txt.
  2) Trong Google Cloud tạo OAuth Client: Web application.
  3) Authorized redirect URI = <WORKER_URL>/google/callback
  4) Windows chạy CONFIGURE_GOOGLE_WINDOWS.bat; Mac chạy CONFIGURE_GOOGLE_MAC.command.
  5) Nhập GOOGLE_CLIENT_ID và GOOGLE_CLIENT_SECRET khi Wrangler yêu cầu.

QUẢN LÝ USER
- Vào <WORKER_URL>/admin.
- Tài khoản mới: pending.
- Chọn active để duyệt.
- suspended = khóa user.
- Max máy = số máy user được phép dùng.
- Hết hạn = yyyy-mm-dd hoặc để trống.
- Thu hồi máy làm session của máy đó mất hiệu lực.
- Có thể Kích hoạt lại thiết bị đã thu hồi.

BẢO MẬT
- Mật khẩu user: PBKDF2-SHA256 + salt riêng + PASSWORD_PEPPER secret.
- Session chỉ lưu SHA-256 hash trong D1.
- ADMIN_PASSWORD, PASSWORD_PEPPER, ADMIN_ACTION_KEY, Google secret nằm trong Cloudflare Secrets, không đặt trong source.
- Windows vẫn có Native License Gate và có thể khóa TrustedAuthHost vào hostname workers.dev sau khi script setup chạy.
- Mac Intel có Account UI + Bridge gate như V148.0; native DPVServer gốc không có source nên lớp hardening native chưa bằng Windows.

LƯU Ý QUAN TRỌNG
- Chỉ chạy SETUP_FIRST_TIME_* một lần cho server mới. Không tự thay PASSWORD_PEPPER sau khi đã có user, nếu không mật khẩu cũ sẽ không xác minh được.
- Khi sửa Worker về sau, dùng REDEPLOY_WINDOWS.ps1 hoặc REDEPLOY_MAC.command.
- Không gửi ADMIN_PASSWORD, Google Client Secret hoặc Cloudflare API token cho người dùng DPV.


XEM THEM: ../DPV_CLOUDFLARE_FREE/README_VI.txt
