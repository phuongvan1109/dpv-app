DPV V113 — STABLE FILE DIALOGS (WINDOWS)
- PON: native OpenFileDialog + chống click lặp.
- Chọn nhiều file nguồn: native multi-select + chống click lặp.
- CSV/TXT: native OpenFileDialog + UTF-8 + chống click lặp.
- Thư mục xuất: modern Windows folder picker + fallback FolderBrowserDialog + chống click lặp.
- Combine PDF: native multi-select/Save dialog + chống click lặp.
- Core V101 STABLE giữ nguyên.
